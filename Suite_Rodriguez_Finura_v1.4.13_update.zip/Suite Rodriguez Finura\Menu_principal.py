import os
import sys
import json
import ctypes
import importlib
import importlib.util
import platform
import threading
import tkinter as tk
import unicodedata
from tkinter import messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_MENU_APPS as SUITE_PAD_MENU_APPS,
    PAD_MENU_INFO as SUITE_PAD_MENU_INFO,
    PAD_TARJETA_MENU as SUITE_PAD_TARJETA_MENU,
    alternar_modo_oscuro as suite_alternar_modo_oscuro,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_modo_compacto_ventana as suite_aplicar_modo_compacto_ventana,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    obtener_paleta as suite_obtener_paleta,
    obtener_preferencia as suite_obtener_preferencia,
    obtener_tema_actual as suite_obtener_tema_actual,
    establecer_preferencia as suite_establecer_preferencia,
    refrescar_tema_ventana as suite_refrescar_tema_ventana,
)


try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


UI_GAP = 12
UI_PANEL_PAD = (12, 12)
UI_CARD_PAD = (15, 14)
UI_CARD_GAP = 8
UI_CARD_BORDER_CLARO = "#D7E3F2"
UI_CARD_BORDER_OSCURO = "#3A4A5F"
UI_RADIUS_PANEL = 14
UI_RADIUS_CARD = 12
UI_RADIUS_ROW = 10


def normalizar_texto_busqueda(texto):
    texto = unicodedata.normalize("NFD", str(texto or ""))
    texto = "".join(caracter for caracter in texto if unicodedata.category(caracter) != "Mn")
    return " ".join(texto.lower().split())


class Tooltip:
    def __init__(self, widget, texto):
        self.widget = widget
        self.texto = texto
        self.ventana = None
        widget.bind("<Enter>", self.mostrar, add="+")
        widget.bind("<Leave>", self.ocultar, add="+")
        widget.bind("<FocusIn>", self.mostrar, add="+")
        widget.bind("<FocusOut>", self.ocultar, add="+")

    def mostrar(self, _event=None):
        if self.ventana or not self.texto:
            return
        try:
            x = self.widget.winfo_rootx() + 16
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 8
            self.ventana = tk.Toplevel(self.widget)
            self.ventana.wm_overrideredirect(True)
            self.ventana.wm_geometry(f"+{x}+{y}")
            etiqueta = tk.Label(
                self.ventana,
                text=self.texto,
                background="#111827",
                foreground="#FFFFFF",
                borderwidth=0,
                padx=8,
                pady=5,
                font=("Segoe UI", 9),
            )
            etiqueta.pack()
        except Exception:
            self.ventana = None

    def ocultar(self, _event=None):
        if self.ventana is not None:
            try:
                self.ventana.destroy()
            except Exception:
                pass
            self.ventana = None

    def actualizar(self, texto):
        self.texto = texto
        self.ocultar()


class RoundedPanel(tk.Frame):
    def __init__(
        self,
        padre,
        *,
        fill,
        border,
        parent_bg,
        radius=12,
        border_width=1,
        padding=(12, 12),
        focus_border=None,
        hover_border=None,
        pressed_border=None,
        hover_enabled=True,
    ):
        super().__init__(padre, bg=parent_bg, highlightthickness=0, bd=0)
        self.fill = fill
        self.border = border
        self.parent_bg = parent_bg
        self.radius = radius
        self.border_width = border_width
        self.focus_border = focus_border or border
        self.hover_border = hover_border or border
        self.pressed_border = pressed_border or self.hover_border
        self.hover_enabled = bool(hover_enabled)
        self.padding = padding if isinstance(padding, tuple) else (padding, padding)
        if len(self.padding) == 2:
            self.padx = self.padding[0]
            self.pady = self.padding[1]
        else:
            self.padx = self.padding[0]
            self.pady = self.padding[1]
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=parent_bg, takefocus=0)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=fill, highlightthickness=0, bd=0)
        self._window = self.canvas.create_window(self.padx, self.pady, window=self.body, anchor="nw")
        self._focused = False
        self._keyboard_focus_requested = False
        self._hovered = False
        self._pressed = False
        self._last_draw_state = None
        self._size_after_id = None
        self._hover_clear_after_id = None
        self.canvas.bind("<Configure>", self._redraw)
        self.body.bind("<Configure>", self._sync_requested_size)
        self.canvas.bind("<FocusIn>", self._focus_in)
        self.canvas.bind("<FocusOut>", self._focus_out)
        if self.hover_enabled:
            self.canvas.bind("<Enter>", self._mouse_enter)
            self.canvas.bind("<Leave>", self._mouse_leave)
            self.body.bind("<Enter>", self._mouse_enter, add="+")
            self.body.bind("<Leave>", self._mouse_leave, add="+")
            self.canvas.bind("<ButtonPress-1>", self._mouse_press, add="+")
            self.canvas.bind("<ButtonRelease-1>", self._mouse_release, add="+")

    def enable_focus(self):
        self.canvas.configure(takefocus=1)

    def focus_keyboard(self):
        self._keyboard_focus_requested = True
        self._focused = True
        try:
            self.canvas.focus_set()
        except Exception:
            pass
        self._redraw(force=True)

    def clear_keyboard_focus(self):
        self._keyboard_focus_requested = False
        self._focused = False
        self._redraw(force=True)

    def configure_visual(self, *, fill=None, border=None, parent_bg=None, focus_border=None, hover_border=None, pressed_border=None):
        cambiado = False
        if fill is not None and fill != self.fill:
            self.fill = fill
            self.body.configure(bg=fill)
            cambiado = True
        if border is not None and border != self.border:
            self.border = border
            cambiado = True
        if parent_bg is not None and parent_bg != self.parent_bg:
            self.parent_bg = parent_bg
            self.configure(bg=parent_bg)
            self.canvas.configure(bg=parent_bg)
            cambiado = True
        if focus_border is not None and focus_border != self.focus_border:
            self.focus_border = focus_border
            cambiado = True
        if hover_border is not None and hover_border != self.hover_border:
            self.hover_border = hover_border
            cambiado = True
        if pressed_border is not None and pressed_border != self.pressed_border:
            self.pressed_border = pressed_border
            cambiado = True
        if cambiado:
            self._last_draw_state = None
            self._redraw(force=True)

    def _sync_requested_size(self, _event=None):
        if self._size_after_id is not None:
            return
        try:
            self._size_after_id = self.after_idle(self._sync_requested_size_now)
        except Exception:
            self._size_after_id = None

    def _sync_requested_size_now(self):
        self._size_after_id = None
        try:
            req_w = self.body.winfo_reqwidth() + self.padx * 2
            req_h = self.body.winfo_reqheight() + self.pady * 2
            if self.canvas.cget("width") != str(req_w) or self.canvas.cget("height") != str(req_h):
                self.canvas.configure(width=req_w, height=req_h)
            self._redraw(force=True)
        except Exception:
            pass

    def _focus_in(self, _event=None):
        self._focused = bool(self._keyboard_focus_requested)
        self._redraw(force=True)

    def _focus_out(self, _event=None):
        self._focused = False
        self._keyboard_focus_requested = False
        self._redraw(force=True)

    def _mouse_enter(self, _event=None):
        if not self.hover_enabled:
            return
        if self._hover_clear_after_id is not None:
            try:
                self.after_cancel(self._hover_clear_after_id)
            except Exception:
                pass
            self._hover_clear_after_id = None
        self._hovered = True
        self._redraw(force=True)

    def _mouse_leave(self, _event=None):
        if not self.hover_enabled:
            return
        if self._hover_clear_after_id is not None:
            return
        try:
            self._hover_clear_after_id = self.after(45, self._clear_hover_if_pointer_outside)
        except Exception:
            self._hover_clear_after_id = None
            self._clear_hover_if_pointer_outside()

    def _clear_hover_if_pointer_outside(self):
        self._hover_clear_after_id = None
        if self._pointer_inside():
            return
        self._hovered = False
        self._pressed = False
        self._focused = False
        self._keyboard_focus_requested = False
        self._redraw(force=True)

    def _mouse_press(self, _event=None):
        if not self.hover_enabled:
            return
        self._pressed = True
        self._focused = False
        self._keyboard_focus_requested = False
        self._redraw(force=True)

    def _mouse_release(self, _event=None):
        if not self.hover_enabled:
            return
        self._pressed = False
        if not self._pointer_inside():
            self._hovered = False
        self._redraw(force=True)

    def _pointer_inside(self):
        try:
            x = self.winfo_pointerx()
            y = self.winfo_pointery()
            left = self.winfo_rootx()
            top = self.winfo_rooty()
            return left <= x < left + self.winfo_width() and top <= y < top + self.winfo_height()
        except Exception:
            return False

    def _round_points(self, x1, y1, x2, y2, r):
        return [
            x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
            x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
            x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
        ]

    def _redraw(self, _event=None, force=False):
        try:
            w = max(2, self.canvas.winfo_width())
            h = max(2, self.canvas.winfo_height())
            if self._pressed:
                color_borde = self.pressed_border
            elif self._focused:
                color_borde = self.focus_border
            elif self._hovered:
                color_borde = self.hover_border
            else:
                color_borde = self.border
            estado = (w, h, self.fill, color_borde, self.border_width, self.radius)
            if not force and estado == self._last_draw_state:
                return
            self._last_draw_state = estado
            self.canvas.delete("panel")
            puntos = self._round_points(
                self.border_width,
                self.border_width,
                w - self.border_width,
                h - self.border_width,
                min(self.radius, max(2, min(w, h) // 2)),
            )
            self.canvas.create_polygon(
                puntos,
                fill=self.fill,
                outline=color_borde,
                width=self.border_width,
                smooth=True,
                tags="panel",
            )
            self.canvas.tag_lower("panel")
            self.canvas.coords(self._window, self.padx, self.pady)
            self.canvas.itemconfigure(
                self._window,
                width=max(1, w - self.padx * 2),
                height=max(1, h - self.pady * 2),
            )
        except Exception:
            pass

def modulo_disponible(nombre_modulo):
    """Comprueba disponibilidad sin importar dependencias pesadas al arrancar."""
    try:
        return importlib.util.find_spec(nombre_modulo) is not None
    except Exception:
        return False


def cargar_atributo(nombre_modulo, nombre_atributo):
    """Importa una aplicacion bajo demanda y devuelve el atributo solicitado."""
    modulo = importlib.import_module(nombre_modulo)
    return getattr(modulo, nombre_atributo)


def ruta_recurso(nombre):
    """Devuelve la ruta correcta de los recursos en modo .py y en empaquetados PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def obtener_version_local():
    """Lee la version instalada sin romper el arranque si falta el JSON."""
    try:
        import json

        with open(ruta_recurso("version_local.json"), "r", encoding="utf-8-sig") as f:
            datos = json.load(f)
        return str(datos.get("version", "")).strip() or "desconocida"
    except Exception:
        return "desconocida"


def carpeta_logs():
    base = os.environ.get("LOCALAPPDATA") or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, "Suite Rodriguez Finura", "logs")


def leer_json_seguro(ruta):
    try:
        with open(ruta, "r", encoding="utf-8-sig") as f:
            datos = json.load(f)
        return datos if isinstance(datos, dict) else {}
    except Exception:
        return {}


def leer_estado_actualizador():
    return leer_json_seguro(os.path.join(carpeta_logs(), "update_status.json"))


def cola_archivo(ruta, lineas=40):
    try:
        with open(ruta, "r", encoding="utf-8-sig", errors="replace") as f:
            contenido = f.readlines()
        return "".join(contenido[-lineas:]).strip()
    except Exception:
        return ""


def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("EmbutidosRodriguez.SuiteFinura")
    except Exception:
        pass
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class MenuPrincipal:
    def __init__(self, ventana):
        self.ventana = ventana
        try:
            self.ventana.withdraw()
        except Exception:
            pass
        suite_configurar_ventana_base(self.ventana, "Suite de Aplicaciones Rodriguez / Finura")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)
        self.ventanas_abiertas = {}
        self.widgets_apps = {}
        self.botones_categoria = {}
        self._after_estado_id = None
        self._estado_aplicaciones_cache = None

        self.logo_izq = None
        self.logo_der = None

        self.modo_compacto = False
        self._scroll_global_compacto_activo = False
        self._vista_previa_compacto = None
        self._categoria_previa_compacto = None
        self._render_menu_after_id = None
        self._scroll_after_id = None
        self._widgets_renderizados = []
        self._componentes_apps = {}
        self._componentes_secciones = {}
        self._componentes_categorias = {}
        self._widgets_scroll_vinculados = set()
        self._etiqueta_sin_resultados = None
        self.configurar_estilos()
        self.busqueda_var = tk.StringVar(value="")
        self.categoria_actual = "Todas"
        self.vista_actual = "tarjetas"
        self.apps_catalogo = self.crear_catalogo_apps()
        self.aplicar_favoritos_usuario()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()
        if bool(suite_obtener_preferencia("modo_compacto", False)):
            self.alternar_modo_compacto()
        else:
            self._sincronizar_canvas_tema()
            self.renderizar_categorias()
            self.renderizar_menu()
        self._mostrar_ventana_inicial()
        self.actualizar_estado_aplicaciones_periodico()

    def _mostrar_ventana_inicial(self):
        """Muestra el menu cuando el primer layout ya esta compuesto."""
        try:
            self.ventana.update_idletasks()
            if not self.modo_compacto:
                self.ventana.state("zoomed")
            self.ventana.deiconify()
            self.ventana.update_idletasks()
        except Exception:
            try:
                self.ventana.deiconify()
            except Exception:
                pass

    def configurar_estilos(self):
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)
        paleta = suite_obtener_paleta()
        self.style.configure("TFrame", background=paleta["fondo"])
        self.style.configure("Card.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure("Shell.TFrame", background=paleta["fondo"])
        card_border = UI_CARD_BORDER_OSCURO if suite_obtener_tema_actual() == "oscuro" else UI_CARD_BORDER_CLARO
        hover_border = paleta.get("borde_hover", paleta["boton_sec_border"])
        self.style.configure(
            "Header.TFrame",
            background=paleta["tarjeta"],
            relief="solid",
            borderwidth=1,
            bordercolor=paleta["borde"],
        )
        self.style.configure(
            "Sidebar.TFrame",
            background=paleta["estado"],
            relief="solid",
            borderwidth=1,
            bordercolor=paleta["borde"],
        )
        self.style.configure("SidebarInner.TFrame", background=paleta["estado"])
        self.style.configure("Content.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure(
            "CenterPanel.TFrame",
            background=paleta["tarjeta"],
            relief="solid",
            borderwidth=1,
            bordercolor=paleta["borde"],
        )
        self.style.configure("CardBody.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure(
            "SoftCard.TFrame",
            background=paleta["tarjeta"],
            relief="solid",
            borderwidth=1,
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        self.style.configure(
            "SoftRow.TFrame",
            background=paleta["tarjeta"],
            relief="solid",
            borderwidth=1,
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        self.style.configure("Footer.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure(
            "HeroTitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["principal"],
            font=("Segoe UI", 17, "bold"),
        )
        self.style.configure(
            "HeroSubtitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["muted"],
            font=("Segoe UI", 10, "normal"),
        )
        self.style.configure(
            "BrandBadge.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Segoe UI", 13, "bold"),
            padding=(10, 9),
        )
        self.style.configure(
            "SectionTitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["texto"],
            font=("Segoe UI", 12, "bold"),
        )
        self.style.configure(
            "CardTitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["principal"],
            font=("Segoe UI", 11, "bold"),
        )
        self.style.configure(
            "Card.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["texto"],
            font=("Segoe UI", 10, "normal"),
        )
        self.style.configure(
            "Muted.Card.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["muted"],
            font=("Segoe UI", 9, "normal"),
        )
        self.style.configure(
            "SidebarTitle.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Segoe UI", 10, "bold"),
        )
        self.style.configure(
            "Chip.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Segoe UI", 9, "bold"),
            padding=(10, 4),
        )
        self.style.configure(
            "SuccessChip.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Segoe UI", 9, "bold"),
            padding=(10, 4),
        )
        self.style.configure(
            "Category.TFrame",
            background=paleta["estado"],
            relief="flat",
            borderwidth=0,
        )
        self.style.configure(
            "Category.Active.TFrame",
            background=paleta["principal"],
            relief="flat",
            borderwidth=0,
        )
        self.style.configure(
            "Category.TLabel",
            background=paleta["estado"],
            foreground=paleta["texto"],
            font=("Segoe UI", 10, "normal"),
        )
        self.style.configure(
            "Category.Active.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Segoe UI", 10, "bold"),
        )
        self.style.configure(
            "Category.Count.TLabel",
            background=paleta["estado"],
            foreground=paleta["muted"],
            font=("Segoe UI", 9, "normal"),
        )
        self.style.configure(
            "Category.Count.Active.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Segoe UI", 9, "bold"),
        )
        self.style.configure(
            "Favorite.TButton",
            font=("Segoe UI", 10, "bold"),
            padding=(3, 2),
            foreground=paleta["rodriguez"],
            background=paleta["boton_sec"],
            borderwidth=1,
            relief="solid",
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        for estilo_boton in ("Primary.TButton", "Secondary.TButton", "Danger.TButton"):
            self.style.configure(estilo_boton, font=("Segoe UI", 10, "bold"))
        self.style.configure(
            "Secondary.TButton",
            borderwidth=1,
            relief="solid",
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        self.style.configure(
            "Danger.TButton",
            borderwidth=1,
            relief="solid",
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        self.style.map(
            "Secondary.TButton",
            bordercolor=[("disabled", paleta["disabled_bg"]), ("focus", hover_border), ("pressed", paleta["principal_hover"]), ("active", hover_border)],
        )
        self.style.map(
            "Danger.TButton",
            bordercolor=[("disabled", paleta["disabled_bg"]), ("focus", hover_border), ("pressed", paleta["principal_hover"]), ("active", hover_border)],
        )
        self.style.map(
            "Favorite.TButton",
            foreground=[("active", paleta["rodriguez"]), ("!disabled", paleta["rodriguez"])],
            background=[("active", paleta["boton_sec_active"]), ("pressed", paleta["boton_sec_active"])],
            bordercolor=[("focus", hover_border), ("pressed", paleta["principal_hover"]), ("active", hover_border), ("!disabled", card_border)],
        )
        self.style.configure(
            "Compact.Primary.TButton",
            font=("Segoe UI", 9, "bold"),
            padding=(3, 2),
            foreground=paleta["principal_fg"],
            background=paleta["principal"],
            bordercolor=paleta["principal"],
        )
        self.style.map(
            "Compact.Primary.TButton",
            background=[("active", paleta["principal_hover"]), ("pressed", paleta["principal_hover"])],
            foreground=[("!disabled", paleta["principal_fg"]), ("disabled", paleta["disabled_fg"])],
        )
        self.style.configure(
            "Compact.Secondary.TButton",
            font=("Segoe UI", 9, "bold"),
            padding=(2, 2),
            foreground=paleta["rodriguez"],
            background=paleta["boton_sec"],
            borderwidth=1,
            relief="solid",
            bordercolor=card_border,
            lightcolor=card_border,
            darkcolor=card_border,
        )
        self.style.map(
            "Compact.Secondary.TButton",
            foreground=[("active", paleta["rodriguez"]), ("!disabled", paleta["rodriguez"])],
            background=[("active", paleta["boton_sec_active"]), ("pressed", paleta["boton_sec_active"])],
            bordercolor=[("focus", hover_border), ("pressed", paleta["principal_hover"]), ("active", hover_border), ("!disabled", card_border)],
        )

    def crear_panel_redondeado(
        self,
        padre,
        *,
        tipo="panel",
        fill=None,
        border=None,
        parent_bg=None,
        padding=UI_PANEL_PAD,
        radius=None,
        focus=False,
    ):
        paleta = suite_obtener_paleta()
        fill = fill or paleta["tarjeta"]
        parent_bg = parent_bg or paleta["fondo"]
        if border is None:
            border = paleta["borde"] if tipo == "panel" else (
                UI_CARD_BORDER_OSCURO if suite_obtener_tema_actual() == "oscuro" else UI_CARD_BORDER_CLARO
            )
        radius = radius if radius is not None else (UI_RADIUS_PANEL if tipo == "panel" else UI_RADIUS_CARD)
        panel = RoundedPanel(
            padre,
            fill=fill,
            border=border,
            parent_bg=parent_bg,
            radius=radius,
            border_width=1,
            padding=padding,
            focus_border=paleta["focus"],
            hover_border=paleta["boton_sec_border"],
            pressed_border=paleta["principal_hover"],
            hover_enabled=(tipo == "card"),
        )
        if focus:
            panel.enable_focus()
        return panel

    def vincular_click_tree(self, widget, comando):
        try:
            widget.configure(cursor="hand2")
            widget.bind("<Button-1>", comando, add="+")
            widget.bind("<Return>", comando, add="+")
            widget.bind("<space>", comando, add="+")
            for hijo in widget.winfo_children():
                self.vincular_click_tree(hijo, comando)
        except Exception:
            pass

    def crear_catalogo_apps(self):
        return [
            {
                "clave": "merma",
                "titulo": "Merma Jamones FAC",
                "descripcion": "Cruza CSV finales con fichero origen y genera el Excel de resultado.",
                "descripcion_compacta": "CSV origen a Excel.",
                "categoria": "Jamones",
                "etiquetas": "merma jamones fac csv origen excel",
                "iniciales": "MJ",
                "atajo": "Alt+1",
                "favorita": True,
                "comando": self.abrir_merma,
                "disponible": lambda: modulo_disponible("programa_mermas"),
            },
            {
                "clave": "txt_csv",
                "titulo": "Procesador TXT a CSV",
                "descripcion": "Carga TXT, normaliza decimales y guarda el CSV final.",
                "descripcion_compacta": "TXT normalizado a CSV.",
                "categoria": "Excel / CSV",
                "etiquetas": "txt csv texto normalizar decimales conversion",
                "iniciales": "TC",
                "atajo": "Alt+2",
                "favorita": False,
                "comando": self.abrir_txt_csv,
                "disponible": lambda: modulo_disponible("FusionarCSV_mejorado"),
            },
            {
                "clave": "palets",
                "titulo": "Palets PDA a CSV",
                "descripcion": "Valida codigos de pallet de PDA, permite correcciones y genera Stock01.csv.",
                "descripcion_compacta": "Valida palets y Stock01.csv.",
                "categoria": "Palets y PDA",
                "etiquetas": "palets pallet pda stock01 csv validacion correcciones",
                "iniciales": "PA",
                "atajo": "Alt+3",
                "favorita": True,
                "comando": self.abrir_palets,
                "disponible": lambda: modulo_disponible("ProcesadorPaletsGUI"),
            },
            {
                "clave": "precintos",
                "titulo": "Precintos Jamones",
                "descripcion": "Valida precintos, GTIN-12 para iberico, duplicados, oficial y correo.",
                "descripcion_compacta": "Valida precintos y TXT/CSV.",
                "categoria": "Jamones",
                "etiquetas": "precintos jamones iberico gtin oficial duplicados correo txt csv",
                "iniciales": "PJ",
                "atajo": "Alt+4",
                "favorita": True,
                "comando": self.abrir_precintos,
                "disponible": lambda: modulo_disponible("ControlPrecintosJamonesGUI"),
            },
            {
                "clave": "exportar_precintos",
                "titulo": "Precintos Excel a CSV",
                "descripcion": "Extrae la columna Identificacion de Excel y genera .csv.",
                "descripcion_compacta": "Identificaciones Excel a CSV.",
                "categoria": "Excel / CSV",
                "etiquetas": "precintos excel identificacion trazabilidad csv anexos",
                "iniciales": "EC",
                "atajo": "Alt+5",
                "favorita": True,
                "comando": self.abrir_exportar_precintos,
                "disponible": lambda: modulo_disponible("ExportarPrecintosExcelGUI"),
            },
        ]

    def favoritos_por_defecto(self):
        return [app["clave"] for app in self.apps_catalogo if app.get("favorita")]

    def aplicar_favoritos_usuario(self):
        favoritos = suite_obtener_preferencia("favoritos_menu", None)
        if not isinstance(favoritos, list):
            favoritos = self.favoritos_por_defecto()
        favoritos = set(str(clave) for clave in favoritos)
        for app in self.apps_catalogo:
            app["favorita"] = app["clave"] in favoritos

    def guardar_favoritos_usuario(self):
        favoritos = [app["clave"] for app in self.apps_catalogo if app.get("favorita")]
        suite_establecer_preferencia("favoritos_menu", favoritos)

    def recientes_usuario(self):
        recientes = suite_obtener_preferencia("recientes_menu", [])
        return recientes if isinstance(recientes, list) else []

    def registrar_uso_app(self, clave):
        recientes = [item for item in self.recientes_usuario() if item != clave]
        recientes.insert(0, clave)
        suite_establecer_preferencia("recientes_menu", recientes[:6])

    def apps_destacadas(self):
        destacadas = []
        claves = set()
        for app in self.apps_catalogo:
            if app.get("favorita"):
                destacadas.append(app)
                claves.add(app["clave"])
        por_clave = {app["clave"]: app for app in self.apps_catalogo}
        for clave in self.recientes_usuario():
            app = por_clave.get(str(clave))
            if app is not None and app["clave"] not in claves:
                destacadas.append(app)
                claves.add(app["clave"])
        return destacadas

    def alternar_favorito(self, app):
        app["favorita"] = not bool(app.get("favorita"))
        self.guardar_favoritos_usuario()
        if self.categoria_actual == "Favoritas" and not app["favorita"]:
            restantes = self.apps_por_categoria("Favoritas")
            if not restantes:
                self.categoria_actual = "Todas"
        self.renderizar_categorias()
        self.solicitar_render_menu()

    def crear_interfaz(self):
        paleta = suite_obtener_paleta()
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(1, weight=1)

        self.cabecera = self.crear_panel_redondeado(
            self.ventana,
            tipo="panel",
            fill=paleta["tarjeta"],
            parent_bg=paleta["fondo"],
            padding=(18, 14),
            radius=UI_RADIUS_PANEL,
        )
        self.cabecera.grid(row=0, column=0, sticky="ew", padx=UI_GAP, pady=(UI_GAP, 0))
        cabecera = self.cabecera.body
        cabecera.columnconfigure(1, weight=1)

        self.badge_sr = ttk.Label(
            cabecera,
            text="SR",
            style="BrandBadge.TLabel",
            anchor="center",
        )
        self.badge_sr.grid(row=0, column=0, rowspan=2, sticky="nsw", padx=(0, 12))

        self.lbl_titulo = ttk.Label(
            cabecera,
            text="Suite de Aplicaciones",
            style="HeroTitle.TLabel",
            anchor="w",
        )
        self.lbl_titulo.grid(row=0, column=1, sticky="ew")

        self.lbl_subtitulo = ttk.Label(
            cabecera,
            text="Menu principal unificado para Rodriguez / Finura",
            style="HeroSubtitle.TLabel",
            anchor="w",
        )
        self.lbl_subtitulo.grid(row=1, column=1, sticky="ew", pady=(3, 0))
        self.linea_cabecera = ttk.Frame(cabecera, style="RedLine.TFrame", height=2)
        self.linea_cabecera.grid(row=2, column=0, columnspan=6, sticky="ew", pady=(14, 0))

        self.boton_compacto = ttk.Button(
            cabecera,
            text="Compacto",
            command=self.alternar_modo_compacto,
            style="Secondary.TButton",
        )
        self.boton_compacto.grid(row=0, column=2, rowspan=2, sticky="e", padx=(16, 0))
        self.boton_tema = ttk.Button(
            cabecera,
            text="Modo claro" if suite_obtener_tema_actual() == "oscuro" else "Modo oscuro",
            command=self.alternar_tema_visual,
            style="Secondary.TButton",
        )
        self.boton_tema.grid(row=0, column=3, rowspan=2, sticky="e", padx=(8, 0))
        self.boton_acerca = ttk.Button(
            cabecera,
            text="Acerca de",
            command=self.abrir_acerca_version,
            style="Secondary.TButton",
        )
        self.boton_acerca.grid(row=0, column=4, rowspan=2, sticky="e", padx=(8, 0))
        self.boton_salir_header = ttk.Button(
            cabecera,
            text="Salir",
            command=self.salir,
            style="Primary.TButton",
        )
        self.boton_salir_header.grid(row=0, column=5, rowspan=2, sticky="e", padx=(8, 0))

        self.contenedor = ttk.Frame(self.ventana, style="Shell.TFrame")
        contenedor = self.contenedor
        contenedor.grid(row=1, column=0, sticky="nsew", padx=UI_GAP, pady=(UI_GAP, UI_GAP))
        contenedor.columnconfigure(0, weight=0, minsize=250)
        contenedor.columnconfigure(1, weight=1)
        contenedor.rowconfigure(0, weight=1)

        self.sidebar_panel = self.crear_panel_redondeado(
            contenedor,
            tipo="panel",
            fill=paleta["estado"],
            parent_bg=paleta["fondo"],
            padding=UI_PANEL_PAD,
            radius=UI_RADIUS_PANEL,
        )
        self.sidebar_panel.grid(row=0, column=0, sticky="nsew", padx=(0, UI_GAP))
        self.sidebar = self.sidebar_panel.body
        self.sidebar.columnconfigure(0, weight=1)

        ttk.Label(self.sidebar, text="Categorias", style="SidebarTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.panel_categorias = ttk.Frame(self.sidebar, style="SidebarInner.TFrame")
        self.panel_categorias.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        self.panel_categorias.columnconfigure(0, weight=1)

        self.sidebar.rowconfigure(2, weight=1)
        self.lbl_version_sidebar = ttk.Label(
            self.sidebar,
            text=f"v{obtener_version_local()} instalada",
            style="Chip.TLabel",
            anchor="center",
        )
        self.lbl_version_sidebar.grid(row=3, column=0, sticky="ew", pady=(12, 8))

        self.panel_apps_area_panel = self.crear_panel_redondeado(
            contenedor,
            tipo="panel",
            fill=paleta["tarjeta"],
            parent_bg=paleta["fondo"],
            padding=UI_PANEL_PAD,
            radius=UI_RADIUS_PANEL,
        )
        self.panel_apps_area_panel.grid(row=0, column=1, sticky="nsew")
        self.panel_apps_area = self.panel_apps_area_panel.body
        self.panel_apps_area.columnconfigure(0, weight=1)
        self.panel_apps_area.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self.panel_apps_area, style="Content.TFrame", padding=(0, 0, 0, UI_GAP))
        toolbar.grid(row=0, column=0, sticky="ew")
        toolbar.columnconfigure(0, weight=1)
        self.placeholder_busqueda = "Buscar aplicacion, fichero o tarea... ejemplo: precintos"
        self._placeholder_busqueda_activo = False
        self.entry_busqueda = ttk.Entry(toolbar, textvariable=self.busqueda_var)
        self.entry_busqueda.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.entry_busqueda.configure(font=("Segoe UI", 12))
        self.entry_busqueda.bind("<FocusIn>", self._limpiar_placeholder_busqueda, add="+")
        self.entry_busqueda.bind("<FocusOut>", self._restaurar_placeholder_busqueda, add="+")
        self.boton_limpiar_busqueda = ttk.Button(
            toolbar,
            text="Limpiar",
            command=self.limpiar_busqueda,
            style="Secondary.TButton",
        )
        self.boton_limpiar_busqueda.grid(row=0, column=1, sticky="e", padx=(0, 10))
        self.lbl_resultados = ttk.Label(toolbar, text="", style="Chip.TLabel", anchor="center")
        self.lbl_resultados.grid(row=0, column=2, sticky="e")

        self.canvas_apps = tk.Canvas(self.panel_apps_area, highlightthickness=0, bd=0, bg=paleta["tarjeta"])
        self.canvas_apps.grid(row=1, column=0, sticky="nsew")
        self.scroll_apps = ttk.Scrollbar(self.panel_apps_area, orient="vertical", command=self.canvas_apps.yview)
        self.scroll_apps.grid(row=1, column=1, sticky="ns")
        self._scroll_apps_visible = True
        self.canvas_apps.configure(yscrollcommand=self._scroll_apps_set)

        self.panel_apps = ttk.Frame(self.canvas_apps, style="Content.TFrame", padding=UI_PANEL_PAD)
        panel_apps = self.panel_apps
        self.panel_apps_window = self.canvas_apps.create_window((0, 0), window=panel_apps, anchor="nw")
        self.panel_apps.bind("<Configure>", self._actualizar_scroll_apps)
        self.canvas_apps.bind("<Configure>", self._ajustar_ancho_panel_apps)
        self.canvas_apps.bind("<MouseWheel>", self._scroll_apps_mousewheel)
        self.canvas_apps.bind("<Button-4>", self._scroll_apps_mousewheel)
        self.canvas_apps.bind("<Button-5>", self._scroll_apps_mousewheel)
        self._restaurar_placeholder_busqueda()
        self.busqueda_var.trace_add("write", lambda *_args: self.solicitar_render_menu())

        self.barra_estado = ttk.Frame(self.ventana, style="TFrame")
        self.etiqueta_estado = ttk.Label(
            self.barra_estado,
            text="Listo para abrir una aplicacion",
            style="Status.TLabel",
            anchor="center",
        )

        self.footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer = self.footer
        footer.grid(row=2, column=0, sticky="ew", padx=UI_GAP, pady=(0, UI_GAP))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)

        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")

        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")


    def alternar_tema_visual(self):
        """Alterna claro/oscuro desde el modulo comun de estilo."""
        nuevo = suite_alternar_modo_oscuro(self.ventana)
        suite_refrescar_tema_ventana(self.ventana)
        self.configurar_estilos()
        for _clave, (_titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    suite_refrescar_tema_ventana(ventana_app)
            except Exception:
                pass
        self.boton_tema.configure(text="Modo claro" if nuevo == "oscuro" else "Modo oscuro")
        self.etiqueta_estado.configure(text=f"Tema visual aplicado: {nuevo}")
        self._sincronizar_canvas_tema()
        self.renderizar_categorias()
        self.solicitar_render_menu()

    def categorias_disponibles(self):
        categorias = ["Todas", "Favoritas"]
        for app in self.apps_catalogo:
            if app["categoria"] not in categorias:
                categorias.append(app["categoria"])
        return categorias

    def apps_por_categoria(self, categoria):
        if categoria == "Todas":
            return list(self.apps_catalogo)
        if categoria == "Favoritas":
            return [app for app in self.apps_catalogo if app.get("favorita")]
        return [app for app in self.apps_catalogo if app["categoria"] == categoria]

    def app_disponible(self, app):
        try:
            return bool(app["disponible"]())
        except Exception:
            return False

    def app_abierta(self, app):
        return app["clave"] in self.ventanas_abiertas

    def texto_estado_app(self, app):
        if self.app_abierta(app):
            return "Abierta"
        return "Disponible" if self.app_disponible(app) else "No disponible"

    def estilo_estado_app(self, app):
        if self.app_abierta(app) or self.app_disponible(app):
            return "Success.TLabel"
        return "Error.TLabel"

    def ejecutar_app(self, app):
        self.registrar_uso_app(app["clave"])
        app["comando"]()

    def filtrar_apps(self):
        texto = "" if self._placeholder_busqueda_activo else normalizar_texto_busqueda(self.busqueda_var.get())
        apps = self.apps_por_categoria(self.categoria_actual)
        if not texto:
            return apps
        terminos = texto.split()
        filtradas = []
        for app in apps:
            bloque = normalizar_texto_busqueda(
                " ".join(
                    [
                        app["titulo"],
                        app["descripcion"],
                        app["descripcion_compacta"],
                        app["categoria"],
                        app["iniciales"],
                        app.get("etiquetas", ""),
                    ]
                )
            )
            if all(termino in bloque for termino in terminos):
                filtradas.append(app)
        return filtradas

    def hay_busqueda_activa(self):
        return (not self._placeholder_busqueda_activo) and bool(self.busqueda_var.get().strip())

    def ordenar_apps_compacto(self, apps):
        return sorted(apps, key=lambda app: (not bool(app.get("favorita")), app["titulo"].lower()))

    def app_por_clave(self, clave):
        for app in self.apps_catalogo:
            if app["clave"] == clave:
                return app
        return None

    def ejecutar_app_por_clave(self, clave):
        app = self.app_por_clave(clave)
        if app is not None:
            self.ejecutar_app(app)

    def alternar_favorito_por_clave(self, clave):
        app = self.app_por_clave(clave)
        if app is not None:
            self.alternar_favorito(app)

    def solicitar_render_menu(self):
        if self._render_menu_after_id is not None:
            return
        try:
            self._render_menu_after_id = self.ventana.after_idle(self._renderizar_menu_programado)
        except Exception:
            self._render_menu_after_id = None
            self.renderizar_menu()

    def _renderizar_menu_programado(self):
        self._render_menu_after_id = None
        self.renderizar_menu()

    def renderizar_categorias(self):
        self.botones_categoria = {}
        paleta = suite_obtener_paleta()
        categorias = self.categorias_disponibles()
        visibles = set(categorias)
        for fila, categoria in enumerate(self.categorias_disponibles()):
            total = len(self.apps_por_categoria(categoria))
            activa = categoria == self.categoria_actual
            componente = self._obtener_componente_categoria(categoria)
            fila_cat_panel = componente["panel"]
            fila_cat_panel.configure_visual(
                fill=paleta["principal"] if activa else paleta["estado"],
                border=paleta["principal"] if activa else paleta["estado"],
                parent_bg=paleta["estado"],
                focus_border=paleta["focus"],
                hover_border=paleta["boton_sec_border"],
                pressed_border=paleta["principal_hover"],
            )
            fila_cat_panel.grid(row=fila, column=0, sticky="ew", pady=(0, 7))
            estilo_texto = "Category.Active.TLabel" if activa else "Category.TLabel"
            estilo_contador = "Category.Count.Active.TLabel" if activa else "Category.Count.TLabel"
            componente["indice"].configure(text=f"{fila + 1:02d}", style=estilo_texto)
            componente["nombre"].configure(text=categoria, style=estilo_texto)
            componente["total"].configure(text=str(total), style=estilo_contador)
            self.botones_categoria[categoria] = fila_cat_panel
        for categoria, componente in list(self._componentes_categorias.items()):
            if categoria not in visibles:
                componente["panel"].grid_remove()

    def _obtener_componente_categoria(self, categoria):
        componente = self._componentes_categorias.get(categoria)
        if componente is not None:
            return componente
        paleta = suite_obtener_paleta()
        fila_cat_panel = self.crear_panel_redondeado(
            self.panel_categorias,
            tipo="card",
            fill=paleta["estado"],
            border=paleta["estado"],
            parent_bg=paleta["estado"],
            padding=(10, 9),
            radius=10,
            focus=True,
        )
        fila_cat = fila_cat_panel.body
        fila_cat.columnconfigure(1, weight=1)
        lbl_indice = ttk.Label(fila_cat, style="Category.TLabel", anchor="w")
        lbl_indice.grid(row=0, column=0, sticky="w", padx=(0, 12))
        lbl_nombre = ttk.Label(fila_cat, style="Category.TLabel", anchor="w")
        lbl_nombre.grid(row=0, column=1, sticky="ew")
        lbl_total = ttk.Label(fila_cat, style="Category.Count.TLabel", anchor="e")
        lbl_total.grid(row=0, column=2, sticky="e", padx=(10, 0))
        self.vincular_click_tree(
            fila_cat_panel,
            lambda _event, c=categoria: self.seleccionar_categoria(c),
        )
        componente = {
            "panel": fila_cat_panel,
            "indice": lbl_indice,
            "nombre": lbl_nombre,
            "total": lbl_total,
        }
        self._componentes_categorias[categoria] = componente
        return componente

    def seleccionar_categoria(self, categoria):
        if categoria == self.categoria_actual:
            return
        self.categoria_actual = categoria
        self.renderizar_categorias()
        self.solicitar_render_menu()

    def cambiar_vista(self, vista):
        self.vista_actual = vista
        self.solicitar_render_menu()

    def aplicar_vista_temporal(self, vista):
        self.vista_actual = vista
        self.solicitar_render_menu()

    def limpiar_busqueda(self):
        self.busqueda_var.set("")
        self._restaurar_placeholder_busqueda()
        self.entry_busqueda.focus_set()

    def _limpiar_placeholder_busqueda(self, _event=None):
        if self._placeholder_busqueda_activo:
            self._placeholder_busqueda_activo = False
            self.busqueda_var.set("")

    def _restaurar_placeholder_busqueda(self, _event=None):
        if not self.busqueda_var.get().strip():
            self._placeholder_busqueda_activo = True
            self.busqueda_var.set(self.placeholder_busqueda)

    def limpiar_panel_apps(self):
        self.widgets_apps = {}
        self._widgets_renderizados = []
        self._widgets_antes_render = set(self.panel_apps.winfo_children())
        self._indice_seccion_render = 0
        for columna in range(4):
            self.panel_apps.columnconfigure(columna, weight=0, uniform="")

    def _registrar_widget_renderizado(self, widget):
        self._widgets_renderizados.append(widget)

    def finalizar_render_panel_apps(self):
        visibles = set(self._widgets_renderizados)
        for widget in getattr(self, "_widgets_antes_render", set()):
            if widget not in visibles:
                try:
                    widget.grid_remove()
                except Exception:
                    pass
        self._widgets_antes_render = set()

    def renderizar_menu(self):
        if not hasattr(self, "panel_apps"):
            return
        self.limpiar_panel_apps()
        apps = self.filtrar_apps()
        self.lbl_resultados.configure(text=f"{len(apps)} accesos")
        if self.modo_compacto:
            apps = self.ordenar_apps_compacto(apps)
            titulo = "Accesos compactos"
            if self.hay_busqueda_activa():
                titulo = "Resultados"
            self.crear_bloque_apps(0, titulo, apps, vista="compacta", limitar_columnas=False)
            self.finalizar_render_panel_apps()
            self.solicitar_actualizar_scroll_apps()
            self.vincular_scroll_widgets(self.panel_apps)
            return
        fila = 0
        if self.categoria_actual == "Todas" and not self.hay_busqueda_activa():
            destacadas = self.apps_destacadas()
            claves_destacadas = {app["clave"] for app in destacadas}
            if destacadas:
                fila = self.crear_bloque_apps(
                    fila,
                    "Favoritas y recientes",
                    destacadas,
                    vista="tarjetas",
                    limitar_columnas=True,
                )
            restantes = [app for app in apps if app["clave"] not in claves_destacadas]
            self.crear_bloque_apps(fila, "Todas las aplicaciones", restantes, vista="lista", limitar_columnas=False)
            self.finalizar_render_panel_apps()
            self.solicitar_actualizar_scroll_apps()
            self.vincular_scroll_widgets(self.panel_apps)
            return
        titulo = "Todas las aplicaciones" if self.categoria_actual == "Todas" else self.categoria_actual
        if self.hay_busqueda_activa():
            titulo = "Resultados de busqueda"
        vista = "lista" if self.hay_busqueda_activa() else "tarjetas"
        self.crear_bloque_apps(fila, titulo, apps, vista=vista, limitar_columnas=False)
        self.finalizar_render_panel_apps()
        self.solicitar_actualizar_scroll_apps()
        self.vincular_scroll_widgets(self.panel_apps)

    def crear_bloque_apps(self, fila_inicio, titulo, apps, vista, limitar_columnas=False):
        cabecera = self._obtener_componente_seccion()
        cabecera.grid(row=fila_inicio, column=0, columnspan=3, sticky="ew", pady=(0, 10))
        cabecera._titulo.configure(text=titulo)
        cabecera._contador.configure(text=f"{len(apps)} resultados" if apps else "0 resultados")
        self._registrar_widget_renderizado(cabecera)
        fila = fila_inicio + 1
        if not apps:
            if self._etiqueta_sin_resultados is None:
                self._etiqueta_sin_resultados = ttk.Label(
                    self.panel_apps,
                    text="No hay aplicaciones que coincidan con el filtro actual.",
                    style="Muted.Card.TLabel",
                    anchor="w",
                )
            self._etiqueta_sin_resultados.grid(row=fila, column=0, sticky="ew", pady=(0, 14))
            self._registrar_widget_renderizado(self._etiqueta_sin_resultados)
            return fila + 1
        if vista == "lista":
            for app in apps:
                self.crear_fila_app(self.panel_apps, fila, app)
                fila += 1
            return fila + 1
        if vista == "compacta":
            for app in apps:
                self.crear_fila_compacta(self.panel_apps, fila, app)
                fila += 1
            return fila + 1
        columnas = 3 if limitar_columnas else 3
        for col in range(columnas):
            self.panel_apps.columnconfigure(col, weight=1, uniform="apps")
        for indice, app in enumerate(apps):
            self.crear_tarjeta_app(self.panel_apps, fila + indice // columnas, indice % columnas, app)
        return fila + ((len(apps) + columnas - 1) // columnas) + 1

    def _obtener_componente_seccion(self):
        indice = getattr(self, "_indice_seccion_render", 0)
        self._indice_seccion_render = indice + 1
        cabecera = self._componentes_secciones.get(indice)
        if cabecera is not None:
            return cabecera
        cabecera = ttk.Frame(self.panel_apps, style="Content.TFrame")
        cabecera.columnconfigure(0, weight=1)
        cabecera._titulo = ttk.Label(cabecera, style="SectionTitle.TLabel", anchor="w")
        cabecera._titulo.grid(row=0, column=0, sticky="ew")
        cabecera._contador = ttk.Label(cabecera, style="Chip.TLabel", anchor="center")
        cabecera._contador.grid(row=0, column=1, sticky="e")
        self._componentes_secciones[indice] = cabecera
        return cabecera

    def crear_icono_app(self, padre, app):
        icono = ttk.Frame(padre, style="CardBody.TFrame")
        icono.columnconfigure(0, weight=1)
        caja = tk.Label(
            icono,
            text=app["iniciales"],
            font=("Arial", 11, "bold"),
            width=3,
            height=1,
            bd=1,
            relief="flat",
        )
        paleta = suite_obtener_paleta()
        caja.configure(
            bg=paleta["estado"],
            fg=paleta["principal"],
            highlightthickness=1,
            highlightbackground="#BFDBFE",
        )
        caja.grid(row=0, column=0, sticky="nsew")
        return icono

    def crear_tarjeta_app(self, padre, fila, columna, app):
        componente = self._obtener_componente_app("tarjeta", app)
        tarjeta_panel = componente["panel"]
        self._actualizar_componente_app(componente, app, "tarjeta")
        tarjeta_panel.grid(row=fila, column=columna, sticky="nsew", padx=UI_CARD_GAP, pady=UI_CARD_GAP)
        self._registrar_widget_renderizado(tarjeta_panel)

    def _crear_componente_tarjeta(self, padre, app):
        paleta = suite_obtener_paleta()
        tarjeta_panel = self.crear_panel_redondeado(
            padre,
            tipo="card",
            fill=paleta["tarjeta"],
            parent_bg=paleta["tarjeta"],
            padding=UI_CARD_PAD,
            radius=UI_RADIUS_CARD,
        )
        tarjeta = tarjeta_panel.body
        tarjeta.columnconfigure(0, weight=1)

        cabecera = ttk.Frame(tarjeta, style="CardBody.TFrame")
        cabecera.grid(row=0, column=0, sticky="ew")
        cabecera.columnconfigure(0, weight=1)
        lbl_titulo = ttk.Label(cabecera, style="CardTitle.TLabel", anchor="w")
        lbl_titulo.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        boton_favorito = ttk.Button(
            cabecera,
            command=lambda clave=app["clave"]: self.alternar_favorito_por_clave(clave),
            style="Favorite.TButton",
            width=3,
        )
        boton_favorito.grid(row=0, column=1, sticky="ne", padx=(0, 8))
        tooltip_favorito = Tooltip(boton_favorito, "")
        icono = self.crear_icono_app(cabecera, app)
        icono.grid(row=0, column=2, sticky="ne")

        descripcion = ttk.Label(
            tarjeta,
            style="Card.TLabel",
            anchor="w",
            justify="left",
            wraplength=300,
        )
        descripcion.grid(row=1, column=0, sticky="ew", pady=(8, 10))
        tarjeta.bind(
            "<Configure>",
            lambda event, label=descripcion: label.configure(wraplength=max(220, event.width - 28)),
            add="+",
        )

        chips = ttk.Frame(tarjeta, style="CardBody.TFrame")
        chips.grid(row=2, column=0, sticky="ew", pady=(0, 12))
        lbl_estado = ttk.Label(chips, style="SuccessChip.TLabel", anchor="w")
        lbl_estado.grid(row=0, column=0, sticky="w", padx=(0, 8))
        lbl_categoria = ttk.Label(chips, style="Chip.TLabel", anchor="w")
        lbl_categoria.grid(row=0, column=1, sticky="w")

        acciones = ttk.Frame(tarjeta, style="CardBody.TFrame")
        acciones.grid(row=3, column=0, sticky="ew")
        acciones.columnconfigure(1, weight=1)
        boton = ttk.Button(
            acciones,
            command=lambda clave=app["clave"]: self.ejecutar_app_por_clave(clave),
            style="Primary.TButton",
            width=8,
        )
        boton.grid(row=0, column=0, sticky="w", padx=(0, 8))
        lbl_atajo = ttk.Label(acciones, style="Muted.Card.TLabel", anchor="e")
        lbl_atajo.grid(row=0, column=2, sticky="e")
        return {
            "panel": tarjeta_panel,
            "titulo": lbl_titulo,
            "descripcion": descripcion,
            "estado": lbl_estado,
            "categoria": lbl_categoria,
            "atajo": lbl_atajo,
            "favorito": boton_favorito,
            "tooltip_favorito": tooltip_favorito,
            "boton": boton,
        }

    def crear_fila_compacta(self, padre, fila, app):
        componente = self._obtener_componente_app("compacta", app)
        fila_panel = componente["panel"]
        self._actualizar_componente_app(componente, app, "compacta")
        fila_panel.grid(row=fila, column=0, columnspan=3, sticky="ew", padx=0, pady=(0, 4))
        self._registrar_widget_renderizado(fila_panel)

    def _crear_componente_fila_compacta(self, padre, app):
        paleta = suite_obtener_paleta()
        fila_panel = self.crear_panel_redondeado(
            padre,
            tipo="card",
            fill=paleta["tarjeta"],
            parent_bg=paleta["tarjeta"],
            padding=(5, 3),
            radius=8,
        )
        fila_app = fila_panel.body
        fila_app.columnconfigure(0, weight=0, minsize=128)
        fila_app.columnconfigure(1, weight=1, minsize=168)
        fila_app.columnconfigure(2, weight=0, minsize=28)
        fila_app.columnconfigure(3, weight=0, minsize=54)
        lbl_titulo = ttk.Label(
            fila_app,
            style="CardTitle.TLabel",
            anchor="w",
        )
        lbl_titulo.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        lbl_descripcion = ttk.Label(
            fila_app,
            style="Muted.Card.TLabel",
            anchor="w",
            wraplength=168,
        )
        lbl_descripcion.grid(row=0, column=1, sticky="ew", padx=(0, 5))
        boton_favorito = ttk.Button(
            fila_app,
            command=lambda clave=app["clave"]: self.alternar_favorito_por_clave(clave),
            style="Compact.Secondary.TButton",
            width=2,
        )
        boton_favorito.grid(row=0, column=2, sticky="ew", padx=(0, 4))
        tooltip_favorito = Tooltip(boton_favorito, "")
        boton = ttk.Button(
            fila_app,
            command=lambda clave=app["clave"]: self.ejecutar_app_por_clave(clave),
            style="Compact.Primary.TButton",
            width=5,
        )
        boton.grid(row=0, column=3, sticky="ew")
        return {
            "panel": fila_panel,
            "titulo": lbl_titulo,
            "descripcion": lbl_descripcion,
            "favorito": boton_favorito,
            "tooltip_favorito": tooltip_favorito,
            "boton": boton,
        }

    def crear_fila_app(self, padre, fila, app):
        componente = self._obtener_componente_app("lista", app)
        fila_panel = componente["panel"]
        self._actualizar_componente_app(componente, app, "lista")
        fila_panel.grid(row=fila, column=0, columnspan=3, sticky="ew", padx=UI_CARD_GAP, pady=(0, UI_CARD_GAP))
        self._registrar_widget_renderizado(fila_panel)

    def _crear_componente_fila_app(self, padre, app):
        paleta = suite_obtener_paleta()
        fila_panel = self.crear_panel_redondeado(
            padre,
            tipo="card",
            fill=paleta["tarjeta"],
            parent_bg=paleta["tarjeta"],
            padding=(12, 10),
            radius=UI_RADIUS_ROW,
        )
        fila_app = fila_panel.body
        fila_app.columnconfigure(2, weight=1)
        fila_app.columnconfigure(3, weight=4)
        fila_app.columnconfigure(4, weight=0)
        fila_app.columnconfigure(5, weight=0)
        fila_app.columnconfigure(6, weight=0)
        self.crear_icono_app(fila_app, app).grid(row=0, column=1, sticky="w", padx=(0, 12))
        lbl_titulo = ttk.Label(fila_app, style="CardTitle.TLabel", anchor="w")
        lbl_titulo.grid(row=0, column=2, sticky="ew", padx=(0, 10))
        lbl_descripcion = ttk.Label(
            fila_app,
            style="Muted.Card.TLabel",
            anchor="w",
            wraplength=760,
        )
        lbl_descripcion.grid(row=0, column=3, sticky="ew", padx=(0, 10))
        lbl_categoria = ttk.Label(fila_app, style="Chip.TLabel", anchor="center")
        lbl_categoria.grid(row=0, column=4, sticky="ew", padx=(0, 8))
        boton_favorito = ttk.Button(
            fila_app,
            command=lambda clave=app["clave"]: self.alternar_favorito_por_clave(clave),
            style="Favorite.TButton",
            width=3,
        )
        boton_favorito.grid(row=0, column=5, sticky="ew", padx=(0, 8))
        tooltip_favorito = Tooltip(boton_favorito, "")
        boton = ttk.Button(
            fila_app,
            command=lambda clave=app["clave"]: self.ejecutar_app_por_clave(clave),
            style="Primary.TButton",
            width=10,
        )
        boton.grid(row=0, column=6, sticky="ew")
        return {
            "panel": fila_panel,
            "titulo": lbl_titulo,
            "descripcion": lbl_descripcion,
            "categoria": lbl_categoria,
            "favorito": boton_favorito,
            "tooltip_favorito": tooltip_favorito,
            "boton": boton,
        }

    def _obtener_componente_app(self, vista, app):
        clave = (vista, app["clave"])
        componente = self._componentes_apps.get(clave)
        if componente is not None:
            return componente
        if vista == "tarjeta":
            componente = self._crear_componente_tarjeta(self.panel_apps, app)
        elif vista == "compacta":
            componente = self._crear_componente_fila_compacta(self.panel_apps, app)
        else:
            componente = self._crear_componente_fila_app(self.panel_apps, app)
        self._componentes_apps[clave] = componente
        return componente

    def _actualizar_componente_app(self, componente, app, vista):
        paleta = suite_obtener_paleta()
        componente["panel"].configure_visual(
            fill=paleta["tarjeta"],
            border=UI_CARD_BORDER_OSCURO if suite_obtener_tema_actual() == "oscuro" else UI_CARD_BORDER_CLARO,
            parent_bg=paleta["tarjeta"],
            focus_border=paleta["focus"],
            hover_border=paleta["boton_sec_border"],
            pressed_border=paleta["principal_hover"],
        )
        componente["titulo"].configure(text=app["titulo"])
        if "descripcion" in componente:
            texto_descripcion = app["descripcion"] if vista == "tarjeta" else app["descripcion_compacta"]
            componente["descripcion"].configure(text=texto_descripcion)
        if "categoria" in componente:
            componente["categoria"].configure(text=app["categoria"])
        if "estado" in componente:
            componente["estado"].configure(text=self.texto_estado_app(app))
        if "atajo" in componente:
            componente["atajo"].configure(text=app["atajo"])
        favorito = bool(app.get("favorita"))
        componente["favorito"].configure(text="\u2605" if favorito else "\u2606")
        componente["tooltip_favorito"].actualizar("Quitar de favoritos" if favorito else "Anadir a favoritos")
        texto_boton = "Traer" if self.app_abierta(app) else "Abrir"
        componente["boton"].configure(text=texto_boton)
        if not self.app_disponible(app) and not self.app_abierta(app):
            componente["boton"].configure(state="disabled")
        else:
            componente["boton"].configure(state="normal")
        self.widgets_apps[app["clave"]] = {"boton": componente["boton"]}

    def _actualizar_estado_componente_app(self, componente, app):
        if "estado" in componente:
            componente["estado"].configure(text=self.texto_estado_app(app))
        texto_boton = "Traer" if self.app_abierta(app) else "Abrir"
        componente["boton"].configure(text=texto_boton)
        if not self.app_disponible(app) and not self.app_abierta(app):
            componente["boton"].configure(state="disabled")
        else:
            componente["boton"].configure(state="normal")
        self.widgets_apps[app["clave"]] = {"boton": componente["boton"]}

    def actualizar_estado_visual_aplicaciones(self):
        self.actualizar_estado_aplicaciones()
        for app in self.apps_catalogo:
            for vista in ("tarjeta", "compacta", "lista"):
                componente = self._componentes_apps.get((vista, app["clave"]))
                if componente is not None:
                    self._actualizar_estado_componente_app(componente, app)

    def solicitar_actualizar_scroll_apps(self):
        if self._scroll_after_id is not None:
            return
        try:
            self._scroll_after_id = self.ventana.after_idle(self._actualizar_scroll_apps)
        except Exception:
            self._scroll_after_id = None
            self._actualizar_scroll_apps()

    def _actualizar_scroll_apps(self, _event=None):
        self._scroll_after_id = None
        try:
            bbox = self.canvas_apps.bbox("all")
            self.canvas_apps.configure(scrollregion=bbox)
            self._actualizar_visibilidad_scroll_apps(bbox)
        except Exception:
            pass

    def _sincronizar_canvas_tema(self):
        try:
            paleta = suite_obtener_paleta()
            borde_tarjeta = UI_CARD_BORDER_OSCURO if suite_obtener_tema_actual() == "oscuro" else UI_CARD_BORDER_CLARO
            for panel, fill, parent_bg, border in (
                (getattr(self, "cabecera", None), paleta["tarjeta"], paleta["fondo"], paleta["borde"]),
                (getattr(self, "sidebar_panel", None), paleta["estado"], paleta["fondo"], paleta["borde"]),
                (getattr(self, "panel_apps_area_panel", None), paleta["tarjeta"], paleta["fondo"], paleta["borde"]),
            ):
                if panel is not None:
                    panel.configure_visual(
                        fill=fill,
                        border=border,
                        parent_bg=parent_bg,
                        focus_border=paleta["focus"],
                        hover_border=paleta["boton_sec_border"],
                        pressed_border=paleta["principal_hover"],
                    )
            for componente in getattr(self, "_componentes_apps", {}).values():
                componente["panel"].configure_visual(
                    fill=paleta["tarjeta"],
                    border=borde_tarjeta,
                    parent_bg=paleta["tarjeta"],
                    focus_border=paleta["focus"],
                    hover_border=paleta["boton_sec_border"],
                    pressed_border=paleta["principal_hover"],
                )
            for categoria, componente in getattr(self, "_componentes_categorias", {}).items():
                activo = categoria == getattr(self, "categoria_actual", "")
                componente["panel"].configure_visual(
                    fill=paleta["principal"] if activo else paleta["estado"],
                    border=paleta["principal"] if activo else paleta["estado"],
                    parent_bg=paleta["estado"],
                    focus_border=paleta["focus"],
                    hover_border=paleta["boton_sec_border"],
                    pressed_border=paleta["principal_hover"],
                )
            self.canvas_apps.configure(
                bg=paleta["tarjeta"],
                highlightbackground=paleta["borde"],
                highlightcolor=paleta["focus"],
            )
        except Exception:
            pass

    def _ajustar_ancho_panel_apps(self, event):
        try:
            self.canvas_apps.itemconfigure(self.panel_apps_window, width=event.width)
            self.solicitar_actualizar_scroll_apps()
        except Exception:
            pass

    def _scroll_apps_set(self, primero, ultimo):
        try:
            self.scroll_apps.set(primero, ultimo)
            if float(primero) <= 0.0 and float(ultimo) >= 1.0:
                self._ocultar_scroll_apps()
            else:
                self._mostrar_scroll_apps()
        except Exception:
            pass

    def _scroll_apps_necesario(self):
        try:
            bbox = self.canvas_apps.bbox("all")
            if not bbox:
                return False
            alto_contenido = bbox[3] - bbox[1]
            alto_canvas = max(1, self.canvas_apps.winfo_height())
            return alto_contenido > alto_canvas + 2
        except Exception:
            return False

    def _actualizar_visibilidad_scroll_apps(self, bbox=None):
        try:
            if bbox is None:
                bbox = self.canvas_apps.bbox("all")
            if not bbox:
                self._ocultar_scroll_apps()
                self.canvas_apps.yview_moveto(0)
                return
            alto_contenido = bbox[3] - bbox[1]
            alto_canvas = max(1, self.canvas_apps.winfo_height())
            if alto_contenido > alto_canvas + 2:
                self._mostrar_scroll_apps()
            else:
                self.canvas_apps.yview_moveto(0)
                self._ocultar_scroll_apps()
        except Exception:
            pass

    def _mostrar_scroll_apps(self):
        if self._scroll_apps_visible:
            return
        try:
            self.scroll_apps.grid(row=1, column=1, sticky="ns")
            self._scroll_apps_visible = True
        except Exception:
            pass

    def _ocultar_scroll_apps(self):
        if not self._scroll_apps_visible:
            return
        try:
            self.scroll_apps.grid_remove()
            self._scroll_apps_visible = False
        except Exception:
            pass

    def _scroll_apps_mousewheel(self, event):
        try:
            if not self._scroll_apps_necesario():
                self.canvas_apps.yview_moveto(0)
                return "break"
            if getattr(event, "num", None) == 4:
                pasos = -1
            elif getattr(event, "num", None) == 5:
                pasos = 1
            else:
                delta = getattr(event, "delta", 0)
                pasos = int(-1 * (delta / 120)) if delta else 0
            if pasos:
                self.canvas_apps.yview_scroll(pasos, "units")
        except Exception:
            pass
        return "break"

    def vincular_scroll_widgets(self, widget):
        try:
            widget_id = str(widget)
            if widget_id not in self._widgets_scroll_vinculados:
                self._widgets_scroll_vinculados.add(widget_id)
                widget.bind("<MouseWheel>", self._scroll_apps_mousewheel, add="+")
                widget.bind("<Button-4>", self._scroll_apps_mousewheel, add="+")
                widget.bind("<Button-5>", self._scroll_apps_mousewheel, add="+")
            for hijo in widget.winfo_children():
                self.vincular_scroll_widgets(hijo)
        except Exception:
            pass

    def _activar_scroll_global_compacto(self):
        if self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.bind_all("<MouseWheel>", self._scroll_apps_mousewheel, add="+")
            self.ventana.bind_all("<Button-4>", self._scroll_apps_mousewheel, add="+")
            self.ventana.bind_all("<Button-5>", self._scroll_apps_mousewheel, add="+")
            self._scroll_global_compacto_activo = True
        except Exception:
            pass

    def _desactivar_scroll_global_compacto(self):
        if not self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.unbind_all("<MouseWheel>")
            self.ventana.unbind_all("<Button-4>")
            self.ventana.unbind_all("<Button-5>")
        except Exception:
            pass
        self._scroll_global_compacto_activo = False

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            messagebox.showwarning(
                "Pillow no instalado",
                "No se pudieron cargar los logos porque falta la libreria Pillow.\nInstalala con: pip install pillow",
                parent=self.ventana)
            return

        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))

            img_izq.thumbnail((210, 80))
            img_der.thumbnail((200, 80))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            lbl_izq = tk.Label(self.logo_slot_izq, image=self.logo_izq)
            lbl_der = tk.Label(self.logo_slot_der, image=self.logo_der)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
            preparar_logo_minimizar(lbl_izq, self.ventana)
            preparar_logo_minimizar(lbl_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script.",
                parent=self.ventana)
        except Exception as e:
            messagebox.showwarning("Error al cargar logos", f"No se pudieron cargar los logos:\n{e}", parent=self.ventana)

    def configurar_accesibilidad(self):
        """Atajos de teclado y refresco manual sin tocar la logica de las aplicaciones."""
        self.ventana.bind("<Alt-Key-1>", lambda _event: self.abrir_merma())
        self.ventana.bind("<Alt-Key-2>", lambda _event: self.abrir_txt_csv())
        self.ventana.bind("<Alt-Key-3>", lambda _event: self.abrir_palets())
        self.ventana.bind("<Alt-Key-4>", lambda _event: self.abrir_precintos())
        self.ventana.bind("<Alt-Key-5>", lambda _event: self.abrir_exportar_precintos())
        self.ventana.bind("<F5>", lambda _event: self.actualizar_estado_aplicaciones())
        self.ventana.bind("<F1>", lambda _event: self.abrir_acerca_version())
        self.ventana.bind("<Escape>", lambda _event: self.salir())
        self.ventana.bind("<Control-k>", lambda _event: self.enfocar_busqueda())
        self.ventana.bind("<Control-K>", lambda _event: self.enfocar_busqueda())
        self.ventana.bind("<Up>", lambda _event: self.seleccionar_categoria_relativa(-1))
        self.ventana.bind("<Down>", lambda _event: self.seleccionar_categoria_relativa(1))

    def enfocar_busqueda(self):
        self.entry_busqueda.focus_set()
        self._limpiar_placeholder_busqueda()
        self.entry_busqueda.selection_range(0, tk.END)

    def seleccionar_categoria_relativa(self, desplazamiento):
        try:
            if self.ventana.focus_get() is self.entry_busqueda:
                return None
        except Exception:
            pass
        categorias = self.categorias_disponibles()
        if not categorias:
            return "break"
        try:
            indice = categorias.index(self.categoria_actual)
        except ValueError:
            indice = 0
        self.seleccionar_categoria(categorias[(indice + desplazamiento) % len(categorias)])
        try:
            self.botones_categoria[self.categoria_actual].focus_keyboard()
        except Exception:
            pass
        return "break"

    def texto_estado_actualizador(self):
        estado = leer_estado_actualizador()
        if not estado:
            return {
                "status": "sin datos",
                "updated_at": "sin comprobar",
                "version_url": "canal por defecto",
                "message": "Todavia no hay registro de comprobacion.",
            }
        return estado

    def copiar_diagnostico(self):
        estado = leer_estado_actualizador()
        logs = carpeta_logs()
        partes = [
            "Suite Rodriguez Finura - diagnostico",
            f"Version instalada: {obtener_version_local()}",
            f"Ruta app: {os.path.dirname(os.path.abspath(__file__))}",
            f"Ejecutable Python: {sys.executable}",
            f"Python: {sys.version}",
            f"Sistema: {platform.platform()}",
            f"Carpeta logs: {logs}",
            "",
            "Estado actualizador:",
            json.dumps(estado, indent=2, ensure_ascii=False) if estado else "Sin estado registrado.",
            "",
            "launcher_update_check.log:",
            cola_archivo(os.path.join(logs, "launcher_update_check.log")),
            "",
            "updater.log:",
            cola_archivo(os.path.join(logs, "updater.log")),
        ]
        texto = "\n".join(partes)
        try:
            self.ventana.clipboard_clear()
            self.ventana.clipboard_append(texto)
            self.etiqueta_estado.configure(text="Diagnostico copiado al portapapeles")
            messagebox.showinfo("Diagnostico", "Diagnostico copiado al portapapeles.", parent=self.ventana)
        except Exception as exc:
            messagebox.showerror("Diagnostico", f"No se pudo copiar el diagnostico:\n{exc}", parent=self.ventana)

    def buscar_actualizacion_manual(self, boton=None, ventana_acerca=None):
        if boton is not None:
            try:
                boton.configure(state="disabled")
            except Exception:
                pass
        self.etiqueta_estado.configure(text="Comprobando actualizaciones...")

        def trabajador():
            iniciado = False
            error = None
            try:
                import SuiteLauncher

                iniciado = bool(SuiteLauncher.check_and_update(manual=True))
            except Exception as exc:
                error = exc

            def finalizar():
                if boton is not None:
                    try:
                        boton.configure(state="normal")
                    except Exception:
                        pass
                if error is not None:
                    self.etiqueta_estado.configure(text="No se pudo comprobar la actualizacion")
                    messagebox.showerror("Actualizaciones", f"No se pudo comprobar la actualizacion:\n{error}", parent=self.ventana)
                    return
                if iniciado:
                    self.etiqueta_estado.configure(text="Actualizacion iniciada")
                    try:
                        if ventana_acerca is not None and ventana_acerca.winfo_exists():
                            ventana_acerca.destroy()
                    except Exception:
                        pass
                    self.ventana.after(1200, self.ventana.destroy)
                else:
                    self.etiqueta_estado.configure(text="Comprobacion de actualizaciones finalizada")

            self.ventana.after(0, finalizar)

        threading.Thread(target=trabajador, daemon=True).start()

    def abrir_acerca_version(self):
        if hasattr(self, "_ventana_acerca") and self._ventana_acerca is not None:
            try:
                if self._ventana_acerca.winfo_exists():
                    self._ventana_acerca.lift()
                    self._ventana_acerca.focus_force()
                    return
            except Exception:
                pass

        estado = self.texto_estado_actualizador()
        ventana = tk.Toplevel(self.ventana)
        self._ventana_acerca = ventana
        suite_configurar_ventana_base(ventana, "Acerca de / Version")
        aplicar_icono_ventana(ventana)
        ventana.transient(self.ventana)
        ventana.columnconfigure(0, weight=1)

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=(18, 16))
        contenedor.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)
        contenedor.columnconfigure(1, weight=1)

        filas = [
            ("Version instalada", obtener_version_local()),
            ("Propiedad intelectual", SUITE_FOOTER_TEXTO),
            ("Ultima comprobacion", str(estado.get("updated_at", "sin comprobar"))),
            ("URL del canal", str(estado.get("version_url", "canal por defecto"))),
            ("Estado", str(estado.get("status", "sin datos"))),
            ("Detalle", str(estado.get("message", ""))),
            ("Logs", carpeta_logs()),
        ]
        ttk.Label(contenedor, text="Suite Rodriguez Finura", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        for indice, (etiqueta, valor) in enumerate(filas, start=1):
            ttk.Label(contenedor, text=etiqueta, style="Muted.Card.TLabel").grid(row=indice, column=0, sticky="nw", padx=(0, 14), pady=4)
            ttk.Label(contenedor, text=valor or "-", style="Card.TLabel", wraplength=480, justify="left").grid(row=indice, column=1, sticky="ew", pady=4)

        acciones = ttk.Frame(contenedor, style="Card.TFrame")
        acciones.grid(row=len(filas) + 1, column=0, columnspan=2, sticky="ew", pady=(16, 0))
        acciones.columnconfigure(0, weight=1)
        boton_actualizar = ttk.Button(
            acciones,
            text="Buscar actualizacion",
            style="Primary.TButton",
            command=lambda: self.buscar_actualizacion_manual(boton_actualizar, ventana),
        )
        boton_actualizar.grid(row=0, column=0, sticky="w")
        ttk.Button(
            acciones,
            text="Copiar diagnostico",
            style="Secondary.TButton",
            command=self.copiar_diagnostico,
        ).grid(row=0, column=1, padx=(10, 0))
        ttk.Button(
            acciones,
            text="Cerrar",
            style="Secondary.TButton",
            command=ventana.destroy,
        ).grid(row=0, column=2, padx=(10, 0))

    def alternar_modo_compacto(self):
        """Alterna entre menu completo y una vista lista compacta."""
        self.modo_compacto = not self.modo_compacto
        if self.modo_compacto:
            self._vista_previa_compacto = self.vista_actual
            self._categoria_previa_compacto = self.categoria_actual
            suite_aplicar_modo_compacto_ventana(self.ventana, True)
            self.cabecera.grid_configure(padx=UI_GAP, pady=(UI_GAP, UI_GAP))
            self.lbl_subtitulo.grid_remove()
            self.linea_cabecera.grid_configure(pady=(6, 0))
            self.contenedor.grid_configure(padx=UI_GAP, pady=(0, UI_GAP))
            self.contenedor.columnconfigure(0, weight=1, minsize=0)
            self.contenedor.columnconfigure(1, weight=0, minsize=0)
            self.sidebar_panel.grid_remove()
            self.boton_tema.grid_remove()
            self.boton_acerca.grid_remove()
            self.boton_salir_header.grid_remove()
            self.panel_apps_area_panel.grid_configure(row=0, column=0, columnspan=2, sticky="nsew")
            self.panel_apps.configure(padding=UI_PANEL_PAD)
            self.footer.grid_remove()
            self.categoria_actual = "Todas"
            self.boton_compacto.config(text="Completo")
            self.aplicar_vista_temporal("compacta")
            self._activar_scroll_global_compacto()
        else:
            self._desactivar_scroll_global_compacto()
            suite_aplicar_modo_compacto_ventana(self.ventana, False)
            self.cabecera.grid_configure(padx=UI_GAP, pady=(UI_GAP, 0))
            self.lbl_subtitulo.grid()
            self.linea_cabecera.grid_configure(pady=(14, 0))
            self.contenedor.grid_configure(padx=UI_GAP, pady=(UI_GAP, UI_GAP))
            self.contenedor.columnconfigure(0, weight=0, minsize=250)
            self.contenedor.columnconfigure(1, weight=1, minsize=0)
            self.sidebar_panel.grid(row=0, column=0, sticky="nsew", padx=(0, UI_GAP))
            self.boton_tema.grid()
            self.boton_acerca.grid()
            self.boton_salir_header.grid()
            self.panel_apps_area_panel.grid_configure(row=0, column=1, columnspan=1, sticky="nsew")
            self.panel_apps.configure(padding=UI_PANEL_PAD)
            self.footer.grid(row=2, column=0, sticky="ew", padx=UI_GAP, pady=(0, UI_GAP))
            self.boton_compacto.config(text="Compacto")
            self._vista_previa_compacto = None
            self.categoria_actual = self._categoria_previa_compacto or "Todas"
            self._categoria_previa_compacto = None
            self.renderizar_categorias()
            self.aplicar_vista_temporal("tarjetas")
        suite_establecer_preferencia("modo_compacto", bool(self.modo_compacto))

    def salir(self):
        if self.ventanas_abiertas:
            if not messagebox.askyesno(
                "Salir de la suite",
                "Hay aplicaciones abiertas. Si sales del menu se cerrara la suite principal, pero las ventanas abiertas pueden perder el foco.\n\nQuieres salir?",
                parent=self.ventana,
            ):
                return
        if self._after_estado_id:
            try:
                self.ventana.after_cancel(self._after_estado_id)
            except Exception:
                pass
            self._after_estado_id = None
        self.ventana.destroy()

    def minimizar_menu_por_app(self):
        """Mantiene el menu maximizado y lo deja detras de la aplicacion abierta."""
        try:
            self.ventana.state("zoomed")
        except Exception:
            pass
        try:
            self.ventana.lower()
        except Exception:
            pass

    def restaurar_menu_si_no_hay_apps(self):
        """Trae el menu al frente sin animacion de restauracion desde minimizado."""
        if self.ventanas_abiertas:
            return
        try:
            self.ventana.deiconify()
            self.ventana.state("zoomed")
            self.ventana.lift()
            self.ventana.focus_force()
        except Exception:
            pass

    def traer_ventana_existente(self, clave):
        existente = self.ventanas_abiertas.get(clave)
        if not existente:
            return False
        _titulo, ventana_app = existente
        try:
            if ventana_app.winfo_exists():
                ventana_app.deiconify()
                ventana_app.lift()
                ventana_app.focus_force()
                self.ventana.lower(ventana_app)
                self.minimizar_menu_por_app()
                self.actualizar_estado_visual_aplicaciones()
                return True
        except Exception:
            pass
        self.ventanas_abiertas.pop(clave, None)
        return False

    def registrar_ventana(self, clave, titulo, ventana_app):
        self.ventanas_abiertas[clave] = (titulo, ventana_app)
        ventana_app.protocol("WM_DELETE_WINDOW", lambda c=clave, v=ventana_app: self.cerrar_ventana_app(c, v))
        ventana_app.bind("<Destroy>", lambda event, c=clave: self._al_destruir_ventana(event, c), add="+")
        try:
            ventana_app.lift()
            ventana_app.focus_force()
            self.ventana.lower(ventana_app)
            self.minimizar_menu_por_app()
        except Exception:
            pass
        self.actualizar_estado_visual_aplicaciones()

    def _al_destruir_ventana(self, event, clave):
        if event.widget is self.ventanas_abiertas.get(clave, (None, None))[1]:
            self.ventanas_abiertas.pop(clave, None)
            self.ventana.after(50, self.actualizar_estado_visual_aplicaciones)
            self.ventana.after(80, self.restaurar_menu_si_no_hay_apps)

    def cerrar_ventana_app(self, clave, ventana_app):
        try:
            ventana_app.destroy()
        finally:
            self.ventanas_abiertas.pop(clave, None)
            self.actualizar_estado_visual_aplicaciones()
            self.restaurar_menu_si_no_hay_apps()

    def actualizar_estado_aplicaciones_periodico(self):
        self.actualizar_estado_aplicaciones()
        try:
            self._after_estado_id = self.ventana.after(1500, self.actualizar_estado_aplicaciones_periodico)
        except Exception:
            self._after_estado_id = None
            pass

    def actualizar_estado_aplicaciones(self):
        abiertas = []
        for clave, (titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    abiertas.append(titulo)
                else:
                    self.ventanas_abiertas.pop(clave, None)
            except Exception:
                self.ventanas_abiertas.pop(clave, None)
        if abiertas:
            texto = "Aplicaciones abiertas: " + " | ".join(abiertas)
        else:
            texto = "Sin aplicaciones abiertas"
        if texto != self._estado_aplicaciones_cache:
            self.etiqueta_estado.config(text=texto)
            self._estado_aplicaciones_cache = texto
        return abiertas

    def abrir_merma(self):
        if self.traer_ventana_existente("merma"):
            return
        try:
            lanzar_app_merma = cargar_atributo("programa_mermas", "lanzar_app_merma")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de merma:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_merma(self.ventana)
        self.registrar_ventana("merma", "Merma", ventana_app)

    def abrir_txt_csv(self):
        if self.traer_ventana_existente("txt_csv"):
            return
        try:
            lanzar_app_txt_csv = cargar_atributo("FusionarCSV_mejorado", "lanzar_app_txt_csv")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion TXT a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_txt_csv(self.ventana)
        self.registrar_ventana("txt_csv", "TXT a CSV", ventana_app)

    def abrir_palets(self):
        if self.traer_ventana_existente("palets"):
            return
        try:
            ProcesadorPaletsApp = cargar_atributo("ProcesadorPaletsGUI", "ProcesadorPaletsApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Palets PDA:\n{exc}", parent=self.ventana)
            return
        ventana_palets = tk.Toplevel(self.ventana)
        ProcesadorPaletsApp(ventana_palets)
        self.registrar_ventana("palets", "Palets PDA", ventana_palets)

    def abrir_precintos(self):
        if self.traer_ventana_existente("precintos"):
            return
        try:
            ControlPrecintosJamonesApp = cargar_atributo("ControlPrecintosJamonesGUI", "ControlPrecintosJamonesApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Jamones:\n{exc}", parent=self.ventana)
            return
        ventana_precintos = tk.Toplevel(self.ventana)
        ControlPrecintosJamonesApp(ventana_precintos)
        self.registrar_ventana("precintos", "Precintos Jamones", ventana_precintos)

    def abrir_exportar_precintos(self):
        if self.traer_ventana_existente("exportar_precintos"):
            return
        try:
            ExportarPrecintosExcelApp = cargar_atributo("ExportarPrecintosExcelGUI", "ExportarPrecintosExcelApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Excel a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_exportar = tk.Toplevel(self.ventana)
        ExportarPrecintosExcelApp(ventana_exportar)
        self.registrar_ventana("exportar_precintos", "Precintos Excel", ventana_exportar)


if __name__ == "__main__":
    root = tk.Tk()
    try:
        root.withdraw()
    except Exception:
        pass
    app = MenuPrincipal(root)
    root.mainloop()
