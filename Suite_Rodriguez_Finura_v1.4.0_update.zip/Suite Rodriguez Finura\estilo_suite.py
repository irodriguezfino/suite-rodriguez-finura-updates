"""Capa visual comun para Suite Rodriguez / Finura.

Este modulo concentra paleta, tipografias, layout, estados visuales,
accesibilidad basica y soporte claro/oscuro. Los scripts funcionales deben
consumir estos helpers en vez de definir estilos locales.
"""
from __future__ import annotations

import json
import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk


def ruta_preferencias_usuario() -> Path:
    """Ruta estable donde se guardan las preferencias visuales del usuario."""
    base = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA")
    if base:
        carpeta = Path(base) / "Suite_Rodriguez_Finura"
    else:
        carpeta = Path.home() / ".suite_rodriguez_finura"
    return carpeta / "preferencias_usuario.json"


def cargar_preferencias_usuario() -> dict:
    """Carga preferencias persistentes sin romper la app si el JSON no existe o esta danado."""
    ruta = ruta_preferencias_usuario()
    try:
        if ruta.exists():
            datos = json.loads(ruta.read_text(encoding="utf-8"))
            if isinstance(datos, dict):
                return datos
    except Exception:
        pass
    return {}


def guardar_preferencias_usuario(preferencias: dict) -> None:
    """Guarda preferencias visuales de forma atomica y silenciosa."""
    ruta = ruta_preferencias_usuario()
    try:
        ruta.parent.mkdir(parents=True, exist_ok=True)
        tmp = ruta.with_suffix(".tmp")
        tmp.write_text(json.dumps(preferencias, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(ruta)
    except Exception:
        pass


def obtener_preferencia(clave: str, valor_defecto=None):
    return cargar_preferencias_usuario().get(clave, valor_defecto)


def establecer_preferencia(clave: str, valor) -> None:
    preferencias = cargar_preferencias_usuario()
    preferencias[clave] = valor
    guardar_preferencias_usuario(preferencias)


FOOTER_TEXTO = "Dpto. Sistemas e Informatica EMBUTIDOS RODRIGUEZ"

FUENTE_BASE = ("Arial", 11)
FUENTE_TITULO = ("Arial", 30, "bold")
FUENTE_SUBTITULO = ("Arial", 12)
FUENTE_BOTON = ("Arial", 11, "bold")
FUENTE_MONO = ("Consolas", 11)
FUENTE_TARJETA_TITULO = ("Arial", 16, "bold")
FUENTE_MUTED = ("Arial", 11)
FUENTE_FOOTER = ("Arial", 10)
FUENTE_VERSION = ("Arial", 9)

VENTANA_GEOMETRIA = "1120x780"
VENTANA_MIN_ANCHO = 900
VENTANA_MIN_ALTO = 620
VENTANA_COMPACTA_GEOMETRIA = "540x500"
VENTANA_COMPACTA_MIN_ANCHO = 520
VENTANA_COMPACTA_MIN_ALTO = 380

PAD_APP = (26, 22, 26, 20)
PAD_CARD = (20, 18)
PAD_PANEL = (20, 16)
PAD_PANEL_COMPACT = (18, 10)
PAD_FOOTER = (22, 12)
PAD_TARJETA_MENU = (14, 12)
PAD_MENU_APPS = (22, 20)
PAD_MENU_INFO = (20, 16)
PAD_MENU_APPS_COMPACTO = (14, 12)
PAD_MENU_INFO_COMPACTO = (16, 12)
STATUS_PADDING = (14, 9)
TEXT_BORDER_WIDTH = 1
RED_LINE_HEIGHT = 4

ESPACIADO_EXTERIOR_X = 28
ESPACIADO_EXTERIOR_Y = 8
ESPACIADO_BOTON_X = 8
ESPACIADO_BOTON_MIN_X = 5


PALETAS = {
    "claro": {
        "fondo": "#F7F9FC",
        "tarjeta": "#FFFFFF",
        "borde": "#64748B",
        "principal": "#103080",
        "principal_fg": "#FFFFFF",
        "principal_hover": "#0B2564",
        "texto": "#1F2937",
        "muted": "#4B5563",
        "estado": "#EAF3FB",
        "error": "#B42318",
        "ok": "#157347",
        "rodriguez": "#C02020",
        "seleccion": "#BFD7F0",
        "seleccion_texto": "#111827",
        "aviso": "#8A5A00",
        "boton_sec": "#FFFFFF",
        "boton_sec_active": "#EAF3FB",
        "boton_sec_border": "#94A3B8",
        "protected_bg": "#E0F2FE",
        "protected_active": "#BAE6FD",
        "protected_fg": "#075985",
        "danger_bg": "#FFF5F5",
        "danger_active": "#FCE1E1",
        "focus": "#C02020",
        "disabled_bg": "#D1D5DB",
        "disabled_fg": "#6B7280",
        "field": "#FFFFFF",
    },
    "oscuro": {
        "fondo": "#111827",
        "tarjeta": "#1F2937",
        "borde": "#6B7280",
        "principal": "#8AB4F8",
        "principal_fg": "#111827",
        "principal_hover": "#60A5FA",
        "texto": "#F9FAFB",
        "muted": "#D1D5DB",
        "estado": "#243447",
        "error": "#FCA5A5",
        "ok": "#86EFAC",
        "rodriguez": "#F05252",
        "seleccion": "#1D4ED8",
        "seleccion_texto": "#FFFFFF",
        "aviso": "#FBBF24",
        "boton_sec": "#243447",
        "boton_sec_active": "#2F455F",
        "boton_sec_border": "#64748B",
        "protected_bg": "#12324A",
        "protected_active": "#164E63",
        "protected_fg": "#7DD3FC",
        "danger_bg": "#3A1F24",
        "danger_active": "#5B252C",
        "focus": "#F87171",
        "disabled_bg": "#243447",
        "disabled_fg": "#9CA3AF",
        "field": "#111827",
    },
}

TEMA_ACTUAL = os.environ.get("SUITE_TEMA") or str(obtener_preferencia("tema", "claro"))
TEMA_ACTUAL = TEMA_ACTUAL.strip().lower() or "claro"

COLOR_FONDO = ""
COLOR_TARJETA = ""
COLOR_BORDE = ""
COLOR_PRINCIPAL = ""
COLOR_PRINCIPAL_HOVER = ""
COLOR_TEXTO = ""
COLOR_MUTED = ""
COLOR_ESTADO = ""
COLOR_ERROR = ""
COLOR_OK = ""
COLOR_RODRIGUEZ = ""
COLOR_SELECCION = ""
COLOR_SELECCION_TEXTO = ""
COLOR_AVISO = ""
COLOR_FOCUS = ""


def obtener_paleta(tema: str | None = None) -> dict[str, str]:
    clave = (tema or TEMA_ACTUAL or "claro").strip().lower()
    return PALETAS.get(clave, PALETAS["claro"])


def aplicar_tema(tema: str = "claro") -> None:
    """Actualiza constantes visuales globales manteniendo compatibilidad."""
    global TEMA_ACTUAL, COLOR_FONDO, COLOR_TARJETA, COLOR_BORDE, COLOR_PRINCIPAL
    global COLOR_PRINCIPAL_HOVER, COLOR_TEXTO, COLOR_MUTED, COLOR_ESTADO
    global COLOR_ERROR, COLOR_OK, COLOR_RODRIGUEZ, COLOR_SELECCION
    global COLOR_SELECCION_TEXTO, COLOR_AVISO, COLOR_FOCUS

    TEMA_ACTUAL = "oscuro" if str(tema).lower().startswith("osc") else "claro"
    p = obtener_paleta(TEMA_ACTUAL)
    COLOR_FONDO = p["fondo"]
    COLOR_TARJETA = p["tarjeta"]
    COLOR_BORDE = p["borde"]
    COLOR_PRINCIPAL = p["principal"]
    COLOR_PRINCIPAL_HOVER = p["principal_hover"]
    COLOR_TEXTO = p["texto"]
    COLOR_MUTED = p["muted"]
    COLOR_ESTADO = p["estado"]
    COLOR_ERROR = p["error"]
    COLOR_OK = p["ok"]
    COLOR_RODRIGUEZ = p["rodriguez"]
    COLOR_SELECCION = p["seleccion"]
    COLOR_SELECCION_TEXTO = p["seleccion_texto"]
    COLOR_AVISO = p["aviso"]
    COLOR_FOCUS = p["focus"]


aplicar_tema(TEMA_ACTUAL)


def ruta_recurso(nombre: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def ruta_recurso_path(nombre: str) -> Path:
    return Path(ruta_recurso(nombre))


def configurar_ttk_unificado(ventana: tk.Misc | None = None, tema: str | None = None) -> ttk.Style:
    """Configura ttk con contraste AA, foco visible y soporte claro/oscuro."""
    if tema:
        aplicar_tema(tema)
    p = obtener_paleta()
    style = ttk.Style(ventana)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(".", font=FUENTE_BASE)
    style.configure("TFrame", background=COLOR_FONDO)
    style.configure("App.TFrame", background=COLOR_FONDO)
    style.configure("Card.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("Panel.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("Footer.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("RedLine.TFrame", background=COLOR_RODRIGUEZ)

    style.configure("TLabel", background=COLOR_FONDO, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure(
        "Title.TLabel",
        background=COLOR_FONDO,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TITULO,
        padding=(0, 4, 0, 2),
    )
    style.configure("Subtitle.TLabel", background=COLOR_FONDO, foreground=COLOR_MUTED, font=FUENTE_SUBTITULO)
    style.configure("Card.TLabel", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure("Panel.TLabel", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure(
        "CardTitle.TLabel",
        background=COLOR_TARJETA,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TARJETA_TITULO,
        padding=(0, 0, 0, 4),
    )
    style.configure(
        "PanelTitle.TLabel",
        background=COLOR_TARJETA,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TARJETA_TITULO,
        padding=(0, 0, 0, 4),
    )
    style.configure("Muted.Card.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_MUTED)
    style.configure("Status.TLabel", background=COLOR_ESTADO, foreground=COLOR_TEXTO, font=FUENTE_BOTON, padding=STATUS_PADDING)
    style.configure("Version.TLabel", background=COLOR_FONDO, foreground=COLOR_MUTED, font=FUENTE_VERSION)
    style.configure("Version.Footer.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_VERSION)
    style.configure("Author.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_FOOTER)
    style.configure("Logo.TLabel", background=COLOR_TARJETA)
    style.configure("Warning.TLabel", background=COLOR_TARJETA, foreground=COLOR_AVISO, font=FUENTE_BOTON)
    style.configure("Error.TLabel", background=COLOR_TARJETA, foreground=COLOR_ERROR, font=FUENTE_BOTON)
    style.configure("Success.TLabel", background=COLOR_TARJETA, foreground=COLOR_OK, font=FUENTE_BOTON)

    button_common = {
        "font": FUENTE_BOTON,
        "padding": (16, 10),
        "borderwidth": 2,
        "relief": "solid",
        "focusthickness": 2,
        "focuscolor": COLOR_FOCUS,
    }
    # Estado normal: pasos anteriores que siguen activos. Fondo neutro y borde visible.
    style.configure(
        "TButton",
        **button_common,
        foreground=COLOR_TEXTO,
        background=p["boton_sec"],
        bordercolor=p["boton_sec_border"],
    )
    style.map(
        "TButton",
        background=[("active", p["boton_sec_active"]), ("pressed", p["boton_sec_active"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    style.configure("Primary.TButton", **button_common, foreground=p["principal_fg"], background=COLOR_PRINCIPAL, bordercolor=COLOR_PRINCIPAL)
    style.map(
        "Primary.TButton",
        background=[("active", COLOR_PRINCIPAL_HOVER), ("pressed", COLOR_PRINCIPAL_HOVER), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    # Siguiente paso: unico boton azul de accion principal.
    style.configure("Next.TButton", **button_common, foreground=p["principal_fg"], background=COLOR_PRINCIPAL, bordercolor=COLOR_PRINCIPAL)
    style.map(
        "Next.TButton",
        background=[("active", COLOR_PRINCIPAL_HOVER), ("pressed", COLOR_PRINCIPAL_HOVER), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    # Boton activo pero protegido por confirmacion. Azul secundario distinto del boton de siguiente paso.
    style.configure("Protected.TButton", **button_common, foreground=p["protected_fg"], background=p["protected_bg"], bordercolor=p["protected_fg"])
    style.map(
        "Protected.TButton",
        foreground=[("!disabled", p["protected_fg"]), ("disabled", p["disabled_fg"])],
        background=[("active", p["protected_active"]), ("pressed", p["protected_active"]), ("disabled", p["disabled_bg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", p["protected_fg"])],
    )
    style.configure("Secondary.TButton", **button_common, foreground=COLOR_TEXTO, background=p["boton_sec"], bordercolor=p["boton_sec_border"])
    style.map(
        "Secondary.TButton",
        background=[("active", p["boton_sec_active"]), ("pressed", p["boton_sec_active"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    style.configure("Danger.TButton", **button_common, foreground=COLOR_ERROR, background=p["danger_bg"], bordercolor=COLOR_ERROR)
    style.map(
        "Danger.TButton",
        foreground=[("!disabled", COLOR_ERROR), ("disabled", p["disabled_fg"])],
        background=[("active", p["danger_active"]), ("pressed", p["danger_active"]), ("disabled", p["disabled_bg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_FOCUS), ("active", COLOR_ERROR)],
    )

    style.configure("TRadiobutton", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE, padding=4)
    style.map("TRadiobutton", foreground=[("disabled", p["disabled_fg"])], background=[("active", COLOR_TARJETA)])
    style.configure(
        "TEntry",
        fieldbackground=p["field"],
        foreground=COLOR_TEXTO,
        insertcolor=COLOR_TEXTO,
        padding=7,
        borderwidth=1,
        bordercolor=COLOR_BORDE,
        focuscolor=COLOR_FOCUS,
    )
    style.map("TEntry", bordercolor=[("focus", COLOR_FOCUS)], foreground=[("disabled", p["disabled_fg"])])
    style.configure(
        "TCombobox",
        fieldbackground=p["field"],
        background=p["field"],
        foreground=COLOR_TEXTO,
        arrowcolor=COLOR_TEXTO,
        padding=7,
        borderwidth=1,
    )
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", p["field"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("focus", COLOR_FOCUS)],
    )
    style.configure("Vertical.TScrollbar", background=p["boton_sec"], troughcolor=COLOR_FONDO, bordercolor=COLOR_BORDE, arrowcolor=COLOR_TEXTO)
    style.configure("Horizontal.TScrollbar", background=p["boton_sec"], troughcolor=COLOR_FONDO, bordercolor=COLOR_BORDE, arrowcolor=COLOR_TEXTO)
    style.configure("Treeview", background=COLOR_TARJETA, fieldbackground=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE, rowheight=28)
    style.configure(
        "Treeview.Heading",
        background=COLOR_ESTADO,
        foreground=COLOR_PRINCIPAL,
        font=(FUENTE_BOTON[0], FUENTE_BOTON[1] + 1, "bold"),
        padding=(8, 7),
    )
    style.map("Treeview", background=[("selected", COLOR_SELECCION)], foreground=[("selected", COLOR_SELECCION_TEXTO)])
    style.configure("TProgressbar", background=COLOR_PRINCIPAL, troughcolor=COLOR_ESTADO, bordercolor=COLOR_BORDE, lightcolor=COLOR_PRINCIPAL, darkcolor=COLOR_PRINCIPAL)

    if ventana is not None:
        configurar_opciones_ventana(ventana)
        actualizar_widgets_tk(ventana)
    return style


configurar_ttk = configurar_ttk_unificado


def configurar_opciones_ventana(ventana: tk.Misc) -> None:
    try:
        ventana.option_add("*Font", FUENTE_BASE)
        ventana.option_add("*TButton*Font", FUENTE_BOTON)
        ventana.option_add("*selectBackground", COLOR_SELECCION)
        ventana.option_add("*selectForeground", COLOR_SELECCION_TEXTO)
    except Exception:
        pass


def configurar_ventana_base(ventana: tk.Misc, titulo: str, redimensionable: bool = True) -> None:
    """Aplica titulo, geometria, fondo y minimos comunes."""
    try:
        ventana.title(titulo)
    except Exception:
        pass
    try:
        ventana.geometry(VENTANA_GEOMETRIA)
        ventana.minsize(VENTANA_MIN_ANCHO, VENTANA_MIN_ALTO)
        ventana.configure(bg=COLOR_FONDO)
        ventana.resizable(redimensionable, redimensionable)
        # Apertura inicial maximizada en Windows. No se usa fullscreen exclusivo
        # para conservar barra de tareas, Alt+Tab y controles de ventana.
        try:
            ventana.state("zoomed")
        except Exception:
            try:
                ventana.attributes("-zoomed", True)
            except Exception:
                pass
    except Exception:
        pass
    configurar_opciones_ventana(ventana)


def configurar_aplicacion(ventana: tk.Misc, titulo: str, *, tema: str | None = None, redimensionable: bool = True) -> ttk.Style:
    configurar_ventana_base(ventana, titulo, redimensionable=redimensionable)
    return configurar_ttk_unificado(ventana, tema)


def aplicar_modo_compacto_ventana(ventana: tk.Misc, activo: bool) -> None:
    try:
        if activo:
            try:
                ventana.state("normal")
            except Exception:
                pass
            ventana.minsize(VENTANA_COMPACTA_MIN_ANCHO, VENTANA_COMPACTA_MIN_ALTO)
            ventana.geometry(VENTANA_COMPACTA_GEOMETRIA)
        else:
            ventana.minsize(VENTANA_MIN_ANCHO, VENTANA_MIN_ALTO)
            ventana.geometry(VENTANA_GEOMETRIA)
            try:
                ventana.state("zoomed")
            except Exception:
                pass
    except Exception:
        pass


def crear_linea_roja(padre: tk.Misc, fila: int = 2, columna: int = 0, columnspan: int = 1, pady=(10, 0)) -> ttk.Frame:
    linea = ttk.Frame(padre, style="RedLine.TFrame", height=RED_LINE_HEIGHT)
    linea.grid(row=fila, column=columna, columnspan=columnspan, sticky="ew", pady=pady)
    return linea


def crear_frame_app(padre: tk.Misc) -> ttk.Frame:
    return ttk.Frame(padre, style="App.TFrame", padding=PAD_APP)


def crear_panel(padre: tk.Misc, *, compacto: bool = False, estilo: str = "Panel.TFrame") -> ttk.Frame:
    return ttk.Frame(padre, style=estilo, padding=PAD_PANEL_COMPACT if compacto else PAD_PANEL)


def crear_tarjeta(padre: tk.Misc, *, padding=None) -> ttk.Frame:
    return ttk.Frame(padre, style="Card.TFrame", padding=padding or PAD_CARD)


def crear_text_frame(padre: tk.Misc) -> tk.Frame:
    return tk.Frame(
        padre,
        bg=COLOR_TARJETA,
        highlightbackground=COLOR_BORDE,
        highlightcolor=COLOR_FOCUS,
        highlightthickness=TEXT_BORDER_WIDTH,
        bd=0,
    )


def aplicar_texto_tk(widget: tk.Text, *, mono: bool = True, alto: int | None = None) -> None:
    """Aplica colores, fuente, seleccion y foco a tk.Text."""
    kwargs = {
        "font": FUENTE_MONO if mono else FUENTE_BASE,
        "bg": COLOR_TARJETA,
        "fg": COLOR_TEXTO,
        "insertbackground": COLOR_TEXTO,
        "selectbackground": COLOR_SELECCION,
        "selectforeground": COLOR_SELECCION_TEXTO,
        "highlightbackground": COLOR_BORDE,
        "highlightcolor": COLOR_FOCUS,
        "highlightthickness": TEXT_BORDER_WIDTH,
    }
    if alto is not None:
        kwargs["height"] = alto
    widget.configure(**kwargs)


def configurar_tags_texto(widget: tk.Text) -> None:
    """Tags visuales comunes para avisos, errores y resultados en tk.Text."""
    widget.tag_configure("titulo", font=FUENTE_MONO, foreground=COLOR_PRINCIPAL)
    widget.tag_configure("comentario", foreground=COLOR_MUTED)
    widget.tag_configure("error", foreground=COLOR_ERROR)
    widget.tag_configure("ok", foreground=COLOR_OK)
    widget.tag_configure("aviso", foreground=COLOR_AVISO)


def aplicar_logo_label(label: tk.Label | ttk.Label) -> None:
    try:
        label.configure(bd=0, bg=COLOR_TARJETA, highlightthickness=0)
    except tk.TclError:
        try:
            label.configure(style="Logo.TLabel")
        except Exception:
            pass


def minimizar_ventana(ventana: tk.Misc) -> None:
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget: tk.Misc, ventana: tk.Misc) -> None:
    """Deja los logos como elementos decorativos, no como acciones ocultas."""
    try:
        widget.configure(cursor="", takefocus=False)
        widget.unbind("<Button-1>")
        widget.unbind("<Return>")
        widget.unbind("<space>")
        widget.unbind("<FocusIn>")
        widget.unbind("<FocusOut>")
    except Exception:
        pass


def _configurar_highlight(widget: tk.Misc, color: str) -> None:
    try:
        widget.configure(highlightbackground=color, highlightcolor=color, highlightthickness=2)
    except Exception:
        pass


def aplicar_icono_ventana(ventana: tk.Misc) -> None:
    """Aplica ICONO_SUITE como icono cuando el sistema lo permite."""
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass


def cargar_imagen_logo(nombre: str, max_size: tuple[int, int]):
    """Carga un logo con Pillow si esta disponible. Devuelve ImageTk.PhotoImage o None."""
    try:
        from PIL import Image, ImageTk
    except ImportError:
        return None
    try:
        img = Image.open(ruta_recurso(nombre))
        img.thumbnail(max_size)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None


def crear_footer_simple(padre: tk.Misc, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    footer = ttk.Frame(padre, style="Footer.TFrame", padding=PAD_FOOTER)
    ttk.Label(footer, text=texto, style="Author.TLabel", anchor="center").pack(fill="x")
    return footer


def crear_footer(padre: tk.Misc, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    return crear_footer_simple(padre, texto)


def crear_footer_con_salida(padre: tk.Misc, salir=None, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    footer = ttk.Frame(padre, style="Footer.TFrame", padding=PAD_FOOTER)
    footer.columnconfigure(0, weight=1)
    ttk.Label(footer, text=texto, style="Author.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
    if salir:
        ttk.Button(footer, text="Salir", command=salir, style="Danger.TButton").grid(row=1, column=0, pady=(8, 0))
    return footer


def configurar_atajos_comunes(ventana: tk.Misc, *, guardar=None, limpiar=None, abrir=None, salir=None) -> None:
    """Atajos comunes sin alterar comandos existentes."""
    if guardar:
        ventana.bind("<Control-s>", lambda _e: guardar())
        ventana.bind("<Control-S>", lambda _e: guardar())
    if limpiar:
        ventana.bind("<Control-l>", lambda _e: limpiar())
        ventana.bind("<Control-L>", lambda _e: limpiar())
    if abrir:
        ventana.bind("<Control-o>", lambda _e: abrir())
        ventana.bind("<Control-O>", lambda _e: abrir())
    if salir:
        ventana.bind("<Escape>", lambda _e: salir())


def configurar_boton_estado(widget: tk.Misc, activo: bool) -> None:
    """Activa o desactiva un boton evitando errores prevenibles."""
    try:
        widget.configure(state="normal" if activo else "disabled")
    except Exception:
        pass


def anunciar_estado(label: tk.Misc, texto: str) -> None:
    """Actualiza un estado visible y mueve el foco cuando el cambio es importante."""
    try:
        label.configure(text=texto)
        label.focus_set()
    except Exception:
        pass


def preparar_dialogo_parent(widget: tk.Misc | None):
    return widget


def crear_header(padre: tk.Misc, titulo: str, subtitulo: str = "") -> ttk.Frame:
    header = ttk.Frame(padre, style="App.TFrame")
    header.columnconfigure(0, weight=1)
    ttk.Label(header, text=titulo, style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
    row_line = 1
    if subtitulo:
        ttk.Label(header, text=subtitulo, style="Subtitle.TLabel", anchor="center", wraplength=980).grid(row=1, column=0, sticky="ew", pady=(6, 0))
        row_line = 2
    ttk.Frame(header, style="RedLine.TFrame", height=RED_LINE_HEIGHT).grid(row=row_line, column=0, sticky="ew", pady=(10, 0))
    return header


def crear_tarjeta_visual(padre: tk.Misc, titulo: str | None = None, *, padding=None) -> ttk.Frame:
    card = ttk.Frame(padre, style="Card.TFrame", padding=padding or PAD_CARD)
    if titulo:
        ttk.Label(card, text=titulo, style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        card._suite_next_row = 1
    else:
        card._suite_next_row = 0
    return card


def crear_indicador_estado(padre: tk.Misc, texto: str = "Sin actividad", *, anchor: str = "center") -> ttk.Label:
    return ttk.Label(padre, text=texto, style="Status.TLabel", anchor=anchor, justify="center", wraplength=980)


def crear_panel_indicadores(padre: tk.Misc, indicadores: list[tuple[str, str]] | None = None) -> ttk.Frame:
    panel = ttk.Frame(padre, style="Card.TFrame", padding=PAD_PANEL_COMPACT)
    for col, (titulo, valor) in enumerate(indicadores or [("Estado", "Sin actividad")]):
        panel.columnconfigure(col, weight=1, uniform="estado")
        bloque = ttk.Frame(panel, style="Card.TFrame")
        bloque.grid(row=0, column=col, sticky="ew", padx=4)
        ttk.Label(bloque, text=titulo, style="Muted.Card.TLabel", anchor="center").pack(fill="x")
        ttk.Label(bloque, text=valor, style="Status.TLabel", anchor="center").pack(fill="x", pady=(4, 0))
    return panel


def crear_botonera_inferior(padre: tk.Misc, botones: list[tuple[str, object, str]] | None = None) -> ttk.Frame:
    barra = ttk.Frame(padre, style="Card.TFrame", padding=PAD_PANEL_COMPACT)
    for i, (texto, comando, variante) in enumerate(botones or []):
        estilo = {"primario": "Primary.TButton", "peligro": "Danger.TButton"}.get(variante, "Secondary.TButton")
        barra.columnconfigure(i, weight=1, uniform="botonera")
        ttk.Button(barra, text=texto, command=comando, style=estilo).grid(row=0, column=i, sticky="ew", padx=4)
    return barra


def actualizar_widgets_tk(widget: tk.Misc) -> None:
    """Refresca widgets Tk no-ttk para que sigan el tema activo."""
    try:
        if isinstance(widget, (tk.Tk, tk.Toplevel)):
            widget.configure(bg=COLOR_FONDO)
        elif isinstance(widget, tk.Text):
            aplicar_texto_tk(widget, mono=(str(widget.cget("font")).lower().find("consol") >= 0))
            configurar_tags_texto(widget)
        elif isinstance(widget, tk.Canvas):
            widget.configure(bg=COLOR_TARJETA, highlightbackground=COLOR_BORDE, highlightcolor=COLOR_FOCUS)
        elif isinstance(widget, tk.Frame):
            widget.configure(bg=COLOR_TARJETA, highlightbackground=COLOR_BORDE, highlightcolor=COLOR_FOCUS)
        elif isinstance(widget, tk.Label):
            widget.configure(bg=COLOR_TARJETA, fg=COLOR_TEXTO)
    except Exception:
        pass
    try:
        for child in widget.winfo_children():
            actualizar_widgets_tk(child)
    except Exception:
        pass


def obtener_tema_actual() -> str:
    return TEMA_ACTUAL


def alternar_modo_oscuro(ventana: tk.Misc | None = None) -> str:
    nuevo = "oscuro" if TEMA_ACTUAL != "oscuro" else "claro"
    configurar_ttk_unificado(ventana, nuevo)
    establecer_preferencia("tema", nuevo)
    if ventana is not None:
        actualizar_widgets_tk(ventana)
    return nuevo


def refrescar_tema_ventana(ventana: tk.Misc | None = None) -> None:
    if ventana is not None:
        configurar_ttk_unificado(ventana, TEMA_ACTUAL)
        actualizar_widgets_tk(ventana)
