#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generador de TXT de precintos de expedicion de jamones para AX."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import os
from pathlib import Path
import re
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import unicodedata

try:
    import openpyxl
except ImportError:  # pragma: no cover - se valida en runtime con mensaje de usuario
    openpyxl = None

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_atajos_comunes as suite_configurar_atajos_comunes,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    ejecutar_con_bloqueo_temporal as suite_ejecutar_con_bloqueo_temporal,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    preparar_ventana_sin_parpadeo as suite_preparar_ventana_sin_parpadeo,
    recordar_directorio as suite_recordar_directorio,
)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

EXTENSIONES_EXCEL = {".xlsx", ".xlsm"}
PESO_MIL = Decimal("0.001")


@dataclass(frozen=True)
class RegistroEntrada:
    codigo_articulo: str
    codigo_externo: str
    lote: str
    lote_proveedor: str
    precinto: str
    peso_neto: Decimal
    id_pallet: str


@dataclass(frozen=True)
class RegistroSalida:
    articulo: str
    id_pallet: str
    unidades: int
    kilos: Decimal


@dataclass(frozen=True)
class ExcelDetectado:
    ruta: Path
    tipo: str
    filas: list[RegistroEntrada] | list[RegistroSalida]


@dataclass(frozen=True)
class ResultadoGeneracion:
    lineas: list[str]
    precintos_usados: int
    unidades_salida: int
    kilos_salida: Decimal
    jumbos: int


def ruta_recurso(nombre: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / nombre  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent / nombre


def aplicar_icono_ventana(ventana):
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def normalizar_texto(valor) -> str:
    texto = unicodedata.normalize("NFKD", str(valor or ""))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = re.sub(r"[^a-zA-Z0-9]+", " ", texto).strip().lower()
    return re.sub(r"\s+", " ", texto)


def limpiar_codigo(valor) -> str:
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    texto = str(valor).strip()
    if re.fullmatch(r"\d+(?:\.0+)?", texto):
        return texto.split(".", 1)[0]
    return texto


def limpiar_precinto(valor) -> str:
    return re.sub(r"\D+", "", limpiar_codigo(valor))


def decimal_desde_valor(valor, campo: str) -> Decimal:
    if valor is None or str(valor).strip() == "":
        raise ValueError(f"{campo} vacio")
    if isinstance(valor, str):
        texto = valor.strip()
        if "," in texto:
            texto = texto.replace(".", "").replace(",", ".")
    else:
        texto = str(valor)
    try:
        return Decimal(texto)
    except InvalidOperation as exc:
        raise ValueError(f"{campo} no numerico: {valor}") from exc


def decimal_desde_usuario(valor: str, campo: str) -> Decimal:
    texto = str(valor or "").strip().replace(",", ".")
    if not texto:
        raise ValueError(f"Introduce {campo}.")
    try:
        return Decimal(texto)
    except InvalidOperation as exc:
        raise ValueError(f"{campo} no es un numero valido.") from exc


def cabeceras_normalizadas(ws) -> tuple[dict[str, int], list[str]]:
    fila = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
    if not fila:
        return {}, []
    originales = [str(v or "").strip() for v in fila]
    return {normalizar_texto(v): i for i, v in enumerate(originales) if str(v or "").strip()}, originales


def indice(cabeceras: dict[str, int], nombre: str) -> int | None:
    return cabeceras.get(normalizar_texto(nombre))


def es_excel_entrada(cabeceras: dict[str, int]) -> bool:
    requeridas = ["codigo de articulo", "numero de lote", "numero de lote del proveedor", "peso neto", "precinto", "id de pallet"]
    return all(indice(cabeceras, nombre) is not None for nombre in requeridas)


def es_excel_salida(cabeceras: dict[str, int]) -> bool:
    requeridas = ["id de pallet", "unidades", "kilos"]
    return all(indice(cabeceras, nombre) is not None for nombre in requeridas)


def leer_excel(ruta: Path) -> ExcelDetectado:
    if openpyxl is None:
        raise RuntimeError("No esta disponible openpyxl para leer Excel.")
    wb = openpyxl.load_workbook(ruta, data_only=True, read_only=True)
    ws = wb.active
    cabeceras, _originales = cabeceras_normalizadas(ws)
    if es_excel_entrada(cabeceras):
        return ExcelDetectado(ruta=ruta, tipo="entrada", filas=leer_filas_entrada(ws, cabeceras))
    if es_excel_salida(cabeceras):
        return ExcelDetectado(ruta=ruta, tipo="salida", filas=leer_filas_salida(ws, cabeceras))
    raise ValueError("no coincide con el formato de entrada ni de salida de expedicion")


def leer_filas_entrada(ws, cabeceras: dict[str, int]) -> list[RegistroEntrada]:
    i_codigo = indice(cabeceras, "codigo de articulo")
    i_externo = indice(cabeceras, "codigo de articulo externo")
    i_lote = indice(cabeceras, "numero de lote")
    i_proveedor = indice(cabeceras, "numero de lote del proveedor")
    i_peso = indice(cabeceras, "peso neto")
    i_precinto = indice(cabeceras, "precinto")
    i_pallet = indice(cabeceras, "id de pallet")
    if None in (i_codigo, i_lote, i_proveedor, i_peso, i_precinto, i_pallet):
        raise ValueError("faltan columnas obligatorias de entrada")
    registros: list[RegistroEntrada] = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        precinto = limpiar_precinto(row[i_precinto])
        if not precinto:
            continue
        try:
            peso = decimal_desde_valor(row[i_peso], "Peso neto")
        except ValueError:
            continue
        registros.append(
            RegistroEntrada(
                codigo_articulo=limpiar_codigo(row[i_codigo]),
                codigo_externo=limpiar_codigo(row[i_externo]) if i_externo is not None else "",
                lote=limpiar_codigo(row[i_lote]),
                lote_proveedor=limpiar_codigo(row[i_proveedor]),
                precinto=precinto,
                peso_neto=peso,
                id_pallet=limpiar_codigo(row[i_pallet]),
            )
        )
    if not registros:
        raise ValueError("no hay lineas de entrada con precinto")
    return registros


def leer_filas_salida(ws, cabeceras: dict[str, int]) -> list[RegistroSalida]:
    i_articulo = indice(cabeceras, "codigo de articulo")
    i_pallet = indice(cabeceras, "id de pallet")
    i_unidades = indice(cabeceras, "unidades")
    i_kilos = indice(cabeceras, "kilos")
    if None in (i_pallet, i_unidades, i_kilos):
        raise ValueError("faltan columnas obligatorias de salida")
    registros: list[RegistroSalida] = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        unidades_valor = row[i_unidades]
        kilos_valor = row[i_kilos]
        if unidades_valor is None or kilos_valor is None:
            continue
        try:
            unidades = int(decimal_desde_valor(unidades_valor, "Unidades"))
            kilos = decimal_desde_valor(kilos_valor, "Kilos")
        except ValueError:
            continue
        if unidades <= 0:
            continue
        registros.append(
            RegistroSalida(
                articulo=limpiar_codigo(row[i_articulo]) if i_articulo is not None else "",
                id_pallet=limpiar_codigo(row[i_pallet]),
                unidades=unidades,
                kilos=kilos,
            )
        )
    if not registros:
        raise ValueError("no hay jumbos de salida con unidades")
    return registros


def pallets_disponibles(registros: list[RegistroEntrada]) -> list[str]:
    vistos: set[str] = set()
    pallets: list[str] = []
    for registro in registros:
        if registro.id_pallet and registro.id_pallet not in vistos:
            vistos.add(registro.id_pallet)
            pallets.append(registro.id_pallet)
    return pallets


def filtrar_precintos_por_pallets(registros: list[RegistroEntrada], pallets: list[str]) -> list[RegistroEntrada]:
    seleccionados = set(pallets)
    if not seleccionados:
        raise ValueError("Selecciona al menos un Id de pallet de entrada.")
    return [registro for registro in registros if registro.id_pallet in seleccionados and registro.precinto]


def resumen_pivot_entrada(registros: list[RegistroEntrada]) -> list[tuple[str, str, int, Decimal]]:
    resumen: dict[tuple[str, str], tuple[int, Decimal]] = {}
    for registro in registros:
        clave = (registro.codigo_articulo, registro.id_pallet)
        cuenta, peso = resumen.get(clave, (0, Decimal("0")))
        resumen[clave] = (cuenta + 1, peso + registro.peso_neto)
    filas = [(codigo, pallet, cuenta, peso) for (codigo, pallet), (cuenta, peso) in resumen.items()]
    return sorted(filas, key=lambda item: (item[0], item[1]))


def miligramos_desde_kilos(kilos: Decimal) -> int:
    return int((kilos * Decimal(1000)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def repartir_pesos_milesimas(kilos: Decimal, unidades: int) -> list[int]:
    if unidades <= 0:
        raise ValueError("Las unidades deben ser mayores que cero.")
    total_milesimas = miligramos_desde_kilos(kilos)
    base = total_milesimas // unidades
    resto = total_milesimas % unidades
    return [base + 1 if i < resto else base for i in range(unidades)]


def formato_peso_milesimas(milesimas: int) -> str:
    entero = milesimas // 1000
    decimal = abs(milesimas % 1000)
    return f"{entero:02d},{decimal:03d}"


def generar_txt_expedicion(
    entradas_filtradas: list[RegistroEntrada],
    salidas: list[RegistroSalida],
    inicio: datetime | None = None,
) -> ResultadoGeneracion:
    total_unidades = sum(salida.unidades for salida in salidas)
    if len(entradas_filtradas) != total_unidades:
        raise ValueError(
            f"Los precintos filtrados ({len(entradas_filtradas)}) no coinciden con las unidades de salida ({total_unidades})."
        )
    inicio = inicio or datetime.now()
    lineas: list[str] = []
    indice_precinto = 0
    segundo = 0
    for salida in salidas:
        pesos = repartir_pesos_milesimas(salida.kilos, salida.unidades)
        if sum(pesos) != miligramos_desde_kilos(salida.kilos):
            raise ValueError(f"No cuadra el peso del jumbo {salida.id_pallet}.")
        for peso in pesos:
            entrada = entradas_filtradas[indice_precinto]
            momento = inicio + timedelta(seconds=segundo)
            lineas.append(
                ";".join(
                    [
                        entrada.lote_proveedor,
                        momento.strftime("%d/%m/%Y"),
                        momento.strftime("%H:%M:%S"),
                        entrada.codigo_externo,
                        entrada.precinto,
                        entrada.lote,
                        formato_peso_milesimas(peso),
                        "",
                    ]
                )
            )
            indice_precinto += 1
            segundo += 1
    kilos = sum((salida.kilos for salida in salidas), Decimal("0"))
    return ResultadoGeneracion(
        lineas=lineas,
        precintos_usados=len(entradas_filtradas),
        unidades_salida=total_unidades,
        kilos_salida=kilos,
        jumbos=len(salidas),
    )


def texto_decimal(valor: Decimal) -> str:
    texto = format(valor.normalize(), "f")
    return texto.replace(".", ",")


class PrecintosExpedicionApp:
    def __init__(self, ventana: tk.Tk | tk.Toplevel):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Precintos de Expedicion")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)

        self.rutas: list[Path] = []
        self.entrada: ExcelDetectado | None = None
        self.salida: ExcelDetectado | None = None
        self.resultado: ResultadoGeneracion | None = None
        self.pallets_entrada: list[str] = []
        self.resumen_var = tk.StringVar(value="Selecciona los Excel generados por AX.")
        self.estado_var = tk.StringVar(value="Listo para cargar archivos.")
        self._logo_rodriguez = None
        self._logo_finura = None

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_atajos()
        self._actualizar_botones()

    def configurar_estilos(self):
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(2, weight=1)

        cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(22, 10))
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(cabecera, text="Precintos de Expedicion", style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
        ttk.Label(
            cabecera,
            text="Genera el TXT de expedicion para AX a partir de los Excel de entrada y salida.",
            style="Subtitle.TLabel",
            anchor="center",
            wraplength=980,
        ).grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        panel_canvas.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 10))
        panel = panel_canvas.body
        for col in range(4):
            panel.columnconfigure(col, weight=1 if col == 1 else 0)
        ttk.Label(panel, text="Flujo de trabajo", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 12))
        self.boton_seleccionar = ttk.Button(panel, text="Seleccionar Excel", command=self.seleccionar_archivos, style="Primary.TButton")
        self.boton_seleccionar.grid(row=0, column=1, sticky="ew", padx=5)
        self.boton_procesar = ttk.Button(panel, text="Comprobar", command=lambda: self._ejecutar_ocupado(self.procesar), style="Primary.TButton")
        self.boton_procesar.grid(row=0, column=2, sticky="ew", padx=5)
        self.boton_limpiar = ttk.Button(panel, text="Limpiar", command=self.limpiar, style="Secondary.TButton")
        self.boton_limpiar.grid(row=0, column=3, sticky="ew", padx=(5, 0))

        self.pasos_flujo = []
        flujo = ttk.Frame(panel, style="Card.TFrame")
        flujo.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(12, 0))
        for col, texto_paso in enumerate(("1. Adjuntar exceles", "2. Seleccionar pallet/s", "3. Comprobar", "4. Guardar")):
            flujo.columnconfigure(col, weight=1, uniform="pasos")
            lbl = ttk.Label(flujo, text=texto_paso, style="Muted.Card.TLabel", anchor="center")
            lbl.grid(row=0, column=col, sticky="ew", padx=4)
            self.pasos_flujo.append(lbl)

        self.lbl_resumen = ttk.Label(panel, textvariable=self.resumen_var, style="Card.TLabel", wraplength=980)
        self.lbl_resumen.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(10, 0))
        ttk.Label(panel, text="Id de pallet de entrada", style="Card.TLabel").grid(row=3, column=0, columnspan=4, sticky="w", pady=(10, 2))
        selector = ttk.Frame(panel, style="Card.TFrame")
        selector.grid(row=4, column=0, columnspan=4, sticky="ew")
        selector.columnconfigure(0, weight=1)
        self.lista_pallets = tk.Listbox(selector, selectmode="extended", height=5, exportselection=False)
        self.lista_pallets.grid(row=0, column=0, sticky="ew")
        self.scroll_pallets = ttk.Scrollbar(selector, orient="vertical", command=self.lista_pallets.yview)
        self.scroll_pallets.grid(row=0, column=1, sticky="ns")
        self.lista_pallets.configure(yscrollcommand=self.scroll_pallets.set)
        self.lista_pallets.bind("<<ListboxSelect>>", self._al_cambiar_pallets)
        suite_configurar_orden_tabulacion(
            self.boton_seleccionar,
            self.lista_pallets,
            self.boton_procesar,
            self.boton_limpiar,
        )
        self._actualizar_flujo(1)

        cuerpo = ttk.Frame(self.ventana, style="TFrame")
        cuerpo.grid(row=2, column=0, sticky="nsew", padx=28, pady=8)
        cuerpo.columnconfigure(0, weight=3)
        cuerpo.columnconfigure(1, weight=2)
        cuerpo.rowconfigure(0, weight=1)

        preview_canvas = suite_crear_panel_canvas(cuerpo, padding=SUITE_PAD_PANEL)
        preview_canvas.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        preview = preview_canvas.body
        preview.columnconfigure(0, weight=1)
        preview.rowconfigure(1, weight=1)
        ttk.Label(preview, text="TXT generado", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.texto = tk.Text(preview, wrap="none", undo=False)
        suite_aplicar_texto_tk(self.texto, mono=True)
        self.texto.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll_y = ttk.Scrollbar(preview, orient="vertical", command=self.texto.yview)
        scroll_y.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        scroll_x = ttk.Scrollbar(preview, orient="horizontal", command=self.texto.xview)
        scroll_x.grid(row=2, column=0, sticky="ew")
        self.texto.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self._actualizar_preview()

        log_canvas = suite_crear_panel_canvas(cuerpo, padding=SUITE_PAD_PANEL)
        log_canvas.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        zona_log = log_canvas.body
        zona_log.columnconfigure(0, weight=1)
        zona_log.rowconfigure(2, weight=1)
        ttk.Label(zona_log, text="Validacion", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.log = tk.Text(zona_log, wrap="word", state="disabled", height=5)
        suite_aplicar_texto_tk(self.log, mono=False, alto=5)
        self.log.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 8))
        columnas = ("codigo", "pallet", "cuenta", "peso")
        self.tabla_resumen = ttk.Treeview(zona_log, columns=columnas, show="headings", height=12)
        self.tabla_resumen.heading("codigo", text="Codigo articulo")
        self.tabla_resumen.heading("pallet", text="Id de pallet")
        self.tabla_resumen.heading("cuenta", text="Cuenta precinto")
        self.tabla_resumen.heading("peso", text="Suma peso neto")
        self.tabla_resumen.column("codigo", width=110, anchor="w")
        self.tabla_resumen.column("pallet", width=165, anchor="w")
        self.tabla_resumen.column("cuenta", width=100, anchor="e")
        self.tabla_resumen.column("peso", width=110, anchor="e")
        self.tabla_resumen.grid(row=2, column=0, sticky="nsew")
        scroll_tabla = ttk.Scrollbar(zona_log, orient="vertical", command=self.tabla_resumen.yview)
        scroll_tabla.grid(row=2, column=1, sticky="ns")
        self.tabla_resumen.configure(yscrollcommand=scroll_tabla.set)
        self._actualizar_log("Selecciona dos Excel. La aplicacion detectara cual es entrada y cual es salida.")
        self._actualizar_tabla_resumen([])

        acciones_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL_COMPACT)
        acciones_canvas.grid(row=3, column=0, sticky="ew", padx=28, pady=(8, 10))
        acciones = acciones_canvas.body
        acciones.columnconfigure(0, weight=1)
        self.lbl_estado = ttk.Label(acciones, textvariable=self.estado_var, style="Status.TLabel", anchor="center", wraplength=980)
        self.lbl_estado.configure(takefocus=True)
        self.lbl_estado.grid(row=0, column=0, sticky="ew")
        self.boton_guardar = ttk.Button(acciones, text="Guardar TXT", command=lambda: self._ejecutar_ocupado(self.guardar_txt), style="Primary.TButton")
        self.boton_guardar.grid(row=0, column=1, sticky="e", padx=(10, 0))
        ttk.Button(acciones, text="Salir", command=self.salir, style="Danger.TButton").grid(row=0, column=2, sticky="e", padx=(10, 0))

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=4, column=0, sticky="ew", padx=28, pady=(0, 16))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")
        ttk.Label(footer, text=SUITE_FOOTER_TEXTO, style="Author.TLabel", anchor="center").grid(row=0, column=1, sticky="ew")
        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            return
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))
            img_izq.thumbnail((190, 70))
            img_der.thumbnail((190, 70))
            self._logo_finura = ImageTk.PhotoImage(img_izq)
            self._logo_rodriguez = ImageTk.PhotoImage(img_der)
            lbl_izq = tk.Label(self.logo_slot_izq, image=self._logo_finura)
            lbl_der = tk.Label(self.logo_slot_der, image=self._logo_rodriguez)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
        except Exception:
            pass

    def configurar_atajos(self):
        suite_configurar_atajos_comunes(self.ventana, abrir=self.seleccionar_archivos, guardar=self.guardar_txt, limpiar=self.limpiar, salir=self.salir)
        self.ventana.bind("<Control-p>", lambda _e: self.procesar())
        self.ventana.bind("<Control-P>", lambda _e: self.procesar())

    def _actualizar_flujo(self, paso_activo: int):
        for indice, etiqueta in enumerate(getattr(self, "pasos_flujo", []), start=1):
            try:
                etiqueta.configure(style="Status.TLabel" if indice == paso_activo else "Muted.Card.TLabel")
            except Exception:
                pass

    def _al_cambiar_pallets(self, _event=None):
        if self.resultado is not None:
            self.resultado = None
            self._actualizar_preview()
            self._set_estado("Seleccion modificada. Pulsa Comprobar antes de guardar.", importante=True)
        self._actualizar_flujo(3 if self._pallets_seleccionados() else 2)
        self._actualizar_botones()

    def _pallets_seleccionados(self) -> list[str]:
        try:
            return [self.lista_pallets.get(i) for i in self.lista_pallets.curselection()]
        except Exception:
            return []

    def _actualizar_tabla_resumen(self, filas: list[tuple[str, str, int, Decimal]]):
        for item in self.tabla_resumen.get_children():
            self.tabla_resumen.delete(item)
        for codigo, pallet, cuenta, peso in filas:
            self.tabla_resumen.insert("", "end", values=(codigo, pallet, cuenta, texto_decimal(peso.quantize(Decimal("0.001")))))

    def _set_estado(self, texto: str, importante: bool = False):
        self.estado_var.set(texto)
        if importante:
            suite_anunciar_estado(self.lbl_estado, texto)

    def _actualizar_log(self, texto: str):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.insert("1.0", texto)
        self.log.configure(state="disabled")

    def _actualizar_preview(self):
        self.texto.delete("1.0", "end")
        if self.resultado:
            self.texto.insert("1.0", "\r\n".join(self.resultado.lineas))
        else:
            self.texto.insert("1.0", "Aqui se mostrara el TXT antes de guardarlo.")

    def _actualizar_botones(self):
        listo = self.entrada is not None and self.salida is not None and bool(self._pallets_seleccionados())
        suite_configurar_boton_estado(self.boton_procesar, listo)
        suite_configurar_boton_estado(self.boton_guardar, self.resultado is not None)
        suite_configurar_boton_estado(self.boton_limpiar, bool(self.rutas or self.entrada or self.salida or self.resultado))

    def _ejecutar_ocupado(self, funcion):
        return suite_ejecutar_con_bloqueo_temporal(
            self.ventana,
            [self.boton_seleccionar, self.boton_procesar, self.boton_guardar, self.boton_limpiar],
            funcion,
            al_final=self._actualizar_botones,
        )

    def _hay_trabajo(self) -> bool:
        return bool(self.rutas or self.entrada or self.salida or self.resultado)

    def confirmar_accion_protegida(self, accion: str) -> bool:
        if not self._hay_trabajo():
            return True
        return messagebox.askyesno(
            "Accion protegida",
            f"Si continuas con '{accion}', se descartara el trabajo actual.\n\nConfirma que quieres continuar.",
            parent=self.ventana,
        )

    def seleccionar_archivos(self):
        if not self.confirmar_accion_protegida("Seleccionar nuevos Excel"):
            return
        rutas = filedialog.askopenfilenames(
            title="Seleccionar Excel de entrada y salida",
            initialdir=suite_obtener_ultimo_directorio("precintos_expedicion_abrir"),
            filetypes=[("Excel moderno", "*.xlsx *.xlsm"), ("Todos los archivos", "*.*")],
            parent=self.ventana,
        )
        if not rutas:
            return
        suite_recordar_directorio("precintos_expedicion_abrir", rutas[0])
        self.limpiar(sin_confirmar=True)
        self.rutas = [Path(r) for r in rutas]
        self.cargar_excels()

    def cargar_excels(self):
        detectados: list[ExcelDetectado] = []
        log: list[str] = []
        for ruta in self.rutas:
            if ruta.suffix.lower() not in EXTENSIONES_EXCEL:
                log.append(f"- Ignorado {ruta.name}: no es XLSX/XLSM.")
                continue
            try:
                detectado = leer_excel(ruta)
                detectados.append(detectado)
                log.append(f"- {ruta.name}: detectado como {detectado.tipo} ({len(detectado.filas)} filas utiles).")
            except Exception as exc:
                log.append(f"- ERROR {ruta.name}: {exc}")
        entradas = [d for d in detectados if d.tipo == "entrada"]
        salidas = [d for d in detectados if d.tipo == "salida"]
        if len(entradas) == 1:
            self.entrada = entradas[0]
        if len(salidas) == 1:
            self.salida = salidas[0]
        if len(entradas) > 1:
            log.append("- Hay mas de un Excel con formato de entrada. Selecciona solo uno.")
        if len(salidas) > 1:
            log.append("- Hay mas de un Excel con formato de salida. Selecciona solo uno.")
        self._preparar_codigos_y_resumen(log)
        self._actualizar_log("Resultado de deteccion:\n" + "\n".join(log))
        self._actualizar_botones()

    def _preparar_codigos_y_resumen(self, log: list[str]):
        if self.entrada is None or self.salida is None:
            self.resumen_var.set("Falta detectar un Excel de entrada y otro de salida.")
            self._actualizar_tabla_resumen([])
            self._actualizar_flujo(1)
            self._set_estado("Revisa los archivos seleccionados.", importante=True)
            return
        entradas = self.entrada.filas
        salidas = self.salida.filas
        assert isinstance(entradas, list)
        self.pallets_entrada = pallets_disponibles(entradas)  # type: ignore[arg-type]
        self.lista_pallets.delete(0, "end")
        for pallet in self.pallets_entrada:
            self.lista_pallets.insert("end", pallet)
        self._actualizar_tabla_resumen(resumen_pivot_entrada(entradas))  # type: ignore[arg-type]
        total_unidades = sum(r.unidades for r in salidas)  # type: ignore[union-attr]
        total_kilos = sum((r.kilos for r in salidas), Decimal("0"))  # type: ignore[union-attr]
        self.resumen_var.set(
            f"Entrada: {self.entrada.ruta.name} | Salida: {self.salida.ruta.name} | Pallets entrada: {len(self.pallets_entrada)} | Jumbos salida: {len(salidas)} | Unidades: {total_unidades} | Kilos: {texto_decimal(total_kilos)}"
        )
        log.append(f"- Pallets de entrada disponibles: {len(self.pallets_entrada)}.")
        self._actualizar_flujo(2)
        self._set_estado("Archivos cargados. Selecciona uno o varios Id de pallet y pulsa Comprobar.", importante=True)

    def procesar(self):
        if self.entrada is None or self.salida is None:
            messagebox.showinfo("Sin archivos", "Selecciona primero los Excel de entrada y salida.", parent=self.ventana)
            return
        try:
            entradas = self.entrada.filas
            salidas = self.salida.filas
            pallets = self._pallets_seleccionados()
            filtradas = filtrar_precintos_por_pallets(entradas, pallets)  # type: ignore[arg-type]
            resultado = generar_txt_expedicion(filtradas, salidas, inicio=datetime.now())  # type: ignore[arg-type]
        except Exception as exc:
            self.resultado = None
            self._actualizar_preview()
            self._actualizar_log(f"No se puede generar:\n- {exc}")
            self._actualizar_flujo(2)
            self._set_estado("No se genero el TXT. Revisa la seleccion de pallets.", importante=True)
            self._actualizar_botones()
            return
        self.resultado = resultado
        self._actualizar_preview()
        self._actualizar_log(
            "TXT comprobado correctamente:\n"
            f"- Pallets seleccionados: {len(self._pallets_seleccionados())}\n"
            f"- Jumbos procesados: {resultado.jumbos}\n"
            f"- Precintos usados: {resultado.precintos_usados}\n"
            f"- Unidades salida: {resultado.unidades_salida}\n"
            f"- Kilos salida: {texto_decimal(resultado.kilos_salida)}"
        )
        self._actualizar_flujo(4)
        self._set_estado(f"Comprobacion correcta: {len(resultado.lineas)} lineas listas para guardar.", importante=True)
        self._actualizar_botones()

    def guardar_txt(self):
        if self.resultado is None:
            messagebox.showinfo("Sin datos", "Genera primero el TXT.", parent=self.ventana)
            return
        ruta = filedialog.asksaveasfilename(
            title="Guardar TXT de expedicion",
            initialdir=suite_obtener_ultimo_directorio("precintos_expedicion_guardar"),
            defaultextension=".TXT",
            initialfile="SC.TXT",
            filetypes=[("Texto AX", "*.TXT"), ("Texto", "*.txt"), ("Todos los archivos", "*.*")],
            parent=self.ventana,
        )
        if not ruta:
            return
        suite_recordar_directorio("precintos_expedicion_guardar", ruta)
        destino = Path(ruta)
        try:
            with destino.open("w", encoding="utf-8-sig", newline="") as fh:
                fh.write("\r\n".join(self.resultado.lineas))
                fh.write("\r\n")
        except Exception as exc:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el TXT:\n{exc}", parent=self.ventana)
            return
        self._actualizar_flujo(4)
        self._set_estado(f"TXT guardado en formato Windows: {destino.name}", importante=True)
        messagebox.showinfo("TXT generado", f"Se han guardado {len(self.resultado.lineas)} lineas para AX.", parent=self.ventana)

    def limpiar(self, sin_confirmar: bool = False):
        if not sin_confirmar and not self.confirmar_accion_protegida("Limpiar"):
            return
        self.rutas = []
        self.entrada = None
        self.salida = None
        self.resultado = None
        self.pallets_entrada = []
        self.lista_pallets.delete(0, "end")
        self.resumen_var.set("Selecciona los Excel generados por AX.")
        self._actualizar_preview()
        self._actualizar_log("Selecciona dos Excel. La aplicacion detectara cual es entrada y cual es salida.")
        self._actualizar_tabla_resumen([])
        self._actualizar_flujo(1)
        self._set_estado("Listo para cargar archivos.", importante=True)
        self._actualizar_botones()

    def salir(self):
        if not self.confirmar_accion_protegida("Salir"):
            return
        self.ventana.destroy()


def lanzar_app_precintos_expedicion(master=None):
    ventana = tk.Toplevel(master) if master is not None else tk.Tk()
    suite_preparar_ventana_sin_parpadeo(ventana)
    PrecintosExpedicionApp(ventana)
    if master is None:
        suite_mostrar_ventana_sin_parpadeo(ventana, maximizar=True, enfocar=True, icono=True)
    return ventana


if __name__ == "__main__":
    root = tk.Tk()
    PrecintosExpedicionApp(root)
    root.mainloop()
