#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interfaz grafica para procesar ficheros TXT de PDA y generar un CSV limpio de palets.

Reglas:
1. Selecciona uno o varios TXT.
2. Cada linea se limpia eliminando letras, espacios y residuos no numericos.
3. Una lectura valida debe quedar como 20 digitos y empezar por los prefijos permitidos.
   Por defecto se acepta "00" para conservar casos como 0078 y 0048.
4. Si hay codigos que no pueden validarse automaticamente, se muestran para corregirlos.
5. Tras corregirlos, se revalidan y se integran con los validos iniciales.
6. Se eliminan los dos primeros ceros y se deduplican por los ultimos 10 digitos.
7. Permite elegir ubicacion y nombre del CSV final.
"""

from __future__ import annotations

# Propiedad intelectual: Departamento de Informatica (Daniel Lombo, Daniel R. Zapico, Lisardo Perez, Manuel Llamas, David Rubio y Nacho Rodriguez).

import csv
import os
import re
import sys
import tkinter as tk
from dataclasses import dataclass
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_APP as SUITE_PAD_APP,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_tags_texto as suite_configurar_tags_texto,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    recordar_directorio as suite_recordar_directorio,
)

from typing import Iterable, Sequence

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


# Prefijo por defecto:
# - "00" acepta codigos 0078... y 0048..., igual que el CSV de ejemplo facilitado.
# - Si se quisiera limitar a 0078, cambiar a PREFIJOS_VALIDOS = ["0078"]
PREFIJOS_VALIDOS = ["00"]


@dataclass
class IncidenciaCodigo:
    archivo: str
    linea: int
    original: str
    limpio: str


def ruta_recurso(nombre: str) -> Path:
    """Devuelve la ruta de un recurso tanto en .py normal como empaquetado con PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / nombre  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent / nombre


def normalizar_linea(linea: str) -> str:
    """Elimina letras, espacios y residuos, conservando solo digitos."""
    return re.sub(r"\D+", "", linea)


def es_codigo_valido(codigo: str, prefijos: Sequence[str]) -> bool:
    """Comprueba si el codigo tiene 20 digitos y empieza por algun prefijo permitido."""
    return len(codigo) == 20 and codigo.isdigit() and any(codigo.startswith(p) for p in prefijos)


def validar_lineas_txt(rutas_txt: Iterable[Path], prefijos: Sequence[str]) -> tuple[list[str], list[IncidenciaCodigo]]:
    """
    Lee los TXT y separa codigos validos e incidencias.

    La correccion automatica considerada "obvia" es quitar cualquier caracter no numerico.
    Si tras esa limpieza el codigo no queda en 20 digitos empezando por los prefijos permitidos,
    se considera incidencia para correccion manual.
    """
    lecturas_validas: list[str] = []
    incidencias: list[IncidenciaCodigo] = []

    for ruta in rutas_txt:
        with ruta.open("r", encoding="utf-8-sig", errors="replace") as fichero:
            for num_linea, linea in enumerate(fichero, start=1):
                original = linea.strip()
                if not original:
                    continue

                if "\ufffd" in original:
                    incidencias.append(
                        IncidenciaCodigo(
                            archivo=ruta.name,
                            linea=num_linea,
                            original=original,
                            limpio=normalizar_linea(original),
                        )
                    )
                    continue

                limpio = normalizar_linea(original)
                if es_codigo_valido(limpio, prefijos):
                    lecturas_validas.append(limpio)
                else:
                    incidencias.append(
                        IncidenciaCodigo(
                            archivo=ruta.name,
                            linea=num_linea,
                            original=original,
                            limpio=limpio,
                        )
                    )

    return lecturas_validas, incidencias


def validar_codigos_editados(texto: str, prefijos: Sequence[str]) -> tuple[list[str], list[str]]:
    """
    Valida los codigos escritos/corregidos en la caja central.

    La caja central puede contener textos informativos de la aplicacion. Por eso:
    - Se ignoran lineas vacias y lineas que empiezan por #.
    - Se vuelve a quitar cualquier residuo no numerico.
    - Solo se considera una linea como intento de codigo si contiene al menos
      10 digitos. Asi no se tratan como errores textos como "20 digitos"
      o "empezando por 00".
    """
    validos: list[str] = []
    invalidos: list[str] = []

    for linea in texto.splitlines():
        linea = linea.strip()
        if not linea:
            continue

        if linea.startswith("#"):
            continue

        limpio = normalizar_linea(linea)

        # Ignora textos explicativos de la interfaz que solo contienen numeros sueltos.
        if len(limpio) < 10:
            continue

        if es_codigo_valido(limpio, prefijos):
            validos.append(limpio)
        else:
            invalidos.append(linea)

    return validos, invalidos


def validar_palets_csv_editados(texto: str, prefijos: Sequence[str]) -> tuple[list[str], list[str]]:
    """Valida el contenido editado de la vista final del CSV.

    En la vista final se trabajan los palets ya preparados para CSV, sin los
    dos ceros iniciales. Para facilitar correcciones, tambien se aceptan
    codigos completos de 20 digitos que empiecen por 00 y se convierten al
    formato CSV final.
    """
    palets: list[str] = []
    invalidos: list[str] = []
    for linea in texto.splitlines():
        original = linea.strip()
        if not original or original.startswith("#"):
            continue
        limpio = normalizar_linea(original)
        if len(limpio) < 10:
            continue
        if len(limpio) == 18 and limpio.isdigit():
            palets.append(limpio)
        elif es_codigo_valido(limpio, prefijos):
            palets.append(limpio[2:])
        else:
            invalidos.append(original)
    # Deduplicacion equivalente a la final: conserva la ultima aparicion por
    # los ultimos 10 digitos.
    resultado_inverso: list[str] = []
    claves_vistas: set[str] = set()
    for pallet in reversed(palets):
        clave = pallet[-10:]
        if clave in claves_vistas:
            continue
        claves_vistas.add(clave)
        resultado_inverso.append(pallet)
    return list(reversed(resultado_inverso)), invalidos


def limpiar_y_deduplicar(lecturas_20: Iterable[str]) -> list[str]:
    """
    Quita los dos primeros ceros y elimina duplicados comparando los ultimos 10 digitos.
    Conserva la ultima aparicion encontrada.
    """
    resultado_inverso: list[str] = []
    claves_vistas: set[str] = set()

    for lectura in reversed(list(lecturas_20)):
        pallet = lectura[2:]
        clave = pallet[-10:]

        if clave in claves_vistas:
            continue

        claves_vistas.add(clave)
        resultado_inverso.append(pallet)

    return list(reversed(resultado_inverso))


def escribir_csv(palets: Iterable[str], salida_csv: Path) -> None:
    """Escribe un CSV sin cabecera, una lectura por fila.

    Dynamics AX necesita saltos de linea de Windows (CRLF: \r\n).
    Se fuerza el terminador de linea para que el archivo quede como en Notepad++:
    cada registro finaliza con CRLF, no solo LF.
    """
    with salida_csv.open("w", encoding="utf-8-sig", newline="") as fichero:
        writer = csv.writer(fichero, lineterminator="\r\n")
        for pallet in palets:
            writer.writerow([pallet])




def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class ProcesadorPaletsApp:
    def __init__(self, ventana: tk.Tk):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Procesador de Palets PDA a CSV")

        self.archivos_txt: list[Path] = []
        self.lecturas_validas_base: list[str] = []
        self.lecturas_detectadas: list[str] = []
        self.incidencias: list[IncidenciaCodigo] = []
        self.palets_limpios: list[str] = []
        self.modo_correccion = False
        self.revalidacion_pendiente = False
        self.guardado_ok = False
        self.flujo_estado = "sin_archivos"

        self.logo_izq = None
        self.logo_der = None

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()


    def configurar_accesibilidad(self):
        """Atajos de teclado y salida segura sin alterar la logica de procesado."""
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir_seguro)
        self.ventana.bind("<Control-o>", lambda _event: self.seleccionar_txts())
        self.ventana.bind("<Control-O>", lambda _event: self.seleccionar_txts())
        self.ventana.bind("<Control-s>", lambda _event: self.guardar_csv())
        self.ventana.bind("<Control-S>", lambda _event: self.guardar_csv())
        self.ventana.bind("<Control-l>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Control-L>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Escape>", lambda _event: self.salir_seguro())

    def hay_trabajo_pendiente_salida(self):
        try:
            return bool(self.modo_correccion)
        except Exception:
            return False

    def salir_seguro(self):
        if not self.confirmar_perdida_correcciones("Salir"):
            return
        self.ventana.destroy()

    def configurar_estilos(self) -> None:
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self) -> None:
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(0, weight=1)

        contenedor = ttk.Frame(self.ventana, style="App.TFrame", padding=SUITE_PAD_APP)
        contenedor.grid(row=0, column=0, sticky="nsew")
        contenedor.columnconfigure(0, weight=1)
        contenedor.rowconfigure(2, weight=1)

        encabezado = ttk.Frame(contenedor, style="App.TFrame")
        encabezado.grid(row=0, column=0, sticky="ew", pady=(0, 16))
        encabezado.columnconfigure(0, weight=1)

        titulo = ttk.Label(
            encabezado,
            text="Procesador de Palets PDA a CSV",
            style="Title.TLabel",
            anchor="center",
        )
        titulo.grid(row=0, column=0, sticky="ew")

        subtitulo = ttk.Label(
            encabezado,
            text="Selecciona los TXT, valida incidencias y genera el CSV final sin cambiar la logica de proceso.",
            style="Subtitle.TLabel",
            anchor="center",
        )
        subtitulo.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Frame(encabezado, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel_acciones_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_PANEL)
        panel_acciones_canvas.grid(row=1, column=0, sticky="ew", pady=(0, 14))
        panel_acciones = panel_acciones_canvas.body
        for col in range(5):
            panel_acciones.columnconfigure(col, weight=1, uniform="botones")

        self.btn_seleccionar = ttk.Button(
            panel_acciones,
            text="Seleccionar TXTs",
            command=self.seleccionar_txts,
            style="Next.TButton",
        )
        self.btn_seleccionar.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        self.btn_procesar = ttk.Button(
            panel_acciones,
            text="Procesar archivos",
            command=self.procesar_archivos,
            style="Primary.TButton",
        )
        self.btn_procesar.grid(row=0, column=1, sticky="ew", padx=8)

        self.btn_revalidar = ttk.Button(
            panel_acciones,
            text="Revalidar codigos",
            command=self.revalidar_codigos_corregidos,
            style="Secondary.TButton",
            state="disabled",
        )
        self.btn_revalidar.grid(row=0, column=2, sticky="ew", padx=8)

        self.btn_guardar = ttk.Button(
            panel_acciones,
            text="Guardar CSV",
            command=self.guardar_csv,
            style="Secondary.TButton",
        )
        self.btn_guardar.grid(row=0, column=3, sticky="ew", padx=8)

        self.btn_limpiar = ttk.Button(
            panel_acciones,
            text="Limpiar lista",
            command=self.limpiar_lista,
            style="Danger.TButton",
        )
        self.btn_limpiar.grid(row=0, column=4, sticky="ew", padx=(8, 0))
        suite_configurar_orden_tabulacion(
            self.btn_seleccionar,
            self.btn_procesar,
            self.btn_revalidar,
            self.btn_guardar,
            self.btn_limpiar,
        )

        # Indicador de flujo secuencial integrado bajo la botonera.
        # Sin linea roja inferior: el texto indica el paso activo sin simular progreso.
        self.etiqueta_flujo = ttk.Label(
            panel_acciones,
            text="Paso 1: Seleccionar | Paso 2: Procesar | Paso 3: Guardar",
            style="CardTitle.TLabel",
            anchor="center",
        )
        self.etiqueta_flujo.grid(row=1, column=0, columnspan=5, sticky="ew", pady=(12, 0))

        panel_texto_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_PANEL)
        panel_texto_canvas.grid(row=2, column=0, sticky="nsew")
        panel_texto = panel_texto_canvas.body
        panel_texto.columnconfigure(0, weight=1, uniform="paneles_trabajo")
        panel_texto.columnconfigure(1, weight=1, uniform="paneles_trabajo")
        panel_texto.rowconfigure(1, weight=1)

        etiqueta_preview = ttk.Label(
            panel_texto,
            text="Vista previa y resumen",
            style="PanelTitle.TLabel",
        )
        etiqueta_preview.grid(row=0, column=1, sticky="w", pady=(0, 10), padx=(8, 0))

        etiqueta_revision = ttk.Label(
            panel_texto,
            text="Revision y correccion",
            style="PanelTitle.TLabel",
        )
        etiqueta_revision.grid(row=0, column=0, sticky="w", pady=(0, 10), padx=(0, 8))

        frame_preview = ttk.Frame(panel_texto, style="Panel.TFrame")
        frame_preview.grid(row=1, column=1, sticky="nsew", padx=(8, 0))
        frame_preview.columnconfigure(0, weight=1)
        frame_preview.rowconfigure(0, weight=1)

        scroll_preview_y = ttk.Scrollbar(frame_preview)
        scroll_preview_y.grid(row=0, column=1, sticky="ns")
        scroll_preview_x = ttk.Scrollbar(frame_preview, orient="horizontal")
        scroll_preview_x.grid(row=1, column=0, sticky="ew")

        self.caja_preview = tk.Text(
            frame_preview,
            width=54,
            height=18,
            yscrollcommand=scroll_preview_y.set,
            xscrollcommand=scroll_preview_x.set,
            wrap="none",
            relief="flat",
            padx=12,
            pady=10,
        )
        suite_aplicar_texto_tk(self.caja_preview, mono=True)
        self.caja_preview.grid(row=0, column=0, sticky="nsew")
        suite_configurar_tags_texto(self.caja_preview)
        self.caja_preview.configure(state="disabled")
        scroll_preview_y.config(command=self.caja_preview.yview)
        scroll_preview_x.config(command=self.caja_preview.xview)

        frame_revision = ttk.Frame(panel_texto, style="Panel.TFrame")
        frame_revision.grid(row=1, column=0, sticky="nsew", padx=(0, 8))
        frame_revision.columnconfigure(0, weight=1)
        frame_revision.rowconfigure(0, weight=1)

        scrollbar_y = ttk.Scrollbar(frame_revision)
        scrollbar_y.grid(row=0, column=1, sticky="ns")
        scrollbar_x = ttk.Scrollbar(frame_revision, orient="horizontal")
        scrollbar_x.grid(row=1, column=0, sticky="ew")

        self.caja_texto = tk.Text(
            frame_revision,
            width=54,
            height=18,
            yscrollcommand=scrollbar_y.set,
            xscrollcommand=scrollbar_x.set,
            wrap="none",
            relief="flat",
            padx=12,
            pady=10,
        )
        suite_aplicar_texto_tk(self.caja_texto, mono=True)
        self.caja_texto.grid(row=0, column=0, sticky="nsew")
        suite_configurar_tags_texto(self.caja_texto)
        self.caja_texto.bind("<<Modified>>", self._marcar_cambios_editor)

        scrollbar_y.config(command=self.caja_texto.yview)
        scrollbar_x.config(command=self.caja_texto.xview)

        self.etiqueta_estado = ttk.Label(
            contenedor,
            text="Sin archivos cargados",
            style="Status.TLabel",
            anchor="center",
            justify="center",
            wraplength=940,
        )
        self.etiqueta_estado.configure(takefocus=True)
        self.etiqueta_estado.grid(row=3, column=0, sticky="ew", pady=(8, 12))

        self.progreso = ttk.Progressbar(contenedor, mode="indeterminate")
        self.progreso.grid(row=4, column=0, sticky="ew", pady=(0, 8))
        self.progreso.grid_remove()

        self.frame_logos = ttk.Frame(contenedor, style="Footer.TFrame", padding=SUITE_PAD_PANEL_COMPACT)
        self.frame_logos.grid(row=5, column=0, sticky="ew")
        self.frame_logos.columnconfigure(0, weight=1)
        self.frame_logos.columnconfigure(1, weight=1)
        self.frame_logos.columnconfigure(2, weight=1)

        self.label_logo_izq = ttk.Label(self.frame_logos, style="Logo.TLabel", anchor="w")
        self.label_logo_izq.grid(row=0, column=0, sticky="w")

        zona_central = ttk.Frame(self.frame_logos, style="Footer.TFrame")
        zona_central.grid(row=0, column=1)
        ttk.Label(zona_central, text=SUITE_FOOTER_TEXTO, style="Muted.Card.TLabel", anchor="center").pack(pady=(0, 8))
        ttk.Button(zona_central, text="Salir", command=self.salir_seguro, style="Danger.TButton").pack()

        self.label_logo_der = ttk.Label(self.frame_logos, style="Logo.TLabel", anchor="e")
        self.label_logo_der.grid(row=0, column=2, sticky="e")
        self._actualizar_botones()

    def _marcar_cambios_editor(self, _event=None) -> None:
        try:
            if not self.caja_texto.edit_modified():
                return
            if self.modo_correccion or self.palets_limpios:
                self.revalidacion_pendiente = True
                self.guardado_ok = False
                self.flujo_estado = "pendiente_revalidar"
                # No usar anuncio accesible con focus_set() mientras el usuario escribe.
                # En los campos de revision/correccion debe mantenerse el cursor,
                # el foco y el scroll para permitir correcciones seguidas con comodidad.
                self._set_estado("Cambios detectados en el area de trabajo. Revalida antes de guardar.", importante=False)
                self._actualizar_botones()
            self.caja_texto.edit_modified(False)
        except Exception:
            pass

    def _reset_editor_modificado(self) -> None:
        try:
            self.caja_texto.edit_modified(False)
        except Exception:
            pass

    def _set_texto_preview(self, texto: str) -> None:
        try:
            self.caja_preview.configure(state="normal")
            self.caja_preview.delete("1.0", tk.END)
            self.caja_preview.insert(tk.END, texto)
            self.caja_preview.configure(state="disabled")
        except Exception:
            pass

    def _set_texto_revision(self, texto: str, editable: bool = True) -> None:
        try:
            self.caja_texto.configure(state="normal")
            self.caja_texto.delete("1.0", tk.END)
            self.caja_texto.insert(tk.END, texto)
            if not editable:
                self.caja_texto.configure(state="disabled")
            else:
                self.caja_texto.configure(state="normal")
            self._reset_editor_modificado()
        except Exception:
            pass

    def _resumen_preview(self, titulo: str, extra: str = "") -> str:
        lineas = [titulo, ""]
        lineas.append(f"Archivos cargados: {len(self.archivos_txt)}")
        lineas.append(f"Lecturas validas automaticas: {len(self.lecturas_validas_base)}")
        lineas.append(f"Incidencias pendientes: {len(self.incidencias)}")
        lineas.append(f"Registros CSV finales: {len(self.palets_limpios)}")
        if self.lecturas_detectadas:
            lineas.append(f"Lecturas validadas totales: {len(self.lecturas_detectadas)}")
        if extra:
            lineas.extend(["", extra])
        return "\n".join(lineas).rstrip() + "\n"

    def _set_estado(self, texto: str, importante: bool = False) -> None:
        if importante:
            suite_anunciar_estado(self.etiqueta_estado, texto)
        else:
            self.etiqueta_estado.config(text=texto)

    def _actualizar_flujo(self) -> None:
        textos = {
            "sin_archivos": "Paso 1: Seleccionar | Paso 2: Procesar | Paso 3: Guardar",
            "archivos": "Archivos cargados | Siguiente paso: Procesar",
            "procesado_ok": "Procesado correcto | Siguiente paso: Guardar",
            "correccion": "Incidencias pendientes | Corrige y pulsa Revalidar",
            "pendiente_revalidar": "Cambios sin validar | Siguiente paso: Revalidar",
            "listo_guardar": "Revalidacion correcta | Siguiente paso: Guardar",
            "guardado": "Guardado correcto",
        }
        try:
            self.etiqueta_flujo.config(text=textos.get(getattr(self, "flujo_estado", "sin_archivos"), textos["sin_archivos"]))
        except Exception:
            pass


    def _aplicar_estilo_boton(self, boton, *, siguiente=False, protegido=False, peligro=False):
        try:
            if siguiente:
                boton.configure(style="Next.TButton")
            elif protegido:
                boton.configure(style="Protected.TButton")
            elif peligro:
                boton.configure(style="Danger.TButton")
            else:
                boton.configure(style="Secondary.TButton")
        except Exception:
            pass

    def _hay_trabajo_en_curso(self) -> bool:
        return bool(self.modo_correccion or self.revalidacion_pendiente or (self.palets_limpios and not getattr(self, "guardado_ok", False)))

    def _actualizar_botones(self) -> None:
        puede_procesar = bool(self.archivos_txt) and not self.revalidacion_pendiente and not self.modo_correccion
        puede_revalidar = bool(self.modo_correccion or self.revalidacion_pendiente)
        puede_guardar = bool(self.palets_limpios) and not self.modo_correccion and not self.revalidacion_pendiente
        hay_trabajo = bool(self.archivos_txt or self.palets_limpios or self.modo_correccion or self.revalidacion_pendiente)

        suite_configurar_boton_estado(self.btn_seleccionar, True)
        suite_configurar_boton_estado(self.btn_procesar, puede_procesar)
        suite_configurar_boton_estado(self.btn_revalidar, puede_revalidar)
        suite_configurar_boton_estado(self.btn_guardar, puede_guardar)
        suite_configurar_boton_estado(self.btn_limpiar, hay_trabajo)

        siguiente = getattr(self, "flujo_estado", "sin_archivos")
        self._aplicar_estilo_boton(self.btn_seleccionar, siguiente=(siguiente == "sin_archivos"), protegido=self._hay_trabajo_en_curso())
        self._aplicar_estilo_boton(self.btn_procesar, siguiente=(siguiente == "archivos" and puede_procesar), protegido=self._hay_trabajo_en_curso() and puede_procesar)
        self._aplicar_estilo_boton(self.btn_revalidar, siguiente=(siguiente in {"correccion", "pendiente_revalidar"} and puede_revalidar))
        self._aplicar_estilo_boton(self.btn_guardar, siguiente=(siguiente in {"procesado_ok", "listo_guardar"} and puede_guardar))
        self._aplicar_estilo_boton(self.btn_limpiar, peligro=True)
        self._actualizar_flujo()

    def _set_ocupado(self, ocupado: bool, texto: str | None = None) -> None:
        for boton in (self.btn_seleccionar, self.btn_procesar, self.btn_revalidar, self.btn_guardar, self.btn_limpiar):
            suite_configurar_boton_estado(boton, not ocupado)
        if ocupado:
            if texto:
                self._set_estado(texto)
            self.progreso.grid()
            self.progreso.start(12)
            self.ventana.update_idletasks()
        else:
            self.progreso.stop()
            self.progreso.grid_remove()
            self._actualizar_botones()

    def cargar_logos(self) -> None:
        if Image is None or ImageTk is None:
            messagebox.showwarning(
                "Pillow no instalado",
                "No se pudieron cargar los logos porque falta la libreria Pillow.\n"
                "Instalala con: pip install pillow",
                parent=self.ventana)
            return

        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))

            img_izq.thumbnail((220, 78))
            img_der.thumbnail((220, 78))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            self.label_logo_izq.config(image=self.logo_izq)
            self.label_logo_der.config(image=self.logo_der)
            preparar_logo_minimizar(self.label_logo_izq, self.ventana)
            preparar_logo_minimizar(self.label_logo_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script.",
                parent=self.ventana)
        except Exception as e:
            messagebox.showwarning("Error al cargar logos", f"No se pudieron cargar los logos:\n{e}", parent=self.ventana)

    def confirmar_perdida_correcciones(self, accion: str) -> bool:
        if not self._hay_trabajo_en_curso():
            return True
        return messagebox.askyesno(
            "Accion protegida",
            "Este boton esta protegido porque hay trabajo en curso o cambios pendientes.\n\n"
            f"Si continuas con '{accion}', se descartara el estado actual de la zona de trabajo y se perderan correcciones no guardadas.\n\n"
            "Confirma que quieres continuar.",
            parent=self.ventana,
        )

    def seleccionar_txts(self) -> None:
        if not self.confirmar_perdida_correcciones("Seleccionar TXTs"):
            return

        archivos = filedialog.askopenfilenames(
            parent=self.ventana,
            title="Selecciona archivos TXT de PDA",
            initialdir=suite_obtener_ultimo_directorio("palets_abrir"),
            filetypes=[("Archivos TXT", "*.txt"), ("Todos los archivos", "*.*")],
        )

        if not archivos:
            return

        suite_recordar_directorio("palets_abrir", archivos[0])
        self.archivos_txt = [Path(archivo) for archivo in archivos]
        self.lecturas_validas_base = []
        self.lecturas_detectadas = []
        self.incidencias = []
        self.palets_limpios = []
        self.modo_correccion = False
        self.revalidacion_pendiente = False
        self.guardado_ok = False
        self.flujo_estado = "archivos"
        self.btn_revalidar.config(state="disabled")

        archivos_txt = "Archivos seleccionados:\n\n" + "\n".join(str(archivo) for archivo in self.archivos_txt) + "\n"
        self._set_texto_preview(archivos_txt)
        self._set_texto_revision("No hay incidencias para revisar. Pulsa Procesar archivos para validar las lecturas.\n", editable=False)

        self.etiqueta_estado.config(text=f"{len(self.archivos_txt)} archivo(s) cargado(s)")
        self._actualizar_botones()

    def procesar_archivos(self) -> None:
        if self._hay_trabajo_en_curso():
            if not self.confirmar_perdida_correcciones("Procesar de nuevo"):
                return

        if not self.archivos_txt:
            self._set_estado("Primero selecciona uno o más archivos TXT.", importante=True)
            return

        try:
            self._set_ocupado(True, "Procesando lecturas de palets...")
            self.lecturas_validas_base, self.incidencias = validar_lineas_txt(self.archivos_txt, PREFIJOS_VALIDOS)
        except Exception as e:
            self._set_ocupado(False)
            messagebox.showerror("Error", f"No se pudieron procesar los archivos:\n{e}", parent=self.ventana)
            return
        finally:
            if not self.incidencias:
                self._set_ocupado(False)

        if self.incidencias:
            self.mostrar_incidencias_para_correccion()
            messagebox.showerror(
                "Codigos de pallet no validos",
                "Hay codigos que no cumplen con 20 digitos empezando por 00.\n\n"
                "Corrigelos en el panel izquierdo y pulsa 'Revalidar codigos corregidos'.",
                parent=self.ventana)
            self._set_ocupado(False)
            return

        self.generar_resultado_final(self.lecturas_validas_base)

    def mostrar_incidencias_para_correccion(self) -> None:
        self.modo_correccion = True
        self.revalidacion_pendiente = True
        self.guardado_ok = False
        self.flujo_estado = "correccion"
        self.palets_limpios = []
        self.btn_revalidar.config(state="normal")

        preview = self._resumen_preview(
            "Resultado del procesamiento",
            "Se han encontrado lecturas que requieren revision. La vista de la izquierda contiene solo los registros incorrectos para corregirlos sin tocar la vista previa.",
        )
        if self.lecturas_validas_base:
            preview += "\nVista previa de lecturas validas automaticas:\n"
            for codigo in self.lecturas_validas_base[:500]:
                preview += f"{codigo[2:]}\n"
            if len(self.lecturas_validas_base) > 500:
                preview += f"... {len(self.lecturas_validas_base) - 500} registro(s) mas no mostrados en preview.\n"
        self._set_texto_preview(preview)

        revision = (
            "Corrige solo estos codigos no validos.\n"
            "Debe quedar una lectura por linea, con 20 digitos y empezando por 00.\n"
            "Las lineas que empiezan por # son informativas y se ignoran.\n\n"
        )
        for incidencia in self.incidencias:
            revision += f"# Archivo: {incidencia.archivo} | Linea: {incidencia.linea}\n"
            revision += f"# Original: {incidencia.original}\n"
            revision += f"{incidencia.limpio}\n\n"
        self._set_texto_revision(revision, editable=True)

        self.etiqueta_estado.config(
            text=(
                f"Pendiente de correccion: {len(self.incidencias)} codigo(s) | "
                f"Validos automaticos: {len(self.lecturas_validas_base)}"
            )
        )
        self._reset_editor_modificado()
        self._actualizar_botones()

    def revalidar_codigos_corregidos(self) -> None:
        texto = self.caja_texto.get("1.0", tk.END)

        if not self.modo_correccion:
            palets_editados, invalidos = validar_palets_csv_editados(texto, PREFIJOS_VALIDOS)
            if invalidos:
                self._set_estado("Hay palets modificados con formato no válido. Corrige y vuelve a revalidar.", importante=True)
                messagebox.showerror("Palets no validos", "Hay lineas que no tienen formato CSV final valido. Deben tener 18 digitos, o 20 digitos empezando por 00.", parent=self.ventana)
                self._actualizar_botones()
                try:
                    self.caja_texto.focus_set()
                except Exception:
                    pass
                return
            if not palets_editados:
                self._set_estado("No hay palets validos en el area de trabajo para revalidar.", importante=True)
                return
            self.palets_limpios = palets_editados
            self.revalidacion_pendiente = False
            self.flujo_estado = "listo_guardar"
            self.generar_resultado_final_desde_palets(self.palets_limpios)
            self._set_estado("Revalidación correcta. Puedes guardar el CSV.", importante=True)
            self._actualizar_botones()
            return

        codigos_corregidos, invalidos = validar_codigos_editados(texto, PREFIJOS_VALIDOS)

        if invalidos:
            revision = (
                "# Estos codigos siguen sin ser validos. Corrigelos y vuelve a revalidar.\n"
                "# Debe quedar una lectura por linea, con 20 digitos y empezando por 00.\n"
                "# Las lineas que empiezan por # son informativas y se ignoran.\n\n"
            )
            if codigos_corregidos:
                revision += "# Codigos ya validos. No hace falta tocarlos:\n"
                for codigo in codigos_corregidos:
                    revision += f"{codigo}\n"
                revision += "\n# Codigos pendientes de corregir:\n"
            for codigo in invalidos:
                revision += f"{codigo}\n"
            self._set_texto_revision(revision, editable=True)
            self._set_texto_preview(self._resumen_preview("Revalidacion con incidencias", f"Siguen pendientes {len(invalidos)} codigo(s). Ya corregidos: {len(codigos_corregidos)}"))
            self.etiqueta_estado.config(
                text=f"Siguen pendientes {len(invalidos)} codigo(s) no valido(s) | "
                f"Ya corregidos: {len(codigos_corregidos)}"
            )
            self.flujo_estado = "correccion"
            self._actualizar_botones()
            try:
                self.caja_texto.focus_set()
            except Exception:
                pass
            messagebox.showerror("Codigos no validos", "Aun quedan codigos que no cumplen el formato requerido.", parent=self.ventana)
            return

        if len(codigos_corregidos) != len(self.incidencias):
            respuesta = messagebox.askyesno(
                "Numero de codigos corregidos distinto",
                f"Habia {len(self.incidencias)} codigo(s) con error y ahora hay "
                f"{len(codigos_corregidos)} codigo(s) corregido(s).\n\n"
                "¿Quieres continuar igualmente?",
                parent=self.ventana)
            if not respuesta:
                return

        todas_las_lecturas = self.lecturas_validas_base + codigos_corregidos
        self.generar_resultado_final(todas_las_lecturas)
        self.modo_correccion = False
        self.revalidacion_pendiente = False
        self.guardado_ok = False
        self.flujo_estado = "listo_guardar"
        self.btn_revalidar.config(state="disabled")
        self._set_estado("Validación completada. Códigos corregidos integrados correctamente en el CSV final.", importante=True)
        self._actualizar_botones()

    def generar_resultado_final(self, lecturas: list[str]) -> None:
        self.lecturas_detectadas = lecturas
        self.palets_limpios = limpiar_y_deduplicar(self.lecturas_detectadas)
        self.revalidacion_pendiente = False
        self.flujo_estado = "procesado_ok"
        self.generar_resultado_final_desde_palets(self.palets_limpios)

    def generar_resultado_final_desde_palets(self, palets: list[str]) -> None:
        self.palets_limpios = palets

        if not self.palets_limpios:
            self._set_texto_preview("No se han encontrado lecturas validas de palets.\n")
            self._set_texto_revision("No hay incidencias para revisar.\n", editable=False)
            self._set_estado("Proceso completado: 0 registros validos", importante=True)
            self._actualizar_botones()
            return

        duplicados_eliminados = len(self.lecturas_detectadas) - len(self.palets_limpios)

        preview = self._resumen_preview(
            "CSV final preparado",
            f"Duplicados eliminados: {duplicados_eliminados}\n\nVista previa CSV final:\n" + "\n".join(self.palets_limpios),
        )
        self._set_texto_preview(preview)
        self._set_texto_revision("No hay registros pendientes de revision. Puedes guardar el CSV.\n", editable=False)

        texto_estado = (
            f"Proceso completado: {len(self.palets_limpios)} registro(s) CSV | "
            f"{len(self.lecturas_detectadas)} lectura(s) validada(s) | "
            f"{duplicados_eliminados} duplicado(s) eliminado(s)"
        )
        self._set_estado(texto_estado, importante=True)
        self._reset_editor_modificado()
        self._actualizar_botones()

    def guardar_csv(self) -> None:
        if self.modo_correccion or self.revalidacion_pendiente:
            self._set_estado("Hay cambios o correcciones pendientes. Pulsa Revalidar antes de guardar.", importante=True)
            messagebox.showwarning("Revalidacion obligatoria", "Antes de guardar debes revalidar el area de trabajo para comprobar que todo esta bien.", parent=self.ventana)
            return
        if not self.palets_limpios:
            self._set_estado("No hay datos procesados para guardar. Procesa archivos y corrige posibles errores.", importante=True)
            return

        ruta_guardado = filedialog.asksaveasfilename(
            parent=self.ventana,
            title="Guardar CSV final",
            initialdir=suite_obtener_ultimo_directorio("palets_guardar"),
            defaultextension=".csv",
            initialfile="Stock01.csv",
            filetypes=[("Archivo CSV", "*.csv"), ("Todos los archivos", "*.*")],
        )

        if not ruta_guardado:
            return
        suite_recordar_directorio("palets_guardar", ruta_guardado)

        self._set_ocupado(True, "Guardando CSV final...")
        try:
            escribir_csv(self.palets_limpios, Path(ruta_guardado))
            self.guardado_ok = True
            self.flujo_estado = "guardado"
            self._set_estado(f"Archivo guardado correctamente: {ruta_guardado}", importante=True)
            self._actualizar_botones()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el archivo:\n{e}", parent=self.ventana)
        finally:
            self._set_ocupado(False)

    def limpiar_lista(self) -> None:
        if not self.confirmar_perdida_correcciones("Limpiar lista"):
            return

        self.archivos_txt = []
        self.lecturas_validas_base = []
        self.lecturas_detectadas = []
        self.incidencias = []
        self.palets_limpios = []
        self.modo_correccion = False
        self.revalidacion_pendiente = False
        self.guardado_ok = False
        self.flujo_estado = "sin_archivos"
        self.btn_revalidar.config(state="disabled")
        self._set_texto_preview("")
        self._set_texto_revision("", editable=False)
        self._set_estado("Sin archivos cargados")
        self._actualizar_botones()


if __name__ == "__main__":
    ventana = tk.Tk()
    app = ProcesadorPaletsApp(ventana)
    ventana.mainloop()
