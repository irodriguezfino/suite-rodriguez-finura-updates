"""Capa visual comun para Suite Rodriguez / Finura.

Este modulo concentra paleta, tipografias, layout, estados visuales,
accesibilidad basica y soporte claro/oscuro. Los scripts funcionales deben
consumir estos helpers en vez de definir estilos locales.
"""
from __future__ import annotations

import json
import os
import sys
import ctypes
import tkinter as tk
from pathlib import Path
from tkinter import ttk


def ruta_preferencias_usuario() -> Path:
    """Ruta estable donde se guardan las preferencias visuales del usuario."""
    base = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA")
    if base:
        carpeta = Path(base) / "Suite_Rodriguez_Finura"
    else:
        carpeta = Path.home() / ".suite_rodriguez_finura"
    return carpeta / "preferencias_usuario.json"


def cargar_preferencias_usuario() -> dict:
    """Carga preferencias persistentes sin romper la app si el JSON no existe o esta danado."""
    ruta = ruta_preferencias_usuario()
    try:
        if ruta.exists():
            datos = json.loads(ruta.read_text(encoding="utf-8"))
            if isinstance(datos, dict):
                return datos
    except Exception:
        pass
    return {}


def guardar_preferencias_usuario(preferencias: dict) -> None:
    """Guarda preferencias visuales de forma atomica y silenciosa."""
    ruta = ruta_preferencias_usuario()
    try:
        ruta.parent.mkdir(parents=True, exist_ok=True)
        tmp = ruta.with_suffix(".tmp")
        tmp.write_text(json.dumps(preferencias, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(ruta)
    except Exception:
        pass


def obtener_preferencia(clave: str, valor_defecto=None):
    return cargar_preferencias_usuario().get(clave, valor_defecto)


def establecer_preferencia(clave: str, valor) -> None:
    preferencias = cargar_preferencias_usuario()
    preferencias[clave] = valor
    guardar_preferencias_usuario(preferencias)


def obtener_ultimo_directorio(clave: str) -> str | None:
    ruta = obtener_preferencia(f"ultimo_directorio_{clave}", None)
    if isinstance(ruta, str) and ruta and os.path.isdir(ruta):
        return ruta
    return None


def recordar_directorio(clave: str, ruta: str | os.PathLike | None) -> None:
    if not ruta:
        return
    try:
        ruta_str = os.fspath(ruta)
        carpeta = ruta_str if os.path.isdir(ruta_str) else os.path.dirname(ruta_str)
        if carpeta and os.path.isdir(carpeta):
            establecer_preferencia(f"ultimo_directorio_{clave}", carpeta)
    except Exception:
        pass


FOOTER_TEXTO = "Dpto. Sistemas e Informatica EMBUTIDOS RODRIGUEZ"

FUENTE_BASE = ("Arial", 11)
FUENTE_TITULO = ("Arial", 30, "bold")
FUENTE_SUBTITULO = ("Arial", 12)
FUENTE_BOTON = ("Arial", 11, "bold")
FUENTE_MONO = ("Consolas", 11)
FUENTE_TARJETA_TITULO = ("Arial", 16, "bold")
FUENTE_MUTED = ("Arial", 11)
FUENTE_FOOTER = ("Arial", 10)
FUENTE_VERSION = ("Arial", 9)

VENTANA_GEOMETRIA = "1120x780"
VENTANA_MIN_ANCHO = 900
VENTANA_MIN_ALTO = 620
VENTANA_COMPACTA_GEOMETRIA = "540x500"
VENTANA_COMPACTA_MIN_ANCHO = 520
VENTANA_COMPACTA_MIN_ALTO = 380

PAD_APP = (26, 22, 26, 20)
PAD_CARD = (20, 18)
PAD_PANEL = (20, 16)
PAD_PANEL_COMPACT = (18, 10)
PAD_FOOTER = (22, 12)
PAD_TARJETA_MENU = (14, 12)
PAD_MENU_APPS = (22, 20)
PAD_MENU_INFO = (20, 16)
PAD_MENU_APPS_COMPACTO = (14, 12)
PAD_MENU_INFO_COMPACTO = (16, 12)
STATUS_PADDING = (14, 9)
TEXT_BORDER_WIDTH = 1
RED_LINE_HEIGHT = 4
RADIUS_PANEL = 14
RADIUS_CARD = 12

ESPACIADO_EXTERIOR_X = 28
ESPACIADO_EXTERIOR_Y = 8
ESPACIADO_BOTON_X = 8
ESPACIADO_BOTON_MIN_X = 5


PALETAS = {
    "claro": {
        "fondo": "#F7F9FC",
        "tarjeta": "#FFFFFF",
        "borde": "#64748B",
        "borde_suave": "#D7E3F2",
        "borde_hover": "#94A3B8",
        "borde_pressed": "#7EA6D8",
        "principal": "#103080",
        "principal_fg": "#FFFFFF",
        "principal_hover": "#0B2564",
        "texto": "#1F2937",
        "muted": "#4B5563",
        "estado": "#EAF3FB",
        "error": "#B42318",
        "ok": "#157347",
        "rodriguez": "#C02020",
        "seleccion": "#BFD7F0",
        "seleccion_texto": "#111827",
        "aviso": "#8A5A00",
        "boton_sec": "#FFFFFF",
        "boton_sec_active": "#EAF3FB",
        "boton_sec_border": "#94A3B8",
        "protected_bg": "#E0F2FE",
        "protected_active": "#BAE6FD",
        "protected_fg": "#075985",
        "danger_bg": "#FFF5F5",
        "danger_active": "#FCE1E1",
        "focus": "#C02020",
        "disabled_bg": "#D1D5DB",
        "disabled_fg": "#6B7280",
        "field": "#FFFFFF",
        "field_border": "#CBD5E1",
        "scroll_trough": "#EEF4FB",
        "scroll_thumb": "#B8C7DA",
        "scroll_thumb_active": "#8EA4BE",
    },
    "oscuro": {
        "fondo": "#111827",
        "tarjeta": "#1F2937",
        "borde": "#6B7280",
        "borde_suave": "#3A4A5F",
        "borde_hover": "#64748B",
        "borde_pressed": "#8AB4F8",
        "principal": "#8AB4F8",
        "principal_fg": "#111827",
        "principal_hover": "#60A5FA",
        "texto": "#F9FAFB",
        "muted": "#D1D5DB",
        "estado": "#243447",
        "error": "#FCA5A5",
        "ok": "#86EFAC",
        "rodriguez": "#F05252",
        "seleccion": "#1D4ED8",
        "seleccion_texto": "#FFFFFF",
        "aviso": "#FBBF24",
        "boton_sec": "#243447",
        "boton_sec_active": "#2F455F",
        "boton_sec_border": "#64748B",
        "protected_bg": "#12324A",
        "protected_active": "#164E63",
        "protected_fg": "#7DD3FC",
        "danger_bg": "#3A1F24",
        "danger_active": "#5B252C",
        "focus": "#F87171",
        "disabled_bg": "#243447",
        "disabled_fg": "#9CA3AF",
        "field": "#111827",
        "field_border": "#475569",
        "scroll_trough": "#172033",
        "scroll_thumb": "#475569",
        "scroll_thumb_active": "#64748B",
    },
}

TEMA_ACTUAL = os.environ.get("SUITE_TEMA") or str(obtener_preferencia("tema", "claro"))
TEMA_ACTUAL = TEMA_ACTUAL.strip().lower() or "claro"

COLOR_FONDO = ""
COLOR_TARJETA = ""
COLOR_BORDE = ""
COLOR_PRINCIPAL = ""
COLOR_PRINCIPAL_HOVER = ""
COLOR_TEXTO = ""
COLOR_MUTED = ""
COLOR_ESTADO = ""
COLOR_ERROR = ""
COLOR_OK = ""
COLOR_RODRIGUEZ = ""
COLOR_SELECCION = ""
COLOR_SELECCION_TEXTO = ""
COLOR_AVISO = ""
COLOR_FOCUS = ""


def obtener_paleta(tema: str | None = None) -> dict[str, str]:
    clave = (tema or TEMA_ACTUAL or "claro").strip().lower()
    return PALETAS.get(clave, PALETAS["claro"])


def _colorref(hex_color: str) -> int:
    """Convierte #RRGGBB al COLORREF BGR que usa Win32."""
    color = str(hex_color or "#000000").lstrip("#")
    try:
        r = int(color[0:2], 16)
        g = int(color[2:4], 16)
        b = int(color[4:6], 16)
        return r | (g << 8) | (b << 16)
    except Exception:
        return 0


def _hwnds_tk_windows(ventana: tk.Misc) -> list[int]:
    """Devuelve posibles HWND nativos de Tk, incluyendo wrappers padres de Windows."""
    handles: list[int] = []
    try:
        hwnd = int(ventana.winfo_id())
    except Exception:
        hwnd = 0
    while hwnd and hwnd not in handles:
        handles.append(hwnd)
        try:
            get_parent = ctypes.windll.user32.GetParent
            get_parent.argtypes = [ctypes.c_void_p]
            get_parent.restype = ctypes.c_void_p
            hwnd = int(get_parent(ctypes.c_void_p(hwnd)) or 0)
        except Exception:
            break
    return handles


def _refrescar_marco_windows(hwnd: int) -> None:
    """Fuerza a Windows a repintar la decoracion no cliente tras cambiar DWM."""
    try:
        flags = 0x0001 | 0x0002 | 0x0004 | 0x0010 | 0x0020
        set_window_pos = ctypes.windll.user32.SetWindowPos
        set_window_pos.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_uint,
        ]
        set_window_pos.restype = ctypes.c_bool
        set_window_pos(
            ctypes.c_void_p(hwnd),
            None,
            0,
            0,
            0,
            0,
            flags,
        )
    except Exception:
        pass


def aplicar_modo_ventana_windows(ventana: tk.Misc, tema: str | None = None) -> None:
    """Sincroniza barra nativa de Windows con el tema claro/oscuro de la suite."""
    if os.name != "nt":
        return
    try:
        handles = _hwnds_tk_windows(ventana)
        if not handles:
            return
        oscuro = 1 if (tema or TEMA_ACTUAL) == "oscuro" else 0
        paleta = obtener_paleta(tema)
        color_barra = _colorref(paleta["fondo"] if oscuro else "#F8FAFC")
        color_texto = _colorref("#FFFFFF" if oscuro else "#111827")
        dwm_set_attr = ctypes.windll.dwmapi.DwmSetWindowAttribute
        dwm_set_attr.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        dwm_set_attr.restype = ctypes.c_long
        for hwnd in handles:
            aplicado = False
            valor = ctypes.c_int(oscuro)
            for atributo in (20, 19):
                try:
                    resultado = dwm_set_attr(
                        ctypes.c_void_p(hwnd),
                        ctypes.c_uint(atributo),
                        ctypes.byref(valor),
                        ctypes.sizeof(valor),
                    )
                    aplicado = aplicado or resultado == 0
                except Exception:
                    pass
            for atributo, color in ((35, color_barra), (36, color_texto)):
                dato = ctypes.c_int(color)
                try:
                    resultado = dwm_set_attr(
                        ctypes.c_void_p(hwnd),
                        ctypes.c_uint(atributo),
                        ctypes.byref(dato),
                        ctypes.sizeof(dato),
                    )
                    aplicado = aplicado or resultado == 0
                except Exception:
                    pass
            if aplicado:
                _refrescar_marco_windows(hwnd)
    except Exception:
        pass


def solicitar_modo_ventana_windows(ventana: tk.Misc, tema: str | None = None) -> None:
    """Reaplica DWM despues de que Tk/Windows termine de crear la decoracion."""
    aplicar_modo_ventana_windows(ventana, tema)
    try:
        ventana.after(80, lambda: aplicar_modo_ventana_windows(ventana, tema))
        ventana.after(220, lambda: aplicar_modo_ventana_windows(ventana, tema))
    except Exception:
        pass


def aplicar_tema(tema: str = "claro") -> None:
    """Actualiza constantes visuales globales manteniendo compatibilidad."""
    global TEMA_ACTUAL, COLOR_FONDO, COLOR_TARJETA, COLOR_BORDE, COLOR_PRINCIPAL
    global COLOR_PRINCIPAL_HOVER, COLOR_TEXTO, COLOR_MUTED, COLOR_ESTADO
    global COLOR_ERROR, COLOR_OK, COLOR_RODRIGUEZ, COLOR_SELECCION
    global COLOR_SELECCION_TEXTO, COLOR_AVISO, COLOR_FOCUS

    TEMA_ACTUAL = "oscuro" if str(tema).lower().startswith("osc") else "claro"
    p = obtener_paleta(TEMA_ACTUAL)
    COLOR_FONDO = p["fondo"]
    COLOR_TARJETA = p["tarjeta"]
    COLOR_BORDE = p["borde"]
    COLOR_PRINCIPAL = p["principal"]
    COLOR_PRINCIPAL_HOVER = p["principal_hover"]
    COLOR_TEXTO = p["texto"]
    COLOR_MUTED = p["muted"]
    COLOR_ESTADO = p["estado"]
    COLOR_ERROR = p["error"]
    COLOR_OK = p["ok"]
    COLOR_RODRIGUEZ = p["rodriguez"]
    COLOR_SELECCION = p["seleccion"]
    COLOR_SELECCION_TEXTO = p["seleccion_texto"]
    COLOR_AVISO = p["aviso"]
    COLOR_FOCUS = p["focus"]


aplicar_tema(TEMA_ACTUAL)


def ruta_recurso(nombre: str) -> str:
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def ruta_recurso_path(nombre: str) -> Path:
    return Path(ruta_recurso(nombre))


def configurar_ttk_unificado(ventana: tk.Misc | None = None, tema: str | None = None) -> ttk.Style:
    """Configura ttk con contraste AA, foco visible y soporte claro/oscuro."""
    if tema:
        aplicar_tema(tema)
    p = obtener_paleta()
    style = ttk.Style(ventana)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(".", font=FUENTE_BASE)
    style.configure("TFrame", background=COLOR_FONDO)
    style.configure("App.TFrame", background=COLOR_FONDO)
    style.configure("Card.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("Panel.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("Footer.TFrame", background=COLOR_TARJETA, relief="flat")
    style.configure("RedLine.TFrame", background=COLOR_RODRIGUEZ)

    style.configure("TLabel", background=COLOR_FONDO, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure(
        "Title.TLabel",
        background=COLOR_FONDO,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TITULO,
        padding=(0, 4, 0, 2),
    )
    style.configure("Subtitle.TLabel", background=COLOR_FONDO, foreground=COLOR_MUTED, font=FUENTE_SUBTITULO)
    style.configure("Card.TLabel", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure("Panel.TLabel", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE)
    style.configure(
        "CardTitle.TLabel",
        background=COLOR_TARJETA,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TARJETA_TITULO,
        padding=(0, 0, 0, 4),
    )
    style.configure(
        "PanelTitle.TLabel",
        background=COLOR_TARJETA,
        foreground=COLOR_PRINCIPAL,
        font=FUENTE_TARJETA_TITULO,
        padding=(0, 0, 0, 4),
    )
    style.configure("Muted.Card.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_MUTED)
    style.configure("Status.TLabel", background=COLOR_ESTADO, foreground=COLOR_TEXTO, font=FUENTE_BOTON, padding=STATUS_PADDING)
    style.configure("Version.TLabel", background=COLOR_FONDO, foreground=COLOR_MUTED, font=FUENTE_VERSION)
    style.configure("Version.Footer.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_VERSION)
    style.configure("Author.TLabel", background=COLOR_TARJETA, foreground=COLOR_MUTED, font=FUENTE_FOOTER)
    style.configure("Logo.TLabel", background=COLOR_TARJETA)
    style.configure("Warning.TLabel", background=COLOR_TARJETA, foreground=COLOR_AVISO, font=FUENTE_BOTON)
    style.configure("Error.TLabel", background=COLOR_TARJETA, foreground=COLOR_ERROR, font=FUENTE_BOTON)
    style.configure("Success.TLabel", background=COLOR_TARJETA, foreground=COLOR_OK, font=FUENTE_BOTON)
    card_button_border = p["borde_suave"]

    button_common = {
        "font": FUENTE_BOTON,
        "padding": (16, 10),
        "borderwidth": 2,
        "relief": "solid",
        "focusthickness": 2,
        "focuscolor": COLOR_FOCUS,
    }
    neutral_button_common = dict(button_common)
    neutral_button_common["borderwidth"] = 1
    # Estado normal: pasos anteriores que siguen activos. Fondo neutro y borde visible.
    style.configure(
        "TButton",
        **neutral_button_common,
        foreground=COLOR_TEXTO,
        background=p["boton_sec"],
        bordercolor=card_button_border,
        lightcolor=card_button_border,
        darkcolor=card_button_border,
    )
    style.map(
        "TButton",
        background=[("active", p["boton_sec_active"]), ("pressed", p["boton_sec_active"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", p["borde_hover"]), ("pressed", p["borde_pressed"]), ("active", p["borde_hover"])],
    )
    style.configure("Primary.TButton", **button_common, foreground=p["principal_fg"], background=COLOR_PRINCIPAL, bordercolor=COLOR_PRINCIPAL)
    style.map(
        "Primary.TButton",
        background=[("active", COLOR_PRINCIPAL_HOVER), ("pressed", COLOR_PRINCIPAL_HOVER), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_PRINCIPAL_HOVER), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    # Siguiente paso: unico boton azul de accion principal.
    style.configure("Next.TButton", **button_common, foreground=p["principal_fg"], background=COLOR_PRINCIPAL, bordercolor=COLOR_PRINCIPAL)
    style.map(
        "Next.TButton",
        background=[("active", COLOR_PRINCIPAL_HOVER), ("pressed", COLOR_PRINCIPAL_HOVER), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", COLOR_PRINCIPAL_HOVER), ("active", COLOR_PRINCIPAL_HOVER)],
    )
    # Boton activo pero protegido por confirmacion. Azul secundario distinto del boton de siguiente paso.
    style.configure("Protected.TButton", **button_common, foreground=p["protected_fg"], background=p["protected_bg"], bordercolor=p["protected_fg"])
    style.map(
        "Protected.TButton",
        foreground=[("!disabled", p["protected_fg"]), ("disabled", p["disabled_fg"])],
        background=[("active", p["protected_active"]), ("pressed", p["protected_active"]), ("disabled", p["disabled_bg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", p["protected_fg"]), ("active", p["protected_fg"])],
    )
    style.configure(
        "Secondary.TButton",
        **neutral_button_common,
        foreground=COLOR_TEXTO,
        background=p["boton_sec"],
        bordercolor=card_button_border,
        lightcolor=card_button_border,
        darkcolor=card_button_border,
    )
    style.map(
        "Secondary.TButton",
        background=[("active", p["boton_sec_active"]), ("pressed", p["boton_sec_active"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", p["borde_hover"]), ("pressed", p["borde_pressed"]), ("active", p["borde_hover"])],
    )
    style.configure(
        "Danger.TButton",
        **neutral_button_common,
        foreground=COLOR_ERROR,
        background=p["danger_bg"],
        bordercolor=card_button_border,
        lightcolor=card_button_border,
        darkcolor=card_button_border,
    )
    style.map(
        "Danger.TButton",
        foreground=[("!disabled", COLOR_ERROR), ("disabled", p["disabled_fg"])],
        background=[("active", p["danger_active"]), ("pressed", p["danger_active"]), ("disabled", p["disabled_bg"])],
        bordercolor=[("disabled", p["disabled_bg"]), ("focus", p["borde_hover"]), ("pressed", p["borde_pressed"]), ("active", p["borde_hover"])],
    )

    style.configure("TRadiobutton", background=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE, padding=4)
    style.map("TRadiobutton", foreground=[("disabled", p["disabled_fg"])], background=[("active", COLOR_TARJETA)])
    style.configure(
        "TEntry",
        fieldbackground=p["field"],
        foreground=COLOR_TEXTO,
        insertcolor=COLOR_TEXTO,
        padding=7,
        borderwidth=1,
        bordercolor=p["field_border"],
        focuscolor=COLOR_FOCUS,
    )
    style.map("TEntry", bordercolor=[("focus", COLOR_FOCUS)], foreground=[("disabled", p["disabled_fg"])])
    style.configure(
        "TCombobox",
        fieldbackground=p["field"],
        background=p["field"],
        foreground=COLOR_TEXTO,
        arrowcolor=COLOR_TEXTO,
        padding=7,
        borderwidth=1,
        bordercolor=p["field_border"],
    )
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", p["field"]), ("disabled", p["disabled_bg"])],
        foreground=[("disabled", p["disabled_fg"])],
        bordercolor=[("focus", COLOR_FOCUS)],
    )
    try:
        style.layout(
            "Vertical.TScrollbar",
            [
                (
                    "Vertical.Scrollbar.trough",
                    {
                        "sticky": "ns",
                        "children": [
                            ("Vertical.Scrollbar.thumb", {"expand": "1", "sticky": "nswe"})
                        ],
                    },
                )
            ],
        )
        style.layout(
            "Horizontal.TScrollbar",
            [
                (
                    "Horizontal.Scrollbar.trough",
                    {
                        "sticky": "ew",
                        "children": [
                            ("Horizontal.Scrollbar.thumb", {"expand": "1", "sticky": "nswe"})
                        ],
                    },
                )
            ],
        )
    except tk.TclError:
        pass
    for scrollbar_style in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
        style.configure(
            scrollbar_style,
            gripcount=0,
            background=p["scroll_thumb"],
            troughcolor=p["scroll_trough"],
            bordercolor=p["scroll_trough"],
            lightcolor=p["scroll_thumb"],
            darkcolor=p["scroll_thumb"],
            arrowcolor=p["scroll_thumb"],
            relief="flat",
            borderwidth=0,
            arrowsize=0,
            width=12,
        )
        style.map(
            scrollbar_style,
            background=[
                ("active", p["scroll_thumb_active"]),
                ("pressed", p["scroll_thumb_active"]),
                ("!disabled", p["scroll_thumb"]),
            ],
            bordercolor=[("!disabled", p["scroll_trough"])],
        )
    style.configure("Treeview", background=COLOR_TARJETA, fieldbackground=COLOR_TARJETA, foreground=COLOR_TEXTO, font=FUENTE_BASE, rowheight=28)
    style.configure(
        "Treeview.Heading",
        background=COLOR_ESTADO,
        foreground=COLOR_PRINCIPAL,
        font=(FUENTE_BOTON[0], FUENTE_BOTON[1] + 1, "bold"),
        padding=(8, 7),
    )
    style.map("Treeview", background=[("selected", COLOR_SELECCION)], foreground=[("selected", COLOR_SELECCION_TEXTO)])
    style.configure("TProgressbar", background=COLOR_PRINCIPAL, troughcolor=COLOR_ESTADO, bordercolor=COLOR_BORDE, lightcolor=COLOR_PRINCIPAL, darkcolor=COLOR_PRINCIPAL)

    if ventana is not None:
        configurar_opciones_ventana(ventana)
        actualizar_widgets_tk(ventana)
    return style


configurar_ttk = configurar_ttk_unificado


def configurar_opciones_ventana(ventana: tk.Misc) -> None:
    try:
        ventana.option_add("*Font", FUENTE_BASE)
        ventana.option_add("*TButton*Font", FUENTE_BOTON)
        ventana.option_add("*selectBackground", COLOR_SELECCION)
        ventana.option_add("*selectForeground", COLOR_SELECCION_TEXTO)
    except Exception:
        pass


def configurar_ventana_base(ventana: tk.Misc, titulo: str, redimensionable: bool = True, maximizar: bool = True) -> None:
    """Aplica titulo, geometria, fondo y minimos comunes."""
    try:
        ventana.title(titulo)
    except Exception:
        pass
    try:
        ventana.geometry(VENTANA_GEOMETRIA)
        ventana.minsize(VENTANA_MIN_ANCHO, VENTANA_MIN_ALTO)
        ventana.configure(bg=COLOR_FONDO)
        ventana.resizable(redimensionable, redimensionable)
        if maximizar:
            try:
                ventana.state("zoomed")
            except Exception:
                try:
                    ventana.attributes("-zoomed", True)
                except Exception:
                    pass
    except Exception:
        pass
    configurar_opciones_ventana(ventana)
    aplicar_icono_ventana(ventana)
    solicitar_modo_ventana_windows(ventana)


def configurar_dialogo_base(
    ventana: tk.Misc,
    titulo: str,
    *,
    geometria: str = "660x500",
    min_ancho: int = 520,
    min_alto: int = 360,
    redimensionable: bool = True,
) -> None:
    """Configura dialogos auxiliares sin heredar el tamano minimo de la ventana principal."""
    try:
        ventana.title(titulo)
        ventana.geometry(geometria)
        ventana.minsize(min_ancho, min_alto)
        ventana.configure(bg=COLOR_FONDO)
        ventana.resizable(redimensionable, redimensionable)
    except Exception:
        pass
    configurar_opciones_ventana(ventana)
    aplicar_icono_ventana(ventana)
    solicitar_modo_ventana_windows(ventana)


def configurar_aplicacion(ventana: tk.Misc, titulo: str, *, tema: str | None = None, redimensionable: bool = True) -> ttk.Style:
    configurar_ventana_base(ventana, titulo, redimensionable=redimensionable)
    return configurar_ttk_unificado(ventana, tema)


def aplicar_modo_compacto_ventana(ventana: tk.Misc, activo: bool) -> None:
    try:
        if activo:
            try:
                ventana.state("normal")
            except Exception:
                pass
            ventana.minsize(VENTANA_COMPACTA_MIN_ANCHO, VENTANA_COMPACTA_MIN_ALTO)
            ventana.geometry(VENTANA_COMPACTA_GEOMETRIA)
        else:
            ventana.minsize(VENTANA_MIN_ANCHO, VENTANA_MIN_ALTO)
            ventana.geometry(VENTANA_GEOMETRIA)
            try:
                ventana.state("zoomed")
            except Exception:
                pass
    except Exception:
        pass


def crear_linea_roja(padre: tk.Misc, fila: int = 2, columna: int = 0, columnspan: int = 1, pady=(10, 0)) -> ttk.Frame:
    linea = ttk.Frame(padre, style="RedLine.TFrame", height=RED_LINE_HEIGHT)
    linea.grid(row=fila, column=columna, columnspan=columnspan, sticky="ew", pady=pady)
    return linea


class SuiteCanvasPanel(tk.Frame):
    """Panel visual redondeado con Canvas y cuerpo interior para widgets ttk."""

    def __init__(
        self,
        padre: tk.Misc,
        *,
        fill: str | None = None,
        border: str | None = None,
        hover_border: str | None = None,
        pressed_border: str | None = None,
        parent_bg: str | None = None,
        hover_enabled: bool = False,
        radius: int = RADIUS_PANEL,
        border_width: int = 1,
        padding=None,
    ):
        p = obtener_paleta()
        self.fill = fill or COLOR_TARJETA
        self.border = border or p["borde_suave"]
        self.hover_border = hover_border or p["borde_hover"]
        self.pressed_border = pressed_border or p["borde_pressed"]
        self.hover_enabled = bool(hover_enabled)
        self.parent_bg = parent_bg or COLOR_FONDO
        self.radius = radius
        self.border_width = border_width
        self.padding = padding if padding is not None else PAD_PANEL
        if len(self.padding) == 2:
            self.padx = int(self.padding[0])
            self.pady = int(self.padding[1])
        else:
            self.padx = int(self.padding[0])
            self.pady = int(self.padding[1])
        super().__init__(padre, bg=self.parent_bg, highlightthickness=0, bd=0)
        self.canvas = tk.Canvas(self, bg=self.parent_bg, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=self.fill, highlightthickness=0, bd=0)
        self._window = self.canvas.create_window(self.padx, self.pady, window=self.body, anchor="nw")
        self._hovered = False
        self._pressed = False
        self._last_draw_state = None
        self._size_after_id = None
        self._hover_clear_after_id = None
        self.canvas.bind("<Configure>", self._redraw)
        self.body.bind("<Configure>", self._schedule_size_sync)
        if self.hover_enabled:
            self.canvas.bind("<Enter>", self._mouse_enter)
            self.canvas.bind("<Leave>", self._mouse_leave)
            self.body.bind("<Enter>", self._mouse_enter, add="+")
            self.body.bind("<Leave>", self._mouse_leave, add="+")
            self.canvas.bind("<ButtonPress-1>", self._mouse_press, add="+")
            self.canvas.bind("<ButtonRelease-1>", self._mouse_release, add="+")

    def configure_visual(
        self,
        *,
        fill: str | None = None,
        border: str | None = None,
        hover_border: str | None = None,
        pressed_border: str | None = None,
        parent_bg: str | None = None,
    ):
        changed = False
        if fill is not None and fill != self.fill:
            self.fill = fill
            self.body.configure(bg=fill)
            changed = True
        if border is not None and border != self.border:
            self.border = border
            changed = True
        if hover_border is not None and hover_border != self.hover_border:
            self.hover_border = hover_border
            changed = True
        if pressed_border is not None and pressed_border != self.pressed_border:
            self.pressed_border = pressed_border
            changed = True
        if parent_bg is not None and parent_bg != self.parent_bg:
            self.parent_bg = parent_bg
            self.configure(bg=parent_bg)
            self.canvas.configure(bg=parent_bg)
            changed = True
        if changed:
            self._last_draw_state = None
            self._redraw(force=True)

    def _mouse_enter(self, _event=None):
        if not self.hover_enabled:
            return
        if self._hover_clear_after_id is not None:
            try:
                self.after_cancel(self._hover_clear_after_id)
            except Exception:
                pass
            self._hover_clear_after_id = None
        self._hovered = True
        self._redraw(force=True)

    def _mouse_leave(self, _event=None):
        if not self.hover_enabled:
            return
        if self._hover_clear_after_id is not None:
            return
        try:
            self._hover_clear_after_id = self.after(45, self._clear_hover_if_pointer_outside)
        except Exception:
            self._hover_clear_after_id = None
            self._clear_hover_if_pointer_outside()

    def _clear_hover_if_pointer_outside(self):
        self._hover_clear_after_id = None
        if self._pointer_inside():
            return
        self._hovered = False
        self._pressed = False
        self._redraw(force=True)

    def _mouse_press(self, _event=None):
        if not self.hover_enabled:
            return
        self._pressed = True
        self._redraw(force=True)

    def _mouse_release(self, _event=None):
        if not self.hover_enabled:
            return
        self._pressed = False
        if not self._pointer_inside():
            self._hovered = False
        self._redraw(force=True)

    def _pointer_inside(self):
        try:
            x = self.winfo_pointerx()
            y = self.winfo_pointery()
            left = self.winfo_rootx()
            top = self.winfo_rooty()
            return left <= x < left + self.winfo_width() and top <= y < top + self.winfo_height()
        except Exception:
            return False

    def _schedule_size_sync(self, _event=None):
        if self._size_after_id is not None:
            return
        try:
            self._size_after_id = self.after_idle(self._sync_requested_size)
        except Exception:
            self._size_after_id = None

    def _sync_requested_size(self):
        self._size_after_id = None
        try:
            req_w = self.body.winfo_reqwidth() + self.padx * 2
            req_h = self.body.winfo_reqheight() + self.pady * 2
            actual_w = int(float(self.canvas.cget("width") or 0))
            actual_h = int(float(self.canvas.cget("height") or 0))
            if actual_w != req_w or actual_h != req_h:
                self.canvas.configure(width=req_w, height=req_h)
            self._redraw(force=True)
        except Exception:
            pass

    def _round_points(self, x1, y1, x2, y2, radius):
        return [
            x1 + radius, y1, x2 - radius, y1, x2, y1, x2, y1 + radius,
            x2, y2 - radius, x2, y2, x2 - radius, y2, x1 + radius, y2,
            x1, y2, x1, y2 - radius, x1, y1 + radius, x1, y1,
        ]

    def _redraw(self, _event=None, force=False):
        try:
            w = max(2, self.canvas.winfo_width())
            h = max(2, self.canvas.winfo_height())
            color_borde = self.pressed_border if self._pressed else (self.hover_border if self._hovered else self.border)
            state = (w, h, self.fill, color_borde, self.border_width, self.radius)
            if not force and state == self._last_draw_state:
                return
            self._last_draw_state = state
            self.canvas.delete("panel")
            radius = min(self.radius, max(2, min(w, h) // 2))
            self.canvas.create_polygon(
                self._round_points(
                    self.border_width,
                    self.border_width,
                    w - self.border_width,
                    h - self.border_width,
                    radius,
                ),
                fill=self.fill,
                outline=color_borde,
                width=self.border_width,
                smooth=True,
                tags="panel",
            )
            self.canvas.tag_lower("panel")
            self.canvas.coords(self._window, self.padx, self.pady)
            self.canvas.itemconfigure(
                self._window,
                width=max(1, w - self.padx * 2),
                height=max(1, h - self.pady * 2),
            )
        except Exception:
            pass


def crear_panel_canvas(
    padre: tk.Misc,
    *,
    padding=None,
    radius: int = RADIUS_PANEL,
    parent_bg: str | None = None,
    fill: str | None = None,
    border: str | None = None,
    hover_enabled: bool = False,
) -> SuiteCanvasPanel:
    p = obtener_paleta()
    return SuiteCanvasPanel(
        padre,
        fill=fill or COLOR_TARJETA,
        border=border or p["borde_suave"],
        hover_border=p["borde_hover"],
        pressed_border=p["borde_pressed"],
        parent_bg=parent_bg or COLOR_FONDO,
        hover_enabled=hover_enabled,
        radius=radius,
        padding=padding if padding is not None else PAD_PANEL,
    )


def crear_tarjeta_canvas(padre: tk.Misc, *, padding=None, radius: int = RADIUS_CARD) -> SuiteCanvasPanel:
    p = obtener_paleta()
    return crear_panel_canvas(
        padre,
        padding=padding if padding is not None else PAD_CARD,
        radius=radius,
        parent_bg=COLOR_FONDO,
        fill=COLOR_TARJETA,
        border=p["borde_suave"],
    )


def crear_frame_app(padre: tk.Misc) -> ttk.Frame:
    return ttk.Frame(padre, style="App.TFrame", padding=PAD_APP)


def crear_panel(padre: tk.Misc, *, compacto: bool = False, estilo: str = "Panel.TFrame") -> ttk.Frame:
    return ttk.Frame(padre, style=estilo, padding=PAD_PANEL_COMPACT if compacto else PAD_PANEL)


def crear_tarjeta(padre: tk.Misc, *, padding=None) -> ttk.Frame:
    return ttk.Frame(padre, style="Card.TFrame", padding=padding or PAD_CARD)


def crear_text_frame(padre: tk.Misc) -> tk.Frame:
    return tk.Frame(
        padre,
        bg=COLOR_TARJETA,
        highlightbackground=COLOR_BORDE,
        highlightcolor=COLOR_FOCUS,
        highlightthickness=TEXT_BORDER_WIDTH,
        bd=0,
    )


def aplicar_texto_tk(widget: tk.Text, *, mono: bool = True, alto: int | None = None) -> None:
    """Aplica colores, fuente, seleccion y foco a tk.Text."""
    kwargs = {
        "font": FUENTE_MONO if mono else FUENTE_BASE,
        "bg": COLOR_TARJETA,
        "fg": COLOR_TEXTO,
        "insertbackground": COLOR_TEXTO,
        "selectbackground": COLOR_SELECCION,
        "selectforeground": COLOR_SELECCION_TEXTO,
        "highlightbackground": COLOR_BORDE,
        "highlightcolor": COLOR_FOCUS,
        "highlightthickness": TEXT_BORDER_WIDTH,
    }
    if alto is not None:
        kwargs["height"] = alto
    widget.configure(**kwargs)


def configurar_tags_texto(widget: tk.Text) -> None:
    """Tags visuales comunes para avisos, errores y resultados en tk.Text."""
    widget.tag_configure("titulo", font=FUENTE_MONO, foreground=COLOR_PRINCIPAL)
    widget.tag_configure("comentario", foreground=COLOR_MUTED)
    widget.tag_configure("error", foreground=COLOR_ERROR)
    widget.tag_configure("ok", foreground=COLOR_OK)
    widget.tag_configure("aviso", foreground=COLOR_AVISO)


def aplicar_logo_label(label: tk.Label | ttk.Label) -> None:
    try:
        label.configure(bd=0, bg=COLOR_TARJETA, highlightthickness=0)
    except tk.TclError:
        try:
            label.configure(style="Logo.TLabel")
        except Exception:
            pass


def minimizar_ventana(ventana: tk.Misc) -> None:
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget: tk.Misc, ventana: tk.Misc) -> None:
    """Deja los logos como elementos decorativos, no como acciones ocultas."""
    try:
        widget.configure(cursor="", takefocus=False)
        widget.unbind("<Button-1>")
        widget.unbind("<Return>")
        widget.unbind("<space>")
        widget.unbind("<FocusIn>")
        widget.unbind("<FocusOut>")
    except Exception:
        pass


def _configurar_highlight(widget: tk.Misc, color: str) -> None:
    try:
        widget.configure(highlightbackground=color, highlightcolor=color, highlightthickness=2)
    except Exception:
        pass


def establecer_app_user_model_id() -> None:
    """Fija el identificador Windows que ayuda a conservar el icono en la barra de tareas."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("EmbutidosRodriguez.SuiteFinura")
    except Exception:
        pass


def aplicar_icono_ventana(ventana: tk.Misc) -> None:
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando es posible."""
    establecer_app_user_model_id()
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
    except Exception:
        pass
    try:
        from PIL import Image, ImageTk
        ruta_png = ruta_recurso("ICONO_SUITE.png")
        if os.path.exists(ruta_png):
            icono = ImageTk.PhotoImage(Image.open(ruta_png))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def preparar_ventana_sin_parpadeo(ventana: tk.Misc) -> None:
    """Evita que Windows pinte una ventana a medio construir."""
    try:
        ventana.attributes("-alpha", 0.0)
    except Exception:
        pass
    try:
        ventana.withdraw()
    except Exception:
        pass


def animar_aparicion_ventana(
    ventana: tk.Misc,
    *,
    duracion_ms: int = 140,
    pasos: int = 7,
    al_final=None,
) -> None:
    """Aplica una entrada visual breve y suave sin bloquear la interfaz."""
    try:
        pasos = max(1, int(pasos))
        duracion_ms = max(40, int(duracion_ms))
        intervalo = max(8, duracion_ms // pasos)

        def paso(indice: int = 1):
            try:
                ventana.attributes("-alpha", min(1.0, indice / pasos))
                if indice < pasos:
                    ventana.after(intervalo, lambda: paso(indice + 1))
                elif al_final is not None:
                    al_final()
            except Exception:
                try:
                    ventana.attributes("-alpha", 1.0)
                except Exception:
                    pass
                if al_final is not None:
                    al_final()

        ventana.attributes("-alpha", 0.0)
        ventana.after(intervalo, paso)
    except Exception:
        try:
            ventana.attributes("-alpha", 1.0)
        except Exception:
            pass
        if al_final is not None:
            al_final()


def animar_cierre_ventana(
    ventana: tk.Misc,
    *,
    duracion_ms: int = 120,
    pasos: int = 6,
    al_final=None,
) -> None:
    """Desvanece una ventana antes de cerrar, dejando visible la ventana que tenga detras."""
    try:
        pasos = max(1, int(pasos))
        duracion_ms = max(40, int(duracion_ms))
        intervalo = max(8, duracion_ms // pasos)

        def paso(indice: int = 1):
            try:
                ventana.attributes("-alpha", max(0.0, 1.0 - (indice / pasos)))
                if indice < pasos:
                    ventana.after(intervalo, lambda: paso(indice + 1))
                    return
            except Exception:
                pass
            if al_final is not None:
                al_final()

        paso()
    except Exception:
        if al_final is not None:
            al_final()


def mostrar_ventana_sin_parpadeo(
    ventana: tk.Misc,
    *,
    maximizar: bool = True,
    enfocar: bool = True,
    icono: bool = True,
    animar: bool = True,
    al_final=None,
) -> None:
    """Muestra una ventana ya compuesta, minimizando transiciones visibles de Tk/Windows."""
    try:
        ventana.update_idletasks()
    except Exception:
        pass
    if maximizar:
        try:
            ventana.state("zoomed")
        except Exception:
            try:
                ventana.attributes("-zoomed", True)
            except Exception:
                pass
    try:
        ventana.deiconify()
    except Exception:
        pass
    try:
        ventana.update_idletasks()
    except Exception:
        pass
    solicitar_modo_ventana_windows(ventana)
    if icono:
        aplicar_icono_ventana(ventana)
    if animar:
        animar_aparicion_ventana(ventana, al_final=al_final)
    else:
        try:
            ventana.attributes("-alpha", 1.0)
        except Exception:
            pass
        if al_final is not None:
            al_final()
    if enfocar:
        try:
            ventana.lift()
            ventana.focus_set()
        except Exception:
            pass


def cargar_imagen_logo(nombre: str, max_size: tuple[int, int]):
    """Carga un logo con Pillow si esta disponible. Devuelve ImageTk.PhotoImage o None."""
    try:
        from PIL import Image, ImageTk
    except ImportError:
        return None
    try:
        img = Image.open(ruta_recurso(nombre))
        img.thumbnail(max_size)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None


def crear_footer_simple(padre: tk.Misc, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    footer = ttk.Frame(padre, style="Footer.TFrame", padding=PAD_FOOTER)
    ttk.Label(footer, text=texto, style="Author.TLabel", anchor="center").pack(fill="x")
    return footer


def crear_footer(padre: tk.Misc, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    return crear_footer_simple(padre, texto)


def crear_footer_con_salida(padre: tk.Misc, salir=None, texto: str = FOOTER_TEXTO) -> ttk.Frame:
    footer = ttk.Frame(padre, style="Footer.TFrame", padding=PAD_FOOTER)
    footer.columnconfigure(0, weight=1)
    ttk.Label(footer, text=texto, style="Author.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
    if salir:
        ttk.Button(footer, text="Salir", command=salir, style="Danger.TButton").grid(row=1, column=0, pady=(8, 0))
    return footer


def configurar_atajos_comunes(ventana: tk.Misc, *, guardar=None, limpiar=None, abrir=None, salir=None) -> None:
    """Atajos comunes sin alterar comandos existentes."""
    if guardar:
        ventana.bind("<Control-s>", lambda _e: guardar())
        ventana.bind("<Control-S>", lambda _e: guardar())
    if limpiar:
        ventana.bind("<Control-l>", lambda _e: limpiar())
        ventana.bind("<Control-L>", lambda _e: limpiar())
    if abrir:
        ventana.bind("<Control-o>", lambda _e: abrir())
        ventana.bind("<Control-O>", lambda _e: abrir())
    if salir:
        ventana.bind("<Escape>", lambda _e: salir())


def configurar_boton_estado(widget: tk.Misc, activo: bool) -> None:
    """Activa o desactiva un boton evitando errores prevenibles."""
    try:
        widget.configure(state="normal" if activo else "disabled")
    except Exception:
        pass


def ejecutar_con_bloqueo_temporal(ventana: tk.Misc, widgets: list[tk.Misc], funcion, *, al_final=None):
    """Ejecuta una accion corta evitando doble clic o acciones contradictorias."""
    estados = []
    for widget in widgets:
        try:
            estados.append((widget, widget.cget("state")))
            widget.configure(state="disabled")
        except Exception:
            pass
    try:
        try:
            ventana.update_idletasks()
        except Exception:
            pass
        return funcion()
    finally:
        if al_final is not None:
            try:
                al_final()
            except Exception:
                pass
        else:
            for widget, estado in estados:
                try:
                    widget.configure(state=estado)
                except Exception:
                    pass


def configurar_orden_tabulacion(*widgets: tk.Misc) -> None:
    """Marca los controles relevantes como alcanzables por Tab en orden de creacion."""
    for widget in widgets:
        try:
            widget.configure(takefocus=True)
        except Exception:
            pass


def anunciar_estado(label: tk.Misc, texto: str) -> None:
    """Actualiza un estado visible y mueve el foco cuando el cambio es importante."""
    try:
        label.configure(text=texto)
        label.focus_set()
    except Exception:
        pass


def preparar_dialogo_parent(widget: tk.Misc | None):
    return widget


def crear_header(padre: tk.Misc, titulo: str, subtitulo: str = "") -> ttk.Frame:
    header = ttk.Frame(padre, style="App.TFrame")
    header.columnconfigure(0, weight=1)
    ttk.Label(header, text=titulo, style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
    row_line = 1
    if subtitulo:
        ttk.Label(header, text=subtitulo, style="Subtitle.TLabel", anchor="center", wraplength=980).grid(row=1, column=0, sticky="ew", pady=(6, 0))
        row_line = 2
    ttk.Frame(header, style="RedLine.TFrame", height=RED_LINE_HEIGHT).grid(row=row_line, column=0, sticky="ew", pady=(10, 0))
    return header


def crear_tarjeta_visual(padre: tk.Misc, titulo: str | None = None, *, padding=None) -> ttk.Frame:
    card = ttk.Frame(padre, style="Card.TFrame", padding=padding or PAD_CARD)
    if titulo:
        ttk.Label(card, text=titulo, style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 10))
        card._suite_next_row = 1
    else:
        card._suite_next_row = 0
    return card


def crear_indicador_estado(padre: tk.Misc, texto: str = "Sin actividad", *, anchor: str = "center") -> ttk.Label:
    return ttk.Label(padre, text=texto, style="Status.TLabel", anchor=anchor, justify="center", wraplength=980)


def crear_panel_indicadores(padre: tk.Misc, indicadores: list[tuple[str, str]] | None = None) -> ttk.Frame:
    panel = ttk.Frame(padre, style="Card.TFrame", padding=PAD_PANEL_COMPACT)
    for col, (titulo, valor) in enumerate(indicadores or [("Estado", "Sin actividad")]):
        panel.columnconfigure(col, weight=1, uniform="estado")
        bloque = ttk.Frame(panel, style="Card.TFrame")
        bloque.grid(row=0, column=col, sticky="ew", padx=4)
        ttk.Label(bloque, text=titulo, style="Muted.Card.TLabel", anchor="center").pack(fill="x")
        ttk.Label(bloque, text=valor, style="Status.TLabel", anchor="center").pack(fill="x", pady=(4, 0))
    return panel


def crear_botonera_inferior(padre: tk.Misc, botones: list[tuple[str, object, str]] | None = None) -> ttk.Frame:
    barra = ttk.Frame(padre, style="Card.TFrame", padding=PAD_PANEL_COMPACT)
    for i, (texto, comando, variante) in enumerate(botones or []):
        estilo = {"primario": "Primary.TButton", "peligro": "Danger.TButton"}.get(variante, "Secondary.TButton")
        barra.columnconfigure(i, weight=1, uniform="botonera")
        ttk.Button(barra, text=texto, command=comando, style=estilo).grid(row=0, column=i, sticky="ew", padx=4)
    return barra


def actualizar_widgets_tk(widget: tk.Misc) -> None:
    """Refresca widgets Tk no-ttk para que sigan el tema activo."""
    try:
        if isinstance(widget, SuiteCanvasPanel):
            p = obtener_paleta()
            widget.configure_visual(
                fill=COLOR_TARJETA,
                border=p["borde_suave"],
                hover_border=p["borde_hover"],
                pressed_border=p["borde_pressed"],
                parent_bg=COLOR_FONDO,
            )
        elif isinstance(widget, (tk.Tk, tk.Toplevel)):
            widget.configure(bg=COLOR_FONDO)
        elif isinstance(widget, tk.Text):
            aplicar_texto_tk(widget, mono=(str(widget.cget("font")).lower().find("consol") >= 0))
            configurar_tags_texto(widget)
        elif isinstance(widget, tk.Canvas):
            widget.configure(bg=COLOR_TARJETA, highlightbackground=COLOR_BORDE, highlightcolor=COLOR_FOCUS)
        elif isinstance(widget, tk.Frame):
            widget.configure(bg=COLOR_TARJETA, highlightbackground=COLOR_BORDE, highlightcolor=COLOR_FOCUS)
        elif isinstance(widget, tk.Label):
            widget.configure(bg=COLOR_TARJETA, fg=COLOR_TEXTO)
    except Exception:
        pass
    try:
        for child in widget.winfo_children():
            actualizar_widgets_tk(child)
    except Exception:
        pass


def obtener_tema_actual() -> str:
    return TEMA_ACTUAL


def alternar_modo_oscuro(ventana: tk.Misc | None = None) -> str:
    nuevo = "oscuro" if TEMA_ACTUAL != "oscuro" else "claro"
    configurar_ttk_unificado(ventana, nuevo)
    establecer_preferencia("tema", nuevo)
    if ventana is not None:
        solicitar_modo_ventana_windows(ventana, nuevo)
        actualizar_widgets_tk(ventana)
    return nuevo


def refrescar_tema_ventana(ventana: tk.Misc | None = None) -> None:
    if ventana is not None:
        configurar_ttk_unificado(ventana, TEMA_ACTUAL)
        solicitar_modo_ventana_windows(ventana, TEMA_ACTUAL)
        actualizar_widgets_tk(ventana)
