﻿# Propiedad intelectual: Departamento de Informatica (Daniel Lombo, Daniel R. Zapico, Lisardo Perez, Manuel Llamas, David Rubio y Nacho Rodriguez).
import os
import sys
import csv
import io
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_CARD as SUITE_PAD_CARD,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    STATUS_PADDING as SUITE_STATUS_PADDING,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    crear_text_frame as suite_crear_text_frame,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    preparar_ventana_sin_parpadeo as suite_preparar_ventana_sin_parpadeo,
    recordar_directorio as suite_recordar_directorio,
)

from PIL import Image, ImageTk



def ruta_recurso(nombre):
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class ConvertidorTXTCSVApp:
    def __init__(self, ventana):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Procesador de TXT a CSV")
        aplicar_icono_ventana(self.ventana)

        self.archivos_txt = []
        self.lineas_procesadas = []

        self.logo_izq = None
        self.logo_der = None
        self.label_logo_izq = None
        self.label_logo_der = None
        self.frame_logos = None

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()


    def configurar_accesibilidad(self):
        """Atajos de teclado y salida segura sin alterar la logica de procesado."""
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir_seguro)
        self.ventana.bind("<Control-o>", lambda _event: self.seleccionar_txts())
        self.ventana.bind("<Control-O>", lambda _event: self.seleccionar_txts())
        self.ventana.bind("<Control-s>", lambda _event: self.guardar_csv())
        self.ventana.bind("<Control-S>", lambda _event: self.guardar_csv())
        self.ventana.bind("<Control-l>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Control-L>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Escape>", lambda _event: self.salir_seguro())

    def hay_trabajo_pendiente_salida(self):
        try:
            return bool(self.archivos_txt or self.lineas_procesadas)
        except Exception:
            return False

    def confirmar_accion_protegida(self, accion: str) -> bool:
        if not self.hay_trabajo_pendiente_salida():
            return True
        return messagebox.askyesno(
            "Accion protegida",
            "Este boton esta protegido porque hay archivos cargados o resultado generado.\n\n"
            f"Si continuas con '{accion}', se descartara el trabajo actual.\n\n"
            "Confirma que quieres continuar.",
            parent=self.ventana,
        )

    def salir_seguro(self):
        if self.hay_trabajo_pendiente_salida():
            if not messagebox.askyesno(
                "Confirmar salida",
                "Hay datos cargados, procesados o correcciones en curso.\n\n¿Quieres cerrar esta aplicacion?",
                parent=self.ventana,
            ):
                return
        self.ventana.destroy()

    def configurar_estilos(self):
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(1, weight=1)

        cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(24, 12))
        cabecera.columnconfigure(0, weight=1)

        titulo = ttk.Label(
            cabecera,
            text="Procesador de TXT a CSV",
            style="Title.TLabel",
            anchor="center"
        )
        titulo.grid(row=0, column=0, sticky="ew")

        subtitulo = ttk.Label(
            cabecera,
            text="Selecciona archivos TXT, revisa la vista previa y guarda el CSV final.",
            style="Subtitle.TLabel",
            anchor="center"
        )
        subtitulo.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        contenedor = ttk.Frame(self.ventana, style="TFrame")
        contenedor.grid(row=1, column=0, sticky="nsew", padx=28, pady=8)
        contenedor.columnconfigure(0, weight=1)
        contenedor.rowconfigure(1, weight=1)

        panel_acciones_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_CARD)
        panel_acciones_canvas.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        panel_acciones = panel_acciones_canvas.body
        panel_acciones.columnconfigure(0, weight=1)
        panel_acciones.columnconfigure(1, weight=0)
        panel_acciones.columnconfigure(2, weight=0)
        panel_acciones.columnconfigure(3, weight=0)

        texto_ayuda = ttk.Label(
            panel_acciones,
            text="1. Carga los TXT  2. Procesa  3. Guarda el CSV",
            style="Card.TLabel"
        )
        texto_ayuda.grid(row=0, column=0, sticky="w", padx=(0, 12))

        self.btn_seleccionar = ttk.Button(
            panel_acciones,
            text="Seleccionar TXTs",
            command=self.seleccionar_txts,
            style="Secondary.TButton"
        )
        self.btn_seleccionar.grid(row=0, column=1, padx=4)

        self.btn_procesar = ttk.Button(
            panel_acciones,
            text="Procesar archivos",
            command=self.procesar_archivos,
            style="Primary.TButton"
        )
        self.btn_procesar.grid(row=0, column=2, padx=4)

        self.btn_guardar = ttk.Button(
            panel_acciones,
            text="Guardar CSV",
            command=self.guardar_csv,
            style="Secondary.TButton"
        )
        self.btn_guardar.grid(row=0, column=3, padx=(4, 0))
        suite_configurar_orden_tabulacion(self.btn_seleccionar, self.btn_procesar, self.btn_guardar)

        panel_texto_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_CARD)
        panel_texto_canvas.grid(row=1, column=0, sticky="nsew")
        panel_texto = panel_texto_canvas.body
        panel_texto.columnconfigure(0, weight=1)
        panel_texto.rowconfigure(1, weight=1)

        encabezado_panel = ttk.Frame(panel_texto, style="Card.TFrame")
        encabezado_panel.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        encabezado_panel.columnconfigure(0, weight=1)

        titulo_panel = ttk.Label(
            encabezado_panel,
            text="Vista previa / archivos seleccionados",
            style="CardTitle.TLabel",
        )
        titulo_panel.grid(row=0, column=0, sticky="w")

        self.btn_limpiar = ttk.Button(
            encabezado_panel,
            text="Limpiar lista",
            command=self.limpiar_lista,
            style="Danger.TButton"
        )
        self.btn_limpiar.grid(row=0, column=1, sticky="e")
        suite_configurar_orden_tabulacion(self.btn_limpiar)

        frame_texto = suite_crear_text_frame(panel_texto)
        frame_texto.grid(row=1, column=0, sticky="nsew")
        frame_texto.columnconfigure(0, weight=1)
        frame_texto.rowconfigure(0, weight=1)

        scrollbar_y = ttk.Scrollbar(frame_texto, orient="vertical")
        scrollbar_y.grid(row=0, column=1, sticky="ns")

        scrollbar_x = ttk.Scrollbar(frame_texto, orient="horizontal")
        scrollbar_x.grid(row=1, column=0, sticky="ew")

        self.caja_texto = tk.Text(
            frame_texto,
            yscrollcommand=scrollbar_y.set,
            xscrollcommand=scrollbar_x.set,
            wrap="word",
            relief="flat",
            padx=12,
            pady=12,
            undo=False
        )
        suite_aplicar_texto_tk(self.caja_texto, mono=True)
        self.caja_texto.grid(row=0, column=0, sticky="nsew")

        scrollbar_y.config(command=self.caja_texto.yview)
        scrollbar_x.config(command=self.caja_texto.xview)

        barra_estado_canvas = suite_crear_panel_canvas(self.ventana, padding=(14, 9))
        barra_estado_canvas.grid(row=2, column=0, sticky="ew", padx=28, pady=(8, 10))
        barra_estado = barra_estado_canvas.body
        barra_estado.columnconfigure(0, weight=1)

        self.etiqueta_estado = ttk.Label(
            barra_estado,
            text="Sin archivos cargados",
            style="Status.TLabel",
            anchor="w",
            padding=SUITE_STATUS_PADDING
        )
        self.etiqueta_estado.configure(takefocus=True)
        self.etiqueta_estado.grid(row=0, column=0, sticky="ew")

        self.progreso = ttk.Progressbar(self.ventana, mode="indeterminate")
        self.progreso.grid(row=3, column=0, sticky="ew", padx=28, pady=(0, 8))
        self.progreso.grid_remove()

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=4, column=0, sticky="ew", padx=28, pady=(0, 18))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.frame_logos = footer

        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")

        zona_central = ttk.Frame(footer, style="Footer.TFrame")
        zona_central.grid(row=0, column=1)
        ttk.Label(zona_central, text=SUITE_FOOTER_TEXTO, style="Muted.Card.TLabel", anchor="center").pack(pady=(0, 8))
        ttk.Button(zona_central, text="Salir", command=self.salir_seguro, style="Danger.TButton").pack()

        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._actualizar_botones()

    def _set_estado(self, texto: str, importante: bool = False):
        if importante:
            suite_anunciar_estado(self.etiqueta_estado, texto)
        else:
            self.etiqueta_estado.config(text=texto)

    def _actualizar_botones(self):
        suite_configurar_boton_estado(self.btn_procesar, bool(self.archivos_txt))
        suite_configurar_boton_estado(self.btn_guardar, bool(self.lineas_procesadas))
        suite_configurar_boton_estado(self.btn_limpiar, bool(self.archivos_txt or self.lineas_procesadas))

    def _set_ocupado(self, ocupado: bool, texto: str | None = None):
        for boton in (self.btn_seleccionar, self.btn_procesar, self.btn_guardar, self.btn_limpiar):
            suite_configurar_boton_estado(boton, not ocupado)
        if ocupado:
            if texto:
                self._set_estado(texto)
            self.progreso.grid()
            self.progreso.start(12)
            self.ventana.update_idletasks()
        else:
            self.progreso.stop()
            self.progreso.grid_remove()
            self._actualizar_botones()

    def cargar_logos(self):
        try:
            ruta_logo_izq = ruta_recurso("FINURA.png")
            ruta_logo_der = ruta_recurso("RODRIGUEZ.png")

            img_izq = Image.open(ruta_logo_izq)
            img_der = Image.open(ruta_logo_der)

            img_izq.thumbnail((210, 80))
            img_der.thumbnail((200, 80))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            self.label_logo_izq = tk.Label(self.logo_slot_izq, image=self.logo_izq)
            self.label_logo_der = tk.Label(self.logo_slot_der, image=self.logo_der)
            suite_aplicar_logo_label(self.label_logo_izq)
            suite_aplicar_logo_label(self.label_logo_der)

            self.label_logo_izq.pack(anchor="w")
            self.label_logo_der.pack(anchor="e")
            preparar_logo_minimizar(self.label_logo_izq, self.ventana)
            preparar_logo_minimizar(self.label_logo_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script."
            , parent=self.ventana)
        except Exception as e:
            messagebox.showwarning(
                "Error al cargar logos",
                f"No se pudieron cargar los logos:\n{e}"
            , parent=self.ventana)

    def seleccionar_txts(self):
        if not self.confirmar_accion_protegida("Seleccionar nuevos TXT"):
            return
        archivos = filedialog.askopenfilenames(
            parent=self.ventana,
            title="Selecciona archivos TXT",
            initialdir=suite_obtener_ultimo_directorio("txt_csv_abrir"),
            filetypes=[("Archivos TXT", "*.txt"), ("Todos los archivos", "*.*")]
        )

        if archivos:
            suite_recordar_directorio("txt_csv_abrir", archivos[0])
            self.archivos_txt = list(archivos)
            self.caja_texto.delete("1.0", tk.END)

            for archivo in self.archivos_txt:
                self.caja_texto.insert(tk.END, f"{archivo}\n")

            self.etiqueta_estado.config(
                text=f"{len(self.archivos_txt)} archivo(s) cargado(s). Pulsa Procesar archivos."
            )
            self._actualizar_botones()

    def formatear_decimal_2(self, valor):
        valor = str(valor).strip()

        if valor == "":
            return valor

        valor = valor.replace(",", ".")

        try:
            numero = float(valor)
            return f"{numero:.2f}".replace(".", ",")
        except ValueError:
            return valor

    def procesar_linea(self, texto):
        try:
            columnas = next(csv.reader([texto], delimiter=";", quotechar='"'))
        except csv.Error:
            columnas = texto.split(";")

        if not columnas:
            return texto

        # Caso habitual en tus archivos:
        # la última columna viene vacía, así que el decimal correcto está en la penúltima
        if len(columnas) >= 2 and columnas[-1].strip() == "":
            columnas[-2] = self.formatear_decimal_2(columnas[-2])
        else:
            columnas[-1] = self.formatear_decimal_2(columnas[-1])

        salida = io.StringIO()
        writer = csv.writer(salida, delimiter=";", quotechar='"', lineterminator="")
        writer.writerow(columnas)
        return salida.getvalue()

    def procesar_archivos(self):
        if self.lineas_procesadas:
            if not self.confirmar_accion_protegida("Procesar de nuevo"):
                return
        if not self.archivos_txt:
            self._set_estado("Primero selecciona uno o más archivos TXT.", importante=True)
            return

        self.lineas_procesadas = []
        errores = 0
        archivos_con_error = []
        self._set_ocupado(True, "Procesando archivos TXT...")

        try:
            for archivo in self.archivos_txt:
                try:
                    with open(archivo, "r", encoding="utf-8-sig", errors="replace") as f:
                        for linea in f:
                            texto = linea.rstrip("\n\r")

                            if not texto.strip():
                                continue

                            if texto.strip().replace(";", "") == "":
                                continue

                            if "\ufffd" in texto:
                                errores += 1
                                archivos_con_error.append(os.path.basename(archivo))
                                continue

                            linea_final = self.procesar_linea(texto)
                            self.lineas_procesadas.append(linea_final)

                except Exception:
                    errores += 1
                    archivos_con_error.append(os.path.basename(archivo))
        finally:
            self._set_ocupado(False)

        self.caja_texto.delete("1.0", tk.END)

        if not self.lineas_procesadas:
            self.caja_texto.insert(tk.END, "No hay datos válidos para mostrar.\n")
            self._set_estado("Proceso completado: 0 líneas", importante=True)
            return

        vista_previa = "\n".join(self.lineas_procesadas[:100])
        self.caja_texto.insert(tk.END, vista_previa)

        texto_estado = f"Proceso completado: {len(self.lineas_procesadas)} línea(s)"
        if errores > 0:
            texto_estado += f" | Errores en {errores} archivo(s): {', '.join(archivos_con_error[:3])}"
        self._set_estado(texto_estado, importante=True)
        self._actualizar_botones()
    def guardar_csv(self):
        if not self.lineas_procesadas:
            self._set_estado("No hay datos procesados para guardar.", importante=True)
            return

        ruta_guardado = filedialog.asksaveasfilename(
            parent=self.ventana,
            title="Guardar CSV",
            initialdir=suite_obtener_ultimo_directorio("txt_csv_guardar"),
            defaultextension=".csv",
            filetypes=[("Archivo CSV", "*.csv")]
        )

        if not ruta_guardado:
            return
        suite_recordar_directorio("txt_csv_guardar", ruta_guardado)

        self._set_ocupado(True, "Guardando CSV...")
        try:
            with open(ruta_guardado, "w", encoding="utf-8", newline="") as f:
                for linea in self.lineas_procesadas:
                    f.write(linea + "\n")

            self._set_estado(f"Archivo guardado correctamente: {ruta_guardado}", importante=True)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el archivo:\n{e}", parent=self.ventana)
        finally:
            self._set_ocupado(False)

    def limpiar_lista(self):
        if not self.confirmar_accion_protegida("Limpiar lista"):
            return
        self.archivos_txt = []
        self.lineas_procesadas = []
        self.caja_texto.delete("1.0", tk.END)
        self._set_estado("Sin archivos cargados")
        self._actualizar_botones()


if __name__ == "__main__":
    ventana = tk.Tk()
    app = ConvertidorTXTCSVApp(ventana)
    ventana.mainloop()


def lanzar_app_txt_csv(parent=None):
    import tkinter as tk
    ventana = tk.Toplevel(parent)
    suite_preparar_ventana_sin_parpadeo(ventana)
    app = ConvertidorTXTCSVApp(ventana)
    if parent is None:
        suite_mostrar_ventana_sin_parpadeo(ventana, maximizar=True, enfocar=True, icono=True)
    return ventana
