#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Control integrado de precintos y recepcion de maquilas.

Mantiene las aplicaciones originales separadas y ofrece un flujo unico:
corregir TXT de precintos, guardar TXT importable en AX, generar PDF de
rangos y enviar el correo final con adjuntos.
"""

from __future__ import annotations

import os
import re
import smtplib
import sys
import tempfile
from dataclasses import dataclass
from decimal import Decimal
from email.message import EmailMessage
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from ControlPrecintosJamonesGUI import (
    CAMPOS_ESPERADOS,
    SMTP_HOST,
    SMTP_PASSWORD,
    SMTP_PORT,
    SMTP_USUARIO,
    RegistroJamones,
    aplicar_correcciones_editor,
    deduplicar,
    formato_importable_ax,
    formatear_peso,
    formatear_registro_para_editor,
    gtin12_valido,
    leer_ficheros,
    parsear_linea,
    parsear_origen_editor,
    parsear_peso,
    sugerir_partida_lote,
    validar_registro_completo,
)
from RecepcionMaquilasGUI import (
    CONFIG_ARTICULOS_INTERNO,
    RegistroMaquila,
    agrupar_por_rangos,
    decimal_a_es,
    decimal_desde_texto,
    generar_pdf_rangos,
    leer_config_articulos,
    leer_seals_report,
    leer_txt_maquila,
    ruta_recurso,
    valor_mayoritario,
)
from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_atajos_comunes as suite_configurar_atajos_comunes,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_flujo_proceso as suite_crear_flujo_proceso,
    crear_header as suite_crear_header,
    crear_panel_canvas as suite_crear_panel_canvas,
    establecer_preferencia as suite_establecer_preferencia,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    obtener_preferencia as suite_obtener_preferencia,
    recordar_directorio as suite_recordar_directorio,
)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


PREF_DESTINATARIOS = "control_recepcion_maquilas_destinatarios"
PREF_ASUNTO = "control_recepcion_maquilas_asunto"
PREF_MENSAJE = "control_recepcion_maquilas_mensaje"
ASUNTO_DEFECTO = "Recepcion maquilas - documentacion"
MENSAJE_DEFECTO = (
    "Buenos dias,\n\n"
    "Adjuntamos la documentacion correspondiente a la recepcion.\n\n"
    "Se incluyen los siguientes archivos:\n"
    "- Detalle de control de precintos.\n"
    "- Informe de clasificacion por rangos.\n\n"
    "Un saludo,"
)


@dataclass
class ResultadoTipo:
    tipo: str
    total: int
    gtin_validos: int
    articulos_ibericos: int = 0


def aplicar_icono_ventana(ventana):
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if ruta_ico.exists():
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def codigo_articulo_registro(registro: RegistroJamones) -> str:
    return registro.campos[3].strip() if len(registro.campos) > 3 else ""


def producto_parece_iberico(nombre: str) -> bool:
    texto = (nombre or "").upper()
    return any(marca in texto for marca in ("IBER", "BELLOTA", "CEBO"))


def codigos_ibericos_desde_config(rangos_por_codigo: dict) -> set[str]:
    codigos: set[str] = set()
    for codigo, rangos in (rangos_por_codigo or {}).items():
        if any(producto_parece_iberico(getattr(rango, "nombre_producto", "")) for rango in rangos):
            codigos.add(str(codigo).strip())
    return codigos


def detectar_tipo_jamon(registros: list[RegistroJamones], codigos_ibericos: set[str] | None = None) -> ResultadoTipo:
    precintos = [r.precinto for r in registros if re.fullmatch(r"\d{12}", r.precinto or "")]
    gtin_validos = sum(1 for codigo in precintos if gtin12_valido(codigo))
    total = len(precintos)
    codigos_ibericos = codigos_ibericos or set()
    articulos_ibericos = sum(1 for registro in registros if codigo_articulo_registro(registro) in codigos_ibericos)
    if articulos_ibericos:
        return ResultadoTipo("Iberico", total, gtin_validos, articulos_ibericos)
    if total and gtin_validos >= max(1, (total + 1) // 2):
        return ResultadoTipo("Iberico", total, gtin_validos)
    return ResultadoTipo("Blanco", total, gtin_validos, articulos_ibericos)


def parsear_destinatarios(texto: str) -> list[str]:
    candidatos = [p.strip() for p in re.split(r"[;,\s]+", texto or "") if p.strip()]
    vistos: set[str] = set()
    resultado: list[str] = []
    for correo in candidatos:
        clave = correo.lower()
        if clave not in vistos:
            vistos.add(clave)
            resultado.append(correo)
    return resultado


def validar_destinatarios(destinatarios: list[str]) -> list[str]:
    return [c for c in destinatarios if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", c)]


class ControlRecepcionMaquilasApp:
    def __init__(self, ventana: tk.Tk | tk.Toplevel):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Control y Recepcion Maquilas")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)

        self.rutas_txt: list[Path] = []
        self.ruta_excel: Path | None = None
        self.ruta_txt_corregido: Path | None = None
        self.ruta_pdf_rangos: Path | None = None
        self.txt_modificado = False
        self.total_registros_leidos = 0
        self.registros_validos: list[RegistroJamones] = []
        self.registros_invalidos: list[tuple[RegistroJamones, str]] = []
        self.duplicados_eliminados: list[RegistroJamones] = []
        self.registros_oficiales = []
        self.rangos_por_codigo = {}
        self.incidencias_recepcion: list[str] = []
        self.partida_sugerida = ""
        self.lote_sugerido = ""
        self.revalidacion_pendiente = False

        self.tipo_var = tk.StringVar(value="Pendiente")
        self.peso_min_var = tk.StringVar()
        self.peso_max_var = tk.StringVar()
        self.destinatarios_var = tk.StringVar(value=str(suite_obtener_preferencia(PREF_DESTINATARIOS, "") or ""))
        self.ganadero_var = tk.StringVar(value="EMBUTIDOS RODRIGUEZ")
        self.origen_var = tk.StringVar(value="Espana")
        self.dac_var = tk.StringVar()
        self.contrato_var = tk.StringVar()
        self.control_temperatura_var = tk.StringVar(value="OK")
        self.ph_var = tk.StringVar(value="OK")
        self.observaciones_var = tk.StringVar()
        self.especificacion_var = tk.StringVar(value="Anexo 5,5 ER Rev 13 FES 01")
        self.estado_var = tk.StringVar(value="Carga el TXT de FAC para empezar.")
        self.flujo_var = tk.StringVar(value="Flujo: 1 TXT > 2 Revisar pesos/correcciones > 3 SealsReport > 4 PDF rangos opcional > 5 Enviar")

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_atajos()
        self.cargar_configuracion_interna()
        self._actualizar_botones()
        suite_mostrar_ventana_sin_parpadeo(self.ventana, maximizar=True, enfocar=True, icono=True)

    def configurar_estilos(self):
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(4, weight=1)

        cabecera = suite_crear_header(
            self.ventana,
            "Control y Recepcion Maquilas",
            "Control de TXT, diferencias contra albaran, PDF de rangos y envio final.",
        )
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(18, 8))

        self.pasos_flujo = ["TXT", "Revisar", "SealsReport", "PDF opcional", "Enviar"]
        self.flujo_panel = suite_crear_flujo_proceso(self.ventana, self.pasos_flujo, activo=0)
        self.flujo_panel.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 8))

        panel_carga_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        panel_carga_canvas.grid(row=2, column=0, sticky="ew", padx=28, pady=(0, 8))
        panel_carga = panel_carga_canvas.body
        for col in range(4):
            panel_carga.columnconfigure(col, weight=1)

        self.boton_txt = ttk.Button(panel_carga, text="Cargar TXT", command=self.cargar_txt, style="Primary.TButton")
        self.boton_txt.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        self.boton_excel = ttk.Button(panel_carga, text="Cargar SealsReport", command=self.cargar_excel, style="Secondary.TButton")
        self.boton_excel.grid(row=0, column=1, sticky="ew", padx=4, pady=4)
        self.boton_revalidar = ttk.Button(panel_carga, text="Revalidar correcciones", command=self.revalidar_editor, style="Secondary.TButton")
        self.boton_revalidar.grid(row=0, column=2, sticky="ew", padx=4, pady=4)
        self.boton_guardar_txt = ttk.Button(panel_carga, text="Guardar TXT AX", command=self.guardar_txt_ax, style="Primary.TButton")
        self.boton_guardar_txt.grid(row=0, column=3, sticky="ew", padx=4, pady=4)

        self.lbl_txt = ttk.Label(panel_carga, text="TXT: no seleccionado", style="Card.TLabel")
        self.lbl_txt.grid(row=1, column=0, columnspan=2, sticky="w", padx=4, pady=(8, 0))
        self.lbl_excel = ttk.Label(panel_carga, text="SealsReport: no seleccionado", style="Card.TLabel")
        self.lbl_excel.grid(row=1, column=2, columnspan=2, sticky="w", padx=4, pady=(8, 0))
        self.lbl_tipo = ttk.Label(panel_carga, textvariable=self.tipo_var, style="CardTitle.TLabel")
        self.lbl_tipo.grid(row=2, column=0, sticky="w", padx=4, pady=(8, 0))
        filtros_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL_COMPACT)
        filtros_canvas.grid(row=3, column=0, sticky="ew", padx=28, pady=(0, 8))
        filtros = filtros_canvas.body
        filtros.columnconfigure(10, weight=1)
        ttk.Label(filtros, text="Filtro de pesos para revision", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 12))
        ttk.Label(filtros, text="Min. kg", style="Card.TLabel").grid(row=0, column=1, sticky="e")
        self.entry_peso_min = ttk.Entry(filtros, textvariable=self.peso_min_var, width=8)
        self.entry_peso_min.grid(row=0, column=2, sticky="w", padx=(5, 12))
        ttk.Label(filtros, text="Max. kg", style="Card.TLabel").grid(row=0, column=3, sticky="e")
        self.entry_peso_max = ttk.Entry(filtros, textvariable=self.peso_max_var, width=8)
        self.entry_peso_max.grid(row=0, column=4, sticky="w", padx=(5, 12))
        self.boton_filtrar_pesos = ttk.Button(filtros, text="Mostrar fuera de rango", command=self.mostrar_pesos_fuera_rango, style="Secondary.TButton")
        self.boton_filtrar_pesos.grid(row=0, column=5, sticky="w", padx=4)
        self.boton_limpiar_filtro = ttk.Button(filtros, text="Limpiar filtro", command=self.limpiar_filtro_pesos, style="Secondary.TButton")
        self.boton_limpiar_filtro.grid(row=0, column=6, sticky="w", padx=4)
        self.lbl_error_pesos = ttk.Label(filtros, text="", style="Error.TLabel")
        self.lbl_error_pesos.grid(row=1, column=1, columnspan=7, sticky="w", pady=(6, 0))

        trabajo = ttk.Frame(self.ventana, padding=(28, 0, 28, 8))
        trabajo.grid(row=4, column=0, sticky="nsew")
        trabajo.columnconfigure(0, weight=3)
        trabajo.columnconfigure(1, weight=2)
        trabajo.rowconfigure(0, weight=1)

        editor_canvas = suite_crear_panel_canvas(trabajo, padding=SUITE_PAD_PANEL)
        editor_canvas.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        editor = editor_canvas.body
        editor.columnconfigure(0, weight=1)
        editor.rowconfigure(1, weight=1)
        ttk.Label(editor, text="Correcciones pendientes", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.texto = tk.Text(editor, wrap="none", undo=True, maxundo=-1, height=16)
        suite_aplicar_texto_tk(self.texto, mono=True)
        self.texto.grid(row=1, column=0, sticky="nsew")
        scroll_y = ttk.Scrollbar(editor, orient="vertical", command=self.texto.yview)
        scroll_y.grid(row=1, column=1, sticky="ns")
        scroll_x = ttk.Scrollbar(editor, orient="horizontal", command=self.texto.xview)
        scroll_x.grid(row=2, column=0, sticky="ew")
        self.texto.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        resumen_canvas = suite_crear_panel_canvas(trabajo, padding=SUITE_PAD_PANEL)
        resumen_canvas.grid(row=0, column=1, sticky="nsew")
        resumen = resumen_canvas.body
        resumen.columnconfigure(0, weight=1)
        resumen.rowconfigure(1, weight=1)
        ttk.Label(resumen, text="Resumen", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 8))
        self.resumen = tk.Text(resumen, wrap="word", height=16, state="disabled")
        suite_aplicar_texto_tk(self.resumen, mono=False)
        self.resumen.grid(row=1, column=0, sticky="nsew")
        scroll_resumen = ttk.Scrollbar(resumen, orient="vertical", command=self.resumen.yview)
        scroll_resumen.grid(row=1, column=1, sticky="ns")
        self.resumen.configure(yscrollcommand=scroll_resumen.set)

        self.entries_meta = []

        correo_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL_COMPACT)
        correo_canvas.grid(row=5, column=0, sticky="ew", padx=28, pady=(0, 8))
        correo = correo_canvas.body
        correo.columnconfigure(1, weight=1)
        ttk.Label(correo, text="Destinatarios", style="Card.TLabel").grid(row=0, column=0, sticky="e", padx=(0, 8))
        self.entry_destinatarios = ttk.Entry(correo, textvariable=self.destinatarios_var)
        self.entry_destinatarios.grid(row=0, column=1, sticky="ew", padx=(0, 8))
        self.boton_pdf = ttk.Button(correo, text="PDF rangos", command=self.abrir_ventana_pdf_rangos, style="Primary.TButton")
        self.boton_pdf.grid(row=0, column=2, padx=4)
        self.boton_plantilla = ttk.Button(correo, text="Plantilla correo", command=self.configurar_plantilla_correo, style="Secondary.TButton")
        self.boton_plantilla.grid(row=0, column=3, padx=4)
        self.boton_enviar = ttk.Button(correo, text="Enviar correo", command=self.enviar_correo, style="Primary.TButton")
        self.boton_enviar.grid(row=0, column=4, padx=4)

        estado_frame = ttk.Frame(self.ventana, padding=(28, 0, 28, 8))
        estado_frame.grid(row=6, column=0, sticky="ew")
        estado_frame.columnconfigure(0, weight=1)
        self.lbl_estado = ttk.Label(estado_frame, textvariable=self.estado_var, style="Status.TLabel")
        self.lbl_estado.grid(row=0, column=0, sticky="ew")

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=7, column=0, sticky="ew", padx=28, pady=(0, 12))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")
        ttk.Label(footer, text=SUITE_FOOTER_TEXTO, style="Author.TLabel", anchor="center").grid(row=0, column=1, sticky="ew")
        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")

        self._set_texto_inicial()
        self._actualizar_resumen("Pendiente de cargar TXT.")
        suite_configurar_orden_tabulacion(
            self.boton_txt,
            self.boton_excel,
            self.boton_revalidar,
            self.boton_guardar_txt,
            self.entry_peso_min,
            self.entry_peso_max,
            self.boton_filtrar_pesos,
            self.boton_limpiar_filtro,
            self.texto,
            *self.entries_meta,
            self.entry_destinatarios,
            self.boton_pdf,
            self.boton_plantilla,
            self.boton_enviar,
        )

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            return
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))
            img_izq.thumbnail((180, 62))
            img_der.thumbnail((180, 62))
            self._logo_finura = ImageTk.PhotoImage(img_izq)
            self._logo_rodriguez = ImageTk.PhotoImage(img_der)
            lbl_izq = tk.Label(self.logo_slot_izq, image=self._logo_finura)
            lbl_der = tk.Label(self.logo_slot_der, image=self._logo_rodriguez)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
        except Exception:
            pass

    def configurar_atajos(self):
        suite_configurar_atajos_comunes(self.ventana, abrir=self.cargar_txt, guardar=self.guardar_txt_ax, salir=self.salir)
        self.ventana.bind("<F5>", lambda _event: self.revalidar_editor())

    def _set_estado(self, texto: str, importante: bool = False):
        self.estado_var.set(texto)
        if importante:
            suite_anunciar_estado(self.lbl_estado, texto)

    def _set_texto_inicial(self):
        self.texto.delete("1.0", "end")
        self.texto.insert(
            "1.0",
            "# Aqui apareceran los registros con incidencias o fuera de rango.\n"
            "# Formato esperado: partida;fecha;hora;codigo_articulo;numero_precinto;lote;peso;\n",
        )
        self.texto.edit_modified(False)

    def _actualizar_botones(self):
        hay_txt = bool(self.registros_validos or self.registros_invalidos)
        listo_sin_incidencias = bool(self.registros_validos) and not self.registros_invalidos and not self.revalidacion_pendiente
        excel_cargado = bool(self.registros_oficiales)
        hay_config = bool(self.rangos_por_codigo)
        debe_guardar = self._requiere_guardar_txt()
        puede_generar_pdf = listo_sin_incidencias and not debe_guardar and excel_cargado and hay_config
        puede_enviar = listo_sin_incidencias and not debe_guardar and excel_cargado and hay_config
        siguiente = None
        if not hay_txt:
            siguiente = self.boton_txt
            self._actualizar_flujo(0, "Siguiente paso: cargar TXT de recepcion")
        elif self.registros_invalidos or self.revalidacion_pendiente:
            siguiente = self.boton_revalidar
            self._actualizar_flujo(1, "Siguiente paso: revalidar correcciones o pesos")
        elif debe_guardar:
            siguiente = self.boton_guardar_txt
            self._actualizar_flujo(1, "Siguiente paso: guardar TXT AX corregido")
        elif not excel_cargado:
            siguiente = self.boton_excel
            self._actualizar_flujo(2, "Siguiente paso: cargar SealsReport")
        elif puede_enviar:
            siguiente = self.boton_enviar
            self._actualizar_flujo(4, "Siguiente paso: enviar correo; PDF rangos es opcional")

        def estilo(boton, base="Secondary.TButton"):
            try:
                boton.configure(style="Next.TButton" if boton is siguiente else base)
            except Exception:
                pass

        suite_configurar_boton_estado(self.boton_txt, True)
        suite_configurar_boton_estado(self.boton_excel, True)
        suite_configurar_boton_estado(self.boton_revalidar, bool(self.registros_invalidos or self.revalidacion_pendiente))
        suite_configurar_boton_estado(self.boton_guardar_txt, listo_sin_incidencias)
        suite_configurar_boton_estado(self.boton_filtrar_pesos, listo_sin_incidencias)
        suite_configurar_boton_estado(self.boton_limpiar_filtro, hay_txt)
        suite_configurar_boton_estado(self.boton_pdf, puede_generar_pdf)
        suite_configurar_boton_estado(self.boton_enviar, puede_enviar)
        estilo(self.boton_txt, "Primary.TButton")
        estilo(self.boton_excel)
        estilo(self.boton_revalidar)
        estilo(self.boton_guardar_txt, "Primary.TButton")
        estilo(self.boton_filtrar_pesos)
        estilo(self.boton_limpiar_filtro)
        estilo(self.boton_pdf)
        estilo(self.boton_enviar, "Primary.TButton")

    def _actualizar_flujo(self, indice: int, texto_siguiente: str) -> None:
        panel = getattr(self, "flujo_panel", None)
        actualizar = getattr(panel, "actualizar", None)
        if callable(actualizar):
            actualizar(indice, texto_siguiente)
        else:
            self.flujo_var.set(texto_siguiente)

    def _actualizar_resumen(self, texto: str):
        self.resumen.configure(state="normal")
        self.resumen.delete("1.0", "end")
        self.resumen.insert("1.0", texto)
        self.resumen.configure(state="disabled")

    def _requiere_guardar_txt(self) -> bool:
        return bool(self.txt_modificado and not (self.ruta_txt_corregido and self.ruta_txt_corregido.exists()))

    def _registro_maquila_desde_jamon(self, registro: RegistroJamones) -> RegistroMaquila | None:
        try:
            peso = decimal_desde_texto(registro.peso)
        except Exception:
            return None
        return RegistroMaquila(
            archivo=registro.archivo,
            linea=registro.linea,
            partida=registro.partida.strip(),
            fecha=registro.fecha.strip(),
            hora=registro.hora.strip(),
            codigo_fac=registro.campos[3].strip() if len(registro.campos) > 3 else "",
            precinto=registro.precinto.strip(),
            lote=registro.lote.strip(),
            peso=peso,
        )

    def _registros_maquila_actuales(self) -> tuple[list[RegistroMaquila], list[str]]:
        if self.ruta_txt_corregido and self.ruta_txt_corregido.exists():
            return leer_txt_maquila(self.ruta_txt_corregido)
        registros: list[RegistroMaquila] = []
        incidencias: list[str] = []
        for registro in self.registros_validos:
            convertido = self._registro_maquila_desde_jamon(registro)
            if convertido is None:
                incidencias.append(f"{registro.archivo}:{registro.linea} peso no valido: {registro.peso}.")
            else:
                registros.append(convertido)
        return registros, incidencias

    def _comparar_con_albaran(self, registros_maquila: list[RegistroMaquila]):
        oficiales_por_precinto = {r.precinto: r for r in self.registros_oficiales if r.precinto}
        txt_por_precinto = {r.precinto: r for r in registros_maquila if r.precinto}
        solo_txt = [txt_por_precinto[p] for p in sorted(set(txt_por_precinto) - set(oficiales_por_precinto))]
        solo_oficial = [oficiales_por_precinto[p] for p in sorted(set(oficiales_por_precinto) - set(txt_por_precinto))]
        return solo_txt, solo_oficial

    def _lineas_diferencias_albaran(self, registros_maquila: list[RegistroMaquila]) -> list[str]:
        if not self.registros_oficiales:
            return ["SealsReport pendiente."]
        solo_txt, solo_oficial = self._comparar_con_albaran(registros_maquila)
        lineas = [
            "",
            "Comparacion entre recepcion y albaran:",
            f"- Precintos recibidos en secaderos: {len({r.precinto for r in registros_maquila if r.precinto})}",
            f"- Precintos del albaran: {len({r.precinto for r in self.registros_oficiales if r.precinto})}",
            f"- Recibidos en secaderos fuera de albaran: {len(solo_txt)}",
            f"- No recibidos en secaderos del albaran: {len(solo_oficial)}",
        ]
        if solo_txt:
            lineas.append("")
            lineas.append("Recibidos en secaderos fuera de albaran:")
            for registro in solo_txt[:200]:
                lineas.append(
                    f"- {registro.precinto} | Cod. FAC {registro.codigo_fac} | Lote {registro.lote} | "
                    f"Peso {decimal_a_es(registro.peso, 2)} kg | {registro.fecha_hora}"
                )
            if len(solo_txt) > 200:
                lineas.append(f"... y {len(solo_txt) - 200} mas")
            lineas.append("Formato importable en AX:")
            lineas.append(formato_importable_ax(r.precinto for r in solo_txt))
        if solo_oficial:
            lineas.append("")
            lineas.append("No recibidos en secaderos del albaran:")
            for registro in solo_oficial[:250]:
                lineas.append(
                    f"- {registro.precinto} | Albaran {registro.albaran} | Articulo {registro.codigo_articulo} | "
                    f"Lote albaran {registro.lote} | {registro.nombre_producto}"
                )
            if len(solo_oficial) > 250:
                lineas.append(f"... y {len(solo_oficial) - 250} mas")
            lineas.append("Formato importable en AX:")
            lineas.append(formato_importable_ax(r.precinto for r in solo_oficial))
        return lineas

    def _texto_detalle_diferencias(self) -> str:
        registros_maquila, incidencias = self._registros_maquila_actuales()
        lineas = self._lineas_resumen_estado(self.total_registros_leidos or len(self.registros_validos), registros_maquila)
        if incidencias:
            lineas.append("")
            lineas.append("Incidencias de lectura para recepcion:")
            lineas.extend(f"- {incidencia}" for incidencia in incidencias)
        return "\n".join(lineas).strip() + "\r\n"

    def cargar_configuracion_interna(self):
        ruta = ruta_recurso(CONFIG_ARTICULOS_INTERNO)
        try:
            self.rangos_por_codigo, incidencias = leer_config_articulos(ruta)
            self.incidencias_recepcion = incidencias
        except Exception as exc:
            self.rangos_por_codigo = {}
            self.incidencias_recepcion = [f"No se pudo leer {CONFIG_ARTICULOS_INTERNO}: {exc}"]

    def cargar_txt(self):
        rutas = filedialog.askopenfilenames(
            parent=self.ventana,
            title="Selecciona TXT de FAC",
            filetypes=[("Ficheros TXT", "*.txt"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("control_recepcion_txt"),
        )
        if not rutas:
            return
        self.rutas_txt = [Path(r) for r in rutas]
        suite_recordar_directorio("control_recepcion_txt", rutas[0])
        self.ruta_txt_corregido = None
        self.ruta_pdf_rangos = None
        self.txt_modificado = False
        self.total_registros_leidos = 0
        try:
            registros = leer_ficheros(self.rutas_txt)
        except Exception as exc:
            messagebox.showerror("TXT no valido", f"No se pudo leer el TXT:\n{exc}", parent=self.ventana)
            return
        if not registros:
            messagebox.showwarning("TXT sin registros", "No se encontraron registros en el TXT.", parent=self.ventana)
            return
        resultado = detectar_tipo_jamon(registros, codigos_ibericos_desde_config(self.rangos_por_codigo))
        detalle_tipo = f"{resultado.gtin_validos}/{resultado.total} GTIN validos"
        if resultado.articulos_ibericos:
            detalle_tipo += f"; {resultado.articulos_ibericos} registros con articulo iberico"
        self.tipo_var.set(f"Tipo detectado: {resultado.tipo} ({detalle_tipo})")
        self._procesar_registros(registros, resultado.tipo)
        nombres = " | ".join(p.name for p in self.rutas_txt)
        self.lbl_txt.config(text=f"TXT: {nombres}")

    def _procesar_registros(self, registros: list[RegistroJamones], tipo: str):
        self.total_registros_leidos = len(registros)
        validos: list[RegistroJamones] = []
        invalidos: list[tuple[RegistroJamones, str]] = []
        self.partida_sugerida, self.lote_sugerido = sugerir_partida_lote(registros)
        for registro in registros:
            motivos = validar_registro_completo(registro, tipo, self.partida_sugerida, self.lote_sugerido)
            if motivos:
                invalidos.append((registro, "; ".join(motivos)))
            else:
                validos.append(registro)
        self.registros_validos, self.duplicados_eliminados = deduplicar(validos)
        self.registros_invalidos = invalidos
        self.txt_modificado = bool(invalidos or self.duplicados_eliminados)
        self.revalidacion_pendiente = bool(invalidos)
        self._mostrar_invalidos()
        self._actualizar_resumen_desde_estado(total=len(registros))
        self._set_estado("Corrige incidencias y revalida." if invalidos else "TXT procesado. Revisa pesos raros y guarda TXT AX.", importante=True)
        self._actualizar_botones()

    def _tipo_actual(self) -> str:
        return "Iberico" if "Iberico" in self.tipo_var.get() else "Blanco"

    def _mostrar_invalidos(self):
        self.texto.delete("1.0", "end")
        if not self.registros_invalidos:
            self.texto.insert("1.0", "# Sin incidencias de formato. Puedes aplicar filtro de pesos o guardar TXT AX.\n")
        else:
            bloques = ["# Corrige las lineas de datos. Las lineas que empiezan por # se ignoran al revalidar."]
            for registro, motivo in self.registros_invalidos:
                bloque = formatear_registro_para_editor(registro, motivo)
                if self.partida_sugerida and not re.fullmatch(r"\d{6}", registro.partida.strip()):
                    bloque += f"\n# Sugerencia partida: sustituye el primer campo por {self.partida_sugerida}"
                if self.lote_sugerido and not registro.lote.strip():
                    bloque += f"\n# Sugerencia lote: sustituye el sexto campo por {self.lote_sugerido}"
                bloques.append(bloque)
            self.texto.insert("1.0", "\n".join(bloques) + "\n")
        self.texto.edit_modified(False)

    def _lineas_resumen_estado(self, total: int, registros_maquila: list[RegistroMaquila] | None = None) -> list[str]:
        if registros_maquila is None:
            registros_maquila, incidencias_maquila = self._registros_maquila_actuales()
        else:
            incidencias_maquila = []
        peso_total = sum((r.peso for r in registros_maquila), Decimal("0"))
        lineas = [
            f"Tipo seleccionado: {self._tipo_actual() if self.registros_validos else 'Pendiente'}",
            f"Registros leidos/procesados: {total}",
            f"Registros validos conservados: {len(self.registros_validos)}",
            f"Incidencias pendientes: {len(self.registros_invalidos)}",
            f"Duplicados suprimidos: {len(self.duplicados_eliminados)}",
            f"Peso secaderos: {decimal_a_es(peso_total, 2)} kg" if registros_maquila else "Peso secaderos: -",
            f"TXT AX guardado: {self.ruta_txt_corregido}" if self.ruta_txt_corregido else (
                "TXT AX pendiente de guardar por modificaciones" if self._requiere_guardar_txt() else "TXT original valido para envio"
            ),
        ]
        if self.ruta_txt_corregido:
            lineas.append(f"Fichero corregido: {self.ruta_txt_corregido}")
        if self.ruta_pdf_rangos:
            lineas.append(f"PDF rangos: {self.ruta_pdf_rangos}")
        if incidencias_maquila:
            lineas.append("\nIncidencias de lectura para recepcion:")
            lineas.extend(f"- {incidencia}" for incidencia in incidencias_maquila[:80])
        if self.registros_invalidos:
            lineas.append("\nIncidencias detectadas:")
            for registro, motivo in self.registros_invalidos[:120]:
                lineas.append(f"- {registro.precinto or '(sin precinto)'} | {motivo} | {registro.archivo}:{registro.linea}")
            if len(self.registros_invalidos) > 120:
                lineas.append(f"... y {len(self.registros_invalidos) - 120} mas")
        lineas.extend(self._lineas_diferencias_albaran(registros_maquila))
        if self.duplicados_eliminados:
            lineas.append("\nDuplicados suprimidos:")
            for registro in self.duplicados_eliminados[:80]:
                lineas.append(f"- {registro.precinto} | {registro.fecha} {registro.hora} | {registro.archivo}:{registro.linea}")
            if len(self.duplicados_eliminados) > 80:
                lineas.append(f"... y {len(self.duplicados_eliminados) - 80} mas")
        return lineas

    def _actualizar_resumen_desde_estado(self, total: int):
        self._actualizar_resumen("\n".join(self._lineas_resumen_estado(total)))

    def _leer_registros_editor(self) -> tuple[list[tuple[tuple[str, int] | None, RegistroJamones]], list[str]]:
        registros_parseados: list[tuple[tuple[str, int] | None, RegistroJamones]] = []
        errores: list[str] = []
        orden_base = max((r.orden for r in self.registros_validos), default=0) + 100000
        origen_pendiente: tuple[str, int] | None = None
        for indice, linea in enumerate(self.texto.get("1.0", "end").splitlines(), start=1):
            texto = linea.strip()
            if not texto:
                continue
            if texto.startswith("#"):
                origen = parsear_origen_editor(texto)
                if origen is not None:
                    origen_pendiente = origen
                continue
            registro = parsear_linea(texto, "CORRECCION_MANUAL", indice, orden_base + indice)
            if registro is not None:
                registros_parseados.append((origen_pendiente, registro))
            origen_pendiente = None

        solo_datos = [registro for _origen, registro in registros_parseados]
        partida, lote = sugerir_partida_lote(self.registros_validos + solo_datos)
        if partida:
            self.partida_sugerida = partida
        if lote:
            self.lote_sugerido = lote

        registros: list[tuple[tuple[str, int] | None, RegistroJamones]] = []
        for origen, registro in registros_parseados:
            motivos = validar_registro_completo(registro, self._tipo_actual(), self.partida_sugerida, self.lote_sugerido)
            if motivos:
                errores.append(f"Linea editor {registro.linea}: {'; '.join(motivos)} -> {registro.precinto or '(sin precinto)'}")
            else:
                registros.append((origen, registro))
        return registros, errores

    def revalidar_editor(self):
        if not (self.registros_invalidos or self.revalidacion_pendiente):
            return
        corregidos, errores = self._leer_registros_editor()
        if errores:
            self._actualizar_resumen("Siguen existiendo incidencias:\n" + "\n".join(errores[:100]))
            self._set_estado("Aun quedan registros incorrectos. Revisa el resumen.", importante=True)
            self.revalidacion_pendiente = True
            self._actualizar_botones()
            return
        self.registros_validos = aplicar_correcciones_editor(self.registros_validos, self.registros_invalidos, corregidos)
        self.registros_invalidos = []
        self.revalidacion_pendiente = False
        self.txt_modificado = True
        self.ruta_txt_corregido = None
        self.ruta_pdf_rangos = None
        self._mostrar_invalidos()
        self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._set_estado("Revalidacion correcta. Guarda el TXT AX porque se han aplicado modificaciones.", importante=True)
        self._actualizar_botones()

    def limpiar_filtro_pesos(self):
        self.peso_min_var.set("")
        self.peso_max_var.set("")
        self.lbl_error_pesos.config(text="")
        self.revalidacion_pendiente = bool(self.registros_invalidos)
        self._mostrar_invalidos()
        self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._actualizar_botones()

    def mostrar_pesos_fuera_rango(self):
        if self.registros_invalidos or self.revalidacion_pendiente:
            self.lbl_error_pesos.config(text="Primero corrige y revalida las incidencias.")
            return
        minimo = parsear_peso(self.peso_min_var.get()) if self.peso_min_var.get().strip() else None
        maximo = parsear_peso(self.peso_max_var.get()) if self.peso_max_var.get().strip() else None
        if minimo is None and maximo is None:
            self.lbl_error_pesos.config(text="Introduce peso minimo, maximo o ambos.")
            return
        if self.peso_min_var.get().strip() and minimo is None:
            self.lbl_error_pesos.config(text="Peso minimo no valido. Ejemplos: 10, 10,5 o 10.5.")
            return
        if self.peso_max_var.get().strip() and maximo is None:
            self.lbl_error_pesos.config(text="Peso maximo no valido. Ejemplos: 16, 16,5 o 16.5.")
            return
        if minimo is not None and maximo is not None and minimo > maximo:
            self.lbl_error_pesos.config(text="El peso minimo no puede ser superior al maximo.")
            return
        self.lbl_error_pesos.config(text="")

        fuera: list[tuple[RegistroJamones, str]] = []
        pesos_no_validos: list[RegistroJamones] = []
        for registro in self.registros_validos:
            peso = parsear_peso(registro.peso)
            if peso is None:
                pesos_no_validos.append(registro)
                continue
            if minimo is not None and peso < minimo:
                fuera.append((registro, f"peso {registro.peso} inferior al minimo {formatear_peso(minimo)}"))
            elif maximo is not None and peso > maximo:
                fuera.append((registro, f"peso {registro.peso} superior al maximo {formatear_peso(maximo)}"))

        self.texto.delete("1.0", "end")
        if not fuera and not pesos_no_validos:
            self.texto.insert("1.0", "# No hay registros fuera del rango de peso indicado.\n")
        else:
            bloques = [
                "# Registros filtrados por peso.",
                "# Modifica estas lineas y pulsa Revalidar para sustituir el registro original.",
                "# Las lineas que empiezan por # se ignoran al revalidar.",
            ]
            bloques.extend(formatear_registro_para_editor(registro, motivo) for registro, motivo in fuera)
            bloques.extend(formatear_registro_para_editor(registro, "peso no numerico o vacio") for registro in pesos_no_validos)
            self.texto.insert("1.0", "\n".join(bloques) + "\n")
        self.revalidacion_pendiente = bool(fuera or pesos_no_validos)
        self.ruta_txt_corregido = None if self.revalidacion_pendiente else self.ruta_txt_corregido
        self.ruta_pdf_rangos = None if self.revalidacion_pendiente else self.ruta_pdf_rangos
        if self.revalidacion_pendiente:
            lineas = [
                "Filtro de pesos aplicado:",
                f"- Peso minimo: {formatear_peso(minimo) if minimo is not None else '(sin minimo)'}",
                f"- Peso maximo: {formatear_peso(maximo) if maximo is not None else '(sin maximo)'}",
                f"- Fuera de rango: {len(fuera)}",
                f"- Peso no numerico/vacio: {len(pesos_no_validos)}",
            ]
            self._actualizar_resumen("\n".join(lineas))
        else:
            self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._set_estado("Filtro aplicado. Revalida si has corregido registros.", importante=True)
        self._actualizar_botones()

    def guardar_txt_ax(self):
        if self.registros_invalidos or self.revalidacion_pendiente:
            messagebox.showwarning("Revalidacion obligatoria", "Corrige y revalida antes de guardar el TXT AX.", parent=self.ventana)
            return
        if not self.registros_validos:
            return
        nombre = self.rutas_txt[0].name if self.rutas_txt else "recepcion_corregida.txt"
        ruta = filedialog.asksaveasfilename(
            parent=self.ventana,
            title="Guardar TXT importable AX",
            defaultextension=".txt",
            filetypes=[("TXT", "*.txt"), ("Todos los archivos", "*.*")],
            initialfile=nombre,
            initialdir=suite_obtener_ultimo_directorio("control_recepcion_guardar"),
        )
        if not ruta:
            return
        salida = Path(ruta)
        try:
            with salida.open("w", encoding="utf-8", newline="") as fichero:
                for registro in self.registros_validos:
                    fichero.write(registro.a_linea().lstrip("\ufeff") + "\r\n")
        except Exception as exc:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el TXT:\n{exc}", parent=self.ventana)
            return
        suite_recordar_directorio("control_recepcion_guardar", str(salida))
        self.ruta_txt_corregido = salida
        self.ruta_pdf_rangos = None
        self._set_estado(f"TXT AX guardado: {salida.name}. Carga SealsReport y genera el PDF de rangos.", importante=True)
        self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._actualizar_botones()

    def cargar_excel(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona SealsReport oficial",
            filetypes=[("Excel", "*.xlsx"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("control_recepcion_excel"),
            parent=self.ventana,
        )
        if not ruta:
            return
        try:
            self.registros_oficiales = leer_seals_report(Path(ruta))
        except Exception as exc:
            messagebox.showerror("Excel no valido", f"No se pudo leer SealsReport:\n{exc}", parent=self.ventana)
            return
        if not self.registros_oficiales:
            messagebox.showwarning("Excel sin datos", "No se encontraron precintos oficiales en SealsReport.", parent=self.ventana)
            return
        self.ruta_excel = Path(ruta)
        self.lbl_excel.config(text=f"SealsReport: {self.ruta_excel.name} ({len(self.registros_oficiales)} precintos)")
        suite_recordar_directorio("control_recepcion_excel", ruta)
        self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._set_estado("SealsReport cargado correctamente. Ya puedes enviar o guardar el PDF de rangos.", importante=True)
        self._actualizar_botones()

    def _registros_maquila_desde_corregido(self) -> tuple[list[RegistroMaquila], list[str]]:
        return self._registros_maquila_actuales()

    def _metadatos_pdf(self) -> dict[str, str]:
        return {
            "ganadero": self.ganadero_var.get().strip(),
            "origen": self.origen_var.get().strip(),
            "dac": self.dac_var.get().strip(),
            "contrato": self.contrato_var.get().strip(),
            "control_temperatura": self.control_temperatura_var.get().strip(),
            "ph": self.ph_var.get().strip(),
            "observaciones": self.observaciones_var.get().strip(),
            "especificacion": self.especificacion_var.get().strip(),
        }

    def _generar_pdf_rangos_en(self, ruta: Path) -> None:
        try:
            registros_maquila, incidencias_txt = self._registros_maquila_desde_corregido()
            filas, avisos = agrupar_por_rangos(registros_maquila, self.rangos_por_codigo)
        except Exception as exc:
            raise RuntimeError(f"No se pudo preparar el PDF: {exc}") from exc
        generar_pdf_rangos(
            ruta,
            filas,
            registros_maquila,
            self.registros_oficiales,
            self._metadatos_pdf(),
            self.incidencias_recepcion + incidencias_txt + avisos,
        )

    def abrir_ventana_pdf_rangos(self):
        if self._requiere_guardar_txt():
            messagebox.showwarning("TXT AX pendiente", "Guarda el TXT AX corregido antes de generar el PDF.", parent=self.ventana)
            return
        if not (self.registros_validos and self.registros_oficiales and self.rangos_por_codigo):
            return
        ventana = tk.Toplevel(self.ventana)
        ventana.title("Campos PDF rangos")
        aplicar_icono_ventana(ventana)
        ventana.transient(self.ventana)
        ventana.grab_set()
        ventana.columnconfigure(0, weight=1)
        try:
            ventana.geometry("860x420")
            ventana.minsize(680, 340)
        except Exception:
            pass

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        contenedor.grid(row=0, column=0, sticky="nsew")
        for col in (1, 3):
            contenedor.columnconfigure(col, weight=1)

        ttk.Label(contenedor, text="Campos del informe de rangos", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 12))
        campos = [
            ("Ganadero", self.ganadero_var, 1, 0),
            ("Origen", self.origen_var, 1, 2),
            ("N DAC", self.dac_var, 2, 0),
            ("Contrato", self.contrato_var, 2, 2),
            ("Control de temperatura", self.control_temperatura_var, 3, 0),
            ("PH", self.ph_var, 3, 2),
            ("Especificacion", self.especificacion_var, 4, 0),
            ("Observaciones", self.observaciones_var, 5, 0),
        ]
        for etiqueta, variable, fila, columna in campos:
            ttk.Label(contenedor, text=etiqueta, style="Card.TLabel").grid(row=fila, column=columna, sticky="e", padx=(0, 8), pady=5)
            entry = ttk.Entry(contenedor, textvariable=variable)
            span = 3 if etiqueta in {"Especificacion", "Observaciones"} else 1
            entry.grid(row=fila, column=columna + 1, columnspan=span, sticky="ew", padx=(0, 14), pady=5)

        ttk.Label(
            contenedor,
            text="Estos valores se usaran tambien si cierras esta ventana y despues envias el correo.",
            style="Card.TLabel",
        ).grid(row=6, column=0, columnspan=4, sticky="w", pady=(12, 0))

        botones = ttk.Frame(contenedor, style="Card.TFrame")
        botones.grid(row=7, column=0, columnspan=4, sticky="e", pady=(18, 0))
        ttk.Button(botones, text="Guardar PDF", command=lambda: self.generar_pdf_rangos(ventana), style="Primary.TButton").grid(row=0, column=0, padx=5)
        ttk.Button(botones, text="Cerrar", command=ventana.destroy, style="Secondary.TButton").grid(row=0, column=1, padx=5)

    def generar_pdf_rangos(self, ventana_dialogo=None):
        if self._requiere_guardar_txt():
            messagebox.showwarning("TXT AX pendiente", "Guarda el TXT AX corregido antes de generar el PDF.", parent=self.ventana)
            return
        if not (self.registros_validos and self.registros_oficiales and self.rangos_por_codigo):
            return
        registros_maquila, _incidencias_txt = self._registros_maquila_actuales()
        partida = valor_mayoritario(r.partida for r in registros_maquila) or "recepcion"
        ruta = filedialog.asksaveasfilename(
            parent=ventana_dialogo or self.ventana,
            title="Guardar PDF de rangos",
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile=f"Informe rangos {partida}.pdf",
            initialdir=str((self.ruta_txt_corregido or self.rutas_txt[0]).parent) if (self.ruta_txt_corregido or self.rutas_txt) else os.getcwd(),
        )
        if not ruta:
            return
        try:
            self._generar_pdf_rangos_en(Path(ruta))
        except Exception as exc:
            messagebox.showerror("Error al generar PDF", f"No se pudo generar el informe de rangos:\n{exc}", parent=ventana_dialogo or self.ventana)
            return
        self.ruta_pdf_rangos = Path(ruta)
        self._set_estado(f"PDF de rangos generado: {self.ruta_pdf_rangos.name}", importante=True)
        self._actualizar_resumen_desde_estado(total=self.total_registros_leidos or len(self.registros_validos) + len(self.duplicados_eliminados))
        self._actualizar_botones()

    def _plantilla_correo_actual(self) -> tuple[str, str]:
        asunto = str(suite_obtener_preferencia(PREF_ASUNTO, ASUNTO_DEFECTO) or ASUNTO_DEFECTO)
        mensaje = str(suite_obtener_preferencia(PREF_MENSAJE, MENSAJE_DEFECTO) or MENSAJE_DEFECTO)
        return asunto, mensaje

    def _guardar_plantilla_correo(self, asunto: str, mensaje: str):
        suite_establecer_preferencia(PREF_ASUNTO, asunto.strip() or ASUNTO_DEFECTO)
        suite_establecer_preferencia(PREF_MENSAJE, mensaje.strip() or MENSAJE_DEFECTO)

    def _valores_plantilla(self) -> dict[str, str]:
        partida = valor_mayoritario(r.partida for r in self.registros_validos)
        lote = valor_mayoritario(r.lote for r in self.registros_validos)
        fecha = valor_mayoritario(r.fecha for r in self.registros_validos)
        return {
            "tipo_jamon": self._tipo_actual(),
            "partida": partida,
            "lote": lote,
            "fecha_recepcion": fecha,
            "registros_validos": str(len(self.registros_validos)),
        }

    def _renderizar_plantilla(self, texto: str) -> str:
        try:
            return texto.format(**self._valores_plantilla())
        except Exception:
            return texto

    def configurar_plantilla_correo(self):
        asunto_actual, mensaje_actual = self._plantilla_correo_actual()
        ventana = tk.Toplevel(self.ventana)
        ventana.title("Plantilla correo")
        aplicar_icono_ventana(ventana)
        ventana.transient(self.ventana)
        ventana.grab_set()
        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(0, weight=1)
        try:
            ventana.geometry("760x520")
            ventana.minsize(600, 380)
        except Exception:
            pass

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        contenedor.grid(row=0, column=0, sticky="nsew")
        contenedor.columnconfigure(1, weight=1)
        contenedor.rowconfigure(2, weight=1)

        ttk.Label(contenedor, text="Plantilla editable", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        ttk.Label(contenedor, text="Asunto", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=(0, 8))
        asunto_var = tk.StringVar(value=asunto_actual)
        ttk.Entry(contenedor, textvariable=asunto_var).grid(row=1, column=1, sticky="ew", pady=(0, 8))
        ttk.Label(contenedor, text="Mensaje", style="Card.TLabel").grid(row=2, column=0, sticky="nw", padx=(0, 10))
        texto = tk.Text(contenedor, wrap="word", undo=True, maxundo=-1, height=12)
        suite_aplicar_texto_tk(texto, mono=False)
        texto.grid(row=2, column=1, sticky="nsew")
        texto.insert("1.0", mensaje_actual)
        ttk.Label(
            contenedor,
            text="Variables: {tipo_jamon}, {partida}, {lote}, {fecha_recepcion}, {registros_validos}",
            style="Card.TLabel",
        ).grid(row=3, column=1, sticky="w", pady=(8, 0))

        botones = ttk.Frame(contenedor, style="Card.TFrame")
        botones.grid(row=4, column=0, columnspan=2, sticky="e", pady=(14, 0))

        def restaurar():
            asunto_var.set(ASUNTO_DEFECTO)
            texto.delete("1.0", "end")
            texto.insert("1.0", MENSAJE_DEFECTO)

        def guardar():
            self._guardar_plantilla_correo(asunto_var.get(), texto.get("1.0", "end-1c"))
            self._set_estado("Plantilla de correo guardada.", importante=False)
            ventana.destroy()

        ttk.Button(botones, text="Restaurar", command=restaurar, style="Secondary.TButton").grid(row=0, column=0, padx=5)
        ttk.Button(botones, text="Guardar plantilla", command=guardar, style="Primary.TButton").grid(row=0, column=1, padx=5)
        ttk.Button(botones, text="Cancelar", command=ventana.destroy, style="Secondary.TButton").grid(row=0, column=2, padx=5)

    def _crear_txt_detalle(self, carpeta: Path) -> Path:
        base = (self.ruta_txt_corregido or (self.rutas_txt[0] if self.rutas_txt else None))
        base = base.stem if base else "recepcion"
        ruta = carpeta / f"{base}_detalles.txt"
        with ruta.open("w", encoding="utf-8", newline="") as fichero:
            fichero.write(self._texto_detalle_diferencias())
        return ruta

    def _enviar_adjuntos(self, destinatarios: list[str], adjuntos: list[Path]):
        asunto, cuerpo = self._plantilla_correo_actual()
        mensaje = EmailMessage()
        mensaje["From"] = SMTP_USUARIO
        mensaje["To"] = ", ".join(destinatarios)
        mensaje["Subject"] = self._renderizar_plantilla(asunto)
        mensaje.set_content(self._renderizar_plantilla(cuerpo))
        for ruta in adjuntos:
            subtype = "pdf" if ruta.suffix.lower() == ".pdf" else "plain"
            maintype = "application" if subtype == "pdf" else "text"
            mensaje.add_attachment(ruta.read_bytes(), maintype=maintype, subtype=subtype, filename=ruta.name)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as smtp:
            smtp.login(SMTP_USUARIO, SMTP_PASSWORD)
            smtp.send_message(mensaje)

    def enviar_correo(self):
        if self.registros_invalidos or self.revalidacion_pendiente:
            messagebox.showwarning("Revalidacion obligatoria", "Corrige y revalida antes de enviar el correo.", parent=self.ventana)
            return
        if self._requiere_guardar_txt():
            messagebox.showwarning("TXT AX pendiente", "Se han aplicado modificaciones. Guarda primero el TXT AX corregido.", parent=self.ventana)
            return
        if not (self.registros_validos and self.registros_oficiales and self.rangos_por_codigo):
            return
        destinatarios = parsear_destinatarios(self.destinatarios_var.get())
        if not destinatarios:
            messagebox.showwarning("Destinatarios", "Introduce al menos una direccion de correo.", parent=self.ventana)
            return
        invalidos = validar_destinatarios(destinatarios)
        if invalidos:
            messagebox.showwarning("Correo no valido", "Revisa estas direcciones:\n" + "\n".join(invalidos), parent=self.ventana)
            return
        try:
            with tempfile.TemporaryDirectory(prefix="control_recepcion_correo_") as temporal:
                carpeta_temporal = Path(temporal)
                detalle = self._crear_txt_detalle(carpeta_temporal)
                pdf = self.ruta_pdf_rangos if self.ruta_pdf_rangos and self.ruta_pdf_rangos.exists() else carpeta_temporal / "Informe rangos recepcion.pdf"
                if not pdf.exists():
                    self._generar_pdf_rangos_en(pdf)
                adjuntos = [detalle, pdf]
                self._enviar_adjuntos(destinatarios, adjuntos)
            suite_establecer_preferencia(PREF_DESTINATARIOS, "; ".join(destinatarios))
        except Exception as exc:
            messagebox.showerror("Error al enviar correo", f"No se pudo enviar el correo:\n{exc}", parent=self.ventana)
            self._set_estado("No se pudo enviar el correo.", importante=True)
            return
        self._set_estado(f"Correo enviado correctamente a {', '.join(destinatarios)}.", importante=True)

    def salir(self):
        self.ventana.destroy()


def lanzar_app_control_recepcion_maquilas(ventana_padre=None):
    ventana = tk.Toplevel(ventana_padre) if ventana_padre is not None else tk.Tk()
    ControlRecepcionMaquilasApp(ventana)
    return ventana


if __name__ == "__main__":
    root = tk.Tk()
    ControlRecepcionMaquilasApp(root)
    root.mainloop()
