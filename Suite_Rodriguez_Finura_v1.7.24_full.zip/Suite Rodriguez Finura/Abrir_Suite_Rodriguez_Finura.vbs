Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = base
command = """" & base & "\runtime\pythonw.exe" & """ """ & base & "\SuiteLauncher.py" & """"
shell.Run command, 0, False
