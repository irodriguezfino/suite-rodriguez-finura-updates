"""Runtime bootstrap for the bundled Suite Rodriguez Finura Python.

Python imports this module automatically during startup. Keeping the Tcl/Tk
paths here makes tkinter independent from the current working directory and
from how Windows resolves the embedded runtime.
"""
from __future__ import annotations

import os
from pathlib import Path


RUNTIME_DIR = Path(__file__).resolve().parents[1]
TCL_LIBRARY = RUNTIME_DIR / "tcl" / "tcl8.6"
TK_LIBRARY = RUNTIME_DIR / "tcl" / "tk8.6"

if TCL_LIBRARY.exists():
    os.environ.setdefault("TCL_LIBRARY", TCL_LIBRARY.as_posix())
if TK_LIBRARY.exists():
    os.environ.setdefault("TK_LIBRARY", TK_LIBRARY.as_posix())
