from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
VERIFY_SCRIPTS = (
    "verify_phase1.py",
    "verify_phase2.py",
    "verify_phase3.py",
    "verify_phase4.py",
    "verify_phase5.py",
    "verify_phase6.py",
    "verify_phase7.py",
    "verify_phase9.py",
    "verify_phase10.py",
    "verify_phase11.py",
    "verify_phase12.py",
    "verify_phase13.py",
    "verify_phase14.py",
    "verify_phase15.py",
    "verify_phase16.py",
    "verify_phase17.py",
    "verify_phase18.py",
    "verify_phase19.py",
    "verify_phase20.py",
    "verify_phase21.py",
    "verify_architecture.py",
    "verify_design_system.py",
)


def run(command: list[str], *, cwd: Path = ROOT) -> str:
    completed = subprocess.run(
        command,
        cwd=cwd,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return completed.stdout


def git_path() -> str:
    override = os.environ.get("GIT_EXE")
    if override:
        return override
    return "git"


def assert_core_unchanged() -> None:
    try:
        output = run(
            [
                git_path(),
                "diff",
                "--name-only",
                "HEAD",
                "--",
                "Suite_PySide6/src/suite_pyside6/core",
            ],
            cwd=REPO,
        )
    except Exception as exc:
        raise AssertionError(f"No se pudo comprobar el estado de core/: {exc}") from exc
    allowed_core_changes = {
        "Suite_PySide6/src/suite_pyside6/core/apps.py",
        "Suite_PySide6/src/suite_pyside6/core/control_recepcion_maquilas.py",
        "Suite_PySide6/src/suite_pyside6/core/file_compare/detectors.py",
        "Suite_PySide6/src/suite_pyside6/core/precintos_jamones.py",
        "Suite_PySide6/src/suite_pyside6/core/pesos.py",
        "Suite_PySide6/src/suite_pyside6/core/reparto_merma_precintos.py",
        "Suite_PySide6/src/suite_pyside6/core/recepcion_maquilas.py",
        # La ruta de configuración se desacopló de Qt; es una mejora de
        # arquitectura deliberada y está cubierta por test_user_paths.py.
        "Suite_PySide6/src/suite_pyside6/core/empresas_clientes.py",
    }
    changed = [
        line.strip()
        for line in output.splitlines()
        if line.strip() and not line.startswith("warning:") and line.strip() not in allowed_core_changes
    ]
    assert not changed, "La capa core/ no debe cambiar en esta fase: " + ", ".join(changed)


def main() -> int:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    assert_core_unchanged()
    for script in VERIFY_SCRIPTS:
        output = run([sys.executable, str(ROOT / "tools" / script)])
        marker = script.replace("verify_", "").replace(".py", "").upper()
        print(output.strip())
        assert "OK" in output, f"No se encontro marcador OK en {script} ({marker})"
    print("UI_CONTRACTS_OK")
    print("core_unchanged=true")
    print(f"checks={len(VERIFY_SCRIPTS)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
