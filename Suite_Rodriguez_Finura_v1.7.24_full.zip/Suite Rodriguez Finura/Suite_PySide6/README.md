# Suite Rodriguez Finura

Suite operativa profesional para procesos Rodriguez Finura.

## Objetivo

- Mantener una interfaz profesional y consistente.
- Separar logica funcional reutilizable de la interfaz.
- Publicar paquetes de actualizacion verificables para todos los equipos.

## Empresas cliente de Control y Recepción

La plantilla distribuida está en `resources/empresas_clientes.txt`. En la primera
ejecución, la aplicación crea una copia editable en la configuración del usuario:
`%APPDATA%\RodriguezFinura\SuitePySide6\control_recepcion_precintos\empresas_clientes.txt`.
Añade una empresa por línea, guarda el archivo en UTF-8 y vuelve a abrir
**Campos manuales informe** para recargar la lista. Las líneas vacías, comentarios
que comienzan por `#` y duplicados no se muestran.

## Fuente de referencia

La primera referencia funcional se toma de:

`../outputs/worktree_1_4_27/build_1_4_43`

Esa carpeta no se modifica desde este proyecto. Se usa como comparador y como
fuente para extraer comportamiento probado.

## Estructura

- `src/suite_pyside6/core`: logica sin GUI.
- `src/suite_pyside6/ui`: capa visual.
- `tools`: verificaciones y utilidades de release.

## Primer modulo extraido

`suite_pyside6.core.precintos_excel` contiene la lectura de precintos desde
archivos XLSX/XLSM, separada de Tkinter. Es la primera pieza para portar la app
"Exportar Precintos Excel a CSV".

## Ejecutar el menu PySide6

Entorno local preparado:

`../qtv/Scripts/python.exe -m suite_pyside6.main`

Verificaciones:

`../qtv/Scripts/python.exe tools/verify_phase2.py`

`../qtv/Scripts/python.exe tools/verify_phase3.py`

`../qtv/Scripts/python.exe tools/verify_phase4.py`

`../qtv/Scripts/python.exe tools/verify_phase5.py`

`../qtv/Scripts/python.exe tools/verify_phase6.py`

`../qtv/Scripts/python.exe tools/verify_phase7.py`

`../qtv/Scripts/python.exe tools/verify_phase8.py`

`../qtv/Scripts/python.exe tools/verify_phase9.py`

`../qtv/Scripts/python.exe tools/verify_phase10.py`

La suite Tkinter actual sigue intacta. El menu nuevo puede lanzar apps legacy
como procesos separados mientras se portan una a una.

## Primera app portada

`Precintos Excel a CSV` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.precintos_excel_window.PrecintosExcelWindow`

El menu PySide6 abre esta version nueva. El resto de apps siguen preparadas para
abrirse como legacy mientras se portan.

## Segunda app portada

`Procesador TXT a CSV` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.txt_csv_window.TxtCsvWindow`

El core separado vive en:

`suite_pyside6.core.txt_csv`

## Tercera app portada

`Palets PDA a CSV` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.palets_window.PaletsWindow`

El core separado vive en:

`suite_pyside6.core.palets`

## Cuarta app portada

`Merma Jamones FAC` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.mermas_window.MermasWindow`

El core separado vive en:

`suite_pyside6.core.mermas`

## Quinta app portada

`Precintos Expedicion` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.precintos_expedicion_window.PrecintosExpedicionWindow`

El core separado vive en:

`suite_pyside6.core.precintos_expedicion`

## Sexta app portada

`Control y Recepción Precintos` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.control_recepcion_maquilas_window.ControlRecepcionPrecintosWindow`

El core separado vive en:

`suite_pyside6.core.control_recepcion_maquilas`

El cruce con SealsReport reutiliza `suite_pyside6.core.recepcion_maquilas`; ya no
existe una ventana independiente de recepción.

## Séptima app portada

`Precintos Jamones` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.precintos_jamones_window.PrecintosJamonesWindow`

El core separado vive en:

`suite_pyside6.core.precintos_jamones`

Con esta fase, las 9 apps del menu estan disponibles en la suite profesional.

## Novena app portada

`Pesos` ya tiene ventana PySide6 propia:

`suite_pyside6.ui.pesos_window.PesosWindow`

El core separado vive en:

`suite_pyside6.core.pesos`

La aplicacion permite seleccionar varios XLSX/XLSM y renombrar la primera hoja
visible a `Hoja1` sin modificar datos ni formatos.

## Precintos Deshuesado

La herramienta conserva el identificador interno `reparto_merma_precintos` y
presenta una selección inicial entre PDA y FAC. PDA mantiene el reparto
proporcional del Excel de mensajes. FAC lee uno o varios CSV separados por
`;`, ignora filas vacías, exporta solo `SI` y reutiliza el mismo contrato AX:
CP1252, `;`, coma decimal, dos decimales, sin cabecera y CRLF.

En PDA, el campo visible `Orden de trabajo - OPL` sigue alimentando el CSV AX.
Además, puede indicarse `Fecha OPL` y enviar por correo un Excel independiente
con fecha OPL, fecha de creación del precinto, precinto, peso origen, peso final,
merma individual y OPL. Los destinatarios son editables y el envío del informe
no altera ni condiciona el guardado del CSV AX.

Los ficheros PDA automáticos pueden incluir mensajes `No hay transacciones
positivas para el serial ...`. Esos avisos se contabilizan como líneas
ignoradas y no bloquean el reparto de los registros que sí contienen precinto
y peso.

## Precintos TXT a CSV AX

La herramienta admite varios TXT en una misma operación y permite seguir
añadiendo archivos hasta completar el lote. Por cada línea conserva el número
posterior a la flecha sin su último dígito. Los duplicados se detectan sobre el
conjunto unificado, se muestran en el resumen y se excluyen del CSV. El contador
`Precintos finales` indica las filas reales de salida y `Limpiar proceso`
reinicia toda la operación sin cerrar la Suite.

## Pasada de paridad visual y funcional

Se ha reforzado el tema global PySide6 con la identidad azul/rojo de Rodriguez:

- Cabecera azul con acento rojo.
- Botones primarios rojos y foco/seleccion azul.
- Tablas, campos, estados y tarjetas con estilos comunes.
- Logo Rodriguez visible en el menu principal.
- Logo Finura visible junto a Rodriguez en el menu principal.
- Foco visible reforzado, contraste AA en colores principales y objetivos de
  accion mas grandes.
- Barras de pasos por aplicacion para indicar el flujo principal sin depender
  de memoria del usuario.
- Panel lateral de categorias y metricas del menu principal para mejorar
  orientacion y visibilidad del estado.
- Segunda pasada profesional sobre WCAG 2.2 AA + heuristicas de Nielsen:
  cabecera en tarjeta blanca con doble marca, acentos azul/rojo mas sobrios,
  paneles con sombras sutiles, tarjetas de aplicaciones con indicador lateral,
  categorias con conteo, botones con iconos nativos y tooltips, y estados mas
  escaneables sin cambiar la secuencia funcional.
- Tercera pasada de producto: se elimina el lenguaje tecnico de migracion del
  menu, se presenta la suite como panel operativo, se sustituyen estados
  "legacy/PySide6" por disponibilidad real, se refinan tarjetas, tablas,
  toolbars y textos de accion para que cada ventana se lea como una aplicacion
  profesional y no como un formulario tecnico.
- Cuarta pasada de interfaz: modo claro/oscuro persistente, logos Rodriguez y
  Finura en las aplicaciones, selector de tema en menu y ventanas, stepper
  visual comun, sombras mas suaves, tablas sin rejilla dura y atajos
  consistentes con tooltips para cargar, procesar, guardar y limpiar.
- Actualizacion de auditoria UI: se eliminan atajos duplicados por ventana, se
  asignan nombres accesibles a botones, campos, combos, tablas y areas de
  resultados, se evita reconstruir el menu en cada resize menor y se hace mas
  fiable el color alterno de tablas en Qt.
- Bloque A de mejoras funcionales de interfaz: panel de contexto por
  aplicacion con estado/siguiente accion/avisos, banners inline para avisos,
  errores y confirmaciones, y tooltips explicativos en botones deshabilitados.
- Bloque B de continuidad operativa: dialogos de abrir/guardar con memoria de
  carpeta por accion, historial reciente de archivos y exportaciones, y base
  comun de sesion con `QSettings` para no repetir navegacion manual.
- Bloque C de uso diario: arrastre de archivos sobre las ventanas portadas,
  stepper dinamico segun estado real, vistas Favoritos/Recientes en el menu y
  marcado de procesos favoritos desde cada tarjeta.
- Primera pasada de paridad funcional con legacy: Recepcion Maquilas y Control
  y Recepcion Maquilas recuperan los metadatos completos del PDF de rangos
  (`N DAC`, contrato, control de temperatura, PH, observaciones y
  especificacion); Control y Recepcion puede continuar con el TXT original si
  no hubo incidencias ni duplicados, genera el PDF temporal al enviar correo
  si no se guardo antes y adjunta detalle + PDF como en el flujo estable.
- Ajuste de Precintos Jamones: `formato_importable_ax` vuelve a generar los
  codigos separados por comas, igual que la aplicacion original.

Tambien se han recuperado pasos de flujo que no estaban suficientemente fieles
al legacy:

- `Precintos Jamones`: correccion editable de incidencias y revalidacion antes
  de guardar TXT/CSV.
- `Control y Recepcion Maquilas`: correccion editable de incidencias y
  revalidacion antes de guardar TXT AX y continuar con SealsReport.
- `Recepcion Maquilas`: los PDFs intentan usar el generador legacy original
  para mantener formato y contenido mas cercano a la version estable.

## Pasada de paridad funcional avanzada

Se han cerrado diferencias detectadas en la auditoria de clonacion frente a las
apps legacy:

- `Control y Recepcion Maquilas`: deteccion de jamon iberico/blanco por GTIN y
  por codigos FAC configurados como ibericos; validacion GTIN-12 estricta para
  iberico; partida de 6 digitos; sugerencias de partida/lote; filtro de pesos
  fuera de rango con correccion y revalidacion; limpieza de correcciones y
  plantilla de correo persistente.
- `Precintos Jamones`: sugerencias oficiales cercanas por distancia de digitos,
  transposicion simple y similitud; comparacion oficial incluyendo precintos de
  12 digitos aunque tengan incidencia; filtro de pesos fuera de rango con
  correccion y revalidacion; plantilla de correo persistente con variables.
- `Recepcion Maquilas`: accion para generar en una sola operacion el PDF de
  diferencias y el PDF de rangos, como en la aplicacion estable.
- `Precintos Expedicion`: validacion previa de nombres TXT pendientes,
  duplicados y caracteres no permitidos antes de guardar.

Las verificaciones `verify_phase1.py` a `verify_phase10.py` pasan tras esta
pasada.

## Bloque UI-A: accesibilidad y seguridad de uso

Primera tanda de mejoras de interfaz tras cerrar la paridad funcional:

- Modo oscuro: colores de texto para estados `success` y `warning` ajustados
  para cumplir contraste WCAG AA sobre sus fondos.
- Badges de pasos: contraste revisado en estados completado/aviso para modo
  oscuro.
- Botones deshabilitados: ademas del tooltip visible, se define descripcion
  accesible con el motivo por el que la accion no esta disponible.
- Orden de tabulacion: se aplica una secuencia de foco consistente a campos,
  combos, botones, areas de texto y tablas.
- Proteccion ante perdida de trabajo: las ventanas confirman al limpiar o
  cerrar cuando hay archivos, correcciones o resultados en pantalla.
- Las confirmaciones se desactivan automaticamente en verificaciones
  `offscreen`, para no bloquear las pruebas automatizadas.

## Bloque UI-B: toolbars y paneles profesionales

Segunda tanda de mejoras de interfaz centrada en reducir ruido visual y mejorar
la secuencia de uso:

- Se anaden estilos comunes para grupos de acciones (`Entrada`, `Revision`,
  `Cruce`, `Proceso`, `Salida`) y campos compactos.
- `Control y Recepcion Maquilas`: la barra de acciones se divide por etapas y
  los campos de peso dejan de forzar anchura excesiva.
- `Precintos Jamones`: se separan tipo/carga, revision/filtros y salidas.
- `Recepcion Maquilas`: se separan carga/configuracion, procesamiento y
  generacion de PDFs.
- Los paneles de correo se muestran como panel secundario diferenciado.
- Los metadatos de informes en Recepcion y Control Recepcion se marcan como
  panel de formulario, no como tarjeta generica.

### Ajuste UI-B adicional

Se ha aplicado una pasada adicional sobre todas las toolbars:

- Se eliminan los iconos automaticos de botones porque daban una lectura visual
  irregular y poco profesional.
- Los botones de toolbar usan etiquetas compactas, manteniendo el texto completo
  en tooltip y nombre accesible.
- Los anchos minimos de botones en toolbars se reducen para evitar cortes de
  texto.
- El stepper dinamico usa textos mas cortos y conectores simples.
- El modo oscuro se suaviza con fondos menos negros, superficies azul grisaceas
  y acentos menos agresivos, manteniendo contraste WCAG AA.

## Comparador de archivos

La suite incluye **Comparador de archivos**, disponible desde `Utilidades`. Su
motor se ha diseñado por capas: `core/file_compare` contiene el modelo de
resultado, deteccion, lectura binaria segura, comparadores de texto y formatos
estructurados, carpetas e informes; la CLI y la ventana PySide6 reutilizan ese
mismo motor.

La igualdad estricta siempre se confirma leyendo ambos archivos por bloques y
comparando bytes. SHA-256 y el tamano sirven de resumen y aceleracion, nunca
son el unico criterio. Los archivos grandes no se cargan enteros en memoria;
los diffs de texto se limitan a 20 MiB y, por encima, queda disponible el
resultado binario. JSON, XML, CSV/TSV y ZIP se limitan a 50 MiB en modo
semantico. JSON, XML y CSV/TSV pueden analizarse semanticamente; ZIP
se compara por entradas descomprimidas sin extraer archivos al disco.

### Instalacion y ejecucion

Requiere Python 3.11+ y las dependencias ya declaradas en `pyproject.toml`.

```powershell
cd Suite_PySide6
python -m pip install -e .
filecompare "C:\datos\uno.json" "C:\datos\dos.json" --mode semantic --format html --output informe.html
suite-pyside6
```

Tambien se puede ejecutar sin instalar desde este repositorio:

```powershell
$env:PYTHONPATH = "src"
..\qtv\Scripts\python.exe -m suite_pyside6.filecompare_cli archivo1 archivo2 --max-differences 50
```

La CLI devuelve `0` si los bytes son iguales, `1` si son diferentes y `2` ante
errores de ruta, lectura o analisis. Acepta `--mode strict|semantic|auto`,
`--format text|json|html`, `--ignore-case`, `--ignore-whitespace`,
`--ignore-line-endings`, `--exclude` y `--max-differences`. La ventana permite
seleccionar archivos o carpetas, ver el detalle sin bloquear la interfaz,
cancelar la presentacion del resultado, copiarlo, abrir las rutas y guardarlo
como texto, JSON o HTML autocontenido.

### Limitaciones y seguridad

“Cualquier tipo” significa que cualquier archivo es comparable de forma
binaria. La interpretacion semantica se limita actualmente a texto, JSON, XML,
CSV/TSV y ZIP. Las imagenes y PDF se identifican y se comparan por bytes, pero
no se incluye aun analisis visual ni extraccion de texto porque requeririan
dependencias opcionales. YAML se trata como texto. Las entradas ZIP no se
extraen, se ignoran enlaces simbolicos en carpetas y las entradas individuales
de ZIP superiores a 512 MiB se omiten en el analisis semantico para evitar
consumo desmedido de recursos.

Para crear otro comparador, implemente una funcion que reciba dos `Path`,
`ComparisonOptions` y `ComparisonResult`, agregue instancias de `Difference`,
y regístrela en `core/file_compare/service.py` segun el tipo detectado.

### Pruebas

Las pruebas usan solo archivos temporales, incluidos binarios, Unicode, JSON,
XML, CSV, ZIP, informes, CLI y carpetas:

```powershell
$env:PYTHONPATH = "src"
..\qtv\Scripts\python.exe -m unittest discover -s tests -p test_file_compare.py -v
```
