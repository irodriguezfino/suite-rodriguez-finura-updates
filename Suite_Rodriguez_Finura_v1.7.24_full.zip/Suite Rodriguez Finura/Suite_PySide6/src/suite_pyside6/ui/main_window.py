from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QEvent, QTimer, Qt
from PySide6.QtGui import QAction, QFont, QIcon
from PySide6.QtWidgets import (
    QApplication,
    QBoxLayout,
    QCheckBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from suite_pyside6 import __version__
from suite_pyside6.ui.visual_controls import ModernCheckBox as QCheckBox
from suite_pyside6.core.app_organization import CategoryDefinition
from suite_pyside6.core.apps import APP_REGISTRY, AppDefinition, app_by_key, categories
from suite_pyside6.core.paths import resource_path
from suite_pyside6.ui.about_dialog import AboutDialog
from suite_pyside6.ui.app_help import AppHelpDialog
from suite_pyside6.ui.app_windows import preloaded_window_class, preload_window_class
from suite_pyside6.ui.components import (
    ActionMenuButton,
    ModernSelect,
    SearchableComboBox,
    configure_header_action,
    dashboard_process_card,
    dropzone,
    empty_state,
    labeled_field,
    metric,
    module_row,
    panel,
    work_item,
)
from suite_pyside6.ui.polish import apply_premium_depth, apply_theme_mode, brand_logo_pixmap, focus_next_action, handle_dropped_paths, operational_snapshot, prepare_embedded_window, trigger_next_action
from suite_pyside6.ui.personalized_descriptions import (
    PersonalizedDescriptionControl,
    header_description_key,
    migrate_control_recepcion_precintos_header,
    process_description_key,
)
from suite_pyside6.ui.navigation import reveal_view
from suite_pyside6.ui.session import (
    load_app_organization,
    recent_app_keys,
    recent_paths,
    remember_app_open,
    reset_app_organization,
    save_app_organization,
)
from suite_pyside6.ui.theme import base_qss, current_theme_preference


NAVIGATION_LOADING_DELAY_MS = 16


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.current_view = "bandeja"
        self.current_category = "Todas"
        self.search_text = ""
        self.open_windows: dict[str, QMainWindow] = {}
        self.app_pages: dict[str, QMainWindow] = {}
        self.app_page_indexes: dict[str, int] = {}
        self.nav_buttons: dict[str, QPushButton] = {}
        self.category_buttons: dict[str, QPushButton] = {}
        self.active_job_buttons: dict[str, QPushButton] = {}
        self._current_app_key = ""
        self._opening_app_key = ""
        self._continue_app_key = ""
        self._open_request_id = 0
        self._pending_open_paths: list[Path] = []
        self._pending_open_buttons: list[tuple[QPushButton, str]] = []
        self._process_catalog_signature = None
        self._process_filter_text = None
        self._process_rows: dict[str, QWidget] = {}
        self._process_groups = []
        self._closing = False
        self.app_organization = load_app_organization(APP_REGISTRY)
        self._organization_updating = False

        self.setWindowTitle("Consola Operativa Rodriguez Finura")
        self.resize(1360, 820)
        self.setMinimumSize(960, 620)
        icon_path = resource_path("ICONO_SUITE.ico")
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.setStyleSheet(base_qss())
        self._build_actions()
        self._build_ui()
        self._refresh_all()
        apply_premium_depth(self)

        self.context_timer = QTimer(self)
        # El contexto es información auxiliar; una cadencia moderada evita
        # recorrer el árbol de widgets repetidamente mientras el usuario lee.
        self.context_timer.setInterval(1200)
        self.context_timer.timeout.connect(self._update_context)
        self.context_timer.start()

    def _build_actions(self) -> None:
        for app in APP_REGISTRY:
            action = QAction(self)
            action.setShortcut(app.shortcut)
            action.triggered.connect(lambda _checked=False, item=app: self.open_app(item))
            self.addAction(action)

        shortcuts = (
            ("Ctrl+L", self._focus_search),
            ("Ctrl+1", lambda: self.show_view("bandeja")),
            ("Ctrl+2", lambda: self.show_view("procesos")),
            ("Ctrl+3", lambda: self.show_view("salidas")),
            ("Ctrl+4", lambda: self.show_view("historial")),
            ("Ctrl+5", lambda: self.show_view("ajustes")),
            ("Ctrl+F", self._focus_find),
            ("Ctrl+Return", self._trigger_next),
            ("Ctrl+Enter", self._trigger_next),
            ("Ctrl+W", self._close_current_work),
            ("F1", self.show_current_app_help),
        )
        for sequence, callback in shortcuts:
            action = QAction(self)
            action.setShortcut(sequence)
            action.triggered.connect(callback)
            self.addAction(action)

    def _build_ui(self) -> None:
        root = QWidget()
        root.setObjectName("SuiteShell")
        root_layout = QHBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        self.sidebar = self._build_sidebar()
        root_layout.addWidget(self.sidebar)

        workspace = QWidget()
        workspace.setObjectName("MainWorkspace")
        workspace_layout = QVBoxLayout(workspace)
        workspace_layout.setContentsMargins(16, 14, 16, 14)
        workspace_layout.setSpacing(12)
        root_layout.addWidget(workspace, 1)

        self.header = self._build_header()
        workspace_layout.addWidget(self.header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)
        self.stack = QStackedWidget()
        self.stack.setObjectName("WorkspaceStack")
        body.addWidget(self.stack, 1)
        self.tabs = QTabWidget()
        self.tabs.setObjectName("WorkTabs")
        self.tabs.setAccessibleName("Trabajos abiertos")
        self.tabs.setAccessibleDescription("Lista de trabajos abiertos. Cambia entre pestañas para recuperar una aplicación.")
        self.tabs.setVisible(False)
        self.tabs.addTab(QWidget(), "Inicio")
        self.tab_keys: list[str] = [""]

        self.context_rail = self._build_context_rail()
        self.process_context = self.context_rail
        self.context_rail.setVisible(False)
        body.addWidget(self.context_rail)
        workspace_layout.addLayout(body, 1)

        # Bandeja es la única vista necesaria para el primer renderizado. Las
        # demás crean controles y modelos propios, por lo que se materializan
        # sólo al abrir su apartado de navegación.
        self.dashboard_page = self._scroll_page(self._build_dashboard())
        self._lazy_page_builders = {
            "procesos": self._build_processes_page,
            "salidas": self._build_outputs_page,
            "historial": self._build_history_page,
            "ajustes": self._build_settings_page,
        }
        self._lazy_page_placeholders: dict[str, QWidget] = {}
        self.page_indexes = {"bandeja": self.stack.addWidget(self.dashboard_page)}
        for view in self._lazy_page_builders:
            placeholder = QWidget()
            placeholder.setObjectName("DeferredConsolePage")
            self._lazy_page_placeholders[view] = placeholder
            self.page_indexes[view] = self.stack.addWidget(placeholder)
        self.navigation_loading_page = self._build_navigation_loading_page()
        self.stack.addWidget(self.navigation_loading_page)
        self.setCentralWidget(root)
        self.result_label = QLabel()
        self.result_label.setText(f"{len(APP_REGISTRY)} procesos disponibles en Todas")
        self.result_label.setAccessibleDescription(self.result_label.text())
        self.result_label.setVisible(False)
        for category in categories():
            button = QPushButton(category)
            button.setCheckable(True)
            button.setChecked(category == "Todas")
            button.setVisible(False)
            self.category_buttons[category] = button
        self._apply_responsive_state()

    def _build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("ConsoleSidebar")
        sidebar.setAccessibleName("Navegación principal")
        sidebar.setAccessibleDescription("Navegación principal de la consola operativa.")
        sidebar.setMinimumWidth(220)
        sidebar.setMaximumWidth(240)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        brand = QVBoxLayout()
        brand.setSpacing(5)
        logo = self._brand_logo("RODRIGUEZ.png", 166, 48, "Rodríguez")
        self.sidebar_logo = logo
        if logo is not None:
            brand.addWidget(logo)
        self.nav_title = QLabel("Rodríguez")
        self.nav_title.setObjectName("SidebarBrandTitle")
        self.nav_title.setWordWrap(True)
        subtitle = QLabel("Consola operativa")
        subtitle.setObjectName("SidebarBrandSubtitle")
        subtitle.setWordWrap(True)
        brand.addWidget(self.nav_title)
        brand.addWidget(subtitle)
        layout.addLayout(brand)

        layout.addWidget(self._nav_label("Trabajo"))
        for key, label in (
            ("bandeja", "Bandeja"),
            ("procesos", "Procesos"),
            ("salidas", "Salidas"),
            ("historial", "Historial"),
            ("ajustes", "Ajustes"),
        ):
            button = self._nav_button(label)
            shortcut = {
                "bandeja": "Ctrl+1",
                "procesos": "Ctrl+2",
                "salidas": "Ctrl+3",
                "historial": "Ctrl+4",
                "ajustes": "Ctrl+5",
            }[key]
            button.setToolTip(f"{label} ({shortcut})")
            button.setAccessibleDescription(f"Ir a {label}. Atajo: {shortcut}.")
            button.clicked.connect(lambda _checked=False, view=key: self.show_view(view))
            self.nav_buttons[key] = button
            layout.addWidget(button)

        layout.addWidget(self._nav_label("Trabajos abiertos"))
        jobs_content = QWidget()
        jobs_content.setObjectName('ActiveJobsContent')
        self.active_jobs_box = QVBoxLayout(jobs_content)
        self.active_jobs_box.setContentsMargins(0, 0, 0, 0)
        self.active_jobs_box.setSpacing(6)
        self.active_jobs_box.setAlignment(Qt.AlignTop)
        self.active_jobs_scroll = QScrollArea()
        self.active_jobs_scroll.setObjectName('ActiveJobsScroll')
        self.active_jobs_scroll.setFrameShape(QFrame.NoFrame)
        self.active_jobs_scroll.setWidgetResizable(True)
        self.active_jobs_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.active_jobs_scroll.setMinimumHeight(64)
        self.active_jobs_scroll.setWidget(jobs_content)
        layout.addWidget(self.active_jobs_scroll, 1)

        self.sidebar_footer = QLabel(f"v{__version__}  |  Ctrl+F buscar  |  Alt+1-9 abrir  |  Ctrl+Enter siguiente")
        self.sidebar_footer.setObjectName("ModuleDescription")
        self.sidebar_footer.setWordWrap(True)
        layout.addWidget(self.sidebar_footer)
        return sidebar

    def _build_header(self) -> QFrame:
        header = QFrame()
        header.setObjectName("ConsoleHeader")
        layout = QVBoxLayout(header)
        layout.setContentsMargins(16, 10, 16, 10)
        layout.setSpacing(8)
        self.header_layout = QHBoxLayout()
        self.header_layout.setSpacing(12)
        layout.addLayout(self.header_layout)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        self.workspace_title = QLabel("Bandeja")
        self.workspace_title.setObjectName("ShellTitle")
        self.workspace_title.setWordWrap(True)
        self.workspace_description = PersonalizedDescriptionControl(
            "Carga archivos, detecta procesos y continúa trabajos activos.",
            label_object_name="ShellSubtitle",
        )
        self.workspace_subtitle = self.workspace_description.description_label
        title_box.addWidget(self.workspace_title)
        self.header_layout.addLayout(title_box, 1)
        layout.addWidget(self.workspace_description)

        self.compact_context_bar = self._build_compact_context_bar()
        self.compact_context_bar.setVisible(False)
        layout.addWidget(self.compact_context_bar)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar proceso, salida o archivo (Ctrl+F)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._on_search_changed)
        self.search.setAccessibleName("Buscar en la consola")
        self.search.setAccessibleDescription("Busca procesos por nombre, categoría o descripción. Atajo: Ctrl+F.")
        layout.addWidget(self.search)

        self.header_actions = QWidget()
        self.header_actions.setObjectName("HeaderActions")
        self.header_actions.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Minimum)
        actions_layout = QHBoxLayout(self.header_actions)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(8)
        self.workspace_description.move_actions_to(actions_layout)

        self.help_button = QPushButton("Ayuda")
        configure_header_action(self.help_button)
        self.help_button.setToolTip("Abrir la guía rápida de la aplicación actual (F1)")
        self.help_button.setAccessibleName("Ayuda de la aplicación actual")
        self.help_button.setAccessibleDescription("Abre una guía con el objetivo, los pasos y la salida de la aplicación actual. Atajo: F1.")
        self.help_button.clicked.connect(self.show_current_app_help)
        self.help_button.setVisible(False)
        actions_layout.addWidget(self.help_button)

        self.about_button = QPushButton(f"v{__version__}")
        configure_header_action(self.about_button)
        self.about_button.setToolTip("Versión, diagnóstico y actualizaciones")
        self.about_button.setAccessibleName("Versión y actualizaciones")
        self.about_button.clicked.connect(self.show_about)
        actions_layout.addWidget(self.about_button)

        self.home_button = QPushButton("Bandeja")
        configure_header_action(self.home_button)
        self.home_button.setToolTip("Volver a la bandeja sin cerrar trabajos.")
        self.home_button.setAccessibleName("Volver a Bandeja")
        self.home_button.setAccessibleDescription("Vuelve a la bandeja sin cerrar trabajos abiertos.")
        self.home_button.clicked.connect(self.show_dashboard)
        self.home_button.setVisible(False)
        actions_layout.addWidget(self.home_button)
        self.header_layout.addWidget(self.header_actions, 0, Qt.AlignRight | Qt.AlignVCenter)
        return header

    def _build_compact_context_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("CompactContextBar")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(0, 3, 0, 3)
        layout.setSpacing(10)

        self.compact_context_state = QLabel("Pendiente")
        self.compact_context_state.setObjectName("CompactContextValue")
        self.compact_context_state.setWordWrap(True)
        self.compact_context_next = QLabel("Abrir proceso")
        self.compact_context_next.setObjectName("CompactContextValue")
        self.compact_context_next.setWordWrap(True)
        self.compact_context_alerts = QLabel("Sin avisos")
        self.compact_context_alerts.setObjectName("CompactContextValue")
        self.compact_context_alerts.setWordWrap(True)

        for label in (self.compact_context_state, self.compact_context_next, self.compact_context_alerts):
            layout.addWidget(label, 1)

        self.compact_next_button = QPushButton("Siguiente")
        self.compact_next_button.setObjectName("PrimaryButton")
        self.compact_next_button.setProperty("primary", True)
        self.compact_next_button.setToolTip("Ejecutar la siguiente acción recomendada (Ctrl+Enter)")
        self.compact_next_button.setAccessibleName("Ejecutar siguiente acción")
        self.compact_next_button.setAccessibleDescription("Ejecuta la siguiente acción recomendada del trabajo abierto. Atajo: Ctrl+Enter.")
        self.compact_next_button.clicked.connect(self._trigger_next)
        layout.addWidget(self.compact_next_button, 0, Qt.AlignVCenter)
        return bar

    def _build_context_rail(self) -> QFrame:
        rail = QFrame()
        rail.setObjectName("ConsoleRail")
        rail.setMinimumWidth(240)
        rail.setMaximumWidth(264)
        layout = QVBoxLayout(rail)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        title = QLabel("Contexto")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)
        self.context_title = QLabel("Sin trabajo abierto")
        self.context_title.setObjectName("ModuleTitle")
        self.context_title.setWordWrap(True)
        self.context_app_title = self.context_title
        layout.addWidget(self.context_title)

        self.context_state = self._context_card("Estado", "Pendiente")
        self.context_next = self._context_card("Siguiente acción", "Abre un proceso")
        self.context_alerts = self._context_card("Avisos", "Sin avisos")
        self.process_state = QLabel("Estado: Pendiente")
        self.process_next = QLabel("Siguiente: Abre un proceso")
        self.process_alerts = QLabel("Avisos: Sin avisos")
        for label in (self.process_state, self.process_next, self.process_alerts):
            label.setVisible(False)
        layout.addWidget(self.context_state)
        layout.addWidget(self.context_next)
        layout.addWidget(self.context_alerts)

        self.next_button = QPushButton("Ejecutar siguiente")
        self.next_button.setObjectName("ShellNextAction")
        self.next_button.setProperty("primary", True)
        self.next_button.setToolTip("Ejecutar la siguiente acción recomendada (Ctrl+Enter)")
        self.next_button.setAccessibleName("Ejecutar siguiente acción")
        self.next_button.setAccessibleDescription("Ejecuta la siguiente acción recomendada del trabajo abierto. Atajo: Ctrl+Enter.")
        self.next_button.clicked.connect(self._trigger_next)
        self.next_action_button = self.next_button
        layout.addWidget(self.next_button)
        layout.addStretch(1)
        return rail

    def _build_dashboard(self) -> QWidget:
        page = QWidget()
        page.setObjectName("ConsolePage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)

        intro = QFrame()
        intro.setObjectName("DashboardIntro")
        intro_layout = QVBoxLayout(intro)
        intro_layout.setContentsMargins(0, 0, 0, 0)
        intro_layout.setSpacing(3)
        eyebrow = QLabel("BANDEJA DE TRABAJO")
        eyebrow.setObjectName("Overline")
        self.command_title = QLabel("Inicia o retoma una operación")
        self.command_title.setObjectName("WindowTitle")
        self.command_detail = QLabel("Carga archivos para detectar el flujo compatible o abre directamente una herramienta de la suite.")
        self.command_detail.setObjectName("WindowSubtitle")
        self.command_detail.setWordWrap(True)
        intro_layout.addWidget(eyebrow)
        intro_layout.addWidget(self.command_title)
        intro_layout.addWidget(self.command_detail)
        layout.addWidget(intro)

        command_card = QFrame()
        command_card.setObjectName("DashboardCommandCard")
        command_layout = QHBoxLayout(command_card)
        self.dashboard_start_layout = command_layout
        command_layout.setContentsMargins(16, 16, 16, 16)
        command_layout.setSpacing(14)

        drop_target = dropzone("Carga archivos", "Arrastra Excel, CSV o TXT aquí. La detección se realiza antes de abrir el proceso.")
        drop_target.setObjectName("DashboardDropTarget")
        drop_target.setMinimumHeight(132)
        self._enable_dashboard_drop(drop_target)
        drop_layout = drop_target.layout()
        self.dashboard_load_button = QPushButton("Cargar archivos")
        self.dashboard_load_button.setProperty("primary", True)
        self.dashboard_load_button.setAccessibleDescription("Selecciona archivos para detectar y abrir el proceso compatible.")
        self.dashboard_load_button.clicked.connect(self._select_dashboard_files)
        if drop_layout is not None:
            drop_layout.addWidget(self.dashboard_load_button, 0, Qt.AlignCenter)
        command_layout.addWidget(drop_target, 3)

        manual_card = QFrame()
        manual_card.setObjectName("DashboardManualCard")
        manual_layout = QVBoxLayout(manual_card)
        manual_layout.setContentsMargins(14, 14, 14, 14)
        manual_layout.setSpacing(6)
        manual_overline = QLabel("ACCESO MANUAL")
        manual_overline.setObjectName("Overline")
        manual_title = QLabel("Elige una herramienta")
        manual_title.setObjectName("ModuleTitle")
        manual_detail = QLabel("Explora todos los procesos si ya sabes qué tarea necesitas realizar.")
        manual_detail.setObjectName("ModuleDescription")
        manual_detail.setWordWrap(True)
        self.dashboard_process_button = QPushButton("Ver procesos")
        self.dashboard_process_button.setAccessibleDescription("Abre el catálogo completo de herramientas operativas.")
        self.dashboard_process_button.clicked.connect(lambda: self.show_view("procesos"))
        manual_layout.addWidget(manual_overline)
        manual_layout.addWidget(manual_title)
        manual_layout.addWidget(manual_detail, 1)
        manual_layout.addWidget(self.dashboard_process_button, 0, Qt.AlignLeft)
        command_layout.addWidget(manual_card, 2)
        layout.addWidget(command_card)

        self.dashboard_metrics_strip = QFrame()
        self.dashboard_metrics_strip.setObjectName("DashboardMetricsStrip")
        metrics = QHBoxLayout(self.dashboard_metrics_strip)
        self.dashboard_metrics = metrics
        metrics.setContentsMargins(0, 0, 0, 0)
        metrics.setSpacing(8)
        self.metric_open = metric("Abiertos", "0", "Trabajos activos")
        self.metric_recent = metric("Recientes", "0", "Procesos utilizados")
        self.metric_outputs = metric("Salidas", "0", "Archivos generados")
        self.command_open_value = self.metric_open.property("valueLabel")
        self.command_recent_value = self.metric_recent.property("valueLabel")
        self.command_outputs_value = self.metric_outputs.property("valueLabel")
        metrics.addWidget(self.metric_open, 1)
        metrics.addWidget(self.metric_recent, 1)
        metrics.addWidget(self.metric_outputs, 1)
        layout.addWidget(self.dashboard_metrics_strip)

        self.continue_strip = QFrame()
        self.continue_strip.setObjectName("DashboardResumeCard")
        continue_layout = QHBoxLayout(self.continue_strip)
        self.dashboard_continue_row = continue_layout
        continue_layout.setContentsMargins(14, 12, 14, 12)
        continue_layout.setSpacing(12)
        continue_copy = QVBoxLayout()
        continue_copy.setSpacing(2)
        resume_overline = QLabel("RECUPERAR TRABAJO")
        resume_overline.setObjectName("Overline")
        self.continue_title = QLabel("Aún no hay actividad")
        self.continue_title.setObjectName("ModuleTitle")
        self.continue_detail = QLabel("Cuando abras un proceso, podrás retomarlo desde este espacio.")
        self.continue_detail.setObjectName("ModuleDescription")
        self.continue_detail.setWordWrap(True)
        continue_copy.addWidget(resume_overline)
        continue_copy.addWidget(self.continue_title)
        continue_copy.addWidget(self.continue_detail)
        continue_layout.addLayout(continue_copy, 1)
        self.continue_activity = QLabel("")
        self.continue_activity.setObjectName("ModuleDescription")
        self.continue_activity.setWordWrap(True)
        continue_layout.addWidget(self.continue_activity, 1)
        self.continue_button = QPushButton("Ver procesos")
        self.continue_button.setProperty("primary", True)
        self.continue_button.setAccessibleName("Continuar trabajo")
        self.continue_button.setAccessibleDescription("Abre el último trabajo activo o reciente disponible.")
        self.continue_button.clicked.connect(self._open_continue_app)
        continue_layout.addWidget(self.continue_button, 0, Qt.AlignVCenter)
        layout.addWidget(self.continue_strip)

        quick_section = QFrame()
        quick_section.setObjectName("DashboardQuickSection")
        quick_layout = QVBoxLayout(quick_section)
        quick_layout.setContentsMargins(0, 0, 0, 0)
        quick_layout.setSpacing(10)
        quick_header = QHBoxLayout()
        quick_copy = QVBoxLayout()
        quick_copy.setSpacing(2)
        quick_title = QLabel("Herramientas frecuentes")
        quick_title.setObjectName("PanelTitle")
        quick_detail = QLabel("Tus procesos recientes se priorizan automáticamente.")
        quick_detail.setObjectName("PanelSubtitle")
        quick_copy.addWidget(quick_title)
        quick_copy.addWidget(quick_detail)
        quick_header.addLayout(quick_copy, 1)
        quick_layout.addLayout(quick_header)
        quick_cards = QHBoxLayout()
        self.dashboard_frequent_layout = quick_cards
        quick_cards.setSpacing(10)
        quick_layout.addLayout(quick_cards)
        layout.addWidget(quick_section)

        recent_columns = QHBoxLayout()
        self.dashboard_recent_columns = recent_columns
        recent_columns.setSpacing(12)
        activity_panel, self.dashboard_activity_layout = panel("Actividad reciente", "Procesos abiertos o usados últimamente.", name="ActivityPanel")
        outputs_panel, self.dashboard_outputs_layout = panel("Últimas salidas", "Archivos generados desde la consola.", name="ActivityPanel")
        recent_columns.addWidget(activity_panel, 1)
        recent_columns.addWidget(outputs_panel, 1)
        layout.addLayout(recent_columns)
        layout.addStretch(1)
        return page

    def _build_processes_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("ConsolePage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        self.compact_catalog = QCheckBox("Vista compacta")
        self.compact_catalog.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Fixed)
        self.compact_catalog.setChecked(True)
        self.compact_catalog.setToolTip("Reduce las tarjetas; las descripciones se personalizan desde Opciones.")
        self.compact_catalog.toggled.connect(self._set_catalog_compact)
        layout.addWidget(self.compact_catalog)
        content = QWidget(page)
        layout.addWidget(content)
        self.processes_layout = QVBoxLayout(content)
        self.processes_layout.setContentsMargins(0, 0, 0, 0)
        self.processes_layout.setSpacing(12)
        self._render_processes()
        return page

    def _build_outputs_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("ConsolePage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        self.outputs_panel, self.outputs_layout = panel("Salidas", "TXT, CSV, Excel y PDF generados por la consola.")
        layout.addWidget(self.outputs_panel)
        layout.addStretch(1)
        return page

    def _build_history_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("ConsolePage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        self.history_panel, self.history_layout = panel("Historial", "Procesos y archivos recientes.")
        layout.addWidget(self.history_panel)
        layout.addStretch(1)
        return page

    def _build_settings_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("ConsolePage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        settings_panel, settings_layout = panel("Ajustes operativos", "Versión, diagnóstico y configuración de soporte.")
        settings_layout.addWidget(work_item("Versión instalada", f"Suite Rodriguez Finura {__version__}", "Disponible"))
        update_button = QPushButton("Abrir diagnóstico y actualizaciones")
        brand_row = QHBoxLayout()
        brand_copy = QVBoxLayout()
        brand_copy.setSpacing(2)
        brand_title = QLabel("Identidad Rodríguez")
        brand_title.setObjectName("ModuleTitle")
        brand_detail = QLabel("Azul corporativo como base y Finura como acento premium.")
        brand_detail.setObjectName("ModuleDescription")
        brand_detail.setWordWrap(True)
        brand_copy.addWidget(brand_title)
        brand_copy.addWidget(brand_detail)
        brand_row.addLayout(brand_copy, 1)
        finura = self._brand_logo("FINURA.png", 96, 34, "Finura")
        if finura is not None:
            finura.setObjectName("BrandSeal")
            brand_row.addWidget(finura, 0, Qt.AlignVCenter)
        settings_layout.addLayout(brand_row)

        self.theme_combo = ModernSelect(placeholder="Selecciona el tema visual")
        self.theme_combo.setObjectName("ThemePreference")
        self.theme_combo.blockSignals(True)
        for label, value in (("Sistema", "system"), ("Claro", "light"), ("Oscuro", "dark")):
            self.theme_combo.add_option(label, value, description=f"Tema visual: {label.lower()}")
        self.theme_combo.setCurrentText({"system": "Sistema", "light": "Claro", "dark": "Oscuro"}[current_theme_preference()])
        self.theme_combo.blockSignals(False)
        self.theme_combo.setAccessibleName("Tema visual")
        self.theme_combo.setAccessibleDescription("Selecciona el tema visual de la aplicación: sistema, claro u oscuro.")
        self.theme_combo.currentTextChanged.connect(self._set_theme_preference)
        settings_layout.addWidget(labeled_field("Tema visual", self.theme_combo))

        update_button.setProperty("primary", True)
        update_button.setAccessibleName("Abrir diagnóstico y actualizaciones")
        update_button.setAccessibleDescription("Abre el diálogo de versión, diagnóstico y actualizaciones.")
        update_button.clicked.connect(self.show_about)
        settings_layout.addWidget(update_button)
        layout.addWidget(settings_panel)

        organization_panel, organization_layout = panel(
            "Organización de procesos",
            "Crea categorías personales y asigna cada proceso a una única categoría. Las categorías del sistema se conservan.",
        )
        self.organization_category_list = QListWidget()
        self.organization_category_list.setObjectName("OrganizationCategoryList")
        self.organization_category_list.setAccessibleName("Categorías de procesos")
        self.organization_category_list.setAccessibleDescription("Selecciona una categoría personalizada para renombrarla, eliminarla o cambiar su orden.")
        self.organization_category_list.currentItemChanged.connect(lambda *_args: self._refresh_organization_buttons())
        organization_layout.addWidget(self.organization_category_list)

        category_actions = QHBoxLayout()
        self.add_category_button = QPushButton("Crear categoría")
        self.category_actions_button = ActionMenuButton(accessible_name="Acciones de categoría")
        category_actions.addWidget(self.add_category_button)
        category_actions.addWidget(self.category_actions_button)
        self.add_category_button.clicked.connect(self._create_category)
        self.rename_category_action = self.category_actions_button.add_action("Renombrar", self._rename_category)
        self.category_up_action = self.category_actions_button.add_action("Subir", lambda: self._move_selected_category(-1))
        self.category_down_action = self.category_actions_button.add_action("Bajar", lambda: self._move_selected_category(1))
        self.category_actions_button.menu().addSeparator()
        self.delete_category_action = self.category_actions_button.add_action("Eliminar", self._delete_category, destructive=True)
        organization_layout.addLayout(category_actions)

        assignment_row = QHBoxLayout()
        self.organization_app_combo = SearchableComboBox(placeholder="Busca un proceso")
        self.organization_target_combo = ModernSelect(placeholder="Selecciona una categoría")
        self.organization_app_combo.setAccessibleName("Proceso a organizar")
        self.organization_target_combo.setAccessibleName("Categoría del proceso")
        self.organization_app_combo.currentIndexChanged.connect(self._sync_assignment_category)
        self.organization_target_combo.currentIndexChanged.connect(self._assign_selected_app)
        assignment_row.addWidget(labeled_field("Proceso", self.organization_app_combo), 1)
        assignment_row.addWidget(labeled_field("Categoría", self.organization_target_combo), 1)
        organization_layout.addLayout(assignment_row)

        self.restore_organization_button = QPushButton("Restaurar organización predeterminada")
        self.restore_organization_button.setAccessibleDescription("Elimina sólo las categorías y asignaciones personalizadas del perfil actual.")
        self.restore_organization_button.clicked.connect(self._restore_default_organization)
        organization_layout.addWidget(self.restore_organization_button)
        layout.addWidget(organization_panel)
        layout.addStretch(1)
        return page

    def _set_theme_preference(self, text: str) -> None:
        apply_theme_mode({"Claro": "light", "Oscuro": "dark", "Sistema": "system"}.get(text, "system"))

    def _category_name_for(self, app: AppDefinition) -> str:
        category_id = self.app_organization.category_for(app, APP_REGISTRY)
        for category in self.app_organization.categories(APP_REGISTRY):
            if category.id == category_id:
                return category.name
        return app.category

    def _selected_category(self) -> CategoryDefinition | None:
        item = getattr(self, "organization_category_list", None)
        if item is None or item.currentItem() is None:
            return None
        category_id = str(item.currentItem().data(Qt.UserRole) or "")
        return next((category for category in self.app_organization.categories(APP_REGISTRY) if category.id == category_id), None)

    def _refresh_organization_controls(self) -> None:
        if not hasattr(self, "organization_category_list") or self._organization_updating:
            return
        self._organization_updating = True
        try:
            selected_category = self._selected_category()
            selected_category_id = selected_category.id if selected_category else ""
            selected_app = self.organization_app_combo.currentData()
            self.organization_category_list.blockSignals(True)
            self.organization_category_list.clear()
            category_items = self.app_organization.categories(APP_REGISTRY)
            for category in category_items:
                item = QListWidgetItem(category.name + ("" if category.is_custom else " (sistema)"))
                item.setData(Qt.UserRole, category.id)
                item.setToolTip("Categoría personalizada" if category.is_custom else "Categoría predeterminada del sistema")
                self.organization_category_list.addItem(item)
                if category.id == selected_category_id:
                    self.organization_category_list.setCurrentItem(item)
            if self.organization_category_list.currentItem() is None and self.organization_category_list.count():
                self.organization_category_list.setCurrentRow(0)
            self.organization_category_list.blockSignals(False)

            self.organization_app_combo.blockSignals(True)
            self.organization_app_combo.clear()
            for app in APP_REGISTRY:
                self.organization_app_combo.add_option(app.title, app.key, description=app.description)
            app_index = self.organization_app_combo.findData(selected_app)
            self.organization_app_combo.setCurrentIndex(app_index if app_index >= 0 else 0)
            self.organization_app_combo.blockSignals(False)
            self._sync_assignment_category()
            self._refresh_organization_buttons()
        finally:
            self._organization_updating = False

    def _refresh_organization_buttons(self) -> None:
        if not hasattr(self, "rename_category_action"):
            return
        category = self._selected_category()
        is_custom = bool(category and category.is_custom)
        self.rename_category_action.setEnabled(is_custom)
        self.delete_category_action.setEnabled(is_custom)
        self.category_up_action.setEnabled(category is not None)
        self.category_down_action.setEnabled(category is not None)
        self.category_actions_button.setEnabled(category is not None)

    def _sync_assignment_category(self) -> None:
        if not hasattr(self, "organization_target_combo"):
            return
        app = self._app_from_key(str(self.organization_app_combo.currentData() or ""))
        self.organization_target_combo.blockSignals(True)
        self.organization_target_combo.clear()
        for category in self.app_organization.categories(APP_REGISTRY):
            detail = "Categoría personalizada" if category.is_custom else "Categoría predeterminada del sistema"
            self.organization_target_combo.add_option(category.name, category.id, description=detail)
        if app is not None:
            index = self.organization_target_combo.findData(self.app_organization.category_for(app, APP_REGISTRY))
            self.organization_target_combo.setCurrentIndex(index if index >= 0 else 0)
        self.organization_target_combo.blockSignals(False)

    def _assign_selected_app(self) -> None:
        if self._organization_updating:
            return
        app = self._app_from_key(str(self.organization_app_combo.currentData() or ""))
        category_id = str(self.organization_target_combo.currentData() or "")
        if app is None or not category_id:
            return
        try:
            self.app_organization.assign(app, category_id, APP_REGISTRY)
        except ValueError as exc:
            QMessageBox.warning(self, "Organización de procesos", str(exc))
            self._sync_assignment_category()
            return
        self._save_organization()

    def _create_category(self) -> None:
        name, accepted = QInputDialog.getText(self, "Crear categoría", "Nombre de la categoría:")
        if not accepted:
            return
        try:
            category = self.app_organization.add_category(name, APP_REGISTRY)
        except ValueError as exc:
            QMessageBox.warning(self, "Crear categoría", str(exc))
            return
        self._save_organization(category.id)

    def _rename_category(self) -> None:
        category = self._selected_category()
        if category is None or not category.is_custom:
            return
        name, accepted = QInputDialog.getText(self, "Renombrar categoría", "Nombre de la categoría:", text=category.name)
        if not accepted:
            return
        try:
            self.app_organization.rename_category(category.id, name, APP_REGISTRY)
        except ValueError as exc:
            QMessageBox.warning(self, "Renombrar categoría", str(exc))
            return
        self._save_organization(category.id)

    def _delete_category(self) -> None:
        category = self._selected_category()
        if category is None or not category.is_custom:
            return
        affected = [app for app in APP_REGISTRY if self.app_organization.category_for(app, APP_REGISTRY) == category.id]
        detail = "Los procesos asignados volverán a su categoría predeterminada." if affected else "La categoría está vacía."
        answer = QMessageBox.question(
            self,
            "Eliminar categoría",
            f"¿Eliminar la categoría «{category.name}»?\n\n{detail}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self.app_organization.delete_category(category.id)
        self._save_organization()

    def _move_selected_category(self, direction: int) -> None:
        category = self._selected_category()
        if category is None:
            return
        self.app_organization.move_category(category.id, direction, APP_REGISTRY)
        self._save_organization(category.id)

    def _restore_default_organization(self) -> None:
        answer = QMessageBox.question(
            self,
            "Restaurar organización predeterminada",
            "Se eliminarán sólo las categorías y asignaciones personalizadas. Las demás preferencias se conservarán. ¿Continuar?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self.app_organization.reset()
        reset_app_organization()
        self._refresh_all()

    def _save_organization(self, selected_category_id: str = "") -> None:
        save_app_organization(self.app_organization)
        self._refresh_all()
        if selected_category_id:
            for row in range(self.organization_category_list.count()):
                item = self.organization_category_list.item(row)
                if str(item.data(Qt.UserRole) or "") == selected_category_id:
                    self.organization_category_list.setCurrentItem(item)
                    break

    @staticmethod
    def _brand_logo(name: str, width: int, height: int, accessible_name: str) -> QLabel | None:
        path = resource_path(name)
        if not path.exists():
            return None
        pixmap = brand_logo_pixmap(path)
        if pixmap.isNull():
            return None
        label = QLabel()
        label._brand_source = pixmap
        label.setMinimumWidth(0)
        label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        label.setObjectName("SidebarBrandLogo")
        label.setAccessibleName(accessible_name)
        label.setPixmap(pixmap.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        label.setMinimumHeight(height)
        label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        return label

    @staticmethod
    def _scroll_page(content: QWidget) -> QScrollArea:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(content)
        return scroll

    def _build_navigation_loading_page(self) -> QWidget:
        page = QFrame()
        page.setObjectName("NavigationLoadingPage")
        page.setAccessibleName("Preparando aplicación")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(36, 36, 36, 36)
        layout.setSpacing(10)
        layout.addStretch(1)
        self.navigation_loading_title = QLabel("Preparando aplicación")
        self.navigation_loading_title.setObjectName("ModuleTitle")
        self.navigation_loading_detail = QLabel("Cargando los componentes necesarios…")
        self.navigation_loading_detail.setObjectName("ModuleDescription")
        self.navigation_loading_detail.setWordWrap(True)
        layout.addWidget(self.navigation_loading_title)
        layout.addWidget(self.navigation_loading_detail)
        self._failed_app_key = ""
        self.navigation_retry_button = QPushButton("Reintentar")
        self.navigation_retry_button.clicked.connect(lambda: self.open_app(app_by_key(self._failed_app_key)))
        self.navigation_retry_button.hide()
        layout.addWidget(self.navigation_retry_button)
        for width in (100, 76, 88):
            skeleton = QFrame()
            skeleton.setObjectName("NavigationSkeleton")
            skeleton.setFixedHeight(12)
            skeleton.setMaximumWidth(width * 3)
            layout.addWidget(skeleton)
        layout.addStretch(2)
        return page

    @staticmethod
    def _nav_label(text: str) -> QLabel:
        label = QLabel(text)
        label.setObjectName("Overline")
        label.setWordWrap(True)
        return label

    @staticmethod
    def _nav_button(text: str) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName("NavItem")
        button.setProperty("nav", True)
        button.setCheckable(True)
        button.setAccessibleName(text)
        return button

    def _wire_app_button(self, button: QPushButton, app: AppDefinition) -> None:
        button.setProperty("appKey", app.key)
        button.installEventFilter(self)
        button.clicked.connect(lambda _checked=False, item=app: self.open_app(item))

    def eventFilter(self, watched, event) -> bool:  # type: ignore[override]
        if isinstance(watched, QPushButton) and event.type() in {QEvent.Enter, QEvent.FocusIn}:
            key = str(watched.property("appKey") or "")
            if key:
                preload_window_class(key)
        return super().eventFilter(watched, event)

    def _context_card(self, title: str, value: str) -> QFrame:
        frame = QFrame()
        frame.setObjectName("ContextCard")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)
        title_label = QLabel(title)
        title_label.setObjectName("Overline")
        value_label = QLabel(value)
        value_label.setObjectName("ModuleDescription")
        value_label.setWordWrap(True)
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        frame.setProperty("valueLabel", value_label)
        return frame

    def _process_row(self, app: AppDefinition) -> QFrame:
        button = QPushButton("Abrir")
        button.setProperty("primary", True)
        button.setAccessibleName(f"Abrir {app.title}")
        self._wire_app_button(button, app)
        description = PersonalizedDescriptionControl(
            app.description,
            process_description_key(app.key),
            label_object_name="ModuleDescription",
        )
        row = module_row(app.title, app.description, self._category_name_for(app), "Disponible", app.shortcut, button, description)
        compact = self.compact_catalog.isChecked() if hasattr(self, "compact_catalog") else True
        row.catalog_metadata.setVisible(not compact)
        description.set_compact(compact)
        return row

    def _set_catalog_compact(self, compact: bool) -> None:
        for row in self._process_rows.values():
            row.catalog_metadata.setVisible(not compact)
            for description in row.findChildren(PersonalizedDescriptionControl):
                description.set_compact(compact)

    def _render_processes(self) -> None:
        if not hasattr(self, "processes_layout"):
            return
        categories = self.app_organization.categories(APP_REGISTRY)
        signature = tuple(
            (category.id, category.name, tuple(
                app.key for app in APP_REGISTRY
                if self.app_organization.category_for(app, APP_REGISTRY) == category.id
            )) for category in categories
        )
        # Cache rows and controls. Filtering changes visibility, not ownership.
        if signature != self._process_catalog_signature:
            self._clear_layout(self.processes_layout)
            self._process_rows = {}
            self._process_groups = []
            for category_id, name, keys in signature:
                if not keys:
                    continue
                group_panel, group_layout = panel(name, f"{len(keys)} procesos disponibles")
                for key in keys:
                    row = self._process_row(app_by_key(key))
                    self._process_rows[key] = row
                    group_layout.addWidget(row)
                self.processes_layout.addWidget(group_panel)
                self._process_groups.append((group_panel, keys))
            self._process_empty = empty_state("Sin procesos", "Ajusta la busqueda para encontrar el proceso.")
            self.processes_layout.addWidget(self._process_empty)
            self.processes_layout.addStretch(1)
            self._process_catalog_signature = signature
            self._process_filter_text = None
            apply_premium_depth(self.processes_layout.parentWidget())
        if self._process_filter_text == self.search_text:
            return
        apps = self._filtered_apps()
        visible_keys = {app.key for app in apps}
        label = (f"{len(apps)} procesos encontrados en Todas" if self.search_text
                 else f"{len(apps)} procesos disponibles en Todas")
        self.result_label.setText(label)
        self.result_label.setAccessibleDescription(label)
        for key, row in self._process_rows.items():
            row.setVisible(key in visible_keys)
        for group, keys in self._process_groups:
            count = sum(key in visible_keys for key in keys)
            group.setVisible(count > 0)
            subtitle = group.findChild(QLabel, "PanelSubtitle")
            if subtitle is not None:
                subtitle.setText(f"{count} procesos disponibles")
        self._process_empty.setVisible(not apps)
        self._process_filter_text = self.search_text

    def _refresh_outputs(self) -> None:
        for layout in (getattr(self, "outputs_layout", None), getattr(self, "dashboard_outputs_layout", None)):
            if layout is None:
                continue
            self._clear_layout(layout)
            exports = recent_paths("exports")
            if not exports:
                label = QLabel("Sin salidas generadas todavia.")
                label.setObjectName("DashboardEmpty")
                label.setWordWrap(True)
                layout.addWidget(label)
                continue
            for path in exports[:8]:
                layout.addWidget(work_item(Path(path).name, path, "Generado"))

    def _refresh_dashboard_activity(self) -> None:
        """Render the short, actionable activity feed shown on the dashboard."""
        layout = getattr(self, "dashboard_activity_layout", None)
        if layout is None:
            return
        self._clear_layout(layout)
        open_keys = list(self.app_pages)
        recent_keys = [key for key in recent_app_keys() if key not in open_keys]
        entries = [(key, "Abierto") for key in open_keys] + [(key, "Reciente") for key in recent_keys]
        if not entries:
            layout.addWidget(empty_state("Sin actividad todavía", "Los procesos que abras aparecerán aquí para recuperarlos rápidamente."))
            return
        for key, status in entries[:4]:
            app = self._app_from_key(key)
            if app is None:
                continue
            button = QPushButton("Continuar" if status == "Abierto" else "Abrir")
            self._wire_app_button(button, app)
            layout.addWidget(work_item(app.title, app.short_description or app.description, status, button))

    def _refresh_dashboard_frequent(self) -> None:
        """Mix recent use with the safe defaults without adding a preference UI."""
        layout = getattr(self, "dashboard_frequent_layout", None)
        if layout is None:
            return
        self._clear_layout(layout)
        default_keys = ("control_recepcion_precintos", "precintos_jamones", "precintos_expedicion")
        candidate_keys = list(dict.fromkeys([*recent_app_keys(), *default_keys]))
        for key in candidate_keys[:3]:
            app = self._app_from_key(key)
            if app is None:
                continue
            button = QPushButton("Abrir")
            self._wire_app_button(button, app)
            layout.addWidget(
                dashboard_process_card(
                    app.title,
                    app.short_description or app.description,
                    self._category_name_for(app),
                    app.shortcut,
                    button,
                ),
                1,
            )

    def _refresh_history(self) -> None:
        if not hasattr(self, "history_layout"):
            return
        self._clear_layout(self.history_layout)
        recent_apps = recent_app_keys()
        if not recent_apps:
            self.history_layout.addWidget(empty_state("Sin historial", "Abre un proceso para empezar a construir historial."))
            return
        for key in recent_apps:
            app = self._app_from_key(key)
            if app is not None:
                button = QPushButton("Abrir")
                self._wire_app_button(button, app)
                self.history_layout.addWidget(work_item(app.title, app.description, "Reciente", button))

    def _refresh_active_jobs(self) -> None:
        self._clear_layout(self.active_jobs_box)
        self.active_job_buttons.clear()
        if not self.app_pages:
            label = QLabel("Sin trabajos abiertos")
            label.setObjectName("ModuleDescription")
            label.setWordWrap(True)
            self.active_jobs_box.addWidget(label)
            return
        for key, page in self.app_pages.items():
            app = self._app_from_key(key)
            if app is None:
                continue
            button = self._nav_button(app.title)
            button.setToolTip(app.title)
            button.setAccessibleName(app.title)
            button.setChecked(key == self._current_app_key)
            self._wire_app_button(button, app)
            self.active_job_buttons[key] = button
            self.active_jobs_box.addWidget(button)
        self._apply_responsive_state()

    def _refresh_metrics(self) -> None:
        open_count = len(self.app_pages)
        recent_count = len(recent_app_keys())
        output_count = len(recent_paths("exports"))
        values = (
            (self.metric_open, str(open_count)),
            (self.metric_recent, str(recent_count)),
            (self.metric_outputs, str(output_count)),
        )
        for frame, value in values:
            label = frame.property("valueLabel")
            if isinstance(label, QLabel):
                label.setText(value)
        if hasattr(self, "command_title"):
            self.command_title.setText("Retoma o inicia una operación" if open_count else "Inicia o retoma una operación")
        has_activity = bool(open_count or recent_count or output_count)
        if hasattr(self, "dashboard_metrics_strip"):
            self.dashboard_metrics_strip.setVisible(has_activity)

    def _refresh_continue(self) -> None:
        open_keys = list(self.app_pages.keys())
        recent_keys = recent_app_keys()
        candidate_key = (recent_keys[:1] or open_keys[:1] or [""])[0]
        app = self._app_from_key(candidate_key) if candidate_key else None
        has_activity = app is not None
        self.continue_strip.setVisible(has_activity)
        if not has_activity:
            self._continue_app_key = ""
            self.continue_title.setText("Aún no hay actividad")
            self.continue_detail.setText("Empieza cargando archivos o elige uno de los procesos frecuentes.")
            self.continue_activity.setText("Sugerencia: la suite detecta automáticamente el flujo según el tipo de archivo.")
            self.continue_button.setText("Ver procesos")
            self.continue_button.setToolTip("Abrir el catálogo de procesos")
            return
        self._continue_app_key = app.key
        prefix = "Trabajo abierto" if app.key in open_keys else "Último proceso"
        self.continue_title.setText(f"{prefix}: {app.title}")
        self.continue_detail.setText(app.description)
        self.continue_activity.setText(
            f"Abiertos {len(open_keys)}  |  Recientes {len(recent_keys)}  |  Salidas {len(recent_paths('exports'))}"
        )
        self.continue_button.setText(f"Continuar {app.short_description or app.title}")
        self.continue_button.setToolTip(f"Abrir {app.title}")

    def _open_continue_app(self) -> None:
        app = self._app_from_key(self._continue_app_key)
        if app is not None:
            self.open_app(app)
            return
        self.show_view("procesos")

    def _refresh_all(self) -> None:
        self._refresh_metrics()
        self._refresh_continue()
        self._refresh_outputs()
        self._refresh_dashboard_activity()
        self._refresh_dashboard_frequent()
        self._refresh_active_jobs()
        # Las vistas diferidas sólo se reconstruyen cuando están activas. Al
        # abrir una herramienta no hay motivo para recrear el catálogo, el
        # historial y los controles de organización que el usuario no ve.
        if self.current_view == "procesos":
            self._render_processes()
        elif self.current_view == "historial":
            self._refresh_history()
        elif self.current_view == "ajustes":
            self._refresh_organization_controls()
        self._update_nav_state()
        self._update_context()

    def _filtered_apps(self) -> list[AppDefinition]:
        text = self.search_text
        if not text:
            return list(APP_REGISTRY)
        result = []
        for app in APP_REGISTRY:
            haystack = " ".join((app.title, app.description, self._category_name_for(app), app.short_description)).lower()
            if text in haystack:
                result.append(app)
        return result

    def _ensure_view(self, view: str) -> None:
        """Construye una vista diferida conservando su posición en el stack."""

        builder = self._lazy_page_builders.pop(view, None)
        if builder is None:
            return
        placeholder = self._lazy_page_placeholders.pop(view)
        index = self.page_indexes[view]
        page = self._scroll_page(builder())
        self.stack.removeWidget(placeholder)
        placeholder.deleteLater()
        self.stack.insertWidget(index, page)
        page_attribute = {
            "procesos": "processes_page",
            "salidas": "outputs_page",
            "historial": "history_page",
            "ajustes": "settings_page",
        }[view]
        setattr(self, page_attribute, page)

    def show_view(self, view: str) -> None:
        self._cancel_app_open()
        self._ensure_view(view)
        self.current_view = view
        self._current_app_key = ""
        self.stack.setCurrentIndex(self.page_indexes[view])
        current_page = self.stack.currentWidget()
        if current_page is not None:
            reveal_view(current_page)
        titles = {
            "bandeja": ("Bandeja", "Carga archivos, detecta procesos y continúa trabajos activos."),
            "procesos": ("Procesos", "Elige manualmente una herramienta operativa."),
            "salidas": ("Salidas", "Revisa exportaciones y documentos generados."),
            "historial": ("Historial", "Retoma procesos usados recientemente."),
            "ajustes": ("Ajustes", "Versión, diagnóstico y soporte."),
        }
        title, subtitle = titles[view]
        self.workspace_title.setText(title)
        self._set_workspace_description(subtitle)
        self.search.setVisible(view in {"bandeja", "procesos"})
        self.home_button.setVisible(view != "bandeja")
        self.help_button.setVisible(False)
        self.context_rail.setVisible(False)
        self.compact_context_bar.setVisible(False)
        self._refresh_all()

    def show_dashboard(self) -> None:
        self.show_view("bandeja")
        self.search.setVisible(True)
        self.tabs.setCurrentIndex(0)

    def _cancel_app_open(self) -> None:
        self._open_request_id += 1
        self._opening_app_key = ""
        self._pending_open_paths.clear()
        for button, text in self._pending_open_buttons:
            try:
                button.setText(text)
                button.setEnabled(True)
            except RuntimeError:
                pass
        self._pending_open_buttons.clear()

    def open_app(self, app: AppDefinition) -> None:
        if self._closing or self._opening_app_key == app.key:
            return
        window = self.app_pages.get(app.key)
        if window is not None and self._current_app_key == app.key and not self._opening_app_key:
            return
        self._cancel_app_open()
        request_id = self._open_request_id
        if window is not None:
            remember_app_open(app.key)
            self._activate_app_page(app, window)
            return
        self._opening_app_key = app.key
        for button in self.findChildren(QPushButton):
            if button.property("appKey") == app.key and button.isEnabled():
                self._pending_open_buttons.append((button, button.text()))
                button.setText("Abriendo…")
                button.setEnabled(False)
        self._show_app_preparing(app)
        # Paint acknowledgement before light GUI construction. Heavy libraries
        # are imported by processing functions, never by this catalogue.
        QTimer.singleShot(NAVIGATION_LOADING_DELAY_MS,
                          lambda: self._complete_app_open(app, request_id))

    def _show_app_preparing(self, app: AppDefinition) -> None:
        self.current_view = "trabajo"
        self._current_app_key = ""
        self.navigation_loading_title.setText(f"Abriendo {app.title}")
        self.navigation_retry_button.hide()
        self.navigation_loading_detail.setText("Preparando la interfaz. Puedes volver a Procesos mientras se abre.")
        self.stack.setCurrentWidget(self.navigation_loading_page)
        self.workspace_title.setText(app.title)
        self._set_workspace_description(app.description, header_description_key(app.key))
        self.search.setVisible(False)
        self.home_button.setVisible(True)
        self.help_button.setVisible(True)
        self.context_rail.setVisible(False)
        self.compact_context_bar.setVisible(False)
        self._update_nav_state()

    def _complete_app_open(self, app: AppDefinition, request_id: int | None = None) -> None:
        request_id = self._open_request_id if request_id is None else request_id
        if self._closing or request_id != self._open_request_id or self._opening_app_key != app.key:
            return
        window = None
        try:
            window_class = preloaded_window_class(app.key)
            if window_class is None:
                raise ValueError("No hay una ventana registrada para esta aplicación.")
            window = window_class()
            if self._closing or request_id != self._open_request_id:
                window.deleteLater()
                return
            window.setObjectName("EmbeddedAppWindow")
            prepare_embedded_window(window)
            window.setParent(self.stack)
            window.setWindowFlags(Qt.Widget)
            self.app_pages[app.key] = window
            self.open_windows[app.key] = window
            self.app_page_indexes[app.key] = self.stack.addWidget(window)
            self.tabs.addTab(QWidget(), app.title)
            self.tab_keys.append(app.key)
            window.destroyed.connect(lambda _obj=None, key=app.key: self._forget_app_page(key))
        except Exception as exc:
            if window is not None:
                window.deleteLater()
            if request_id == self._open_request_id and not self._closing:
                self._cancel_app_open()
                self.navigation_loading_title.setText(f"No se pudo abrir {app.title}")
                self.navigation_loading_detail.setText(str(exc))
                self._failed_app_key = app.key
                self.navigation_retry_button.show()
            return
        paths = list(self._pending_open_paths)
        self._cancel_app_open()
        remember_app_open(app.key)
        self._activate_app_page(app, window)
        if paths:
            self._deliver_dropped_paths(app, window, paths)

    def _activate_app_page(self, app: AppDefinition, window: QMainWindow) -> None:
        self._current_app_key = app.key
        self.current_view = "trabajo"
        self.stack.setCurrentWidget(window)
        reveal_view(window)
        if app.key in self.tab_keys:
            self.tabs.setCurrentIndex(self.tab_keys.index(app.key))
        self.workspace_title.setText(app.title)
        if app.key == "control_recepcion_precintos":
            migrate_control_recepcion_precintos_header()
        self._set_workspace_description(app.description, header_description_key(app.key))
        self.search.setVisible(False)
        self.home_button.setVisible(True)
        self.help_button.setVisible(True)
        self.context_rail.setVisible(True)
        window.setFocus(Qt.ActiveWindowFocusReason)
        self._refresh_all()
        QTimer.singleShot(0, lambda window=window: focus_next_action(window))
        self._apply_responsive_state()

    def show_about(self) -> None:
        dialog = AboutDialog(self)
        dialog.exec()
        self._refresh_all()

    def show_current_app_help(self) -> None:
        """Show contextual help only while an application is the active view."""
        if not self._current_app_key:
            return
        try:
            app = app_by_key(self._current_app_key)
        except KeyError:
            return
        AppHelpDialog(app, self).exec()

    def _update_context(self) -> None:
        if self._closing:
            return
        app = self._app_from_key(self._current_app_key)
        window = self.app_pages.get(self._current_app_key)
        if app is None or window is None:
            self.context_title.setText("Sin trabajo abierto")
            self._set_context_value(self.context_state, "Selecciona un proceso")
            self._set_context_value(self.context_next, "Abrir proceso")
            self._set_context_value(self.context_alerts, "Sin avisos")
            self.process_state.setText("Estado: Selecciona un proceso")
            self.process_next.setText("Siguiente: Abrir proceso")
            self.process_alerts.setText("Avisos: Sin avisos")
            self.next_button.setEnabled(False)
            self.compact_context_state.setText("Selecciona un proceso")
            self.compact_context_next.setText("Abrir proceso")
            self.compact_context_alerts.setText("Sin avisos")
            self.compact_next_button.setEnabled(False)
            return
        snapshot = operational_snapshot(window)
        self.context_title.setText(app.title)
        self._set_context_value(self.context_state, snapshot["state"])
        self._set_context_value(self.context_next, snapshot["next"])
        self._set_context_value(self.context_alerts, snapshot["alerts"] or "Sin avisos")
        self.process_state.setText(f"Estado: {snapshot['state']}")
        self.process_next.setText(f"Siguiente: {snapshot['next']}")
        self.process_alerts.setText(f"Avisos: {snapshot['alerts'] or 'Sin avisos'}")
        next_label = snapshot["next"] if snapshot["next"] else "Ejecutar"
        full_next_label = f"Siguiente: {next_label}"
        self.next_button.setText(self._compact_action_text(next_label, 22))
        self.next_button.setToolTip(f"{full_next_label} (Ctrl+Enter)")
        self.next_button.setEnabled(snapshot["next"] != "Completa el paso actual")
        self.compact_context_state.setText(f"Estado: {snapshot['state']}")
        self.compact_context_next.setText(f"Siguiente: {snapshot['next']}")
        self.compact_context_alerts.setText(f"Avisos: {snapshot['alerts'] or 'Sin avisos'}")
        self.compact_next_button.setText(self._compact_action_text(next_label, 18))
        self.compact_next_button.setToolTip(f"{full_next_label} (Ctrl+Enter)")
        self.compact_next_button.setEnabled(snapshot["next"] != "Completa el paso actual")

    def _update_process_context(self) -> None:
        self._update_context()

    @staticmethod
    def _compact_action_text(text: str, limit: int = 28) -> str:
        clean = " ".join(str(text).split())
        if len(clean) <= limit:
            return clean
        return clean[: max(0, limit - 3)].rstrip() + "..."

    @staticmethod
    def _set_context_value(card: QFrame, value: str) -> None:
        label = card.property("valueLabel")
        if isinstance(label, QLabel):
            label.setText(value)

    def _trigger_next(self) -> None:
        window = self.app_pages.get(self._current_app_key)
        if window is not None and trigger_next_action(window):
            self._update_context()
            self._refresh_all()

    def _close_current_work(self) -> None:
        key = self._current_app_key
        if not key:
            return
        window = self.app_pages.get(key)
        if window is None or not window.close():
            return
        self.stack.removeWidget(window)
        window.setParent(None)
        self.open_windows.pop(key, None)
        self.app_pages.pop(key, None)
        self.app_page_indexes.pop(key, None)
        if key in self.tab_keys:
            index = self.tab_keys.index(key)
            self.tabs.removeTab(index)
            self.tab_keys.pop(index)
        self.show_dashboard()

    def _close_current_tab(self) -> None:
        index = self.tabs.currentIndex()
        if index <= 0 or index >= len(self.tab_keys):
            return
        key = self.tab_keys[index]
        window = self.app_pages.get(key)
        if window is not None and not window.close():
            return
        if window is not None:
            self.stack.removeWidget(window)
            window.setParent(None)
        self.tabs.removeTab(index)
        self.tab_keys.pop(index)
        self.open_windows.pop(key, None)
        self.app_pages.pop(key, None)
        self.app_page_indexes.pop(key, None)
        self.show_dashboard()

    def _on_search_changed(self, text: str) -> None:
        self.search_text = " ".join(text.lower().split())
        if not hasattr(self, "processes_layout"):
            count = len(self._filtered_apps())
            label = f"{count} procesos encontrados en Todas" if self.search_text else f"{len(APP_REGISTRY)} procesos disponibles en Todas"
            self.result_label.setText(label)
            self.result_label.setAccessibleDescription(label)
        self._render_processes()

    def _focus_search(self) -> None:
        if self.current_view not in {"bandeja", "procesos"}:
            self.show_view("procesos")
        self.search.setFocus(Qt.ShortcutFocusReason)
        self.search.selectAll()

    def _focus_find(self) -> None:
        if self.current_view == "trabajo":
            window = self.app_pages.get(self._current_app_key)
            if window is not None:
                for field in window.findChildren(QLineEdit):
                    text = " ".join((field.placeholderText(), field.accessibleName(), field.toolTip())).lower()
                    if field.isVisible() and field.isEnabled() and any(word in text for word in ("buscar", "filtro", "peso")):
                        field.setFocus(Qt.ShortcutFocusReason)
                        field.selectAll()
                        return
                for button in window.findChildren(QPushButton):
                    text = " ".join((button.text(), button.toolTip(), button.accessibleName())).lower()
                    if button.isVisible() and button.isEnabled() and "filtrar" in text:
                        button.setFocus(Qt.ShortcutFocusReason)
                        return
        self._focus_search()

    def _update_nav_state(self) -> None:
        for key, button in self.nav_buttons.items():
            button.setChecked(key == self.current_view)
        for key, button in self.active_job_buttons.items():
            button.setChecked(key in {self._current_app_key, self._opening_app_key})

    def _forget_app_page(self, key: str) -> None:
        if self._closing or QApplication.closingDown():
            return
        try:
            self.open_windows.pop(key, None)
            self.app_pages.pop(key, None)
            self.app_page_indexes.pop(key, None)
            if key in self.tab_keys:
                index = self.tab_keys.index(key)
                self.tabs.removeTab(index)
                self.tab_keys.pop(index)
            if self._current_app_key == key:
                self.show_view("bandeja")
            self._refresh_all()
        except RuntimeError:
            return

    def close_embedded_apps_for_update(self) -> bool:
        for key, window in list(self.open_windows.items()):
            if not window.close():
                app = self._app_from_key(key)
                if app is not None:
                    self.open_app(app)
                return False
        return True

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        self._closing = True
        self._cancel_app_open()
        for key, window in list(self.open_windows.items()):
            if not window.close():
                self._closing = False
                app = self._app_from_key(key)
                if app is not None:
                    self.open_app(app)
                event.ignore()
                return
        super().closeEvent(event)

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        if hasattr(self, "header_layout"):
            # Only title/actions share this row; description, state and search
            # have their own rows and no longer force the whole header to stack.
            direction = QBoxLayout.TopToBottom if self.width() < 900 else QBoxLayout.LeftToRight
            self.header_layout.setDirection(direction)
        self._apply_responsive_state()

    def _apply_responsive_state(self) -> None:
        compact = self.width() < 1120
        narrow = self.width() < 980
        self.sidebar.setMaximumWidth(112 if narrow else 176 if compact else 240)
        self.sidebar.setMinimumWidth(96 if narrow else 164 if compact else 220)
        if self.sidebar_logo is not None:
            logo = self.sidebar_logo
            dimensions = (68 if narrow else 132 if compact else 166, logo.devicePixelRatioF())
            if getattr(logo, '_rendered_size', None) != dimensions:
                width, dpr = dimensions
                pixmap = logo._brand_source.scaled(round(width*dpr), round(48*dpr), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                pixmap.setDevicePixelRatio(dpr)
                logo.setPixmap(pixmap)
                logo._rendered_size = dimensions
        self.nav_title.setText("SRF" if compact else "Rodriguez Finura")
        # At medium sizes the long keyboard-help paragraph competed with the
        # actual navigation.  Its shortcuts remain available in tooltips and
        # the command palette, so reserve the vertical rhythm for navigation.
        if hasattr(self, "sidebar_footer"):
            self.sidebar_footer.setVisible(not compact)
        if hasattr(self, "command_detail"):
            self.command_detail.setVisible(self.width() > 960)
        if hasattr(self, "dashboard_recent_columns"):
            self.dashboard_recent_columns.setDirection(QBoxLayout.TopToBottom if self.width() < 1120 else QBoxLayout.LeftToRight)
        if hasattr(self, "dashboard_frequent_layout"):
            self.dashboard_frequent_layout.setDirection(QBoxLayout.TopToBottom if self.width() < 1180 else QBoxLayout.LeftToRight)
        if hasattr(self, "dashboard_metrics"):
            self.dashboard_metrics.setDirection(QBoxLayout.TopToBottom if self.width() < 900 else QBoxLayout.LeftToRight)
        if hasattr(self, "dashboard_start_layout"):
            self.dashboard_start_layout.setDirection(QBoxLayout.TopToBottom if self.width() < 1040 else QBoxLayout.LeftToRight)
        if hasattr(self, "dashboard_continue_row"):
            self.dashboard_continue_row.setDirection(QBoxLayout.TopToBottom if self.width() < 1040 else QBoxLayout.LeftToRight)
        if hasattr(self, "continue_activity"):
            self.continue_activity.setVisible(self.width() >= 1320)
        if hasattr(self, "context_rail") and self.current_view == "trabajo":
            # At medium widths the rail was technically visible but squeezed
            # the active application into a column.  Surface the same state
            # in the header and reserve the rail for genuinely wide layouts.
            wide_context = self.width() >= 1440
            self.context_rail.setVisible(wide_context)
            self.compact_context_bar.setVisible(not wide_context)
            # The embedded application owns the primary action. Keep only the
            # short status in this fixed header, without duplicating its button.
            self.compact_next_button.hide()
            self.compact_context_next.hide()
            self.workspace_description.setVisible(True)
            self.header_actions.setVisible(True)
        elif hasattr(self, "compact_context_bar"):
            self.compact_context_bar.setVisible(False)
            self.workspace_description.setVisible(True)
            self.header_actions.setVisible(True)
        for category, button in self.category_buttons.items():
            count = len(list(APP_REGISTRY)) if category == "Todas" else len([app for app in APP_REGISTRY if app.category == category])
            short = {
                "Todas": "Todo",
                "Excel / CSV": "CSV",
                "Palets y PDA": "PDA",
            }.get(category, category)
            button.setText(f"{short} ({count})" if compact else f"{category} ({count})")
        nav_text = {
            "bandeja": "B" if narrow else "Bandeja",
            "procesos": "Proc" if narrow else "Procesos",
            "salidas": "Sal" if narrow else "Salidas",
            "historial": "Hist" if narrow else "Historial",
            "ajustes": "Aj" if narrow else "Ajustes",
        }
        for key, button in self.nav_buttons.items():
            button.setText(nav_text.get(key, button.text()))
        for key, button in self.active_job_buttons.items():
            app = self._app_from_key(key)
            if app is not None:
                available = max(40, self.sidebar.width() - 44)
                button.setText(button.fontMetrics().elidedText(app.title, Qt.ElideRight, available))
                button.setToolTip(app.title)
                button.setAccessibleName(app.title)

    def _column_count(self) -> int:
        available = self.width()
        if available < 760:
            return 1
        if available < 1180:
            return 2
        return 3

    def _enable_dashboard_drop(self, drop_target: QFrame) -> None:
        drop_target.setAcceptDrops(True)
        drop_target.setAccessibleDescription("Arrastra archivos para abrir el proceso compatible y cargarlos en la aplicacion.")

        def set_active(active: bool, *, _target=drop_target) -> None:
            _target.setProperty("active", active)
            _target.style().unpolish(_target)
            _target.style().polish(_target)

        def drag_enter(event, *, _target=drop_target) -> None:
            paths = self._paths_from_drop_event(event)
            if paths and self._app_for_dropped_paths(paths) is not None:
                set_active(True, _target=_target)
                event.acceptProposedAction()
            else:
                event.ignore()

        def drag_leave(event, *, _target=drop_target) -> None:
            set_active(False, _target=_target)
            event.accept()

        def drop(event, *, _target=drop_target) -> None:
            set_active(False, _target=_target)
            paths = self._paths_from_drop_event(event)
            if paths and self._open_dropped_paths(paths):
                event.acceptProposedAction()
            else:
                self.command_detail.setText("No se reconocen esos archivos. Elige un proceso manualmente para cargarlos.")
                event.ignore()

        drop_target.dragEnterEvent = drag_enter  # type: ignore[method-assign]
        drop_target.dragMoveEvent = drag_enter  # type: ignore[method-assign]
        drop_target.dragLeaveEvent = drag_leave  # type: ignore[method-assign]
        drop_target.dropEvent = drop  # type: ignore[method-assign]

    def _select_dashboard_files(self) -> None:
        """Offer the same automatic detection used by the dashboard dropzone."""
        selected, _filter = QFileDialog.getOpenFileNames(
            self,
            "Cargar archivos",
            "",
            "Archivos compatibles (*.xlsx *.xlsm *.xls *.csv *.txt);;Todos los archivos (*.*)",
        )
        paths = [Path(path) for path in selected if Path(path).is_file()]
        if not paths:
            return
        if self._open_dropped_paths(paths):
            return
        self.command_detail.setText("No se pudo detectar un flujo para esos archivos. Elige un proceso y cárgalos desde su pantalla.")

    def _paths_from_drop_event(self, event) -> list[Path]:
        if not event.mimeData().hasUrls():
            return []
        paths: list[Path] = []
        for url in event.mimeData().urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile())
            if path.exists():
                paths.append(path)
        return paths

    def _open_dropped_paths(self, paths: list[Path]) -> bool:
        app = self._app_for_dropped_paths(paths)
        if app is None:
            return False
        self.open_app(app)
        window = self.app_pages.get(app.key)
        if window is None:
            if self._opening_app_key == app.key:
                self._pending_open_paths = list(dict.fromkeys(self._pending_open_paths + paths))
                return True
            return False
        return self._deliver_dropped_paths(app, window, paths)

    def _deliver_dropped_paths(self, app: AppDefinition, window: QMainWindow, paths: list[Path]) -> bool:
        if not handle_dropped_paths(window, paths):
            self.command_detail.setText(f"No se pudieron cargar los archivos en {app.title}. Usa los botones de carga del proceso.")
            return False
        self.command_detail.setText(f"Archivos cargados en {app.title}.")
        QTimer.singleShot(0, lambda window=window: focus_next_action(window))
        return True

    def _app_for_dropped_paths(self, paths: list[Path]) -> AppDefinition | None:
        suffixes = [path.suffix.lower() for path in paths]
        txts = [suffix for suffix in suffixes if suffix == ".txt"]
        csvs = [suffix for suffix in suffixes if suffix == ".csv"]
        excels = [suffix for suffix in suffixes if suffix in {".xlsx", ".xlsm", ".xls"}]
        if csvs and excels:
            return self._app_from_key("mermas")
        if txts and excels:
            return self._app_from_key("control_recepcion_precintos")
        if len(txts) > 1:
            return self._app_from_key("control_recepcion_precintos")
        if txts:
            return self._app_from_key("txt_csv")
        if excels:
            return self._app_from_key("exportar_precintos_excel")
        if csvs:
            return self._app_from_key("mermas")
        return None

    @staticmethod
    def _app_from_key(key: str) -> AppDefinition | None:
        try:
            return app_by_key(key)
        except KeyError:
            return None

    def _set_workspace_description(self, standard_description: str, preference_key: str | None = None) -> None:
        self.workspace_description.configure(standard_description, preference_key)

    @staticmethod
    def _clear_layout(layout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            child_layout = item.layout()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
            elif child_layout is not None:
                MainWindow._clear_layout(child_layout)


def run() -> int:
    import sys

    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))
    window = MainWindow()
    # Open maximized so operational pages receive the room they need while
    # retaining the standard Windows title bar and window controls.
    window.showMaximized()
    return app.exec()
