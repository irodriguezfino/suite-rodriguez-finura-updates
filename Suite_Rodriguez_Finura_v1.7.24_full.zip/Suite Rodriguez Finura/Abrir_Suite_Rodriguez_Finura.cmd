@echo off
setlocal EnableExtensions
set "APP_DIR=%~dp0"
start "" "%APP_DIR%runtime\pythonw.exe" "%APP_DIR%SuiteLauncher.py"
exit /b 0
