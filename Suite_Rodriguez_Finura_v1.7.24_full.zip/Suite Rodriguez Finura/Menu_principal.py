from __future__ import annotations

import sys
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
SRC = APP_DIR / "Suite_PySide6" / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from suite_pyside6.main import main


if __name__ == "__main__":
    raise SystemExit(main())
