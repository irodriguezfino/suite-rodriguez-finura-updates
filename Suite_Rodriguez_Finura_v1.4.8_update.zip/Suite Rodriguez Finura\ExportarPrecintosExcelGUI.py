#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Exportador de precintos desde anexos Excel a CSV Windows.

Permite seleccionar multiples archivos de distintos tipos, procesa solo Excel
XLSX/XLSM por agilidad y genera un CSV de una unica columna con saltos CRLF
compatible con importacion en Dynamics AX.
"""

from __future__ import annotations

import csv
import os
import re
import sys
import unicodedata
from pathlib import Path
from zipfile import ZipFile, BadZipFile
from xml.etree import ElementTree as ET
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_atajos_comunes as suite_configurar_atajos_comunes,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

EXTENSIONES_EXCEL_VALIDAS = {".xlsx", ".xlsm"}
EXTENSIONES_EXCEL_NO_SOPORTADAS = {".xls", ".xlsb"}
CABECERAS_IDENTIFICACION = {
    "identificacion",
    "identificacion precinto",
    "precinto",
    "precintos",
    "numero precinto",
    "numero del precinto",
    "n precinto",
    "nº precinto",
}


def ruta_recurso(nombre: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / nombre  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent / nombre


def aplicar_icono_ventana(ventana):
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def normalizar_texto(valor: str) -> str:
    texto = unicodedata.normalize("NFKD", valor or "")
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    texto = texto.replace("º", "o").replace("ª", "a")
    texto = re.sub(r"[^a-zA-Z0-9]+", " ", texto).strip().lower()
    return re.sub(r"\s+", " ", texto)


def limpiar_precinto(valor: str) -> str:
    texto = str(valor or "").strip()
    if not texto:
        return ""
    if re.fullmatch(r"\d+(?:\.0+)?", texto):
        texto = texto.split(".", 1)[0]
    return re.sub(r"\D+", "", texto)


def columna_excel_a_indice(referencia: str) -> int:
    letras = re.sub(r"[^A-Z]", "", referencia.upper())
    indice = 0
    for letra in letras:
        indice = indice * 26 + (ord(letra) - ord("A") + 1)
    return indice - 1


def leer_valor_celda(celda, cadenas_compartidas: list[str]) -> str:
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    tipo = celda.attrib.get("t")
    if tipo == "inlineStr":
        return "".join(t.text or "" for t in celda.findall(".//a:t", ns)).strip()
    valor = celda.find("a:v", ns)
    if valor is None:
        return ""
    texto = valor.text or ""
    if tipo == "s" and texto.isdigit():
        idx = int(texto)
        if 0 <= idx < len(cadenas_compartidas):
            return cadenas_compartidas[idx].strip()
    return texto.strip()


def _hojas_visibles(workbook_xml: bytes) -> list[tuple[str, str]]:
    ns = {
        "a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }
    root = ET.fromstring(workbook_xml)
    hojas = []
    for sheet in root.findall(".//a:sheet", ns):
        if sheet.attrib.get("state") == "hidden":
            continue
        hojas.append((sheet.attrib.get("name", "Hoja"), sheet.attrib.get(f"{{{ns['r']}}}id", "")))
    return hojas


def _relaciones_workbook(rels_xml: bytes) -> dict[str, str]:
    ns = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}
    root = ET.fromstring(rels_xml)
    rels = {}
    for rel in root.findall("r:Relationship", ns):
        rid = rel.attrib.get("Id", "")
        target = rel.attrib.get("Target", "")
        if rid and target:
            limpio = target.lstrip("/")
            if limpio.startswith("xl/"):
                rels[rid] = limpio
            elif limpio.startswith("../"):
                rels[rid] = limpio.replace("../", "", 1)
            else:
                rels[rid] = "xl/" + limpio
    return rels


def leer_precintos_excel(ruta: Path) -> tuple[list[str], str]:
    """Extrae valores de la columna Identificacion de un XLSX/XLSM."""
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    try:
        with ZipFile(ruta) as zf:
            nombres = set(zf.namelist())
            if "xl/workbook.xml" not in nombres:
                raise ValueError("no se encontro xl/workbook.xml")
            cadenas: list[str] = []
            if "xl/sharedStrings.xml" in nombres:
                root_ss = ET.fromstring(zf.read("xl/sharedStrings.xml"))
                for si in root_ss.findall("a:si", ns):
                    cadenas.append("".join(t.text or "" for t in si.findall(".//a:t", ns)).strip())
            rels = _relaciones_workbook(zf.read("xl/_rels/workbook.xml.rels"))
            hojas = _hojas_visibles(zf.read("xl/workbook.xml"))
            for nombre_hoja, rid in hojas:
                ruta_hoja = rels.get(rid)
                if not ruta_hoja or ruta_hoja not in nombres:
                    continue
                root = ET.fromstring(zf.read(ruta_hoja))
                filas: list[dict[int, str]] = []
                for fila in root.findall(".//a:row", ns):
                    celdas = {}
                    for celda in fila.findall("a:c", ns):
                        ref = celda.attrib.get("r", "")
                        if ref:
                            celdas[columna_excel_a_indice(ref)] = leer_valor_celda(celda, cadenas)
                    if celdas:
                        filas.append(celdas)
                indice_columna = None
                fila_cabecera = -1
                for i, fila in enumerate(filas):
                    for col, valor in fila.items():
                        cabecera = normalizar_texto(valor)
                        if cabecera in CABECERAS_IDENTIFICACION or "identificacion" == cabecera:
                            indice_columna = col
                            fila_cabecera = i
                            break
                    if indice_columna is not None:
                        break
                if indice_columna is None:
                    continue
                precintos = []
                for fila in filas[fila_cabecera + 1:]:
                    valor = limpiar_precinto(fila.get(indice_columna, ""))
                    if valor:
                        precintos.append(valor)
                return precintos, nombre_hoja
    except BadZipFile as exc:
        raise ValueError("el archivo no parece un Excel XLSX/XLSM valido") from exc
    raise ValueError("no se encontro la columna 'Identificación'")


class ExportarPrecintosExcelApp:
    def __init__(self, ventana: tk.Tk | tk.Toplevel):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Exportar Precintos Excel a CSV")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)

        self.rutas: list[Path] = []
        self.precintos: list[str] = []
        self.excel_procesados: list[Path] = []
        self.archivos_ignorados: list[Path] = []
        self.errores: list[str] = []
        self.estado_var = tk.StringVar(value="Selecciona archivos para empezar.")
        self.resumen_var = tk.StringVar(value="Sin archivos cargados")
        self._logo_rodriguez = None
        self._logo_finura = None

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_atajos()
        self._actualizar_botones()

    def configurar_estilos(self):
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(2, weight=1)

        cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(22, 10))
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(cabecera, text="Exportar Precintos Excel a CSV", style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
        ttk.Label(
            cabecera,
            text="Selecciona varios archivos; la aplicacion procesa solo Excel y genera un CSV Windows para Dynamics.",
            style="Subtitle.TLabel",
            anchor="center",
            wraplength=980,
        ).grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel = ttk.Frame(self.ventana, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        panel.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 10))
        for col in range(5):
            panel.columnconfigure(col, weight=1 if col in (1, 2) else 0)
        ttk.Label(panel, text="Flujo de trabajo", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 12))
        self.boton_seleccionar = ttk.Button(panel, text="Seleccionar archivos", command=self.seleccionar_archivos, style="Primary.TButton")
        self.boton_seleccionar.grid(row=0, column=1, sticky="ew", padx=5)
        self.boton_procesar = ttk.Button(panel, text="Procesar Excel", command=self.procesar, style="Primary.TButton")
        self.boton_procesar.grid(row=0, column=2, sticky="ew", padx=5)
        self.boton_guardar = ttk.Button(panel, text="Guardar CSV", command=self.guardar_csv, style="Primary.TButton")
        self.boton_guardar.grid(row=0, column=3, sticky="ew", padx=5)
        self.boton_limpiar = ttk.Button(panel, text="Limpiar", command=self.limpiar, style="Secondary.TButton")
        self.boton_limpiar.grid(row=0, column=4, sticky="ew", padx=(5, 0))
        self.lbl_resumen = ttk.Label(panel, textvariable=self.resumen_var, style="Card.TLabel", wraplength=980)
        self.lbl_resumen.grid(row=1, column=0, columnspan=5, sticky="ew", pady=(10, 0))

        cuerpo = ttk.Frame(self.ventana, style="TFrame")
        cuerpo.grid(row=2, column=0, sticky="nsew", padx=28, pady=8)
        cuerpo.columnconfigure(0, weight=3)
        cuerpo.columnconfigure(1, weight=2)
        cuerpo.rowconfigure(0, weight=1)

        zona_resultado = ttk.Frame(cuerpo, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        zona_resultado.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        zona_resultado.columnconfigure(0, weight=1)
        zona_resultado.rowconfigure(1, weight=1)
        ttk.Label(zona_resultado, text="Precintos detectados", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.texto = tk.Text(zona_resultado, wrap="none", undo=False)
        suite_aplicar_texto_tk(self.texto, mono=True)
        self.texto.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll_y = ttk.Scrollbar(zona_resultado, orient="vertical", command=self.texto.yview)
        scroll_y.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        scroll_x = ttk.Scrollbar(zona_resultado, orient="horizontal", command=self.texto.xview)
        scroll_x.grid(row=2, column=0, sticky="ew")
        self.texto.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)

        zona_log = ttk.Frame(cuerpo, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        zona_log.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        zona_log.columnconfigure(0, weight=1)
        zona_log.rowconfigure(1, weight=1)
        ttk.Label(zona_log, text="Resumen de proceso", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.log = tk.Text(zona_log, wrap="word", state="disabled")
        suite_aplicar_texto_tk(self.log, mono=False, alto=12)
        self.log.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll_log = ttk.Scrollbar(zona_log, orient="vertical", command=self.log.yview)
        scroll_log.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        self.log.configure(yscrollcommand=scroll_log.set)

        acciones = ttk.Frame(self.ventana, style="Card.TFrame", padding=SUITE_PAD_PANEL_COMPACT)
        acciones.grid(row=3, column=0, sticky="ew", padx=28, pady=(8, 10))
        acciones.columnconfigure(0, weight=1)
        self.lbl_estado = ttk.Label(acciones, textvariable=self.estado_var, style="Status.TLabel", anchor="center", wraplength=980)
        self.lbl_estado.configure(takefocus=True)
        self.lbl_estado.grid(row=0, column=0, sticky="ew")
        ttk.Button(acciones, text="Salir", command=self.salir, style="Danger.TButton").grid(row=0, column=1, sticky="e", padx=(10, 0))

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=4, column=0, sticky="ew", padx=28, pady=(0, 16))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")
        ttk.Label(footer, text=SUITE_FOOTER_TEXTO, style="Author.TLabel", anchor="center").grid(row=0, column=1, sticky="ew")
        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._actualizar_log("Selecciona archivos PDF, Excel u otros; solo se procesaran XLSX/XLSM.")

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            return
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))
            img_izq.thumbnail((190, 70))
            img_der.thumbnail((190, 70))
            self._logo_finura = ImageTk.PhotoImage(img_izq)
            self._logo_rodriguez = ImageTk.PhotoImage(img_der)
            lbl_izq = tk.Label(self.logo_slot_izq, image=self._logo_finura)
            lbl_der = tk.Label(self.logo_slot_der, image=self._logo_rodriguez)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
        except Exception:
            pass

    def configurar_atajos(self):
        suite_configurar_atajos_comunes(self.ventana, abrir=self.seleccionar_archivos, guardar=self.guardar_csv, limpiar=self.limpiar, salir=self.salir)
        self.ventana.bind("<Control-p>", lambda _e: self.procesar())
        self.ventana.bind("<Control-P>", lambda _e: self.procesar())

    def _set_estado(self, texto: str, importante: bool = False):
        self.estado_var.set(texto)
        if importante:
            suite_anunciar_estado(self.lbl_estado, texto)

    def _actualizar_log(self, texto: str):
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.insert("1.0", texto)
        self.log.configure(state="disabled")

    def _actualizar_texto_precintos(self):
        self.texto.delete("1.0", "end")
        if self.precintos:
            self.texto.insert("1.0", "\n".join(self.precintos))
        else:
            self.texto.insert("1.0", "Aqui se mostraran los precintos extraidos antes de guardar el CSV.")

    def _actualizar_botones(self):
        suite_configurar_boton_estado(self.boton_procesar, bool(self.rutas))
        suite_configurar_boton_estado(self.boton_guardar, bool(self.precintos))
        suite_configurar_boton_estado(self.boton_limpiar, bool(self.rutas or self.precintos or self.errores))

    def _hay_trabajo_en_curso(self):
        return bool(self.rutas or self.precintos or self.excel_procesados or self.archivos_ignorados or self.errores)

    def confirmar_accion_protegida(self, accion: str) -> bool:
        if not self._hay_trabajo_en_curso():
            return True
        return messagebox.askyesno(
            "Accion protegida",
            "Este boton esta protegido porque hay seleccion, resultado o incidencias en pantalla.\n\n"
            f"Si continuas con '{accion}', se descartara el trabajo actual.\n\n"
            "Confirma que quieres continuar.",
            parent=self.ventana,
        )

    def seleccionar_archivos(self):
        if not self.confirmar_accion_protegida("Seleccionar nuevos archivos"):
            return

        rutas = filedialog.askopenfilenames(
            title="Seleccionar anexos y archivos",
            filetypes=[
                ("Todos los archivos admitidos", "*.xlsx *.xlsm *.xls *.xlsb *.pdf *.csv *.txt"),
                ("Excel moderno", "*.xlsx *.xlsm"),
                ("PDF", "*.pdf"),
                ("Todos los archivos", "*.*"),
            ],
            parent=self.ventana,
        )
        if not rutas:
            return
        self.rutas = [Path(r) for r in rutas]
        self.precintos = []
        self.excel_procesados = []
        self.archivos_ignorados = []
        self.errores = []
        candidatos = [p for p in self.rutas if p.suffix.lower() in EXTENSIONES_EXCEL_VALIDAS]
        ignorados = len(self.rutas) - len(candidatos)
        self.resumen_var.set(f"Archivos seleccionados: {len(self.rutas)} | Excel procesables: {len(candidatos)} | Ignorados al procesar: {ignorados}")
        self._actualizar_texto_precintos()
        self._actualizar_log("Archivos seleccionados:\n" + "\n".join(f"- {p.name}" for p in self.rutas))
        self._set_estado("Seleccion completada. Pulsa Procesar Excel.", importante=True)
        self._actualizar_botones()

    def procesar(self):
        if self.precintos or self.excel_procesados or self.archivos_ignorados or self.errores:
            if not self.confirmar_accion_protegida("Procesar de nuevo"):
                return
        if not self.rutas:
            messagebox.showinfo("Sin archivos", "Selecciona primero uno o varios archivos.", parent=self.ventana)
            return
        self.precintos = []
        self.excel_procesados = []
        self.archivos_ignorados = []
        self.errores = []
        log = []
        total_excel = 0
        for ruta in self.rutas:
            ext = ruta.suffix.lower()
            if ext not in EXTENSIONES_EXCEL_VALIDAS:
                self.archivos_ignorados.append(ruta)
                if ext in EXTENSIONES_EXCEL_NO_SOPORTADAS:
                    log.append(f"- Ignorado {ruta.name}: formato Excel antiguo/no soportado para lectura agil. Guarda como .xlsx.")
                else:
                    log.append(f"- Ignorado {ruta.name}: no es Excel.")
                continue
            total_excel += 1
            try:
                precintos, hoja = leer_precintos_excel(ruta)
                self.precintos.extend(precintos)
                self.excel_procesados.append(ruta)
                log.append(f"- OK {ruta.name}: {len(precintos)} precintos desde hoja '{hoja}'.")
            except Exception as exc:
                mensaje = f"- ERROR {ruta.name}: {exc}"
                self.errores.append(mensaje)
                log.append(mensaje)
        self._actualizar_texto_precintos()
        self.resumen_var.set(
            f"Excel encontrados: {total_excel} | Procesados: {len(self.excel_procesados)} | Precintos extraidos: {len(self.precintos)} | Ignorados/errores: {len(self.archivos_ignorados) + len(self.errores)}"
        )
        self._actualizar_log("Resultado del proceso:\n" + "\n".join(log))
        if self.precintos:
            self._set_estado(f"Proceso finalizado: {len(self.precintos)} precintos listos para guardar.", importante=True)
        else:
            self._set_estado("No se extrajeron precintos. Revisa que exista la columna Identificación.", importante=True)
        self._actualizar_botones()

    def guardar_csv(self):
        if not self.precintos:
            messagebox.showinfo("Sin datos", "Procesa primero los Excel para generar precintos.", parent=self.ventana)
            return
        ruta = filedialog.asksaveasfilename(
            title="Guardar CSV de precintos",
            defaultextension=".csv",
            initialfile="Precintos.csv",
            filetypes=[("CSV", "*.csv"), ("Todos los archivos", "*.*")],
            parent=self.ventana,
        )
        if not ruta:
            return
        destino = Path(ruta)
        try:
            with destino.open("w", encoding="utf-8-sig", newline="") as fh:
                writer = csv.writer(fh, lineterminator="\r\n")
                for precinto in self.precintos:
                    writer.writerow([precinto])
        except Exception as exc:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el CSV:\n{exc}", parent=self.ventana)
            return
        self._set_estado(f"CSV guardado en formato Windows: {destino.name}", importante=True)
        messagebox.showinfo("CSV generado", f"Se han guardado {len(self.precintos)} precintos en formato Windows CRLF.", parent=self.ventana)

    def limpiar(self):
        if not self.confirmar_accion_protegida("Limpiar"):
            return
        self.rutas = []
        self.precintos = []
        self.excel_procesados = []
        self.archivos_ignorados = []
        self.errores = []
        self.resumen_var.set("Sin archivos cargados")
        self._actualizar_texto_precintos()
        self._actualizar_log("Selecciona archivos PDF, Excel u otros; solo se procesaran XLSX/XLSM.")
        self._set_estado("Listo para seleccionar archivos.", importante=True)
        self._actualizar_botones()

    def salir(self):
        if not self.confirmar_accion_protegida("Salir"):
            return
        self.ventana.destroy()


def lanzar_app_exportar_precintos_excel(master=None):
    ventana = tk.Toplevel(master) if master is not None else tk.Tk()
    ExportarPrecintosExcelApp(ventana)
    return ventana


if __name__ == "__main__":
    root = tk.Tk()
    ExportarPrecintosExcelApp(root)
    root.mainloop()
