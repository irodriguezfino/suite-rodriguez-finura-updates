# Propiedad intelectual: Departamento de Informatica (Daniel Lombo, Daniel R. Zapico, Lisardo Perez, Manuel Llamas, David Rubio y Nacho Rodriguez).
import os
import sys
import csv
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_APP as SUITE_PAD_APP,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    preparar_ventana_sin_parpadeo as suite_preparar_ventana_sin_parpadeo,
    recordar_directorio as suite_recordar_directorio,
)

from PIL import Image, ImageTk
from datetime import datetime

pd = None


def asegurar_pandas():
    """Carga pandas solo cuando el flujo de mermas lo necesita."""
    global pd
    if pd is not None:
        return pd
    try:
        import pandas as pandas_mod
    except ImportError:
        return None
    pd = pandas_mod
    return pd


def ruta_recurso(nombre):
    """Devuelve la ruta correcta de los recursos en modo .py y en empaquetados PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)




def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class ProcesadorCSVApp:
    def __init__(self, ventana):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "MERMA JAMONES FAC EMBUTIDOS RODRIGUEZ")

        self.archivos_seleccionados = []
        self.archivo_origen = None
        self.resultado_df = None

        self.logo_izq = None
        self.logo_der = None

        self.filtro_var = tk.StringVar(value="SI")

        self.resumen_datos = {
            "archivos_cargados": 0,
            "filas_leidas": 0,
            "precintos_unicos": 0,
            "duplicados_detectados": 0,
            "total_piezas_si": 0,
            "total_piezas_no": 0,
            "piezas_resultado_final": 0,
            "lotes_origen_vacios": 0,
            "lotes_origen_informados": 0,
        }

        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()


    def configurar_accesibilidad(self):
        """Atajos de teclado y salida segura sin alterar la logica de procesado."""
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir_seguro)
        self.ventana.bind("<Control-o>", lambda _event: self.seleccionar_archivos())
        self.ventana.bind("<Control-O>", lambda _event: self.seleccionar_archivos())
        self.ventana.bind("<Control-s>", lambda _event: self.guardar_resultado())
        self.ventana.bind("<Control-S>", lambda _event: self.guardar_resultado())
        self.ventana.bind("<Control-l>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Control-L>", lambda _event: self.limpiar_lista())
        self.ventana.bind("<Escape>", lambda _event: self.salir_seguro())

    def hay_trabajo_pendiente_salida(self):
        try:
            return bool(self.archivos_seleccionados or self.archivo_origen or (self.resultado_df is not None and not self.resultado_df.empty))
        except Exception:
            return False

    def confirmar_accion_protegida(self, accion: str) -> bool:
        if not self.hay_trabajo_pendiente_salida():
            return True
        return messagebox.askyesno(
            "Accion protegida",
            "Este boton esta protegido porque hay archivos cargados o resultado generado.\n\n"
            f"Si continuas con '{accion}', se descartara el trabajo actual.\n\n"
            "Confirma que quieres continuar.",
            parent=self.ventana,
        )

    def salir_seguro(self):
        if self.hay_trabajo_pendiente_salida():
            if not messagebox.askyesno(
                "Confirmar salida",
                "Hay datos cargados, procesados o correcciones en curso.\n\n¿Quieres cerrar esta aplicacion?",
                parent=self.ventana,
            ):
                return
        self.ventana.destroy()

    def crear_interfaz(self):
        # Paleta visual y estilos centralizados. No afecta a la logica de procesado.
        self.estilo = suite_configurar_ttk(self.ventana)

        contenedor = ttk.Frame(self.ventana, padding=SUITE_PAD_APP)
        contenedor.pack(fill="both", expand=True)
        contenedor.columnconfigure(0, weight=1)
        contenedor.rowconfigure(2, weight=1)

        cabecera = ttk.Frame(contenedor)
        cabecera.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        cabecera.columnconfigure(0, weight=1)

        titulo = ttk.Label(
            cabecera,
            text="MERMA JAMONES FAC EMBUTIDOS RODRIGUEZ",
            style="Title.TLabel"
        )
        titulo.grid(row=0, column=0, sticky="w")

        subtitulo = ttk.Label(
            cabecera,
            text="Carga ficheros finales, cruza el origen y genera el Excel de resultado.",
            style="Subtitle.TLabel"
        )
        subtitulo.grid(row=1, column=0, sticky="w", pady=(4, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel_acciones_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_PANEL)
        panel_acciones_canvas.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        panel_acciones = panel_acciones_canvas.body
        panel_acciones.columnconfigure(0, weight=1)
        panel_acciones.columnconfigure(1, weight=1)
        panel_acciones.columnconfigure(2, weight=1)
        panel_acciones.columnconfigure(3, weight=1)
        panel_acciones.columnconfigure(4, weight=1)

        self.btn_seleccionar_finales = ttk.Button(
            panel_acciones,
            text="Seleccionar CSVs finales",
            command=self.seleccionar_archivos,
            style="Secondary.TButton"
        )
        self.btn_seleccionar_finales.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        self.btn_seleccionar_origen = ttk.Button(
            panel_acciones,
            text="Seleccionar fichero origen",
            command=self.seleccionar_origen,
            style="Secondary.TButton"
        )
        self.btn_seleccionar_origen.grid(row=0, column=1, sticky="ew", padx=8)

        self.btn_procesar = ttk.Button(
            panel_acciones,
            text="Procesar archivos",
            command=self.procesar_archivos,
            style="Primary.TButton"
        )
        self.btn_procesar.grid(row=0, column=2, sticky="ew", padx=8)

        self.btn_guardar = ttk.Button(
            panel_acciones,
            text="Guardar Excel",
            command=self.guardar_resultado,
            style="Secondary.TButton"
        )
        self.btn_guardar.grid(row=0, column=3, sticky="ew", padx=8)

        self.btn_limpiar = ttk.Button(
            panel_acciones,
            text="Limpiar",
            command=self.limpiar_lista,
            style="Secondary.TButton"
        )
        self.btn_limpiar.grid(row=0, column=4, sticky="ew", padx=(8, 0))
        suite_configurar_orden_tabulacion(
            self.btn_seleccionar_finales,
            self.btn_seleccionar_origen,
            self.btn_procesar,
            self.btn_guardar,
            self.btn_limpiar,
        )

        panel_trabajo_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_PANEL)
        panel_trabajo_canvas.grid(row=2, column=0, sticky="nsew", pady=(0, 12))
        panel_trabajo = panel_trabajo_canvas.body
        panel_trabajo.columnconfigure(0, weight=1)
        panel_trabajo.rowconfigure(2, weight=1)

        fila_superior = ttk.Frame(panel_trabajo, style="Panel.TFrame")
        fila_superior.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        fila_superior.columnconfigure(1, weight=1)

        ttk.Label(
            fila_superior,
            text="Mostrar:",
            style="Panel.TLabel"
        ).grid(row=0, column=0, sticky="w", padx=(0, 10))

        filtros = ttk.Frame(fila_superior, style="Panel.TFrame")
        filtros.grid(row=0, column=1, sticky="w")

        ttk.Radiobutton(filtros, text="Solo SI", variable=self.filtro_var, value="SI").pack(side="left", padx=(0, 12))
        ttk.Radiobutton(filtros, text="Solo NO", variable=self.filtro_var, value="NO").pack(side="left", padx=(0, 12))
        ttk.Radiobutton(filtros, text="Todos", variable=self.filtro_var, value="TODOS").pack(side="left")

        ttk.Label(
            panel_trabajo,
            text="Archivos seleccionados y vista previa del resultado",
            style="Panel.TLabel"
        ).grid(row=1, column=0, sticky="w", pady=(0, 6))

        frame_texto = ttk.Frame(panel_trabajo, style="Panel.TFrame")
        frame_texto.grid(row=2, column=0, sticky="nsew")
        frame_texto.columnconfigure(0, weight=1)
        frame_texto.rowconfigure(0, weight=1)

        scrollbar_y = ttk.Scrollbar(frame_texto, orient="vertical")
        scrollbar_y.grid(row=0, column=1, sticky="ns")

        scrollbar_x = ttk.Scrollbar(frame_texto, orient="horizontal")
        scrollbar_x.grid(row=1, column=0, sticky="ew")

        self.caja_texto = tk.Text(
            frame_texto,
            width=100,
            height=16,
            yscrollcommand=scrollbar_y.set,
            xscrollcommand=scrollbar_x.set,
            wrap="word",
            relief="flat",
            padx=10,
            pady=10
        )
        suite_aplicar_texto_tk(self.caja_texto, mono=True)
        self.caja_texto.grid(row=0, column=0, sticky="nsew")
        scrollbar_y.config(command=self.caja_texto.yview)
        scrollbar_x.config(command=self.caja_texto.xview)

        panel_estado_canvas = suite_crear_panel_canvas(contenedor, padding=SUITE_PAD_PANEL_COMPACT)
        panel_estado_canvas.grid(row=3, column=0, sticky="ew", pady=(0, 12))
        panel_estado = panel_estado_canvas.body
        panel_estado.columnconfigure(0, weight=1)

        self.etiqueta_estado = ttk.Label(
            panel_estado,
            text="Sin archivos cargados",
            style="Status.TLabel",
            anchor="w"
        )
        self.etiqueta_estado.configure(takefocus=True)
        self.etiqueta_estado.grid(row=0, column=0, sticky="ew")

        self.progreso = ttk.Progressbar(contenedor, mode="indeterminate")
        self.progreso.grid(row=4, column=0, sticky="ew", pady=(0, 8))
        self.progreso.grid_remove()

        self.frame_logos = ttk.Frame(contenedor, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        self.frame_logos.grid(row=5, column=0, sticky="ew", pady=(2, 6))
        self.frame_logos.columnconfigure(0, weight=1)
        self.frame_logos.columnconfigure(1, weight=1)
        self.frame_logos.columnconfigure(2, weight=1)

        self.logo_slot_izq = ttk.Frame(self.frame_logos, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")

        zona_central = ttk.Frame(self.frame_logos, style="Footer.TFrame")
        zona_central.grid(row=0, column=1)
        ttk.Label(zona_central, text=SUITE_FOOTER_TEXTO, style="Muted.Card.TLabel", anchor="center").pack(pady=(0, 8))
        ttk.Button(zona_central, text="Salir", command=self.salir_seguro, style="Danger.TButton").pack()

        self.logo_slot_der = ttk.Frame(self.frame_logos, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._actualizar_botones()

    def _set_estado(self, texto: str, importante: bool = False):
        if importante:
            suite_anunciar_estado(self.etiqueta_estado, texto)
        else:
            self.etiqueta_estado.config(text=texto)

    def _hay_resultado_guardable(self):
        try:
            return self.resultado_df is not None and not self.resultado_df.empty
        except Exception:
            return False

    def _actualizar_botones(self):
        suite_configurar_boton_estado(self.btn_procesar, bool(self.archivos_seleccionados and self.archivo_origen))
        suite_configurar_boton_estado(self.btn_guardar, self._hay_resultado_guardable())
        suite_configurar_boton_estado(self.btn_limpiar, bool(self.archivos_seleccionados or self.archivo_origen or self._hay_resultado_guardable()))

    def _set_ocupado(self, ocupado: bool, texto: str | None = None):
        for boton in (self.btn_seleccionar_finales, self.btn_seleccionar_origen, self.btn_procesar, self.btn_guardar, self.btn_limpiar):
            suite_configurar_boton_estado(boton, not ocupado)
        if ocupado:
            if texto:
                self._set_estado(texto)
            self.progreso.grid()
            self.progreso.start(12)
            self.ventana.update_idletasks()
        else:
            self.progreso.stop()
            self.progreso.grid_remove()
            self._actualizar_botones()


    def cargar_logos(self):
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))

            # Misma disposicion y proporcion visual que en el resto de aplicaciones.
            img_izq.thumbnail((210, 80))
            img_der.thumbnail((200, 80))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            self.label_logo_izq = tk.Label(self.logo_slot_izq, image=self.logo_izq)
            self.label_logo_der = tk.Label(self.logo_slot_der, image=self.logo_der)

            suite_aplicar_logo_label(self.label_logo_izq)
            suite_aplicar_logo_label(self.label_logo_der)
            self.label_logo_izq.pack(anchor="w")
            self.label_logo_der.pack(anchor="e")
            preparar_logo_minimizar(self.label_logo_izq, self.ventana)
            preparar_logo_minimizar(self.label_logo_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script."
            , parent=self.ventana)
        except Exception as e:
            messagebox.showwarning(
                "Error al cargar logos",
                f"No se pudieron cargar los logos:\n{e}"
            , parent=self.ventana)

    def seleccionar_archivos(self):
        if self.archivos_seleccionados or self.resultado_df is not None:
            if not self.confirmar_accion_protegida("Seleccionar nuevos CSV finales"):
                return
        archivos = filedialog.askopenfilenames(
            parent=self.ventana,
            title="Selecciona archivos CSV finales",
            initialdir=suite_obtener_ultimo_directorio("mermas_csv_finales"),
            filetypes=[("Archivos CSV", "*.csv"), ("Todos los archivos", "*.*")]
        )

        if archivos:
            suite_recordar_directorio("mermas_csv_finales", archivos[0])
            self.archivos_seleccionados = list(archivos)
            self.caja_texto.delete("1.0", tk.END)

            self.caja_texto.insert(tk.END, "FICHEROS FINALES:\n")
            for archivo in self.archivos_seleccionados:
                self.caja_texto.insert(tk.END, f"{archivo}\n")

            if self.archivo_origen:
                self.caja_texto.insert(tk.END, f"\nFICHERO ORIGEN:\n{self.archivo_origen}\n")

            self.etiqueta_estado.config(
                text=f"{len(self.archivos_seleccionados)} archivo(s) final(es) cargado(s)"
            )
            self._actualizar_botones()

    def seleccionar_origen(self):
        if self.archivo_origen or self.resultado_df is not None:
            if not self.confirmar_accion_protegida("Seleccionar nuevo fichero origen"):
                return
        archivo = filedialog.askopenfilename(
            parent=self.ventana,
            title="Selecciona fichero origen",
            initialdir=suite_obtener_ultimo_directorio("mermas_origen"),
            filetypes=[
                ("Archivos CSV", "*.csv"),
                ("Archivos Excel", "*.xlsx *.xls"),
                ("Todos los archivos", "*.*")
            ]
        )

        if archivo:
            suite_recordar_directorio("mermas_origen", archivo)
            self.archivo_origen = archivo
            self.caja_texto.delete("1.0", tk.END)

            self.caja_texto.insert(tk.END, "FICHEROS FINALES:\n")
            for a in self.archivos_seleccionados:
                self.caja_texto.insert(tk.END, f"{a}\n")

            self.caja_texto.insert(tk.END, f"\nFICHERO ORIGEN:\n{self.archivo_origen}\n")

            self.etiqueta_estado.config(
                text=f"Origen cargado: {os.path.basename(archivo)}"
            )
            self._actualizar_botones()

    def limpiar_lineas_invalidas(self, ruta_archivo):
        lineas_validas = []

        with open(ruta_archivo, "r", encoding="utf-8-sig", errors="replace") as f:
            for linea in f:
                texto = linea.strip()

                if not texto:
                    continue

                if texto.replace(";", "") == "":
                    continue

                if "\ufffd" in texto:
                    raise ValueError(
                        f"El archivo contiene caracteres no legibles con UTF-8 en la linea: {texto[:120]}"
                    )

                lineas_validas.append(texto)

        return lineas_validas

    def normalizar_hora(self, valor):
        valor = str(valor).strip()

        if not valor:
            return ""

        partes = valor.split(":")
        if len(partes) != 3:
            return valor

        try:
            h = partes[0].zfill(2)
            m = partes[1].zfill(2)
            s = partes[2].zfill(2)
            return f"{h}:{m}:{s}"
        except Exception:
            return valor

    def normalizar_fecha(self, valor):
        valor = str(valor).strip()
        if not valor:
            return ""

        formatos = [
            "%d/%m/%Y",
            "%d/%m/%y",
            "%Y-%m-%d",
            "%d-%m-%Y",
            "%d-%m-%y"
        ]

        for fmt in formatos:
            try:
                fecha = datetime.strptime(valor, fmt)
                return fecha.strftime("%d/%m/%Y")
            except ValueError:
                continue

        return valor

    def convertir_numero(self, valor):
        valor = str(valor).strip()
        if not valor:
            return None

        valor = valor.replace(",", ".")
        try:
            return float(valor)
        except ValueError:
            return None

    def procesar_archivos(self):
        if self.resultado_df is not None:
            if not self.confirmar_accion_protegida("Procesar de nuevo"):
                return
        if not self.archivos_seleccionados:
            messagebox.showwarning("Aviso", "Primero selecciona uno o más archivos CSV finales.", parent=self.ventana)
            return

        if not self.archivo_origen:
            messagebox.showwarning("Aviso", "Primero selecciona el fichero origen.", parent=self.ventana)
            return

        pandas_mod = asegurar_pandas()
        if pandas_mod is None:
            messagebox.showerror(
                "Falta pandas",
                "No está instalada la librería pandas.\nInstálala con:\npip install pandas openpyxl"
            , parent=self.ventana)
            return
        pd = pandas_mod

        self._set_ocupado(True, "Procesando cruce de mermas...")
        datos_totales = []

        for archivo in self.archivos_seleccionados:
            try:
                lineas = self.limpiar_lineas_invalidas(archivo)

                for linea in lineas:
                    try:
                        columnas = next(csv.reader([linea], delimiter=";", quotechar='"'))
                    except csv.Error:
                        columnas = linea.split(";")
                    datos_totales.append(columnas)

            except Exception as e:
                messagebox.showerror(
                    "Error",
                    f"No se pudo procesar el archivo final:\n{archivo}\n\n{e}"
                , parent=self.ventana)
                self._set_ocupado(False)
                return

        if not datos_totales:
            self._set_estado("No hay datos válidos en los ficheros finales.", importante=True)
            self._set_ocupado(False)
            return

        filas_leidas = len(datos_totales)

        max_columnas = max(len(fila) for fila in datos_totales)
        datos_normalizados = []

        for fila in datos_totales:
            if len(fila) < max_columnas:
                fila = fila + [""] * (max_columnas - len(fila))
            datos_normalizados.append(fila)

        nombres_base = [
            "Fichero FAC",
            "Fecha",
            "Hora",
            "Precinto",
            "Peso Origen",
            "Peso Final",
            "Merma",
            "Cumple"
        ]

        if max_columnas <= len(nombres_base):
            columnas = nombres_base[:max_columnas]
        else:
            columnas = nombres_base + [f"Columna_{i+1}" for i in range(len(nombres_base), max_columnas)]

        df_final = pd.DataFrame(datos_normalizados, columns=columnas)
        df_base = df_final.copy()

        if "Fecha" in df_final.columns:
            df_final["Fecha"] = df_final["Fecha"].apply(self.normalizar_fecha)
            df_base["Fecha"] = df_base["Fecha"].apply(self.normalizar_fecha)

        if "Hora" in df_final.columns:
            df_final["Hora"] = df_final["Hora"].apply(self.normalizar_hora)
            df_base["Hora"] = df_base["Hora"].apply(self.normalizar_hora)

        for col in ["Peso Origen", "Peso Final", "Merma"]:
            if col in df_final.columns:
                df_final[col] = df_final[col].astype(str).str.replace(".", ",", regex=False)
                df_base[col] = df_base[col].astype(str).str.replace(".", ",", regex=False)

        precintos_unicos = 0
        duplicados_detectados = 0

        if "Precinto" in df_base.columns:
            df_base["Precinto"] = df_base["Precinto"].astype(str).str.strip()
            precintos_unicos = int(df_base["Precinto"].nunique())
            duplicados_detectados = int(filas_leidas - precintos_unicos)

            df_final["Precinto"] = df_final["Precinto"].astype(str).str.strip()
            df_final = df_final.drop_duplicates(subset=["Precinto"], keep="last").copy()

        total_piezas_si = 0
        total_piezas_no = 0

        if "Cumple" in df_final.columns:
            total_piezas_si = int(df_final["Cumple"].astype(str).str.strip().str.upper().eq("SI").sum())
            total_piezas_no = int(df_final["Cumple"].astype(str).str.strip().str.upper().eq("NO").sum())

        filtro = self.filtro_var.get()

        if filtro in ("SI", "NO") and "Cumple" in df_final.columns:
            df_final = df_final[df_final["Cumple"].astype(str).str.strip().str.upper().eq(filtro)].copy()

        try:
            if self.archivo_origen.lower().endswith(".csv"):
                df_origen = pd.read_csv(
                    self.archivo_origen,
                    sep=";",
                    header=None,
                    dtype=str,
                    encoding="utf-8",
                    engine="python"
                )
            else:
                df_origen = pd.read_excel(
                    self.archivo_origen,
                    header=None,
                    dtype=str
                )
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer el fichero origen:\n{e}", parent=self.ventana)
            self._set_ocupado(False)
            return

        df_final = df_final.fillna("")
        df_origen = df_origen.fillna("")

        if df_origen.shape[1] < 6:
            messagebox.showerror(
                "Error",
                "El fichero origen no tiene al menos 6 columnas."
            , parent=self.ventana)
            self._set_ocupado(False)
            return

        if "Precinto" not in df_final.columns:
            messagebox.showerror(
                "Error",
                "No se ha encontrado la columna 'Precinto' en los ficheros finales."
            , parent=self.ventana)
            self._set_ocupado(False)
            return

        mapa_lote_origen = (
            df_origen.iloc[:, [4, 5]]
            .astype(str)
            .apply(lambda col: col.str.strip())
            .drop_duplicates(subset=df_origen.columns[4], keep="first")
            .set_index(df_origen.columns[4])[df_origen.columns[5]]
            .to_dict()
        )

        df_final["LOTE ORIGEN"] = df_final["Precinto"].astype(str).str.strip().map(
            lambda x: mapa_lote_origen.get(x, "")
        )

        lotes_origen_vacios = 0
        lotes_origen_informados = 0
        if "LOTE ORIGEN" in df_final.columns:
            lotes_origen_vacios = int(df_final["LOTE ORIGEN"].astype(str).str.strip().eq("").sum())
            lotes_origen_informados = int(len(df_final) - lotes_origen_vacios)

        self.resultado_df = df_final

        self.resumen_datos = {
            "archivos_cargados": len(self.archivos_seleccionados),
            "filas_leidas": filas_leidas,
            "precintos_unicos": precintos_unicos,
            "duplicados_detectados": duplicados_detectados,
            "total_piezas_si": total_piezas_si,
            "total_piezas_no": total_piezas_no,
            "piezas_resultado_final": len(df_final),
            "lotes_origen_vacios": lotes_origen_vacios,
            "lotes_origen_informados": lotes_origen_informados,
        }

        self.caja_texto.delete("1.0", tk.END)

        if self.resultado_df.empty:
            self.caja_texto.insert(tk.END, "No hay resultados para mostrar.\n")
            self._set_estado("Proceso completado: 0 registros", importante=True)
        else:
            vista_previa = self.resultado_df.head(100).to_string(index=False)
            self.caja_texto.insert(tk.END, vista_previa)
            self._set_estado(f"Proceso completado: {len(self.resultado_df)} registros", importante=True)
        self._set_ocupado(False)

    def guardar_resultado(self):
        if self.resultado_df is None or self.resultado_df.empty:
            self._set_estado("No hay resultados para guardar.", importante=True)
            return

        pandas_mod = asegurar_pandas()
        if pandas_mod is None:
            messagebox.showerror(
                "Falta pandas",
                "No está instalada la librería pandas.\nInstálala con:\npip install pandas openpyxl"
            , parent=self.ventana)
            return
        pd = pandas_mod

        ruta_guardado = filedialog.asksaveasfilename(
            parent=self.ventana,
            title="Guardar resultado en Excel",
            initialdir=suite_obtener_ultimo_directorio("mermas_guardar"),
            defaultextension=".xlsx",
            filetypes=[("Archivo Excel", "*.xlsx")]
        )

        if not ruta_guardado:
            return
        suite_recordar_directorio("mermas_guardar", ruta_guardado)

        try:
            df_export = self.resultado_df.copy()

            if "Fecha" in df_export.columns:
                df_export["Fecha"] = pd.to_datetime(
                    df_export["Fecha"],
                    format="%d/%m/%Y",
                    errors="coerce"
                )

            for col in ["Peso Origen", "Peso Final", "Merma"]:
                if col in df_export.columns:
                    df_export[col] = df_export[col].apply(self.convertir_numero)

            with pd.ExcelWriter(ruta_guardado, engine="openpyxl") as writer:
                df_export.to_excel(writer, index=False, sheet_name="Resultado")

                ws = writer.sheets["Resultado"]

                total_filas = len(df_export)
                total_columnas = len(df_export.columns)

                from openpyxl.worksheet.table import Table, TableStyleInfo
                from openpyxl.styles import Font, Alignment, Border, Side

                ultima_col_letra = ws.cell(row=1, column=total_columnas).column_letter
                rango_tabla = f"A1:{ultima_col_letra}{total_filas + 1}"

                tabla = Table(displayName="TablaResultados", ref=rango_tabla)
                estilo = TableStyleInfo(
                    name="TableStyleMedium2",
                    showFirstColumn=False,
                    showLastColumn=False,
                    showRowStripes=True,
                    showColumnStripes=False
                )
                tabla.tableStyleInfo = estilo
                ws.add_table(tabla)

                for fila in range(2, total_filas + 2):
                    if "Fecha" in df_export.columns:
                        col_fecha = df_export.columns.get_loc("Fecha") + 1
                        ws.cell(row=fila, column=col_fecha).number_format = "dd/mm/yyyy"

                    if "Hora" in df_export.columns:
                        col_hora = df_export.columns.get_loc("Hora") + 1
                        ws.cell(row=fila, column=col_hora).number_format = "@"

                    for nombre_col in ["Peso Origen", "Peso Final", "Merma"]:
                        if nombre_col in df_export.columns:
                            col_num = df_export.columns.get_loc(nombre_col) + 1
                            ws.cell(row=fila, column=col_num).number_format = "0.00"

                for col_idx, col_name in enumerate(df_export.columns, start=1):
                    max_len = len(str(col_name))
                    for fila in range(2, min(total_filas + 2, 300)):
                        valor = ws.cell(row=fila, column=col_idx).value
                        if valor is not None:
                            max_len = max(max_len, len(str(valor)))
                    ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(max_len + 2, 22)

                col_resumen = total_columnas + 3
                col_valor = total_columnas + 4

                borde_fino = Border(
                    left=Side(style="thin"),
                    right=Side(style="thin"),
                    top=Side(style="thin"),
                    bottom=Side(style="thin")
                )

                fila_inicio = 2

                ws.cell(row=fila_inicio, column=col_resumen, value="RESUMEN")
                ws.cell(row=fila_inicio, column=col_resumen).font = Font(bold=True, size=16)
                ws.cell(row=fila_inicio, column=col_resumen).alignment = Alignment(horizontal="center")
                ws.merge_cells(
                    start_row=fila_inicio,
                    start_column=col_resumen,
                    end_row=fila_inicio,
                    end_column=col_valor
                )

                resumen = [
                    ("Archivos cargados", self.resumen_datos["archivos_cargados"]),
                    ("Filas leídas", self.resumen_datos["filas_leidas"]),
                    ("Precintos únicos", self.resumen_datos["precintos_unicos"]),
                    ("Duplicados detectados", self.resumen_datos["duplicados_detectados"]),
                    ("Total piezas SI", self.resumen_datos["total_piezas_si"]),
                    ("Total piezas NO", self.resumen_datos["total_piezas_no"]),
                    ("Piezas resultado final", self.resumen_datos["piezas_resultado_final"]),
                    ("Lotes origen informados", self.resumen_datos["lotes_origen_informados"]),
                    ("Lotes origen vacíos", self.resumen_datos["lotes_origen_vacios"]),
                ]

                fila_actual = fila_inicio + 2
                for etiqueta, valor in resumen:
                    celda_etiqueta = ws.cell(row=fila_actual, column=col_resumen, value=etiqueta)
                    celda_valor = ws.cell(row=fila_actual, column=col_valor, value=valor)

                    celda_etiqueta.font = Font(bold=True, size=12)
                    celda_valor.font = Font(size=12)

                    celda_etiqueta.alignment = Alignment(horizontal="right")
                    celda_valor.alignment = Alignment(horizontal="center")

                    celda_etiqueta.border = borde_fino
                    celda_valor.border = borde_fino

                    fila_actual += 1

                ws.column_dimensions[ws.cell(row=1, column=col_resumen).column_letter].width = 26
                ws.column_dimensions[ws.cell(row=1, column=col_valor).column_letter].width = 16

                ws.freeze_panes = "A2"

            self._set_estado(f"Archivo guardado correctamente: {ruta_guardado}", importante=True)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el archivo:\n{e}", parent=self.ventana)

    def limpiar_lista(self):
        if not self.confirmar_accion_protegida("Limpiar"):
            return
        self.archivos_seleccionados = []
        self.archivo_origen = None
        self.resultado_df = None
        self.caja_texto.delete("1.0", tk.END)
        self._set_estado("Sin archivos cargados")
        self.resumen_datos = {
            "archivos_cargados": 0,
            "filas_leidas": 0,
            "precintos_unicos": 0,
            "duplicados_detectados": 0,
            "total_piezas_si": 0,
            "total_piezas_no": 0,
            "piezas_resultado_final": 0,
            "lotes_origen_vacios": 0,
            "lotes_origen_informados": 0,
        }
        self._actualizar_botones()


if __name__ == "__main__":
    ventana = tk.Tk()
    app = ProcesadorCSVApp(ventana)
    ventana.mainloop()
    
def lanzar_app_merma(parent=None):
    import tkinter as tk
    ventana = tk.Toplevel(parent)
    suite_preparar_ventana_sin_parpadeo(ventana)
    app = ProcesadorCSVApp(ventana)
    suite_mostrar_ventana_sin_parpadeo(ventana, maximizar=True, enfocar=True, icono=True)
    return ventana
