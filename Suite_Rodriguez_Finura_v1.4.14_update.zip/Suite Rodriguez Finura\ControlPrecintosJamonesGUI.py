#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Aplicacion para controlar precintos de jamones.

Valida ficheros TXT con campos separados por punto y coma:
partida;fecha;hora;codigo_articulo;numero_precinto;lote;peso;

Reglas:
- Blanco: precinto de 12 digitos numericos.
- Iberico: precinto de 12 digitos numericos y checksum GTIN-12 valido.
- Duplicados: conserva el registro mas reciente por fecha+hora; si empata o falta fecha,
  conserva la lectura posterior en el orden de carga.
- Exporta TXT o CSV en formato Windows CRLF.
- En iberico, el CSV exporta una unica columna de precintos validos y crea
  junto a el un TXT con el resumen final.
"""

from __future__ import annotations

import csv
import os
import re
import smtplib
import sys
import tempfile
import unicodedata
from collections import Counter
from difflib import SequenceMatcher
from email.message import EmailMessage
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    FUENTE_BASE as SUITE_FUENTE_BASE,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_atajos_comunes as suite_configurar_atajos_comunes,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    establecer_preferencia as suite_establecer_preferencia,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    obtener_paleta as suite_obtener_paleta,
    obtener_preferencia as suite_obtener_preferencia,
    preparar_ventana_sin_parpadeo as suite_preparar_ventana_sin_parpadeo,
    recordar_directorio as suite_recordar_directorio,
)

from typing import Iterable

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

TIPOS_JAMON = ("Blanco", "Iberico")
CAMPOS_ESPERADOS = 7
SMTP_HOST = "smtp.vallcompanys.es"
SMTP_PORT = 25
SMTP_USUARIO = "envio@smtp.erod.es"
SMTP_PASSWORD = "71sJ5&z5j"
PREF_ULTIMO_CORREO_PRECINTOS = "control_precintos_ultimo_correo"
PREF_ASUNTO_CORREO_PRECINTOS = "control_precintos_asunto_correo"
PREF_MENSAJE_CORREO_PRECINTOS = "control_precintos_mensaje_correo"
ASUNTO_CORREO_DEFECTO = "Control precintos jamones"
MENSAJE_CORREO_DEFECTO = (
    "Adjunto se envian los ficheros generados por Control Precintos Jamones.\n\n"
    "Tipo: {tipo_jamon}\n"
    "Registros validos: {registros_validos}\n"
    "Incidencias pendientes: {incidencias}\n"
    "Duplicados suprimidos: {duplicados}\n\n"
    "CSV corregido y resumen TXT."
)


@dataclass
class RegistroJamones:
    archivo: str
    linea: int
    campos: list[str]
    orden: int

    @property
    def partida(self) -> str:
        return self.campos[0] if len(self.campos) > 0 else ""

    @property
    def fecha(self) -> str:
        return self.campos[1] if len(self.campos) > 1 else ""

    @property
    def hora(self) -> str:
        return self.campos[2] if len(self.campos) > 2 else ""

    @property
    def precinto(self) -> str:
        return self.campos[4] if len(self.campos) > 4 else ""

    @property
    def lote(self) -> str:
        return self.campos[5] if len(self.campos) > 5 else ""

    @property
    def peso(self) -> str:
        return self.campos[6] if len(self.campos) > 6 else ""

    def fecha_hora(self) -> datetime | None:
        for formato in ("%d/%m/%Y %H:%M:%S", "%d/%m/%y %H:%M:%S"):
            try:
                return datetime.strptime(f"{self.fecha} {self.hora}", formato)
            except ValueError:
                continue
        return None

    def a_linea(self) -> str:
        campos = self.campos[:CAMPOS_ESPERADOS]
        while len(campos) < CAMPOS_ESPERADOS:
            campos.append("")
        return ";".join(campos) + ";"


def ruta_recurso(nombre: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / nombre  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent / nombre


def aplicar_icono_ventana(ventana):
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


def normalizar_precinto(valor: str) -> str:
    return re.sub(r"\D+", "", valor or "")


def gtin12_valido(codigo: str) -> bool:
    if not re.fullmatch(r"\d{12}", codigo):
        return False
    digitos = [int(c) for c in codigo]
    suma = sum(digitos[i] * (3 if i % 2 == 0 else 1) for i in range(11))
    check = (10 - (suma % 10)) % 10
    return check == digitos[11]



def normalizar_cabecera(valor: str) -> str:
    texto = unicodedata.normalize("NFKD", valor or "")
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texto.strip().lower())


def columna_excel_a_indice(referencia: str) -> int:
    letras = re.sub(r"[^A-Z]", "", referencia.upper())
    indice = 0
    for letra in letras:
        indice = indice * 26 + (ord(letra) - ord("A") + 1)
    return indice - 1


def leer_valor_celda_xlsx(celda, cadenas_compartidas: list[str]) -> str:
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    tipo = celda.attrib.get("t")
    if tipo == "inlineStr":
        return "".join(t.text or "" for t in celda.findall(".//a:t", ns)).strip()
    valor = celda.find("a:v", ns)
    if valor is None:
        return ""
    texto = valor.text or ""
    if tipo == "s" and texto.isdigit():
        idx = int(texto)
        if 0 <= idx < len(cadenas_compartidas):
            return cadenas_compartidas[idx].strip()
    return texto.strip()


def hojas_visibles_workbook(workbook_xml: bytes) -> list[tuple[str, str]]:
    ns = {
        "a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }
    root = ET.fromstring(workbook_xml)
    hojas = []
    for sheet in root.findall(".//a:sheet", ns):
        if sheet.attrib.get("state") == "hidden":
            continue
        nombre = sheet.attrib.get("name", "Hoja")
        rid = sheet.attrib.get(f"{{{ns['r']}}}id", "")
        if rid:
            hojas.append((nombre, rid))
    return hojas


def relaciones_workbook(rels_xml: bytes) -> dict[str, str]:
    ns = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}
    root = ET.fromstring(rels_xml)
    rels = {}
    for rel in root.findall("r:Relationship", ns):
        rid = rel.attrib.get("Id", "")
        target = rel.attrib.get("Target", "")
        if not rid or not target:
            continue
        limpio = target.lstrip("/")
        if limpio.startswith("xl/"):
            rels[rid] = limpio
        elif limpio.startswith("../"):
            rels[rid] = limpio.replace("../", "", 1)
        else:
            rels[rid] = "xl/" + limpio
    return rels


def leer_precintos_excel_oficial(ruta: Path) -> list[str]:
    """Lee un XLSX oficial y extrae la columna llamada 'Numero del precinto'.

    Se usa solo libreria estandar para no anadir dependencias al instalador.
    """
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    with ZipFile(ruta) as zf:
        nombres = set(zf.namelist())
        if "xl/workbook.xml" not in nombres or "xl/_rels/workbook.xml.rels" not in nombres:
            raise ValueError("El Excel no contiene la estructura esperada de libro XLSX.")
        cadenas: list[str] = []
        if "xl/sharedStrings.xml" in nombres:
            root_ss = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root_ss.findall("a:si", ns):
                cadenas.append("".join(t.text or "" for t in si.findall(".//a:t", ns)).strip())
        rels = relaciones_workbook(zf.read("xl/_rels/workbook.xml.rels"))
        hojas = hojas_visibles_workbook(zf.read("xl/workbook.xml"))
        for _nombre_hoja, rid in hojas:
            ruta_hoja = rels.get(rid)
            if not ruta_hoja or ruta_hoja not in nombres:
                continue
            root = ET.fromstring(zf.read(ruta_hoja))
            filas = []
            for fila in root.findall(".//a:row", ns):
                celdas = {}
                for celda in fila.findall("a:c", ns):
                    ref = celda.attrib.get("r", "")
                    if not ref:
                        continue
                    celdas[columna_excel_a_indice(ref)] = leer_valor_celda_xlsx(celda, cadenas)
                if celdas:
                    filas.append(celdas)
            indice_columna = None
            fila_cabecera = -1
            for i, fila in enumerate(filas):
                for col, valor in fila.items():
                    if normalizar_cabecera(valor) == "numero del precinto":
                        indice_columna = col
                        fila_cabecera = i
                        break
                if indice_columna is not None:
                    break
            if indice_columna is None:
                continue
            precintos: list[str] = []
            vistos: set[str] = set()
            for fila in filas[fila_cabecera + 1:]:
                valor = normalizar_precinto(fila.get(indice_columna, ""))
                if re.fullmatch(r"\d{12}", valor) and valor not in vistos:
                    vistos.add(valor)
                    precintos.append(valor)
            return precintos
        raise ValueError("No se encontro la columna 'Numero del precinto' en ninguna hoja visible del Excel oficial.")


def distancia_digitos(a: str, b: str) -> int:
    if len(a) != len(b):
        return max(len(a), len(b))
    return sum(1 for x, y in zip(a, b) if x != y)


def es_transposicion_simple(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    dif = [i for i, (x, y) in enumerate(zip(a, b)) if x != y]
    return len(dif) == 2 and a[dif[0]] == b[dif[1]] and a[dif[1]] == b[dif[0]]


def sugerir_precintos(codigo: str, oficiales: set[str], max_sugerencias: int = 3) -> list[str]:
    limpio = normalizar_precinto(codigo)
    if not limpio or not oficiales:
        return []
    candidatos = []
    for oficial in oficiales:
        dist = distancia_digitos(limpio, oficial)
        ratio = SequenceMatcher(None, limpio, oficial).ratio()
        trans = es_transposicion_simple(limpio, oficial)
        if dist <= 2 or trans or ratio >= 0.84:
            penalizacion = 0 if trans else dist
            candidatos.append((penalizacion, -ratio, oficial))
    candidatos.sort()
    return [oficial for _dist, _ratio, oficial in candidatos[:max_sugerencias]]

def validar_precinto(codigo: str, tipo_jamon: str) -> tuple[bool, str]:
    limpio = normalizar_precinto(codigo)
    if codigo != limpio:
        return False, "contiene caracteres no numericos"
    if not re.fullmatch(r"\d{12}", codigo):
        return False, "debe tener exactamente 12 digitos numericos"
    if tipo_jamon.lower() == "iberico" and not gtin12_valido(codigo):
        return False, "GTIN-12 incorrecto"
    return True, ""


def valor_mayoritario(valores: Iterable[str]) -> str:
    contador = Counter(v.strip() for v in valores if v and v.strip())
    if not contador:
        return ""
    comunes = contador.most_common(2)
    valor, repeticiones = comunes[0]
    if len(comunes) > 1 and repeticiones == comunes[1][1]:
        return ""
    return valor


def sugerir_partida_lote(registros: Iterable[RegistroJamones]) -> tuple[str, str]:
    registros_lista = list(registros)
    partida = valor_mayoritario(
        r.partida for r in registros_lista if re.fullmatch(r"\d{6}", r.partida.strip())
    )
    lote = valor_mayoritario(r.lote for r in registros_lista)
    return partida, lote


def validar_registro_completo(
    registro: RegistroJamones,
    tipo_jamon: str,
    partida_sugerida: str = "",
    lote_sugerido: str = "",
) -> list[str]:
    motivos: list[str] = []
    if len(registro.campos) < CAMPOS_ESPERADOS:
        motivos.append(f"faltan campos: {len(registro.campos)} de {CAMPOS_ESPERADOS}")

    partida = registro.partida.strip()
    if not re.fullmatch(r"\d{6}", partida):
        detalle = "partida vacia" if not partida else f"partida '{partida}' no valida"
        if partida_sugerida:
            motivos.append(f"{detalle}: debe tener 6 digitos; sugerida {partida_sugerida}")
        else:
            motivos.append(f"{detalle}: debe tener 6 digitos")

    lote = registro.lote.strip()
    if not lote:
        if lote_sugerido:
            motivos.append(f"lote vacio; sugerido {lote_sugerido}")
        else:
            motivos.append("lote vacio")

    ok_precinto, motivo_precinto = validar_precinto(registro.precinto, tipo_jamon)
    if not ok_precinto:
        motivos.append(motivo_precinto)
    return motivos


def parsear_peso(valor: str) -> float | None:
    texto = (valor or "").strip().replace(".", "").replace(",", ".")
    if not texto:
        return None
    try:
        return float(texto)
    except ValueError:
        return None


def formatear_peso(valor: float) -> str:
    texto = f"{valor:.3f}".rstrip("0").rstrip(".")
    return texto.replace(".", ",")


def parsear_linea(linea: str, archivo: str, numero_linea: int, orden: int) -> RegistroJamones | None:
    texto = linea.strip("\r\n")
    if not texto.strip():
        return None
    try:
        partes = next(csv.reader([texto], delimiter=";", quotechar='"'))
    except csv.Error:
        partes = texto.split(";")
    if partes and partes[-1] == "":
        partes = partes[:-1]
    return RegistroJamones(archivo=archivo, linea=numero_linea, campos=partes, orden=orden)


def leer_ficheros(rutas: Iterable[Path]) -> list[RegistroJamones]:
    registros: list[RegistroJamones] = []
    orden = 0
    for ruta in rutas:
        with ruta.open("r", encoding="utf-8-sig", errors="replace", newline=None) as fichero:
            for numero_linea, linea in enumerate(fichero, start=1):
                orden += 1
                registro = parsear_linea(linea, ruta.name, numero_linea, orden)
                if registro is not None:
                    registros.append(registro)
    return registros


def es_mas_reciente(nuevo: RegistroJamones, actual: RegistroJamones) -> bool:
    fecha_nueva = nuevo.fecha_hora()
    fecha_actual = actual.fecha_hora()
    if fecha_nueva and fecha_actual and fecha_nueva != fecha_actual:
        return fecha_nueva > fecha_actual
    if fecha_nueva and not fecha_actual:
        return True
    if not fecha_nueva and fecha_actual:
        return False
    return nuevo.orden > actual.orden


def deduplicar(registros: list[RegistroJamones]) -> tuple[list[RegistroJamones], list[RegistroJamones]]:
    por_precinto: dict[str, RegistroJamones] = {}
    eliminados: list[RegistroJamones] = []
    for registro in registros:
        clave = registro.precinto
        anterior = por_precinto.get(clave)
        if anterior is None:
            por_precinto[clave] = registro
            continue
        if es_mas_reciente(registro, anterior):
            eliminados.append(anterior)
            por_precinto[clave] = registro
        else:
            eliminados.append(registro)
    conservados = sorted(por_precinto.values(), key=lambda r: r.orden)
    return conservados, eliminados


def formatear_registro_para_editor(registro: RegistroJamones, motivo: str) -> str:
    return (
        f"# Archivo: {registro.archivo} | linea: {registro.linea} | motivo: {motivo}\n"
        f"{registro.a_linea()}"
    )


def ruta_resumen_para_csv(ruta_csv: Path) -> Path:
    return ruta_csv.with_name(f"{ruta_csv.stem}_resumen.txt")


def formato_importable_ax(codigos: Iterable[str]) -> str:
    return ",".join(codigo for codigo in codigos if codigo)


class ControlPrecintosJamonesApp:
    def __init__(self, ventana: tk.Tk | tk.Toplevel):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Control de Precintos Jamones")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)

        self.rutas: list[Path] = []
        self.registros_validos: list[RegistroJamones] = []
        self.registros_invalidos: list[tuple[RegistroJamones, str]] = []
        self.duplicados_eliminados: list[RegistroJamones] = []
        self.ruta_excel_oficial: Path | None = None
        self.precintos_oficiales: set[str] = set()
        self.partida_sugerida = ""
        self.lote_sugerido = ""
        self.hay_cambios_sin_guardar = False
        self.revalidacion_pendiente = False
        self.flujo_estado = "sin_archivos"

        self._logo_rodriguez = None
        self._logo_finura = None
        self.tipo_var = tk.StringVar(value="Blanco")
        self.resumen_var = tk.StringVar(value="Selecciona tipo de jamon y carga uno o varios TXT.")
        self.estado_var = tk.StringVar(value="Listo")
        self.peso_min_var = tk.StringVar()
        self.peso_max_var = tk.StringVar()

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_atajos()

    def configurar_estilos(self):
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(2, weight=1)

        cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(22, 10))
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(cabecera, text="Control de Precintos Jamones", style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
        ttk.Label(cabecera, text="Valida formato, GTIN-12 para iberico, elimina duplicados y exporta TXT/CSV.", style="Subtitle.TLabel", anchor="center").grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        panel_canvas.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 10))
        panel = panel_canvas.body
        for col in range(7):
            panel.columnconfigure(col, weight=1 if col in (3, 4) else 0)
        ttk.Label(panel, text="Tipo de jamon", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 10))
        self.combo_tipo = ttk.Combobox(panel, textvariable=self.tipo_var, values=TIPOS_JAMON, state="readonly", width=15)
        self.combo_tipo.grid(row=0, column=1, sticky="w", padx=(0, 12))
        self.combo_tipo.bind("<<ComboboxSelected>>", self._al_cambiar_tipo)
        self.boton_excel = ttk.Button(panel, text="Importar Excel oficial", command=self.cargar_excel_oficial, style="Secondary.TButton")
        self.boton_excel.grid(row=0, column=2, sticky="ew", padx=5)
        self.boton_txt = ttk.Button(panel, text="Añadir TXT", command=self.cargar_txt, style="Next.TButton")
        self.boton_txt.grid(row=0, column=3, sticky="ew", padx=5)
        self.boton_procesar = ttk.Button(panel, text="Procesar", command=self.procesar, style="Primary.TButton")
        self.boton_procesar.grid(row=0, column=4, sticky="ew", padx=5)
        self.boton_revalidar = ttk.Button(panel, text="Revalidar", command=self.revalidar_editor, style="Secondary.TButton")
        self.boton_revalidar.grid(row=0, column=5, sticky="ew", padx=5)
        self.boton_limpiar = ttk.Button(panel, text="Limpiar", command=self.limpiar, style="Secondary.TButton")
        self.boton_limpiar.grid(row=0, column=6, sticky="ew", padx=(5, 0))
        suite_configurar_orden_tabulacion(
            self.combo_tipo,
            self.boton_excel,
            self.boton_txt,
            self.boton_procesar,
            self.boton_revalidar,
            self.boton_limpiar,
        )

        self.lbl_archivos = ttk.Label(panel, text="Sin archivos cargados", style="Card.TLabel")
        self.lbl_archivos.grid(row=1, column=0, columnspan=7, sticky="ew", pady=(10, 0))
        self.lbl_excel = ttk.Label(panel, text="Excel oficial: no cargado", style="Card.TLabel")
        self.lbl_excel.grid(row=2, column=0, columnspan=7, sticky="ew", pady=(6, 0))
        self._al_cambiar_tipo()

        cuerpo = ttk.Frame(self.ventana, style="TFrame")
        cuerpo.grid(row=2, column=0, sticky="nsew", padx=28, pady=8)
        cuerpo.columnconfigure(0, weight=3)
        cuerpo.columnconfigure(1, weight=2)
        cuerpo.rowconfigure(0, weight=1)

        zona_editor_canvas = suite_crear_panel_canvas(cuerpo, padding=SUITE_PAD_PANEL)
        zona_editor_canvas.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        zona_editor = zona_editor_canvas.body
        zona_editor.columnconfigure(0, weight=1)
        zona_editor.rowconfigure(1, weight=1)
        self.lbl_flujo = ttk.Label(zona_editor, text="Paso 1: Seleccionar | Paso 2: Procesar | Paso 3: Guardar", style="CardTitle.TLabel")
        self.lbl_flujo.grid(row=0, column=0, sticky="w")
        self.texto = tk.Text(zona_editor, wrap="none", undo=True, maxundo=-1, autoseparators=True)
        suite_aplicar_texto_tk(self.texto, mono=False)
        self._configurar_area_trabajo()
        self.texto.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll_y = ttk.Scrollbar(zona_editor, orient="vertical", command=self.texto.yview)
        scroll_y.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        scroll_x = ttk.Scrollbar(zona_editor, orient="horizontal", command=self.texto.xview)
        scroll_x.grid(row=2, column=0, sticky="ew")
        self.texto.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        self.texto.bind("<<Modified>>", self._marcar_cambios_editor)

        zona_resumen_canvas = suite_crear_panel_canvas(cuerpo, padding=SUITE_PAD_PANEL)
        zona_resumen_canvas.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        zona_resumen = zona_resumen_canvas.body
        zona_resumen.columnconfigure(0, weight=1)
        zona_resumen.rowconfigure(1, weight=1)
        ttk.Label(zona_resumen, text="Resumen final", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.resumen = tk.Text(zona_resumen, wrap="word", state="disabled")
        suite_aplicar_texto_tk(self.resumen, mono=False, alto=12)
        self.resumen.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll_resumen = ttk.Scrollbar(zona_resumen, orient="vertical", command=self.resumen.yview)
        scroll_resumen.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        self.resumen.configure(yscrollcommand=scroll_resumen.set)

        filtros_peso_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL_COMPACT)
        filtros_peso_canvas.grid(row=3, column=0, sticky="ew", padx=28, pady=(8, 0))
        filtros_peso = filtros_peso_canvas.body
        filtros_peso.columnconfigure(6, weight=1)
        ttk.Label(filtros_peso, text="Filtro de pesos para revisión", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w", padx=(0, 14))
        ttk.Label(filtros_peso, text="Peso mínimo (kg)", style="Card.TLabel").grid(row=0, column=1, sticky="e")
        self.entry_peso_min = ttk.Entry(filtros_peso, textvariable=self.peso_min_var, width=8)
        self.entry_peso_min.grid(row=0, column=2, sticky="w", padx=(5, 12))
        ttk.Label(filtros_peso, text="Peso máximo (kg)", style="Card.TLabel").grid(row=0, column=3, sticky="e")
        self.entry_peso_max = ttk.Entry(filtros_peso, textvariable=self.peso_max_var, width=8)
        self.entry_peso_max.grid(row=0, column=4, sticky="w", padx=(5, 12))
        self.boton_filtro_pesos = ttk.Button(filtros_peso, text="Mostrar fuera de rango", command=self.mostrar_pesos_fuera_rango, style="Secondary.TButton")
        self.boton_filtro_pesos.grid(row=0, column=5, sticky="w", padx=5)
        self.boton_limpiar_filtro = ttk.Button(filtros_peso, text="Limpiar filtro", command=self.limpiar_filtro_pesos, style="Secondary.TButton")
        self.boton_limpiar_filtro.grid(row=0, column=6, sticky="w", padx=5)
        self.lbl_error_pesos = ttk.Label(filtros_peso, text="", style="Error.TLabel")
        self.lbl_error_pesos.grid(row=1, column=1, columnspan=6, sticky="w", pady=(6, 0))

        acciones_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        acciones_canvas.grid(row=4, column=0, sticky="ew", padx=28, pady=(8, 10))
        acciones = acciones_canvas.body
        acciones.columnconfigure(0, weight=1)
        ttk.Frame(acciones, style="RedLine.TFrame", height=1).grid(row=0, column=0, columnspan=6, sticky="ew", pady=(0, 8))
        self.lbl_estado_acciones = ttk.Label(acciones, textvariable=self.estado_var, style="Card.TLabel")
        self.lbl_estado_acciones.configure(takefocus=False)
        self.lbl_estado_acciones.grid(row=1, column=0, sticky="w")
        self.boton_guardar_txt = ttk.Button(acciones, text="Guardar TXT", command=lambda: self.guardar("txt"), style="Primary.TButton")
        self.boton_guardar_txt.grid(row=1, column=1, padx=5)
        self.boton_guardar_csv = ttk.Button(acciones, text="Guardar CSV", command=lambda: self.guardar("csv"), style="Primary.TButton")
        self.boton_guardar_csv.grid(row=1, column=2, padx=5)
        self.boton_mensaje_correo = ttk.Button(acciones, text="Mensaje correo", command=self.configurar_mensaje_correo, style="Secondary.TButton")
        self.boton_mensaje_correo.grid(row=1, column=3, padx=5)
        self.boton_enviar_correo = ttk.Button(acciones, text="Enviar correo", command=self.enviar_correo, style="Primary.TButton")
        self.boton_enviar_correo.grid(row=1, column=4, padx=5)
        self.boton_salir = ttk.Button(acciones, text="Salir", command=self.salir, style="Danger.TButton")
        self.boton_salir.grid(row=1, column=5, padx=(5, 0))
        suite_configurar_orden_tabulacion(
            self.texto,
            self.entry_peso_min,
            self.entry_peso_max,
            self.boton_filtro_pesos,
            self.boton_limpiar_filtro,
            self.boton_guardar_txt,
            self.boton_guardar_csv,
            self.boton_mensaje_correo,
            self.boton_enviar_correo,
            self.boton_salir,
        )

        self.progreso = ttk.Progressbar(self.ventana, mode="indeterminate")
        self.progreso.grid(row=5, column=0, sticky="ew", padx=28, pady=(0, 8))
        self.progreso.grid_remove()

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=6, column=0, sticky="ew", padx=28, pady=(0, 16))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")
        ttk.Label(footer, text=SUITE_FOOTER_TEXTO, style="Author.TLabel", anchor="center").grid(row=0, column=1, sticky="ew")
        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._actualizar_botones()

        self._set_texto_inicial()
        self._actualizar_resumen("Esperando archivos.")

    def _set_estado(self, texto: str, importante: bool = False):
        self.estado_var.set(texto)
        if importante:
            suite_anunciar_estado(self.lbl_estado_acciones, texto)

    def _actualizar_flujo(self):
        try:
            textos = {
                "sin_archivos": "Paso 1: Seleccionar | Paso 2: Procesar | Paso 3: Guardar",
                "archivos": "Archivos cargados | Siguiente paso: Procesar",
                "procesado_ok": "Procesado correcto | Siguiente paso: Guardar",
                "correccion": "Incidencias pendientes | Corrige y pulsa Revalidar",
                "pendiente_revalidar": "Cambios sin validar | Siguiente paso: Revalidar",
                "listo_guardar": "Revalidacion correcta | Siguiente paso: Guardar",
                "guardado": "Guardado correcto",
            }
            self.lbl_flujo.config(text=textos.get(getattr(self, "flujo_estado", "sin_archivos"), textos["sin_archivos"]))
        except Exception:
            pass

    def _hay_trabajo_en_curso(self) -> bool:
        return bool(self.hay_cambios_sin_guardar or self.revalidacion_pendiente or self.registros_invalidos)


    def _aplicar_estilo_boton(self, boton, *, siguiente=False, protegido=False, peligro=False):
        try:
            if siguiente:
                boton.configure(style="Next.TButton")
            elif protegido:
                boton.configure(style="Protected.TButton")
            elif peligro:
                boton.configure(style="Danger.TButton")
            else:
                boton.configure(style="Secondary.TButton")
        except Exception:
            pass

    def _actualizar_botones(self):
        hay_rutas = bool(getattr(self, "rutas", []))
        hay_validos = bool(getattr(self, "registros_validos", []))
        hay_invalidos = bool(getattr(self, "registros_invalidos", []))
        hay_datos = hay_rutas or hay_validos or hay_invalidos or self.hay_cambios_sin_guardar
        puede_procesar = hay_rutas and not self.revalidacion_pendiente
        puede_revalidar = self.revalidacion_pendiente or hay_invalidos
        puede_guardar = hay_validos and not hay_invalidos and not self.revalidacion_pendiente
        puede_filtrar = hay_validos and not hay_invalidos and not self.revalidacion_pendiente

        suite_configurar_boton_estado(self.boton_excel, True)
        suite_configurar_boton_estado(self.boton_txt, True)
        suite_configurar_boton_estado(self.boton_procesar, puede_procesar)
        suite_configurar_boton_estado(self.boton_revalidar, puede_revalidar)
        suite_configurar_boton_estado(self.boton_limpiar, hay_datos)
        suite_configurar_boton_estado(self.boton_guardar_txt, puede_guardar)
        suite_configurar_boton_estado(self.boton_guardar_csv, puede_guardar)
        suite_configurar_boton_estado(self.boton_mensaje_correo, True)
        suite_configurar_boton_estado(self.boton_enviar_correo, puede_guardar)
        suite_configurar_boton_estado(self.boton_filtro_pesos, puede_filtrar)
        suite_configurar_boton_estado(self.boton_limpiar_filtro, hay_validos or bool(self.peso_min_var.get() or self.peso_max_var.get()))

        siguiente = getattr(self, "flujo_estado", "sin_archivos")
        trabajo_en_curso = bool(hay_validos or hay_invalidos or self.revalidacion_pendiente or self.hay_cambios_sin_guardar)
        self._aplicar_estilo_boton(self.boton_excel, protegido=trabajo_en_curso)
        self._aplicar_estilo_boton(self.boton_txt, siguiente=(siguiente == "sin_archivos"), protegido=trabajo_en_curso)
        self._aplicar_estilo_boton(self.boton_procesar, siguiente=(siguiente == "archivos" and puede_procesar), protegido=trabajo_en_curso and puede_procesar)
        self._aplicar_estilo_boton(self.boton_revalidar, siguiente=(siguiente in {"correccion", "pendiente_revalidar"} and puede_revalidar))
        self._aplicar_estilo_boton(self.boton_guardar_txt, siguiente=(siguiente in {"procesado_ok", "listo_guardar"} and puede_guardar))
        self._aplicar_estilo_boton(self.boton_guardar_csv, siguiente=(siguiente in {"procesado_ok", "listo_guardar"} and puede_guardar))
        self._aplicar_estilo_boton(self.boton_mensaje_correo)
        self._aplicar_estilo_boton(self.boton_enviar_correo, siguiente=(siguiente in {"procesado_ok", "listo_guardar"} and puede_guardar))
        self._aplicar_estilo_boton(self.boton_limpiar, peligro=True)
        self._aplicar_estilo_boton(self.boton_filtro_pesos)
        self._aplicar_estilo_boton(self.boton_limpiar_filtro)
        self._actualizar_flujo()

    def _set_error_pesos(self, texto: str):
        self.lbl_error_pesos.config(text=texto)
        if texto:
            try:
                self.texto.focus_set()
            except Exception:
                pass

    def _set_ocupado(self, ocupado: bool, texto: str | None = None):
        botones = (
            self.boton_excel,
            self.boton_txt,
            self.boton_procesar,
            self.boton_revalidar,
            self.boton_limpiar,
            self.boton_guardar_txt,
            self.boton_guardar_csv,
            self.boton_mensaje_correo,
            self.boton_enviar_correo,
            self.boton_filtro_pesos,
            self.boton_limpiar_filtro,
        )
        for boton in botones:
            suite_configurar_boton_estado(boton, not ocupado)
        if ocupado:
            if texto:
                self._set_estado(texto)
            self.progreso.grid()
            self.progreso.start(12)
            self.ventana.update_idletasks()
        else:
            self.progreso.stop()
            self.progreso.grid_remove()
            self._actualizar_botones()

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            return
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))
            img_izq.thumbnail((180, 62))
            img_der.thumbnail((180, 62))
            self._logo_finura = ImageTk.PhotoImage(img_izq)
            self._logo_rodriguez = ImageTk.PhotoImage(img_der)
            lbl_izq = tk.Label(self.logo_slot_izq, image=self._logo_finura)
            lbl_der = tk.Label(self.logo_slot_der, image=self._logo_rodriguez)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
            preparar_logo_minimizar(lbl_izq, self.ventana)
            preparar_logo_minimizar(lbl_der, self.ventana)
        except Exception:
            pass

    def configurar_atajos(self):
        suite_configurar_atajos_comunes(self.ventana, abrir=self.cargar_txt, guardar=lambda: self.guardar("txt"), limpiar=self.limpiar, salir=self.salir)
        self.ventana.bind("<F5>", lambda _event: self.revalidar_editor())
        self.texto.bind("<Control-a>", self._seleccionar_todo_editor)
        self.texto.bind("<Control-A>", self._seleccionar_todo_editor)
        self.texto.bind("<Control-y>", self._rehacer_editor)
        self.texto.bind("<Control-Y>", self._rehacer_editor)

    def _seleccionar_todo_editor(self, _event=None):
        self.texto.tag_add("sel", "1.0", "end-1c")
        self.texto.mark_set("insert", "end-1c")
        self.texto.see("insert")
        return "break"

    def _rehacer_editor(self, _event=None):
        try:
            self.texto.edit_redo()
        except tk.TclError:
            pass
        return "break"

    def _configurar_area_trabajo(self):
        paleta = suite_obtener_paleta()
        familia, tamano = SUITE_FUENTE_BASE[0], SUITE_FUENTE_BASE[1]
        fuente_comentario = (familia, max(tamano - 1, 8), "italic")
        self.texto.configure(
            font=SUITE_FUENTE_BASE,
            background=paleta["field"],
            foreground=paleta["texto"],
            insertbackground=paleta["texto"],
            selectbackground=paleta["seleccion"],
            selectforeground=paleta["seleccion_texto"],
            relief="flat",
            borderwidth=0,
            padx=12,
            pady=10,
            spacing1=2,
            spacing3=3,
        )
        self.texto.tag_configure(
            "comentario",
            foreground=paleta["muted"],
            font=fuente_comentario,
            spacing1=3,
            spacing3=4,
        )
        self.texto.tag_configure(
            "dato",
            foreground=paleta["texto"],
            font=SUITE_FUENTE_BASE,
            spacing1=2,
            spacing3=3,
        )

    def _resaltar_area_trabajo(self):
        try:
            self.texto.tag_remove("comentario", "1.0", "end")
            self.texto.tag_remove("dato", "1.0", "end")
            total_lineas = int(self.texto.index("end-1c").split(".")[0])
            for numero in range(1, total_lineas + 1):
                inicio = f"{numero}.0"
                fin = f"{numero}.end"
                contenido = self.texto.get(inicio, fin).strip()
                if not contenido:
                    continue
                tag = "comentario" if contenido.startswith("#") else "dato"
                self.texto.tag_add(tag, inicio, fin)
        except Exception:
            pass

    def _set_texto_inicial(self):
        self.texto.delete("1.0", "end")
        self.texto.insert("1.0", "# Aquí aparecerán los registros con incidencias para corregirlos.\n# Formato esperado: partida;fecha;hora;codigo_articulo;numero_precinto;lote;peso;\n")
        self._resaltar_area_trabajo()
        self.texto.edit_modified(False)

    def _marcar_cambios_editor(self, _event=None):
        try:
            if not self.texto.edit_modified():
                return
            hay_contenido_util = any(
                linea.strip() and not linea.lstrip().startswith("#")
                for linea in self.texto.get("1.0", "end").splitlines()
            )
            if hay_contenido_util and (self.registros_validos or self.registros_invalidos):
                self.hay_cambios_sin_guardar = True
                self.revalidacion_pendiente = True
                self.flujo_estado = "pendiente_revalidar"
                # No usar anuncio accesible con focus_set() mientras el usuario escribe.
                # Si se roba el foco en cada <<Modified>>, el editor solo permite borrar/escribir
                # un caracter y obliga a volver a hacer clic. Actualizamos el estado visual
                # sin mover el foco ni tocar la posicion del cursor.
                self._set_estado("Cambios detectados en el area de trabajo. Revalida antes de guardar.", importante=False)
            self.texto.edit_modified(False)
            self._actualizar_botones()
        except Exception:
            pass

    def confirmar_perdida_cambios(self, accion: str = "continuar") -> bool:
        """Confirma acciones protegidas que pueden descartar datos o correcciones sin guardar."""
        if not self._hay_trabajo_en_curso():
            return True

        mensajes = {
            "cargar": (
                "Accion protegida: cargar nuevos TXT",
                "Este boton esta protegido porque hay datos o correcciones en curso. Si cargas nuevos ficheros TXT se sustituira el trabajo actual.",
            ),
            "limpiar": (
                "Accion protegida: limpiar pantalla",
                "Este boton esta protegido porque hay datos o correcciones en curso. Si limpias la pantalla se borrara el trabajo actual.",
            ),
            "salir": (
                "Accion protegida: salir sin guardar",
                "Hay datos o correcciones sin guardar. Si sales ahora se perdera el trabajo no guardado.",
            ),
            "procesar": (
                "Accion protegida: volver a procesar",
                "Este boton esta protegido porque hay correcciones o cambios pendientes. Si procesas de nuevo se recalculara desde los TXT originales y se perderan las correcciones actuales.",
            ),
        }
        titulo, mensaje = mensajes.get(
            accion,
            (
                "Accion protegida",
                "Hay datos o correcciones sin guardar. Si continuas podrias perder informacion.",
            ),
        )
        return messagebox.askyesno(
            titulo,
            f"{mensaje}\n\nConfirma que quieres continuar.",
            parent=self.ventana,
        )


    def _al_cambiar_tipo(self, _event=None):
        es_iberico = self.tipo_var.get().lower() == "iberico"
        try:
            if es_iberico:
                self.boton_excel.grid()
                self.lbl_excel.grid()
            else:
                self.boton_excel.grid_remove()
                self.lbl_excel.grid_remove()
                self.ruta_excel_oficial = None
                self.precintos_oficiales = set()
        except Exception:
            pass

    def cargar_excel_oficial(self):
        if self.tipo_var.get().lower() != "iberico":
            self._set_estado("El Excel oficial solo se utiliza en el control exhaustivo de jamones ibéricos.", importante=True)
            return
        if self._hay_trabajo_en_curso() and not self.confirmar_perdida_cambios("cambiar Excel oficial"):
            return
        ruta = filedialog.askopenfilename(
            parent=self.ventana,
            title="Selecciona Excel oficial de precintos ibericos",
            filetypes=[("Excel", "*.xlsx"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("precintos_excel_oficial"),
        )
        if not ruta:
            return
        suite_recordar_directorio("precintos_excel_oficial", ruta)
        if not self._cargar_excel_oficial_desde_ruta(ruta):
            return
        self.estado_var.set("Excel oficial cargado. Su comparacion se incluira en el resumen al procesar.")
        self._actualizar_resumen(
            f"Excel oficial cargado correctamente.\nPrecintos oficiales detectados: {len(self.precintos_oficiales)}\n\n"
            "Este listado es informativo: ayuda a comparar lecturas raras, pero no sustituye automaticamente ningun precinto."
        )

    def _cargar_excel_oficial_desde_ruta(self, ruta: str | Path) -> bool:
        try:
            precintos = leer_precintos_excel_oficial(Path(ruta))
        except Exception as exc:
            messagebox.showerror(
                "Excel oficial no valido",
                f"No se pudo leer el listado oficial de precintos.\n\nDetalle: {exc}",
                parent=self.ventana,
            )
            return False
        if not precintos:
            messagebox.showwarning(
                "Excel oficial sin precintos",
                "Se encontro la columna 'Numero del precinto', pero no se detectaron precintos de 12 digitos.",
                parent=self.ventana,
            )
            return False
        self.ruta_excel_oficial = Path(ruta)
        self.precintos_oficiales = set(precintos)
        self.lbl_excel.config(text=f"Excel oficial: {self.ruta_excel_oficial.name} ({len(self.precintos_oficiales)} precintos)")
        return True

    def _pedir_excel_oficial_si_hay_incidencias_iberico(self) -> None:
        if self.tipo_var.get().lower() != "iberico" or not self.registros_invalidos or self.precintos_oficiales:
            return
        quiere_excel = messagebox.askyesno(
            "Incidencias en precintos ibericos",
            "Se han detectado precintos ibericos con formato incorrecto o GTIN-12 no valido.\n\n"
            "Puedes cargar ahora el Excel oficial para que el resumen muestre los precintos oficiales que no aparecen en el TXT. "
            "Asi podras copiar el posible correcto desde el resumen y pegarlo en la zona de trabajo para revalidar.\n\n"
            "¿Quieres seleccionar el Excel oficial ahora?",
            parent=self.ventana,
        )
        if not quiere_excel:
            return
        ruta = filedialog.askopenfilename(
            parent=self.ventana,
            title="Selecciona Excel oficial de precintos ibericos",
            filetypes=[("Excel", "*.xlsx"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("precintos_excel_oficial"),
        )
        if ruta:
            suite_recordar_directorio("precintos_excel_oficial", ruta)
            self._cargar_excel_oficial_desde_ruta(ruta)

    def _resumen_comparacion_oficial(self) -> list[str]:
        if self.tipo_var.get().lower() != "iberico" or not self.precintos_oficiales:
            return []

        leidos = {r.precinto for r in self.registros_validos if re.fullmatch(r"\d{12}", r.precinto)}
        # Incluimos tambien los codigos invalidos de 12 digitos para que la comparacion ayude
        # justo en los casos raros: si el codigo erroneo no esta en el oficial, el correcto
        # aparecera como "oficial no leido" y el usuario podra copiarlo al editor.
        leidos.update(
            r.precinto for r, _motivo in self.registros_invalidos if re.fullmatch(r"\d{12}", r.precinto)
        )

        leidos_no_oficiales = sorted(leidos - self.precintos_oficiales)
        oficiales_no_leidos = sorted(self.precintos_oficiales - leidos)
        hay_incidencias_formato = bool(self.registros_invalidos)

        lineas = [
            "",
            "Comparacion informativa con Excel oficial:",
            f"- Precintos oficiales cargados: {len(self.precintos_oficiales)}",
            f"- Precintos del TXT que no aparecen en el oficial: {len(leidos_no_oficiales)}",
            f"- Precintos oficiales que no aparecen en el TXT: {len(oficiales_no_leidos)}",
        ]

        if leidos_no_oficiales:
            lineas.append("\nLeidos en TXT que no aparecen en el Excel oficial:")
            for codigo in leidos_no_oficiales[:120]:
                lineas.append(f"- {codigo}")
            if len(leidos_no_oficiales) > 120:
                lineas.append(f"... y {len(leidos_no_oficiales) - 120} mas")
            lineas.append("Formato importable en AX:")
            lineas.append(formato_importable_ax(leidos_no_oficiales))

        if oficiales_no_leidos:
            lineas.append("\nOficiales que aparecen en el Excel y no en el TXT (copiables para corregir en la zona de trabajo):")
            for codigo in oficiales_no_leidos[:200]:
                lineas.append(f"- {codigo}")
            if len(oficiales_no_leidos) > 200:
                lineas.append(f"... y {len(oficiales_no_leidos) - 200} mas")
            lineas.append("Formato importable en AX:")
            lineas.append(formato_importable_ax(oficiales_no_leidos))

        # Las sugerencias solo se muestran si existen incidencias reales de formato/GTIN.
        # Si el TXT es valido y solo hay diferencias informativas con el Excel, no se
        # propone sustituir nada: se listan las diferencias y el usuario decide.
        if hay_incidencias_formato:
            candidatos_sugerencia = []
            candidatos_sugerencia.extend(leidos_no_oficiales)
            candidatos_sugerencia.extend(
                r.precinto for r, _motivo in self.registros_invalidos if r.precinto and r.precinto not in candidatos_sugerencia
            )

            sugerencias_mostradas = []
            for codigo in candidatos_sugerencia:
                sugerencias = sugerir_precintos(codigo, self.precintos_oficiales)
                if sugerencias:
                    sugerencias_mostradas.append((codigo, sugerencias))

            if sugerencias_mostradas:
                lineas.append("\nSugerencias oficiales cercanas:")
                for codigo, sugerencias in sugerencias_mostradas[:80]:
                    lineas.append(f"- {codigo} -> {', '.join(sugerencias)}")
                if len(sugerencias_mostradas) > 80:
                    lineas.append(f"... y {len(sugerencias_mostradas) - 80} sugerencias mas")

        return lineas

    def cargar_txt(self):
        if not self.confirmar_perdida_cambios("cargar"):
            return
        rutas = filedialog.askopenfilenames(
            parent=self.ventana,
            title="Selecciona fichero/s TXT de precintos",
            filetypes=[("Ficheros TXT", "*.txt"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("precintos_txt_abrir"),
        )
        if not rutas:
            return
        suite_recordar_directorio("precintos_txt_abrir", rutas[0])
        self.rutas = [Path(r) for r in rutas]
        self.lbl_archivos.config(text="Archivos cargados: " + " | ".join(p.name for p in self.rutas))
        self.registros_validos = []
        self.registros_invalidos = []
        self.duplicados_eliminados = []
        self.partida_sugerida = ""
        self.lote_sugerido = ""
        self._set_texto_inicial()
        self.flujo_estado = "archivos"
        self._set_estado(f"{len(self.rutas)} archivo/s cargado/s. Pulsa Procesar.", importante=True)
        self._actualizar_resumen("Archivos cargados. Pendiente de procesar.")
        self.hay_cambios_sin_guardar = False
        self.revalidacion_pendiente = False
        self._actualizar_botones()

    def procesar(self):
        if self._hay_trabajo_en_curso() and not self.confirmar_perdida_cambios("procesar"):
            return
        if not self.rutas:
            self._set_estado("Añade primero uno o varios ficheros TXT.", importante=True)
            return
        tipo = self.tipo_var.get()
        try:
            self._set_ocupado(True, "Procesando precintos...")
            registros = leer_ficheros(self.rutas)
        except Exception as exc:
            self._set_ocupado(False)
            messagebox.showerror("Error al leer", f"No se pudieron leer los ficheros:\n{exc}", parent=self.ventana)
            return

        validos: list[RegistroJamones] = []
        invalidos: list[tuple[RegistroJamones, str]] = []
        self.partida_sugerida, self.lote_sugerido = sugerir_partida_lote(registros)
        for registro in registros:
            motivos = validar_registro_completo(registro, tipo, self.partida_sugerida, self.lote_sugerido)
            if not motivos:
                validos.append(registro)
            else:
                invalidos.append((registro, "; ".join(motivos)))

        self.registros_validos, self.duplicados_eliminados = deduplicar(validos)
        self.registros_invalidos = invalidos
        self._pedir_excel_oficial_si_hay_incidencias_iberico()
        self._mostrar_invalidos_en_editor()
        self._actualizar_resumen_desde_estado(total=len(registros))
        self.hay_cambios_sin_guardar = bool(invalidos)
        self.revalidacion_pendiente = bool(invalidos)
        self.flujo_estado = "correccion" if invalidos else "procesado_ok"
        self._set_estado("Procesado con incidencias. Corrige y pulsa Revalidar." if invalidos else "Procesado correcto. Puedes guardar TXT o CSV.", importante=True)
        self.texto.edit_modified(False)
        self._set_ocupado(False)

    def _formatear_registro_invalido(self, registro: RegistroJamones, motivo: str) -> str:
        bloque = formatear_registro_para_editor(registro, motivo)
        if self.partida_sugerida and not re.fullmatch(r"\d{6}", registro.partida.strip()):
            bloque += f"\n# Sugerencia partida: sustituye el primer campo por {self.partida_sugerida}"
        if self.lote_sugerido and not registro.lote.strip():
            bloque += f"\n# Sugerencia lote: sustituye el sexto campo por {self.lote_sugerido}"
        if self.precintos_oficiales:
            sugerencias = sugerir_precintos(registro.precinto, self.precintos_oficiales)
            if sugerencias:
                bloque += "\n# Sugerencias oficiales cercanas: " + ", ".join(sugerencias)
        return bloque

    def _mostrar_invalidos_en_editor(self):
        self.texto.delete("1.0", "end")
        if not self.registros_invalidos:
            self.texto.insert("1.0", "# Sin incidencias de formato. Puedes guardar TXT o CSV.\n")
        else:
            bloques = ["# Corrige las lineas de datos. Las lineas que empiezan por # se ignoran al revalidar."]
            bloques += [self._formatear_registro_invalido(reg, motivo) for reg, motivo in self.registros_invalidos]
            self.texto.insert("1.0", "\n".join(bloques) + "\n")
        self._resaltar_area_trabajo()
        self.texto.edit_modified(False)

    def limpiar_filtro_pesos(self):
        """Limpia los campos de peso y restaura la zona de trabajo normal."""
        self.peso_min_var.set("")
        self.peso_max_var.set("")
        self._set_error_pesos("")
        self._mostrar_invalidos_en_editor()
        if self.registros_invalidos:
            self._set_estado("Filtro de pesos limpiado. Siguen pendientes incidencias de precintos.")
            self.hay_cambios_sin_guardar = True
        else:
            self._set_estado("Filtro de pesos limpiado. No hay incidencias visibles.")
            self.hay_cambios_sin_guardar = False
        self.texto.edit_modified(False)
        self._actualizar_botones()

    def mostrar_pesos_fuera_rango(self):
        if self.registros_invalidos:
            self._set_error_pesos("Primero corrige y revalida las incidencias de precintos.")
            return
        if not self.registros_validos:
            self._set_error_pesos("Procesa primero uno o varios ficheros TXT.")
            return

        minimo = parsear_peso(self.peso_min_var.get()) if self.peso_min_var.get().strip() else None
        maximo = parsear_peso(self.peso_max_var.get()) if self.peso_max_var.get().strip() else None
        if minimo is None and maximo is None:
            self._set_error_pesos("Introduce un peso mínimo, un peso máximo o ambos.")
            return
        if self.peso_min_var.get().strip() and minimo is None:
            self._set_error_pesos("Peso mínimo no válido. Ejemplos: 10, 10,5 o 10.5.")
            return
        if self.peso_max_var.get().strip() and maximo is None:
            self._set_error_pesos("Peso máximo no válido. Ejemplos: 16, 16,5 o 16.5.")
            return
        if minimo is not None and maximo is not None and minimo > maximo:
            self._set_error_pesos("El peso mínimo no puede ser superior al peso máximo.")
            return
        self._set_error_pesos("")

        fuera: list[tuple[RegistroJamones, str]] = []
        pesos_no_validos: list[RegistroJamones] = []
        for registro in self.registros_validos:
            peso = parsear_peso(registro.peso)
            if peso is None:
                pesos_no_validos.append(registro)
                continue
            if minimo is not None and peso < minimo:
                fuera.append((registro, f"peso {registro.peso} inferior al minimo {formatear_peso(minimo)}"))
            elif maximo is not None and peso > maximo:
                fuera.append((registro, f"peso {registro.peso} superior al maximo {formatear_peso(maximo)}"))

        self.texto.delete("1.0", "end")
        if not fuera and not pesos_no_validos:
            self.texto.insert("1.0", "# No hay registros fuera del rango de peso indicado.\n")
        else:
            bloques = [
                "# Registros filtrados por peso.",
                "# Puedes modificar estas lineas y pulsar Revalidar para sustituir el registro original por el corregido.",
                "# Las lineas que empiezan por # se ignoran al revalidar.",
            ]
            for registro, motivo in fuera:
                bloques.append(formatear_registro_para_editor(registro, motivo))
            for registro in pesos_no_validos:
                bloques.append(formatear_registro_para_editor(registro, "peso no numerico o vacio"))
            self.texto.insert("1.0", "\n".join(bloques) + "\n")
        self._resaltar_area_trabajo()

        lineas = [
            "Filtro de pesos aplicado:",
            f"- Peso minimo: {formatear_peso(minimo) if minimo is not None else '(sin minimo)'}",
            f"- Peso maximo: {formatear_peso(maximo) if maximo is not None else '(sin maximo)'}",
            f"- Registros por debajo del minimo o por encima del maximo: {len(fuera)}",
            f"- Registros con peso no numerico o vacio: {len(pesos_no_validos)}",
        ]
        if fuera:
            lineas.append("\nRegistros fuera de rango mostrados en la zona de trabajo:")
            for registro, motivo in fuera[:120]:
                lineas.append(f"- {registro.precinto} | {motivo} | {registro.archivo}:{registro.linea}")
            if len(fuera) > 120:
                lineas.append(f"... y {len(fuera) - 120} mas")
        if pesos_no_validos:
            lineas.append("\nRegistros con peso no numerico o vacio:")
            for registro in pesos_no_validos[:80]:
                lineas.append(f"- {registro.precinto} | peso='{registro.peso}' | {registro.archivo}:{registro.linea}")
            if len(pesos_no_validos) > 80:
                lineas.append(f"... y {len(pesos_no_validos) - 80} mas")
        self._actualizar_resumen("\n".join(lineas))
        self._set_estado("Filtro de pesos aplicado. Modifica registros si procede y pulsa Revalidar.", importante=True)
        self.hay_cambios_sin_guardar = bool(fuera or pesos_no_validos)
        self.revalidacion_pendiente = bool(fuera or pesos_no_validos)
        self.texto.edit_modified(False)
        self._actualizar_botones()

    def _leer_registros_editor(self) -> tuple[list[RegistroJamones], list[str]]:
        registros_parseados: list[RegistroJamones] = []
        errores: list[str] = []
        orden_base = max((r.orden for r in self.registros_validos), default=0) + 100000
        for indice, linea in enumerate(self.texto.get("1.0", "end").splitlines(), start=1):
            texto = linea.strip()
            if not texto or texto.startswith("#"):
                continue
            registro = parsear_linea(texto, "CORRECCION_MANUAL", indice, orden_base + indice)
            if registro is None:
                continue
            registros_parseados.append(registro)

        partida_sugerida, lote_sugerido = sugerir_partida_lote(self.registros_validos + registros_parseados)
        if partida_sugerida:
            self.partida_sugerida = partida_sugerida
        if lote_sugerido:
            self.lote_sugerido = lote_sugerido

        registros: list[RegistroJamones] = []
        for registro in registros_parseados:
            motivos = validar_registro_completo(
                registro,
                self.tipo_var.get(),
                self.partida_sugerida,
                self.lote_sugerido,
            )
            if motivos:
                errores.append(f"Linea editor {registro.linea}: {'; '.join(motivos)} -> {registro.precinto or '(sin precinto)'}")
            else:
                registros.append(registro)
        return registros, errores

    def revalidar_editor(self):
        corregidos, errores = self._leer_registros_editor()
        if errores:
            self._actualizar_resumen("Siguen existiendo incidencias:\n" + "\n".join(errores[:80]))
            self._set_estado("Aún hay precintos o registros incorrectos. Revisa el resumen.", importante=True)
            self.revalidacion_pendiente = True
            self._actualizar_botones()
            try:
                self.texto.focus_set()
            except Exception:
                pass
            return
        combinados = self.registros_validos + corregidos
        self.registros_validos, _duplicados_por_correccion = deduplicar(combinados)
        # Los duplicados provocados por correcciones sustituyen al registro anterior,
        # pero no son duplicados reales del TXT original y no deben ensuciar el resumen.
        self.registros_invalidos = []
        self._mostrar_invalidos_en_editor()
        self._actualizar_resumen_desde_estado(total=len(self.registros_validos) + len(self.duplicados_eliminados))
        self.flujo_estado = "listo_guardar"
        self._set_estado("Revalidación correcta. Puedes guardar TXT o CSV.", importante=True)
        self.hay_cambios_sin_guardar = True
        self.revalidacion_pendiente = False
        self.texto.edit_modified(False)
        self._actualizar_botones()

    def _actualizar_resumen(self, texto: str):
        self.resumen.configure(state="normal")
        self.resumen.delete("1.0", "end")
        self.resumen.insert("1.0", texto)
        self.resumen.configure(state="disabled")

    def _texto_resumen_actual(self) -> str:
        return self.resumen.get("1.0", "end-1c").strip()

    def _validar_listo_para_salida(self, *, confirmar_diferencias: bool = True) -> bool:
        if self.revalidacion_pendiente:
            self._set_estado("Hay cambios pendientes en el area de trabajo. Revalida antes de guardar o enviar.", importante=True)
            messagebox.showwarning("Revalidacion obligatoria", "Antes de continuar debes revalidar el area de trabajo para comprobar que todo esta bien.", parent=self.ventana)
            return False
        if self.registros_invalidos:
            self._set_estado("Corrige y revalida los registros incorrectos antes de guardar o enviar.", importante=True)
            return False
        if not self.registros_validos:
            self._set_estado("No hay registros validos para guardar o enviar.", importante=True)
            return False
        if confirmar_diferencias and self.tipo_var.get().lower() == "iberico" and self.precintos_oficiales:
            leidos = {r.precinto for r in self.registros_validos if re.fullmatch(r"\d{12}", r.precinto)}
            diferencias = (leidos - self.precintos_oficiales) or (self.precintos_oficiales - leidos)
            if diferencias:
                return messagebox.askyesno(
                    "Diferencias con Excel oficial",
                    "El resumen indica diferencias entre los precintos leidos y el Excel oficial.\n\n"
                    "El listado oficial es informativo y puedes continuar igualmente.\n\n¿Quieres continuar?",
                    parent=self.ventana,
                )
        return True

    def _escribir_csv(self, salida: Path) -> Path | None:
        if self.tipo_var.get().lower() == "iberico":
            return self._guardar_csv_iberico_con_resumen(salida)
        with salida.open("w", encoding="utf-8-sig", newline="") as fichero:
            writer = csv.writer(fichero, delimiter=";", lineterminator="\r\n")
            for registro in self.registros_validos:
                campos = registro.campos[:CAMPOS_ESPERADOS]
                while len(campos) < CAMPOS_ESPERADOS:
                    campos.append("")
                writer.writerow(campos + [""])
        return None

    def _escribir_resumen_txt(self, salida: Path) -> None:
        with salida.open("w", encoding="utf-8", newline="") as fichero:
            fichero.write(self._texto_resumen_actual() + "\r\n")

    def _guardar_csv_iberico_con_resumen(self, salida: Path) -> Path:
        ruta_resumen = ruta_resumen_para_csv(salida)
        with salida.open("w", encoding="utf-8-sig", newline="") as fichero:
            writer = csv.writer(fichero, delimiter=";", lineterminator="\r\n")
            for registro in self.registros_validos:
                writer.writerow([registro.precinto])
        with ruta_resumen.open("w", encoding="utf-8", newline="") as fichero:
            fichero.write(self._texto_resumen_actual() + "\r\n")
        return ruta_resumen

    def _actualizar_resumen_desde_estado(self, total: int):
        lineas = [
            f"Tipo seleccionado: {self.tipo_var.get()}",
            f"Registros leidos/procesados: {total}",
            f"Registros validos conservados: {len(self.registros_validos)}",
            f"Incidencias pendientes: {len(self.registros_invalidos)}",
            f"Duplicados suprimidos: {len(self.duplicados_eliminados)}",
        ]
        if self.registros_invalidos:
            lineas.append("\nIncidencias detectadas en el TXT:")
            for reg, motivo in self.registros_invalidos[:120]:
                lineas.append(f"- {reg.precinto or '(sin precinto)'} | {motivo} | {reg.archivo}:{reg.linea}")
            if len(self.registros_invalidos) > 120:
                lineas.append(f"... y {len(self.registros_invalidos) - 120} mas")
        lineas.extend(self._resumen_comparacion_oficial())
        if self.duplicados_eliminados:
            lineas.append("\nDuplicados suprimidos:")
            for reg in self.duplicados_eliminados[:120]:
                lineas.append(f"- {reg.precinto} | {reg.fecha} {reg.hora} | {reg.archivo}:{reg.linea}")
            if len(self.duplicados_eliminados) > 120:
                lineas.append(f"... y {len(self.duplicados_eliminados) - 120} mas")
        self._actualizar_resumen("\n".join(lineas))

    def _pedir_destinatario_correo(self) -> str:
        ultimo = str(suite_obtener_preferencia(PREF_ULTIMO_CORREO_PRECINTOS, "") or "")
        destinatario = simpledialog.askstring(
            "Enviar correo",
            "Direccion de correo destinataria:",
            initialvalue=ultimo,
            parent=self.ventana,
        )
        return (destinatario or "").strip()

    def _plantilla_correo_actual(self) -> tuple[str, str]:
        asunto = str(suite_obtener_preferencia(PREF_ASUNTO_CORREO_PRECINTOS, ASUNTO_CORREO_DEFECTO) or ASUNTO_CORREO_DEFECTO)
        mensaje = str(suite_obtener_preferencia(PREF_MENSAJE_CORREO_PRECINTOS, MENSAJE_CORREO_DEFECTO) or MENSAJE_CORREO_DEFECTO)
        return asunto, mensaje

    def _guardar_plantilla_correo(self, asunto: str, mensaje: str) -> None:
        suite_establecer_preferencia(PREF_ASUNTO_CORREO_PRECINTOS, asunto.strip() or ASUNTO_CORREO_DEFECTO)
        suite_establecer_preferencia(PREF_MENSAJE_CORREO_PRECINTOS, mensaje.strip() or MENSAJE_CORREO_DEFECTO)

    def _valores_plantilla_correo(self) -> dict[str, str]:
        return {
            "tipo_jamon": self.tipo_var.get(),
            "registros_validos": str(len(self.registros_validos)),
            "incidencias": str(len(self.registros_invalidos)),
            "duplicados": str(len(self.duplicados_eliminados)),
        }

    def _renderizar_plantilla_correo(self, texto: str) -> str:
        try:
            return texto.format(**self._valores_plantilla_correo())
        except Exception:
            return texto

    def configurar_mensaje_correo(self):
        asunto_actual, mensaje_actual = self._plantilla_correo_actual()
        ventana = tk.Toplevel(self.ventana)
        ventana.title("Mensaje de correo")
        aplicar_icono_ventana(ventana)
        ventana.transient(self.ventana)
        ventana.grab_set()
        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(2, weight=1)
        try:
            ventana.geometry("720x460")
            ventana.minsize(560, 360)
        except Exception:
            pass

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=SUITE_PAD_PANEL)
        contenedor.grid(row=0, column=0, sticky="nsew")
        ventana.rowconfigure(0, weight=1)
        contenedor.columnconfigure(1, weight=1)
        contenedor.rowconfigure(3, weight=1)

        ttk.Label(contenedor, text="Destinatario, asunto y mensaje", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        ttk.Label(contenedor, text="Asunto", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=(0, 8))
        asunto_var = tk.StringVar(value=asunto_actual)
        ttk.Entry(contenedor, textvariable=asunto_var).grid(row=1, column=1, sticky="ew", pady=(0, 8))

        ttk.Label(contenedor, text="Mensaje", style="Card.TLabel").grid(row=2, column=0, sticky="nw", padx=(0, 10))
        texto = tk.Text(contenedor, wrap="word", undo=True, maxundo=-1, height=10)
        suite_aplicar_texto_tk(texto, mono=False)
        texto.grid(row=2, column=1, sticky="nsew")
        texto.insert("1.0", mensaje_actual)
        scroll = ttk.Scrollbar(contenedor, orient="vertical", command=texto.yview)
        scroll.grid(row=2, column=2, sticky="ns")
        texto.configure(yscrollcommand=scroll.set)

        ayuda = ttk.Label(
            contenedor,
            text="Variables disponibles: {tipo_jamon}, {registros_validos}, {incidencias}, {duplicados}",
            style="Card.TLabel",
        )
        ayuda.grid(row=3, column=1, sticky="w", pady=(8, 0))

        botones = ttk.Frame(contenedor, style="Card.TFrame")
        botones.grid(row=4, column=0, columnspan=3, sticky="e", pady=(14, 0))

        def restaurar():
            asunto_var.set(ASUNTO_CORREO_DEFECTO)
            texto.delete("1.0", "end")
            texto.insert("1.0", MENSAJE_CORREO_DEFECTO)

        def guardar_y_cerrar():
            self._guardar_plantilla_correo(asunto_var.get(), texto.get("1.0", "end-1c"))
            self._set_estado("Plantilla de correo guardada.", importante=False)
            ventana.destroy()

        ttk.Button(botones, text="Restaurar predeterminado", command=restaurar, style="Secondary.TButton").grid(row=0, column=0, padx=5)
        ttk.Button(botones, text="Guardar plantilla", command=guardar_y_cerrar, style="Primary.TButton").grid(row=0, column=1, padx=5)
        ttk.Button(botones, text="Cancelar", command=ventana.destroy, style="Secondary.TButton").grid(row=0, column=2, padx=(5, 0))
        try:
            texto.focus_set()
        except Exception:
            pass

    def _crear_adjuntos_correo(self, carpeta: Path) -> list[Path]:
        base = self.rutas[0].stem if self.rutas else "precintos_jamones"
        base = re.sub(r"[^A-Za-z0-9_.-]+", "_", base).strip("._") or "precintos_jamones"
        ruta_csv = carpeta / f"{base}_corregido.csv"
        ruta_resumen = carpeta / f"{base}_resumen.txt"
        resumen_generado = self._escribir_csv(ruta_csv)
        if resumen_generado is not None and resumen_generado != ruta_resumen:
            ruta_resumen.write_bytes(resumen_generado.read_bytes())
        else:
            self._escribir_resumen_txt(ruta_resumen)
        return [ruta_csv, ruta_resumen]

    def _enviar_adjuntos_correo(self, destinatario: str, adjuntos: list[Path]) -> None:
        asunto, cuerpo = self._plantilla_correo_actual()
        mensaje = EmailMessage()
        mensaje["From"] = SMTP_USUARIO
        mensaje["To"] = destinatario
        mensaje["Subject"] = self._renderizar_plantilla_correo(asunto)
        mensaje.set_content(self._renderizar_plantilla_correo(cuerpo))
        for ruta in adjuntos:
            maintype = "text"
            subtype = "csv" if ruta.suffix.lower() == ".csv" else "plain"
            mensaje.add_attachment(
                ruta.read_bytes(),
                maintype=maintype,
                subtype=subtype,
                filename=ruta.name,
            )
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as smtp:
            smtp.login(SMTP_USUARIO, SMTP_PASSWORD)
            smtp.send_message(mensaje)

    def enviar_correo(self):
        if not self._validar_listo_para_salida(confirmar_diferencias=True):
            return
        destinatario = self._pedir_destinatario_correo()
        if not destinatario:
            return
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", destinatario):
            messagebox.showwarning("Correo no valido", "Introduce una direccion de correo valida.", parent=self.ventana)
            return
        try:
            self._set_ocupado(True, "Enviando correo...")
            with tempfile.TemporaryDirectory(prefix="precintos_correo_") as temporal:
                adjuntos = self._crear_adjuntos_correo(Path(temporal))
                self._enviar_adjuntos_correo(destinatario, adjuntos)
            suite_establecer_preferencia(PREF_ULTIMO_CORREO_PRECINTOS, destinatario)
        except Exception as exc:
            self._set_ocupado(False)
            messagebox.showerror("Error al enviar correo", f"No se pudo enviar el correo:\n{exc}", parent=self.ventana)
            self._set_estado("No se pudo enviar el correo.", importante=True)
            return
        self._set_ocupado(False)
        self._set_estado(f"Correo enviado correctamente a {destinatario}.", importante=True)

    def guardar(self, formato: str):
        if self.revalidacion_pendiente:
            self._set_estado("Hay cambios pendientes en el area de trabajo. Revalida antes de guardar.", importante=True)
            messagebox.showwarning("Revalidacion obligatoria", "Antes de guardar debes revalidar el area de trabajo para comprobar que todo esta bien.", parent=self.ventana)
            return
        if self.registros_invalidos:
            self._set_estado("Corrige y revalida los registros incorrectos antes de guardar.", importante=True)
            return
        if not self.registros_validos:
            self._set_estado("No hay registros válidos para guardar.", importante=True)
            return
        if self.tipo_var.get().lower() == "iberico" and self.precintos_oficiales:
            leidos = {r.precinto for r in self.registros_validos if re.fullmatch(r"\d{12}", r.precinto)}
            diferencias = (leidos - self.precintos_oficiales) or (self.precintos_oficiales - leidos)
            if diferencias:
                if not messagebox.askyesno(
                    "Diferencias con Excel oficial",
                    "El resumen indica diferencias entre los precintos leidos y el Excel oficial.\n\n"
                    "El listado oficial es informativo y puedes guardar igualmente.\n\n¿Quieres guardar el resultado?",
                    parent=self.ventana,
                ):
                    return
        extension = ".csv" if formato == "csv" else ".txt"
        if formato == "txt" and self.rutas:
            nombre_propuesto = self.rutas[0].with_suffix(extension).name
        else:
            nombre_propuesto = f"precintos_jamones_corregido{extension}"
        ruta = filedialog.asksaveasfilename(
            parent=self.ventana,
            title=f"Guardar resultado {extension.upper()}",
            defaultextension=extension,
            filetypes=[(f"Fichero {extension.upper()}", f"*{extension}"), ("Todos los archivos", "*.*")],
            initialfile=nombre_propuesto,
            initialdir=suite_obtener_ultimo_directorio("precintos_guardar"),
        )
        if not ruta:
            return
        suite_recordar_directorio("precintos_guardar", ruta)
        salida = Path(ruta)
        self._set_ocupado(True, f"Guardando resultado {extension.upper()}...")
        try:
            if formato == "csv":
                resumen_guardado = None
                if self.tipo_var.get().lower() == "iberico":
                    resumen_guardado = self._guardar_csv_iberico_con_resumen(salida)
                else:
                    with salida.open("w", encoding="utf-8-sig", newline="") as fichero:
                        writer = csv.writer(fichero, delimiter=";", lineterminator="\r\n")
                        for registro in self.registros_validos:
                            campos = registro.campos[:CAMPOS_ESPERADOS]
                            while len(campos) < CAMPOS_ESPERADOS:
                                campos.append("")
                            writer.writerow(campos + [""])
            else:
                with salida.open("w", encoding="utf-8", newline="") as fichero:
                    for registro in self.registros_validos:
                        fichero.write(registro.a_linea().lstrip("\ufeff") + "\r\n")
        except Exception as exc:
            messagebox.showerror("Error al guardar", f"No se pudo guardar el archivo:\n{exc}", parent=self.ventana)
            return
        finally:
            self._set_ocupado(False)
        self.hay_cambios_sin_guardar = False
        self.revalidacion_pendiente = False
        self.flujo_estado = "guardado"
        if formato == "csv" and self.tipo_var.get().lower() == "iberico" and resumen_guardado is not None:
            self._set_estado(f"Guardado correctamente: {salida.name} y {resumen_guardado.name}", importante=True)
        else:
            self._set_estado(f"Guardado correctamente: {salida.name}", importante=True)
        self._actualizar_botones()

    def limpiar(self):
        if not self.confirmar_perdida_cambios("limpiar"):
            return
        self.rutas = []
        self.registros_validos = []
        self.registros_invalidos = []
        self.duplicados_eliminados = []
        self.partida_sugerida = ""
        self.lote_sugerido = ""
        self.ruta_excel_oficial = None
        self.precintos_oficiales = set()
        self.lbl_excel.config(text="Excel oficial: no cargado")
        self.lbl_archivos.config(text="Sin archivos cargados")
        self.peso_min_var.set("")
        self.peso_max_var.set("")
        self._set_error_pesos("")
        self._set_texto_inicial()
        self._actualizar_resumen("Esperando archivos.")
        self.flujo_estado = "sin_archivos"
        self._set_estado("Listo")
        self.hay_cambios_sin_guardar = False
        self.revalidacion_pendiente = False
        self._actualizar_botones()

    def salir(self):
        if not self.confirmar_perdida_cambios("salir"):
            return
        self.ventana.destroy()


def lanzar_app_control_precintos(parent=None):
    ventana = tk.Toplevel(parent) if parent is not None else tk.Tk()
    suite_preparar_ventana_sin_parpadeo(ventana)
    ControlPrecintosJamonesApp(ventana)
    suite_mostrar_ventana_sin_parpadeo(ventana, maximizar=True, enfocar=True, icono=True)
    return ventana


if __name__ == "__main__":
    root = tk.Tk()
    ControlPrecintosJamonesApp(root)
    root.mainloop()
