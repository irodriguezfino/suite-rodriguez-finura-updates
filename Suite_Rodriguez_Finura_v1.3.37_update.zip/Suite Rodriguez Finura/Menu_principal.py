import os
import sys
import importlib
import importlib.util
import tkinter as tk
from tkinter import messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_MENU_APPS as SUITE_PAD_MENU_APPS,
    PAD_MENU_INFO as SUITE_PAD_MENU_INFO,
    PAD_TARJETA_MENU as SUITE_PAD_TARJETA_MENU,
    alternar_modo_oscuro as suite_alternar_modo_oscuro,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_modo_compacto_ventana as suite_aplicar_modo_compacto_ventana,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    obtener_paleta as suite_obtener_paleta,
    obtener_preferencia as suite_obtener_preferencia,
    obtener_tema_actual as suite_obtener_tema_actual,
    establecer_preferencia as suite_establecer_preferencia,
    refrescar_tema_ventana as suite_refrescar_tema_ventana,
)


try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

def modulo_disponible(nombre_modulo):
    """Comprueba disponibilidad sin importar dependencias pesadas al arrancar."""
    try:
        return importlib.util.find_spec(nombre_modulo) is not None
    except Exception:
        return False


def cargar_atributo(nombre_modulo, nombre_atributo):
    """Importa una aplicacion bajo demanda y devuelve el atributo solicitado."""
    modulo = importlib.import_module(nombre_modulo)
    return getattr(modulo, nombre_atributo)


def ruta_recurso(nombre):
    """Devuelve la ruta correcta de los recursos en modo .py y en empaquetados PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def obtener_version_local():
    """Lee la version instalada sin romper el arranque si falta el JSON."""
    try:
        import json

        with open(ruta_recurso("version_local.json"), "r", encoding="utf-8-sig") as f:
            datos = json.load(f)
        return str(datos.get("version", "")).strip() or "desconocida"
    except Exception:
        return "desconocida"


def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class MenuPrincipal:
    def __init__(self, ventana):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Suite de Aplicaciones Rodriguez / Finura")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)
        self.ventanas_abiertas = {}
        self.tarjetas_app = []
        self.descripciones_app = []
        self.widgets_tarjetas_app = []
        self._after_estado_id = None

        self.logo_izq = None
        self.logo_der = None

        self.modo_compacto = False
        self._scroll_global_compacto_activo = False
        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()
        if bool(suite_obtener_preferencia("modo_compacto", False)):
            self.alternar_modo_compacto()
        self.actualizar_estado_aplicaciones_periodico()

    def configurar_estilos(self):
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(1, weight=1)

        self.cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera = self.cabecera
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(24, 12))
        cabecera.columnconfigure(0, weight=1)

        self.lbl_titulo = ttk.Label(
            cabecera,
            text="Suite de Aplicaciones",
            style="Title.TLabel",
            anchor="center",
        )
        self.lbl_titulo.grid(row=0, column=0, sticky="ew")

        self.lbl_subtitulo = ttk.Label(
            cabecera,
            text="Menu principal unificado para acceder a las herramientas de Rodriguez / Finura.",
            style="Subtitle.TLabel",
            anchor="center",
        )
        self.lbl_subtitulo.grid(row=1, column=0, sticky="ew", pady=(6, 0))
        self.linea_cabecera = ttk.Frame(cabecera, style="RedLine.TFrame", height=2)
        self.linea_cabecera.grid(row=2, column=0, sticky="ew", pady=(10, 0))

        self.contenedor = ttk.Frame(self.ventana, style="TFrame")
        contenedor = self.contenedor
        contenedor.grid(row=1, column=0, sticky="nsew", padx=28, pady=8)
        contenedor.columnconfigure(0, weight=1)
        contenedor.rowconfigure(1, weight=1)

        self.panel_info = ttk.Frame(contenedor, style="Card.TFrame", padding=SUITE_PAD_MENU_INFO)
        panel_info = self.panel_info
        panel_info.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        panel_info.columnconfigure(0, weight=1)
        panel_info.columnconfigure(1, weight=0)
        panel_info.columnconfigure(2, weight=0)

        ttk.Label(
            panel_info,
            text="Panel de control",
            style="CardTitle.TLabel",
        ).grid(row=0, column=0, sticky="w")
        self.lbl_dashboard = ttk.Label(
            panel_info,
            text="Accesos: Alt+1 Merma | Alt+2 TXT a CSV | Alt+3 Palets | Alt+4 Precintos | Alt+5 Precintos Excel | F5 estado",
            style="Muted.Card.TLabel",
        )
        self.lbl_dashboard.grid(row=1, column=0, sticky="w", pady=(4, 0))
        self.boton_compacto = ttk.Button(
            panel_info,
            text="Modo compacto",
            command=self.alternar_modo_compacto,
            style="Secondary.TButton",
        )
        self.boton_compacto.grid(row=0, column=1, rowspan=2, sticky="e", padx=(18, 0))
        self.boton_tema = ttk.Button(
            panel_info,
            text="Modo claro" if suite_obtener_tema_actual() == "oscuro" else "Modo oscuro",
            command=self.alternar_tema_visual,
            style="Secondary.TButton",
        )
        self.boton_tema.grid(row=0, column=2, rowspan=2, sticky="e", padx=(10, 0))

        self.panel_apps_area = ttk.Frame(contenedor, style="Card.TFrame")
        self.panel_apps_area.grid(row=1, column=0, sticky="nsew")
        self.panel_apps_area.columnconfigure(0, weight=1)
        self.panel_apps_area.rowconfigure(0, weight=1)

        self.canvas_apps = tk.Canvas(self.panel_apps_area, highlightthickness=0, bd=0, bg="#FFFFFF")
        self.canvas_apps.grid(row=0, column=0, sticky="nsew")
        self.scroll_apps = ttk.Scrollbar(self.panel_apps_area, orient="vertical", command=self.canvas_apps.yview)
        self.scroll_apps.grid(row=0, column=1, sticky="ns")
        self.canvas_apps.configure(yscrollcommand=self.scroll_apps.set)
        self.scroll_apps.grid_remove()

        self.panel_apps = ttk.Frame(self.canvas_apps, style="Card.TFrame", padding=SUITE_PAD_MENU_APPS)
        panel_apps = self.panel_apps
        self.panel_apps_window = self.canvas_apps.create_window((0, 0), window=panel_apps, anchor="nw")
        self.panel_apps.bind("<Configure>", self._actualizar_scroll_apps)
        self.canvas_apps.bind("<Configure>", self._ajustar_ancho_panel_apps)
        self.canvas_apps.bind("<MouseWheel>", self._scroll_apps_mousewheel)
        for col in range(3):
            panel_apps.columnconfigure(col, weight=1, uniform="apps")
        panel_apps.rowconfigure(0, weight=0)
        panel_apps.rowconfigure(1, weight=0)

        self.crear_tarjeta_app(
            panel_apps,
            fila=0,
            columna=0,
            titulo="Merma Jamones FAC",
            descripcion="Cruza CSV finales con fichero origen y genera el Excel de resultado.",
            descripcion_compacta="CSV origen a Excel.",
            texto_boton="Abrir Merma",
            comando=self.abrir_merma,
            disponible=modulo_disponible("programa_mermas"),
        )
        self.crear_tarjeta_app(
            panel_apps,
            fila=0,
            columna=1,
            titulo="Procesador TXT a CSV",
            descripcion="Carga TXT, normaliza decimales y guarda el CSV final.",
            descripcion_compacta="TXT normalizado a CSV.",
            texto_boton="Abrir TXT a CSV",
            comando=self.abrir_txt_csv,
            disponible=modulo_disponible("FusionarCSV_mejorado"),
        )
        self.crear_tarjeta_app(
            panel_apps,
            fila=0,
            columna=2,
            titulo="Palets PDA a CSV",
            descripcion="Valida codigos de pallet de PDA, permite correcciones y genera Stock01.csv.",
            descripcion_compacta="Valida palets y Stock01.csv.",
            texto_boton="Abrir Palets PDA",
            comando=self.abrir_palets,
            disponible=modulo_disponible("ProcesadorPaletsGUI"),
        )
        self.crear_tarjeta_app(
            panel_apps,
            fila=1,
            columna=0,
            titulo="Precintos Jamones",
            descripcion="Valida precintos, GTIN-12 para iberico, elimina duplicados y exporta TXT/CSV.",
            descripcion_compacta="Valida precintos y TXT/CSV.",
            texto_boton="Abrir Precintos",
            comando=self.abrir_precintos,
            disponible=modulo_disponible("ControlPrecintosJamonesGUI"),
        )

        self.crear_tarjeta_app(
            panel_apps,
            fila=1,
            columna=1,
            titulo="Precintos Excel a CSV",
            descripcion="Extrae la columna Identificacion de Excel y genera .csv.",
            descripcion_compacta="Identificaciones Excel a CSV.",
            texto_boton="Abrir Precintos Excel",
            comando=self.abrir_exportar_precintos,
            disponible=modulo_disponible("ExportarPrecintosExcelGUI"),
        )

        barra_estado = ttk.Frame(self.ventana, style="TFrame")
        barra_estado.grid(row=2, column=0, sticky="ew", padx=28, pady=(8, 10))
        barra_estado.columnconfigure(0, weight=1)

        self.etiqueta_estado = ttk.Label(
            barra_estado,
            text="Listo para abrir una aplicacion",
            style="Status.TLabel",
            anchor="center",
        )
        self.etiqueta_estado.grid(row=0, column=0, sticky="ew")

        self.footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer = self.footer
        footer.grid(row=3, column=0, sticky="ew", padx=28, pady=(0, 18))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)

        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")

        zona_central = ttk.Frame(footer, style="Footer.TFrame")
        zona_central.grid(row=0, column=1, sticky="ew")
        zona_central.columnconfigure(0, weight=1)

        ttk.Label(
            zona_central,
            text=SUITE_FOOTER_TEXTO,
            style="Muted.Card.TLabel",
            anchor="center",
        ).grid(row=0, column=0, sticky="ew")
        self.etiqueta_version = ttk.Label(
            zona_central,
            text=f"v{obtener_version_local()}",
            style="Version.Footer.TLabel",
            anchor="center",
        )
        self.etiqueta_version.grid(row=1, column=0, sticky="ew", pady=(3, 0))
        ttk.Button(
            zona_central,
            text="Salir",
            command=self.salir,
            style="Danger.TButton",
        ).grid(row=2, column=0, pady=(10, 0))

        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._sincronizar_canvas_tema()


    def alternar_tema_visual(self):
        """Alterna claro/oscuro desde el modulo comun de estilo."""
        nuevo = suite_alternar_modo_oscuro(self.ventana)
        suite_refrescar_tema_ventana(self.ventana)
        for _clave, (_titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    suite_refrescar_tema_ventana(ventana_app)
            except Exception:
                pass
        self.boton_tema.configure(text="Modo claro" if nuevo == "oscuro" else "Modo oscuro")
        self.etiqueta_estado.configure(text=f"Tema visual aplicado: {nuevo}")
        self._sincronizar_canvas_tema()

    def crear_tarjeta_app(self, padre, fila, columna, titulo, descripcion, texto_boton, comando, disponible=True, descripcion_compacta=None):
        tarjeta = ttk.Frame(padre, style="Card.TFrame", padding=(12, 8))
        tarjeta.grid(row=fila, column=columna, sticky="nsew", padx=8, pady=8)
        self.tarjetas_app.append(tarjeta)
        tarjeta.columnconfigure(0, weight=1)
        tarjeta.rowconfigure(1, weight=0)

        lbl_titulo = ttk.Label(tarjeta, text=titulo, style="CardTitle.TLabel", anchor="center")
        lbl_titulo.grid(row=0, column=0, sticky="ew", pady=(0, 4))
        lbl_desc = ttk.Label(
            tarjeta,
            text=descripcion,
            style="Card.TLabel",
            anchor="center",
            justify="center",
            wraplength=280,
        )
        lbl_desc.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        self.descripciones_app.append(lbl_desc)
        estado = "Disponible" if disponible else "No disponible"
        lbl_estado = ttk.Label(tarjeta, text=estado, style="Success.TLabel" if disponible else "Error.TLabel", anchor="center")
        lbl_estado.grid(row=2, column=0, sticky="ew", pady=(0, 6))
        boton = ttk.Button(tarjeta, text=texto_boton, command=comando, style="Primary.TButton")
        boton.grid(row=3, column=0, sticky="ew")
        if not disponible:
            boton.configure(state="disabled")
        self.widgets_tarjetas_app.append(
            {
                "tarjeta": tarjeta,
                "titulo": lbl_titulo,
                "descripcion": lbl_desc,
                "estado": lbl_estado,
                "boton": boton,
                "fila": fila,
                "columna": columna,
                "descripcion_completa": descripcion,
                "descripcion_compacta": descripcion_compacta or descripcion,
                "texto_boton": texto_boton,
            }
        )

    def _actualizar_scroll_apps(self, _event=None):
        try:
            self.canvas_apps.configure(scrollregion=self.canvas_apps.bbox("all"))
        except Exception:
            pass

    def _sincronizar_canvas_tema(self):
        try:
            paleta = suite_obtener_paleta()
            self.canvas_apps.configure(
                bg=paleta["tarjeta"],
                highlightbackground=paleta["borde"],
                highlightcolor=paleta["focus"],
            )
        except Exception:
            pass

    def _ajustar_ancho_panel_apps(self, event):
        try:
            ancho = min(event.width, 470) if self.modo_compacto else event.width
            self.canvas_apps.itemconfigure(self.panel_apps_window, width=ancho)
        except Exception:
            pass

    def _scroll_apps_mousewheel(self, event):
        if not self.modo_compacto:
            return "break"
        try:
            self.canvas_apps.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass
        return "break"

    def _activar_scroll_global_compacto(self):
        if self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.bind_all("<MouseWheel>", self._scroll_apps_mousewheel, add="+")
            self.ventana.bind_all("<Button-4>", lambda _event: self.canvas_apps.yview_scroll(-1, "units"), add="+")
            self.ventana.bind_all("<Button-5>", lambda _event: self.canvas_apps.yview_scroll(1, "units"), add="+")
            self._scroll_global_compacto_activo = True
        except Exception:
            pass

    def _desactivar_scroll_global_compacto(self):
        if not self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.unbind_all("<MouseWheel>")
            self.ventana.unbind_all("<Button-4>")
            self.ventana.unbind_all("<Button-5>")
        except Exception:
            pass
        self._scroll_global_compacto_activo = False

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            messagebox.showwarning(
                "Pillow no instalado",
                "No se pudieron cargar los logos porque falta la libreria Pillow.\nInstalala con: pip install pillow",
                parent=self.ventana)
            return

        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))

            img_izq.thumbnail((210, 80))
            img_der.thumbnail((200, 80))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            lbl_izq = tk.Label(self.logo_slot_izq, image=self.logo_izq)
            lbl_der = tk.Label(self.logo_slot_der, image=self.logo_der)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
            preparar_logo_minimizar(lbl_izq, self.ventana)
            preparar_logo_minimizar(lbl_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script.",
                parent=self.ventana)
        except Exception as e:
            messagebox.showwarning("Error al cargar logos", f"No se pudieron cargar los logos:\n{e}", parent=self.ventana)

    def configurar_accesibilidad(self):
        """Atajos de teclado y refresco manual sin tocar la logica de las aplicaciones."""
        self.ventana.bind("<Alt-Key-1>", lambda _event: self.abrir_merma())
        self.ventana.bind("<Alt-Key-2>", lambda _event: self.abrir_txt_csv())
        self.ventana.bind("<Alt-Key-3>", lambda _event: self.abrir_palets())
        self.ventana.bind("<Alt-Key-4>", lambda _event: self.abrir_precintos())
        self.ventana.bind("<Alt-Key-5>", lambda _event: self.abrir_exportar_precintos())
        self.ventana.bind("<F5>", lambda _event: self.actualizar_estado_aplicaciones())
        self.ventana.bind("<Escape>", lambda _event: self.salir())

    def alternar_modo_compacto(self):
        """Alterna entre menu completo y un menu compacto realmente usable.

        El modo compacto no toca la logica de procesamiento: solo cambia la
        distribucion visual del menu principal para ocupar menos pantalla.
        """
        self.modo_compacto = not self.modo_compacto
        if self.modo_compacto:
            suite_aplicar_modo_compacto_ventana(self.ventana, True)
            self.cabecera.grid_configure(padx=18, pady=(10, 6))
            self.lbl_subtitulo.grid_remove()
            self.linea_cabecera.grid_configure(pady=(6, 0))
            self.contenedor.grid_configure(padx=14, pady=4)
            self.contenedor.rowconfigure(1, weight=1)
            self.boton_compacto.config(text="Modo completo")
            self.lbl_dashboard.grid_remove()
            self.footer.grid_remove()
            self.scroll_apps.grid()
            self.panel_apps_area.columnconfigure(0, weight=0)
            self.canvas_apps.configure(width=470)
            self.canvas_apps.grid_configure(sticky="nsw")
            self.panel_apps.configure(padding=(8, 8))
            for i in range(3):
                self.panel_apps.columnconfigure(i, weight=0, uniform="")
            self.panel_apps.columnconfigure(0, weight=1, uniform="")
            for i, widgets in enumerate(self.widgets_tarjetas_app):
                tarjeta = widgets["tarjeta"]
                tarjeta.configure(width=442, height=54, padding=(7, 4))
                tarjeta.grid_propagate(False)
                tarjeta.grid_configure(row=i, column=0, sticky="w", padx=0, pady=(0, 4))
                tarjeta.columnconfigure(0, weight=0, minsize=154)
                tarjeta.columnconfigure(1, weight=0, minsize=186)
                tarjeta.columnconfigure(2, weight=0, minsize=84)
                tarjeta.columnconfigure(3, weight=0, minsize=0)
                tarjeta.rowconfigure(0, weight=1, minsize=42)
                for fila in range(4):
                    tarjeta.rowconfigure(fila, weight=0)
                widgets["titulo"].grid_configure(row=0, column=0, columnspan=1, sticky="w", pady=0, padx=(0, 8))
                widgets["titulo"].configure(anchor="w")
                widgets["descripcion"].grid_configure(row=0, column=1, columnspan=1, sticky="w", pady=0, padx=(0, 8))
                widgets["descripcion"].configure(text=widgets["descripcion_compacta"], anchor="w", justify="left", wraplength=186)
                widgets["estado"].grid_remove()
                widgets["boton"].configure(text="Abrir", width=8)
                widgets["boton"].grid_configure(row=0, column=2, rowspan=1, sticky="nsew", padx=0, pady=0)
            self._actualizar_scroll_apps()
            self._activar_scroll_global_compacto()
        else:
            self._desactivar_scroll_global_compacto()
            suite_aplicar_modo_compacto_ventana(self.ventana, False)
            self.cabecera.grid_configure(padx=28, pady=(24, 12))
            self.lbl_subtitulo.grid()
            self.linea_cabecera.grid_configure(pady=(10, 0))
            self.contenedor.grid_configure(padx=28, pady=8)
            self.contenedor.rowconfigure(1, weight=1)
            self.boton_compacto.config(text="Modo compacto")
            self.lbl_dashboard.config(text="Accesos: Alt+1 Merma | Alt+2 TXT a CSV | Alt+3 Palets | Alt+4 Precintos | Alt+5 Precintos Excel | F5 estado")
            self.lbl_dashboard.grid()
            self.footer.grid()
            self.scroll_apps.grid_remove()
            self.panel_apps_area.columnconfigure(0, weight=1)
            self.canvas_apps.configure(width=1)
            self.canvas_apps.grid_configure(sticky="nsew")
            self.panel_apps.configure(padding=SUITE_PAD_MENU_APPS)
            for i in range(3):
                self.panel_apps.columnconfigure(i, weight=1, uniform="apps")
            for widgets in self.widgets_tarjetas_app:
                tarjeta = widgets["tarjeta"]
                tarjeta.grid_propagate(True)
                tarjeta.configure(width=0, height=0, padding=(12, 8))
                tarjeta.grid_configure(row=widgets["fila"], column=widgets["columna"], sticky="nsew", padx=8, pady=8)
                tarjeta.columnconfigure(0, weight=1)
                for col in range(1, 4):
                    tarjeta.columnconfigure(col, weight=0, minsize=0)
                widgets["titulo"].grid_configure(row=0, column=0, columnspan=1, sticky="ew", pady=(0, 4))
                widgets["titulo"].configure(anchor="center")
                widgets["descripcion"].grid_configure(row=1, column=0, columnspan=1, sticky="ew", pady=(0, 6), padx=0)
                widgets["descripcion"].configure(text=widgets["descripcion_completa"], anchor="center", justify="center", wraplength=280)
                widgets["estado"].grid_configure(row=2, column=0, columnspan=1, sticky="ew", pady=(0, 6))
                widgets["estado"].configure(anchor="center")
                widgets["boton"].configure(text=widgets["texto_boton"], width=0)
                widgets["boton"].grid_configure(row=3, column=0, rowspan=1, sticky="ew", padx=0)
            self._actualizar_scroll_apps()
        suite_establecer_preferencia("modo_compacto", bool(self.modo_compacto))

    def salir(self):
        if self.ventanas_abiertas:
            if not messagebox.askyesno(
                "Salir de la suite",
                "Hay aplicaciones abiertas. Si sales del menu se cerrara la suite principal, pero las ventanas abiertas pueden perder el foco.\n\n¿Quieres salir?",
                parent=self.ventana,
            ):
                return
        if self._after_estado_id:
            try:
                self.ventana.after_cancel(self._after_estado_id)
            except Exception:
                pass
            self._after_estado_id = None
        self.ventana.destroy()

    def minimizar_menu_por_app(self):
        """Minimiza el menu principal para que no se superponga a una aplicacion abierta."""
        try:
            self.ventana.after(150, self.ventana.iconify)
        except Exception:
            pass

    def restaurar_menu_si_no_hay_apps(self):
        """Restaura el menu cuando todas las aplicaciones se han cerrado."""
        if self.ventanas_abiertas:
            return
        try:
            self.ventana.deiconify()
            self.ventana.lift()
            self.ventana.focus_force()
        except Exception:
            pass

    def traer_ventana_existente(self, clave):
        existente = self.ventanas_abiertas.get(clave)
        if not existente:
            return False
        _titulo, ventana_app = existente
        try:
            if ventana_app.winfo_exists():
                ventana_app.deiconify()
                ventana_app.lift()
                ventana_app.focus_force()
                self.ventana.lower(ventana_app)
                self.minimizar_menu_por_app()
                self.actualizar_estado_aplicaciones()
                return True
        except Exception:
            pass
        self.ventanas_abiertas.pop(clave, None)
        return False

    def registrar_ventana(self, clave, titulo, ventana_app):
        self.ventanas_abiertas[clave] = (titulo, ventana_app)
        ventana_app.protocol("WM_DELETE_WINDOW", lambda c=clave, v=ventana_app: self.cerrar_ventana_app(c, v))
        ventana_app.bind("<Destroy>", lambda event, c=clave: self._al_destruir_ventana(event, c), add="+")
        try:
            ventana_app.lift()
            ventana_app.focus_force()
            self.ventana.lower(ventana_app)
            self.minimizar_menu_por_app()
        except Exception:
            pass
        self.actualizar_estado_aplicaciones()

    def _al_destruir_ventana(self, event, clave):
        if event.widget is self.ventanas_abiertas.get(clave, (None, None))[1]:
            self.ventanas_abiertas.pop(clave, None)
            self.ventana.after(50, self.actualizar_estado_aplicaciones)
            self.ventana.after(80, self.restaurar_menu_si_no_hay_apps)

    def cerrar_ventana_app(self, clave, ventana_app):
        try:
            ventana_app.destroy()
        finally:
            self.ventanas_abiertas.pop(clave, None)
            self.actualizar_estado_aplicaciones()
            self.restaurar_menu_si_no_hay_apps()

    def actualizar_estado_aplicaciones_periodico(self):
        self.actualizar_estado_aplicaciones()
        try:
            self._after_estado_id = self.ventana.after(1500, self.actualizar_estado_aplicaciones_periodico)
        except Exception:
            self._after_estado_id = None
            pass

    def actualizar_estado_aplicaciones(self):
        abiertas = []
        for clave, (titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    abiertas.append(titulo)
                else:
                    self.ventanas_abiertas.pop(clave, None)
            except Exception:
                self.ventanas_abiertas.pop(clave, None)
        if abiertas:
            self.etiqueta_estado.config(text="Aplicaciones abiertas: " + " | ".join(abiertas))
        else:
            self.etiqueta_estado.config(text="Sin aplicaciones abiertas")

    def abrir_merma(self):
        if self.traer_ventana_existente("merma"):
            return
        try:
            lanzar_app_merma = cargar_atributo("programa_mermas", "lanzar_app_merma")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de merma:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_merma(self.ventana)
        self.registrar_ventana("merma", "Merma", ventana_app)

    def abrir_txt_csv(self):
        if self.traer_ventana_existente("txt_csv"):
            return
        try:
            lanzar_app_txt_csv = cargar_atributo("FusionarCSV_mejorado", "lanzar_app_txt_csv")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion TXT a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_txt_csv(self.ventana)
        self.registrar_ventana("txt_csv", "TXT a CSV", ventana_app)

    def abrir_palets(self):
        if self.traer_ventana_existente("palets"):
            return
        try:
            ProcesadorPaletsApp = cargar_atributo("ProcesadorPaletsGUI", "ProcesadorPaletsApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Palets PDA:\n{exc}", parent=self.ventana)
            return
        ventana_palets = tk.Toplevel(self.ventana)
        ProcesadorPaletsApp(ventana_palets)
        self.registrar_ventana("palets", "Palets PDA", ventana_palets)

    def abrir_precintos(self):
        if self.traer_ventana_existente("precintos"):
            return
        try:
            ControlPrecintosJamonesApp = cargar_atributo("ControlPrecintosJamonesGUI", "ControlPrecintosJamonesApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Jamones:\n{exc}", parent=self.ventana)
            return
        ventana_precintos = tk.Toplevel(self.ventana)
        ControlPrecintosJamonesApp(ventana_precintos)
        self.registrar_ventana("precintos", "Precintos Jamones", ventana_precintos)

    def abrir_exportar_precintos(self):
        if self.traer_ventana_existente("exportar_precintos"):
            return
        try:
            ExportarPrecintosExcelApp = cargar_atributo("ExportarPrecintosExcelGUI", "ExportarPrecintosExcelApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Excel a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_exportar = tk.Toplevel(self.ventana)
        ExportarPrecintosExcelApp(ventana_exportar)
        self.registrar_ventana("exportar_precintos", "Precintos Excel", ventana_exportar)


if __name__ == "__main__":
    root = tk.Tk()
    app = MenuPrincipal(root)
    root.mainloop()
