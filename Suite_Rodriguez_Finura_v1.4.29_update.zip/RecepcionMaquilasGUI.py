#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Recepcion Maquilas.

Genera informes PDF para recepciones de maquila a partir del TXT de FAC,
el Excel oficial SealsReport y el CSV interno de configuracion de articulos/rangos.
El modulo evita dependencias externas para mantener compatible el paquete
ligero de actualizacion de la suite.
"""

from __future__ import annotations

import csv
import os
import re
import sys
import unicodedata
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Iterable
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    FUENTE_BASE as SUITE_FUENTE_BASE,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_PANEL as SUITE_PAD_PANEL,
    PAD_PANEL_COMPACT as SUITE_PAD_PANEL_COMPACT,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_texto_tk as suite_aplicar_texto_tk,
    anunciar_estado as suite_anunciar_estado,
    configurar_boton_estado as suite_configurar_boton_estado,
    configurar_atajos_comunes as suite_configurar_atajos_comunes,
    configurar_orden_tabulacion as suite_configurar_orden_tabulacion,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    crear_panel_canvas as suite_crear_panel_canvas,
    mostrar_ventana_sin_parpadeo as suite_mostrar_ventana_sin_parpadeo,
    obtener_ultimo_directorio as suite_obtener_ultimo_directorio,
    obtener_paleta as suite_obtener_paleta,
    recordar_directorio as suite_recordar_directorio,
)

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None


A4_PORTRAIT = (595.0, 842.0)
CAMPOS_TXT = 7
CENT = Decimal("0.01")
CONFIG_ARTICULOS_INTERNO = "config_articulos.csv"


@dataclass
class RegistroMaquila:
    archivo: str
    linea: int
    partida: str
    fecha: str
    hora: str
    codigo_fac: str
    precinto: str
    lote: str
    peso: Decimal

    @property
    def fecha_hora(self) -> str:
        return " ".join(parte for parte in (self.fecha, self.hora) if parte).strip()


@dataclass
class RegistroOficial:
    albaran: str
    codigo_articulo: str
    nombre_producto: str
    lote: str
    precinto: str


@dataclass
class RangoArticulo:
    codigo_fac: str
    nombre_producto: str
    rango_original: str
    minimo: Decimal | None
    maximo_exclusivo: Decimal | None
    orden: int

    def contiene(self, peso: Decimal) -> bool:
        if self.minimo is not None and peso < self.minimo:
            return False
        if self.maximo_exclusivo is not None and peso >= self.maximo_exclusivo:
            return False
        return True


@dataclass
class FilaRango:
    lote: str
    lote_origen: str
    etiqueta_rango: str
    producto_corto: str
    piezas: int
    peso_total: Decimal
    peso_medio: Decimal
    codigo_fac: str
    producto_completo: str


def ruta_recurso(nombre: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / nombre  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent / nombre


def aplicar_icono_ventana(ventana):
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if ruta_ico.exists():
            ventana.iconbitmap(ruta_ico)
            return
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def normalizar_texto(valor: str) -> str:
    texto = unicodedata.normalize("NFKD", valor or "")
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", texto.strip().lower())


def normalizar_precinto(valor: str) -> str:
    return re.sub(r"\D+", "", valor or "")


def decimal_desde_texto(valor: str) -> Decimal:
    texto = (valor or "").strip().replace(".", "").replace(",", ".")
    if not texto:
        raise ValueError("peso vacio")
    try:
        return Decimal(texto)
    except InvalidOperation as exc:
        raise ValueError(f"peso no numerico: {valor}") from exc


def decimal_a_es(valor: Decimal, decimales: int = 2) -> str:
    q = Decimal("1").scaleb(-decimales)
    numero = valor.quantize(q, rounding=ROUND_HALF_UP)
    entero, _, decimal = f"{numero:f}".partition(".")
    grupos = []
    while entero:
        grupos.insert(0, entero[-3:])
        entero = entero[:-3]
    return ".".join(grupos or ["0"]) + ("," + decimal if decimales else "")


def leer_texto_lineas(ruta: Path) -> list[str]:
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return ruta.read_text(encoding=encoding).splitlines()
        except UnicodeDecodeError:
            continue
    return ruta.read_text(encoding="utf-8-sig", errors="replace").splitlines()


def leer_txt_maquila(ruta: Path) -> tuple[list[RegistroMaquila], list[str]]:
    registros: list[RegistroMaquila] = []
    incidencias: list[str] = []
    for numero, linea in enumerate(leer_texto_lineas(ruta), start=1):
        if not linea.strip():
            continue
        try:
            campos = next(csv.reader([linea], delimiter=";", quotechar='"'))
        except csv.Error:
            campos = linea.split(";")
        if campos and campos[-1] == "":
            campos = campos[:-1]
        if len(campos) < CAMPOS_TXT:
            incidencias.append(f"{ruta.name}:{numero} tiene {len(campos)} campos; se esperaban {CAMPOS_TXT}.")
            continue
        try:
            peso = decimal_desde_texto(campos[6])
        except ValueError as exc:
            incidencias.append(f"{ruta.name}:{numero} {exc}.")
            continue
        precinto = normalizar_precinto(campos[4])
        if not re.fullmatch(r"\d{12}", precinto):
            incidencias.append(f"{ruta.name}:{numero} precinto no valido: {campos[4]}.")
        registros.append(
            RegistroMaquila(
                archivo=ruta.name,
                linea=numero,
                partida=campos[0].strip(),
                fecha=campos[1].strip(),
                hora=campos[2].strip(),
                codigo_fac=campos[3].strip(),
                precinto=precinto,
                lote=campos[5].strip(),
                peso=peso,
            )
        )
    return registros, incidencias


def columna_excel_a_indice(referencia: str) -> int:
    letras = re.sub(r"[^A-Z]", "", referencia.upper())
    indice = 0
    for letra in letras:
        indice = indice * 26 + (ord(letra) - ord("A") + 1)
    return indice - 1


def leer_valor_celda_xlsx(celda, cadenas_compartidas: list[str]) -> str:
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    tipo = celda.attrib.get("t")
    if tipo == "inlineStr":
        return "".join(t.text or "" for t in celda.findall(".//a:t", ns)).strip()
    valor = celda.find("a:v", ns)
    if valor is None:
        return ""
    texto = valor.text or ""
    if tipo == "s" and texto.isdigit():
        idx = int(texto)
        if 0 <= idx < len(cadenas_compartidas):
            return cadenas_compartidas[idx].strip()
    return texto.strip()


def hojas_visibles_workbook(workbook_xml: bytes) -> list[tuple[str, str]]:
    ns = {
        "a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    }
    root = ET.fromstring(workbook_xml)
    hojas = []
    for sheet in root.findall(".//a:sheet", ns):
        if sheet.attrib.get("state") == "hidden":
            continue
        rid = sheet.attrib.get(f"{{{ns['r']}}}id", "")
        if rid:
            hojas.append((sheet.attrib.get("name", "Hoja"), rid))
    return hojas


def relaciones_workbook(rels_xml: bytes) -> dict[str, str]:
    ns = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}
    root = ET.fromstring(rels_xml)
    rels = {}
    for rel in root.findall("r:Relationship", ns):
        rid = rel.attrib.get("Id", "")
        target = rel.attrib.get("Target", "")
        if not rid or not target:
            continue
        limpio = target.lstrip("/")
        if limpio.startswith("xl/"):
            rels[rid] = limpio
        elif limpio.startswith("../"):
            rels[rid] = limpio.replace("../", "", 1)
        else:
            rels[rid] = "xl/" + limpio
    return rels


def leer_filas_xlsx(ruta: Path) -> list[dict[int, str]]:
    ns = {"a": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
    filas: list[dict[int, str]] = []
    with ZipFile(ruta) as zf:
        nombres = set(zf.namelist())
        if "xl/workbook.xml" not in nombres or "xl/_rels/workbook.xml.rels" not in nombres:
            raise ValueError("El Excel no contiene una estructura XLSX valida.")
        cadenas: list[str] = []
        if "xl/sharedStrings.xml" in nombres:
            root_ss = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in root_ss.findall("a:si", ns):
                cadenas.append("".join(t.text or "" for t in si.findall(".//a:t", ns)).strip())
        rels = relaciones_workbook(zf.read("xl/_rels/workbook.xml.rels"))
        for _nombre, rid in hojas_visibles_workbook(zf.read("xl/workbook.xml")):
            ruta_hoja = rels.get(rid)
            if not ruta_hoja or ruta_hoja not in nombres:
                continue
            root = ET.fromstring(zf.read(ruta_hoja))
            for fila in root.findall(".//a:row", ns):
                celdas = {}
                for celda in fila.findall("a:c", ns):
                    ref = celda.attrib.get("r", "")
                    if ref:
                        celdas[columna_excel_a_indice(ref)] = leer_valor_celda_xlsx(celda, cadenas)
                if celdas:
                    filas.append(celdas)
    return filas


def leer_seals_report(ruta: Path) -> list[RegistroOficial]:
    filas = leer_filas_xlsx(ruta)
    cabecera_idx = -1
    mapa: dict[str, int] = {}
    alias = {
        "albaran": "albaran",
        "codigo de articulo": "codigo_articulo",
        "nombre del producto": "nombre_producto",
        "numero de lote": "lote",
        "numero del precinto": "precinto",
    }
    for i, fila in enumerate(filas):
        encontrados = {}
        for col, valor in fila.items():
            clave = alias.get(normalizar_texto(valor))
            if clave:
                encontrados[clave] = col
        if {"albaran", "codigo_articulo", "nombre_producto", "lote", "precinto"}.issubset(encontrados):
            cabecera_idx = i
            mapa = encontrados
            break
    if cabecera_idx < 0:
        raise ValueError("No se encontraron las cabeceras esperadas en SealsReport.")
    registros: list[RegistroOficial] = []
    vistos: set[str] = set()
    for fila in filas[cabecera_idx + 1:]:
        precinto = normalizar_precinto(fila.get(mapa["precinto"], ""))
        if not precinto:
            continue
        if precinto in vistos:
            continue
        vistos.add(precinto)
        registros.append(
            RegistroOficial(
                albaran=fila.get(mapa["albaran"], "").strip(),
                codigo_articulo=fila.get(mapa["codigo_articulo"], "").strip(),
                nombre_producto=fila.get(mapa["nombre_producto"], "").strip(),
                lote=fila.get(mapa["lote"], "").strip(),
                precinto=precinto,
            )
        )
    return registros


def extraer_rango(nombre: str) -> tuple[Decimal | None, Decimal | None, str]:
    limpio = re.sub(r"\s+W\s*$", "", nombre.strip(), flags=re.IGNORECASE)
    patron_abierto = re.search(r"([<>+])\s*(\d+(?:[,.]\d+)?)\s*$", limpio)
    if patron_abierto:
        simbolo, numero = patron_abierto.groups()
        valor = decimal_desde_texto(numero)
        if simbolo == "<":
            return None, valor, patron_abierto.group(0).strip()
        return valor, None, patron_abierto.group(0).strip()
    patron_cerrado = re.search(r"(\d+(?:[,.]\d+)?)\s*-\s*(\d+(?:[,.]\d+)?)\s*$", limpio)
    if patron_cerrado:
        minimo = decimal_desde_texto(patron_cerrado.group(1))
        maximo = decimal_desde_texto(patron_cerrado.group(2))
        return minimo, maximo, patron_cerrado.group(0).strip()
    raise ValueError(f"No se pudo detectar rango de pesos en '{nombre}'.")


def leer_config_articulos(ruta: Path) -> tuple[dict[str, list[RangoArticulo]], list[str]]:
    rangos: dict[str, list[RangoArticulo]] = defaultdict(list)
    incidencias: list[str] = []
    lineas = leer_texto_lineas(ruta)
    reader = csv.reader(lineas, delimiter=";")
    for indice, fila in enumerate(reader, start=1):
        if indice == 1 and fila and normalizar_texto(fila[0]).startswith("codigo"):
            continue
        if len(fila) < 2 or not fila[0].strip() or not fila[1].strip():
            continue
        codigo = fila[0].strip()
        nombre = fila[1].strip()
        try:
            minimo, maximo, rango_original = extraer_rango(nombre)
        except ValueError as exc:
            incidencias.append(f"config_articulos.csv:{indice} {exc}")
            continue
        rangos[codigo].append(
            RangoArticulo(
                codigo_fac=codigo,
                nombre_producto=nombre,
                rango_original=rango_original,
                minimo=minimo,
                maximo_exclusivo=maximo,
                orden=indice,
            )
        )
    for lista in rangos.values():
        lista.sort(key=lambda r: (Decimal("-999") if r.minimo is None else r.minimo, r.orden))
    return dict(rangos), incidencias


def etiqueta_rango(rango: RangoArticulo) -> str:
    if rango.minimo is None and rango.maximo_exclusivo is not None:
        return f"< {decimal_a_es(rango.maximo_exclusivo - CENT, 2)} kg"
    if rango.maximo_exclusivo is None and rango.minimo is not None:
        return f">= {decimal_a_es(rango.minimo, 2)} kg"
    if rango.minimo is not None and rango.maximo_exclusivo is not None:
        return f"{decimal_a_es(rango.minimo, 2)} - {decimal_a_es(rango.maximo_exclusivo - CENT, 2)} kg"
    return "Sin rango"


def producto_corto(nombre: str) -> str:
    normal = normalizar_texto(nombre)
    for clave, etiqueta in (
        ("iberico", "IBERICO"),
        ("duroc", "DUROC"),
        ("serrano", "SERRANO"),
        ("paleta", "PALETA"),
        ("jamon", "JAMON"),
    ):
        if clave in normal:
            return etiqueta
    return nombre.split()[0].upper() if nombre.split() else ""


def agrupar_por_rangos(
    registros: list[RegistroMaquila],
    rangos_por_codigo: dict[str, list[RangoArticulo]],
    oficiales_por_precinto: dict[str, RegistroOficial],
) -> tuple[list[FilaRango], list[str]]:
    filas: list[FilaRango] = []
    incidencias: list[str] = []
    por_codigo = defaultdict(list)
    for registro in registros:
        por_codigo[registro.codigo_fac].append(registro)
    for codigo in sorted(por_codigo):
        rangos = rangos_por_codigo.get(codigo)
        if not rangos:
            incidencias.append(f"Sin configuracion de rangos para codigo FAC {codigo}.")
            continue
        usados: set[tuple[str, int]] = set()
        for rango in rangos:
            seleccion = [r for r in por_codigo[codigo] if rango.contiene(r.peso)]
            for r in seleccion:
                usados.add((r.precinto, r.linea))
            if not seleccion:
                continue
            por_lote = defaultdict(list)
            for registro in seleccion:
                oficial = oficiales_por_precinto.get(registro.precinto)
                lote_origen = oficial.lote if oficial is not None and oficial.lote else "Sin oficial"
                por_lote[(registro.lote or "-", lote_origen)].append(registro)
            for lote_txt, lote_origen in sorted(por_lote):
                seleccion_lote = por_lote[(lote_txt, lote_origen)]
                peso_total = sum((r.peso for r in seleccion_lote), Decimal("0"))
                piezas = len(seleccion_lote)
                filas.append(
                    FilaRango(
                        lote=lote_txt,
                        lote_origen=lote_origen,
                        etiqueta_rango=etiqueta_rango(rango),
                        producto_corto=producto_corto(rango.nombre_producto),
                        piezas=piezas,
                        peso_total=peso_total,
                        peso_medio=peso_total / Decimal(piezas),
                        codigo_fac=codigo,
                        producto_completo=rango.nombre_producto,
                    )
                )
        no_asignados = [r for r in por_codigo[codigo] if (r.precinto, r.linea) not in usados]
        if no_asignados:
            incidencias.append(f"{len(no_asignados)} piezas del codigo {codigo} no encajan en ningun rango configurado.")
    return filas, incidencias


def valor_mayoritario(valores: Iterable[str]) -> str:
    conteo = defaultdict(int)
    for valor in valores:
        if valor:
            conteo[valor] += 1
    if not conteo:
        return ""
    return sorted(conteo.items(), key=lambda item: (-item[1], item[0]))[0][0]


def resumir_valores(valores: Iterable[str], max_items: int = 3) -> str:
    unicos: list[str] = []
    vistos: set[str] = set()
    for valor in valores:
        limpio = str(valor or "").strip()
        if limpio and limpio not in vistos:
            vistos.add(limpio)
            unicos.append(limpio)
    if not unicos:
        return "-"
    if len(unicos) <= max_items:
        return ", ".join(unicos)
    return ", ".join(unicos[:max_items]) + f" (+{len(unicos) - max_items})"


def resumen_lotes_origen(registros_oficiales: list[RegistroOficial]) -> list[list[str]]:
    conteo: dict[str, int] = defaultdict(int)
    for registro in registros_oficiales:
        lote = registro.lote.strip() if registro.lote else "Sin lote"
        conteo[lote] += 1
    return [[lote, str(conteo[lote])] for lote in sorted(conteo)]


class PdfSimple:
    def __init__(self, titulo: str):
        self.titulo = titulo
        self.ancho, self.alto = A4_PORTRAIT
        self.paginas: list[list[str]] = []
        self.nueva_pagina()

    def nueva_pagina(self):
        self.paginas.append([])

    @property
    def contenido(self) -> list[str]:
        return self.paginas[-1]

    def y(self, y_top: float) -> float:
        return self.alto - y_top

    def texto(self, x: float, y_top: float, texto: str, size: int = 9, bold: bool = False):
        fuente = "F2" if bold else "F1"
        self.contenido.append(f"BT /{fuente} {size} Tf {x:.2f} {self.y(y_top):.2f} Td ({self._esc(texto)}) Tj ET")

    def linea(self, x1: float, y1_top: float, x2: float, y2_top: float, ancho: float = 0.6):
        self.contenido.append(f"{ancho:.2f} w {x1:.2f} {self.y(y1_top):.2f} m {x2:.2f} {self.y(y2_top):.2f} l S")

    def rect(self, x: float, y_top: float, w: float, h: float, fill: str | None = None, stroke: bool = True):
        op = "B" if fill and stroke else ("f" if fill else "S")
        if fill:
            self.contenido.append(fill)
        self.contenido.append(f"{x:.2f} {self.y(y_top + h):.2f} {w:.2f} {h:.2f} re {op}")
        if fill:
            self.contenido.append("0 0 0 rg")

    def wrap(self, texto: str, ancho: float, size: int) -> list[str]:
        max_chars = max(8, int(ancho / (size * 0.48)))
        palabras = str(texto or "").split()
        if not palabras:
            return [""]
        lineas: list[str] = []
        actual = ""
        for palabra in palabras:
            candidato = palabra if not actual else f"{actual} {palabra}"
            if len(candidato) <= max_chars:
                actual = candidato
            else:
                if actual:
                    lineas.append(actual)
                actual = palabra
        if actual:
            lineas.append(actual)
        return lineas

    def tabla(
        self,
        x: float,
        y_top: float,
        columnas: list[tuple[str, float, str]],
        filas: list[list[str]],
        *,
        size: int = 8,
        header_size: int = 8,
        margen_inferior: float = 44,
    ) -> float:
        y = y_top
        ancho_total = sum(col[1] for col in columnas)

        def cabecera(y_actual: float) -> float:
            self.rect(x, y_actual, ancho_total, 20, fill="0.82 0.82 0.82 rg")
            cx = x
            for titulo, ancho, align in columnas:
                self.texto(cx + 4, y_actual + 13, titulo, header_size, True)
                cx += ancho
            self.linea(x, y_actual + 20, x + ancho_total, y_actual + 20, 0.7)
            return y_actual + 20

        y = cabecera(y)
        if not filas:
            filas = [["Sin datos"] + [""] * (len(columnas) - 1)]
        for fila in filas:
            lineas_por_col = [self.wrap(fila[i] if i < len(fila) else "", columnas[i][1] - 8, size) for i in range(len(columnas))]
            alto = max(17, 8 + max(len(l) for l in lineas_por_col) * (size + 2))
            if y + alto > self.alto - margen_inferior:
                self.nueva_pagina()
                y = 34
                y = cabecera(y)
            cx = x
            for i, (_titulo, ancho, align) in enumerate(columnas):
                self.linea(cx, y, cx, y + alto, 0.3)
                texto_lineas = lineas_por_col[i]
                for j, linea in enumerate(texto_lineas):
                    tx = cx + 4
                    if align == "right":
                        tx = cx + ancho - 4 - min(len(linea) * size * 0.46, ancho - 8)
                    self.texto(tx, y + 12 + j * (size + 2), linea, size)
                cx += ancho
            self.linea(x + ancho_total, y, x + ancho_total, y + alto, 0.3)
            self.linea(x, y + alto, x + ancho_total, y + alto, 0.3)
            y += alto
        return y

    def guardar(self, ruta: Path):
        objetos: list[bytes] = []

        def add(contenido: bytes) -> int:
            objetos.append(contenido)
            return len(objetos)

        catalog_id = add(b"")
        pages_id = add(b"")
        font_id = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        bold_id = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        page_ids = []
        for pagina in self.paginas:
            stream = "\n".join(pagina).encode("cp1252", errors="replace")
            content_id = add(b"<< /Length " + str(len(stream)).encode("ascii") + b" >>\nstream\n" + stream + b"\nendstream")
            page = (
                f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 {self.ancho:.0f} {self.alto:.0f}] "
                f"/Resources << /Font << /F1 {font_id} 0 R /F2 {bold_id} 0 R >> >> "
                f"/Contents {content_id} 0 R >>"
            ).encode("ascii")
            page_ids.append(add(page))
        kids = " ".join(f"{pid} 0 R" for pid in page_ids)
        objetos[pages_id - 1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>".encode("ascii")
        objetos[catalog_id - 1] = f"<< /Type /Catalog /Pages {pages_id} 0 R >>".encode("ascii")
        salida = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = [0]
        for i, obj in enumerate(objetos, start=1):
            offsets.append(len(salida))
            salida.extend(f"{i} 0 obj\n".encode("ascii"))
            salida.extend(obj)
            salida.extend(b"\nendobj\n")
        xref = len(salida)
        salida.extend(f"xref\n0 {len(objetos) + 1}\n0000000000 65535 f \n".encode("ascii"))
        for offset in offsets[1:]:
            salida.extend(f"{offset:010d} 00000 n \n".encode("ascii"))
        salida.extend(
            f"trailer << /Size {len(objetos) + 1} /Root {catalog_id} 0 R >>\nstartxref\n{xref}\n%%EOF".encode("ascii")
        )
        ruta.write_bytes(bytes(salida))

    @staticmethod
    def _esc(texto: str) -> str:
        return str(texto or "").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def dibujar_cabecera(pdf: PdfSimple, titulo: str, subtitulo: str = ""):
    pdf.texto(28, 30, "EMBUTIDOS RODRIGUEZ", 8, True)
    pdf.texto(28, 48, titulo, 15, True)
    if subtitulo:
        pdf.texto(28, 64, subtitulo, 9)
    pdf.linea(28, 74, pdf.ancho - 28, 74, 1.0)
    pdf.texto(pdf.ancho - 150, 30, datetime.now().strftime("%d/%m/%Y %H:%M"), 8)


def generar_pdf_diferencias(
    ruta: Path,
    registros_txt: list[RegistroMaquila],
    registros_oficiales: list[RegistroOficial],
    incidencias: list[str],
):
    partida = valor_mayoritario(r.partida for r in registros_txt) or "-"
    oficiales_por_precinto = {r.precinto: r for r in registros_oficiales}
    txt_por_precinto = {r.precinto: r for r in registros_txt if r.precinto}
    solo_txt = [txt_por_precinto[p] for p in sorted(set(txt_por_precinto) - set(oficiales_por_precinto))]
    solo_oficial = [oficiales_por_precinto[p] for p in sorted(set(oficiales_por_precinto) - set(txt_por_precinto))]

    pdf = PdfSimple(f"Informe diferencias {partida}")
    dibujar_cabecera(pdf, f"Informe diferencias {partida}", "Comparacion TXT recibido frente a SealsReport oficial")
    peso_total = sum((r.peso for r in registros_txt), Decimal("0"))
    resumen = [
        ("Partida TXT", partida),
        ("Registros TXT", str(len(registros_txt))),
        ("Precintos oficiales", str(len(registros_oficiales))),
        ("Peso TXT", f"{decimal_a_es(peso_total, 2)} kg"),
        ("TXT no oficial", str(len(solo_txt))),
        ("Oficial no recibido", str(len(solo_oficial))),
    ]
    x = 28
    y = 92
    for etiqueta, valor in resumen:
        pdf.texto(x, y, etiqueta, 8, True)
        pdf.texto(x + 88, y, valor, 8)
        x += 240
        if x > 420:
            x = 28
            y += 16
    y += 28
    if incidencias:
        pdf.texto(28, y, "Incidencias de lectura", 10, True)
        y += 13
        for incidencia in incidencias[:6]:
            pdf.texto(34, y, f"- {incidencia}", 8)
            y += 11
        if len(incidencias) > 6:
            pdf.texto(34, y, f"- ... y {len(incidencias) - 6} incidencias mas", 8)
            y += 11
        y += 8

    pdf.texto(28, y, "Recibidos en TXT que no aparecen en SealsReport", 10, True)
    y += 8
    y = pdf.tabla(
        28,
        y,
        [("Precinto", 82, "left"), ("Cod. FAC", 55, "left"), ("Lote", 95, "left"), ("Peso", 55, "right"), ("Fecha/hora", 110, "left")],
        [[r.precinto, r.codigo_fac, r.lote, decimal_a_es(r.peso, 2), r.fecha_hora] for r in solo_txt],
    )
    y += 18
    if y > 680:
        pdf.nueva_pagina()
        dibujar_cabecera(pdf, f"Informe diferencias {partida}", "Continuacion")
        y = 92
    pdf.texto(28, y, "Oficiales en SealsReport que no aparecen en el TXT recibido", 10, True)
    y += 8
    pdf.tabla(
        28,
        y,
        [("Precinto", 78, "left"), ("Albaran", 58, "left"), ("Articulo oficial", 90, "left"), ("Lote oficial", 70, "left"), ("Producto", 240, "left")],
        [[r.precinto, r.albaran, r.codigo_articulo, r.lote, r.nombre_producto] for r in solo_oficial],
    )
    pdf.guardar(ruta)


def generar_pdf_rangos(
    ruta: Path,
    filas: list[FilaRango],
    registros_txt: list[RegistroMaquila],
    registros_oficiales: list[RegistroOficial],
    metadatos: dict[str, str],
    incidencias: list[str],
):
    partida = valor_mayoritario(r.partida for r in registros_txt) or "-"
    codigo = valor_mayoritario(r.codigo_fac for r in registros_txt)
    lote_txt = valor_mayoritario(r.lote for r in registros_txt)
    albaran = resumir_valores(r.albaran for r in registros_oficiales)
    lotes_origen = resumen_lotes_origen(registros_oficiales)
    peso_total = sum((fila.peso_total for fila in filas), Decimal("0"))
    piezas_total = sum(fila.piezas for fila in filas)
    medio = peso_total / Decimal(piezas_total) if piezas_total else Decimal("0")

    pdf = PdfSimple(f"Informe rangos {partida}")
    dibujar_cabecera(pdf, f"Recepcion Maquilas {partida}", "Clasificacion por rangos de peso")
    y = 92
    info = [
        ("Ganadero", metadatos.get("ganadero") or "EMBUTIDOS RODRIGUEZ"),
        ("Partida", partida),
        ("Albaran", albaran),
        ("Codigo FAC", codigo),
        ("Lote", lote_txt),
        ("Origen", metadatos.get("origen") or "Espana"),
        ("N DAC", metadatos.get("dac") or ""),
        ("Contrato", metadatos.get("contrato") or ""),
        ("Especificacion", metadatos.get("especificacion") or ""),
    ]
    for i, (etiqueta, valor) in enumerate(info):
        col = i % 2
        row = i // 2
        x = 28 + col * 270
        pdf.texto(x, y + row * 16, f"{etiqueta}: ", 8, True)
        pdf.texto(x + 82, y + row * 16, valor, 8)
    y += 78

    if lotes_origen:
        pdf.texto(28, y, "Lotes origen SealsReport", 9, True)
        y += 8
        y = pdf.tabla(
            28,
            y,
            [("Lote origen", 130, "left"), ("Piezas oficiales", 75, "right")],
            lotes_origen,
            size=8,
        )
        y += 14

    if incidencias:
        pdf.texto(28, y, "Avisos", 9, True)
        y += 12
        for incidencia in incidencias[:4]:
            pdf.texto(34, y, f"- {incidencia}", 8)
            y += 10
        y += 4

    filas_tabla = [
        [
            fila.lote,
            fila.lote_origen,
            fila.etiqueta_rango,
            fila.producto_corto,
            str(fila.piezas),
            decimal_a_es(fila.peso_total, 2),
            decimal_a_es(fila.peso_medio, 2),
        ]
        for fila in filas
    ]
    y = pdf.tabla(
        28,
        y,
        [("Lote", 80, "left"), ("Lote origen", 82, "left"), ("Rango", 92, "left"), ("", 44, "left"), ("Piezas", 45, "right"), ("Peso", 76, "right"), ("Peso medio", 76, "right")],
        filas_tabla,
        size=8,
    )
    if y + 28 > pdf.alto - 40:
        pdf.nueva_pagina()
        y = 40
    pdf.rect(28, y + 5, 495, 22, stroke=True)
    pdf.texto(150, y + 19, "Total", 8, True)
    pdf.texto(360, y + 19, str(piezas_total), 8, True)
    pdf.texto(434, y + 19, decimal_a_es(peso_total, 2), 8, True)
    pdf.texto(510, y + 19, decimal_a_es(medio, 2), 8, True)
    pdf.guardar(ruta)


class RecepcionMaquilasApp:
    def __init__(self, ventana: tk.Tk | tk.Toplevel):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Recepcion Maquilas")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)

        self.ruta_txt: Path | None = None
        self.ruta_excel: Path | None = None
        self.ruta_config: Path | None = ruta_recurso(CONFIG_ARTICULOS_INTERNO)
        self.registros_txt: list[RegistroMaquila] = []
        self.registros_oficiales: list[RegistroOficial] = []
        self.rangos_por_codigo: dict[str, list[RangoArticulo]] = {}
        self.incidencias: list[str] = []
        self._logo_rodriguez = None
        self._logo_finura = None

        self.estado_var = tk.StringVar(value="Selecciona TXT y SealsReport. La configuracion de rangos se carga internamente.")
        self.ganadero_var = tk.StringVar(value="EMBUTIDOS RODRIGUEZ")
        self.origen_var = tk.StringVar(value="Espana")
        self.dac_var = tk.StringVar()
        self.contrato_var = tk.StringVar()
        self.especificacion_var = tk.StringVar(value="Anexo 5,5 ER Rev 13 FES 01")

        self.configurar_estilos()
        self.crear_interfaz()
        self.cargar_configuracion_interna()
        self.cargar_logos()
        self.configurar_atajos()
        self._actualizar_botones()

    def configurar_estilos(self):
        self.style = suite_configurar_ttk(self.ventana)

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(3, weight=1)

        cabecera = ttk.Frame(self.ventana, style="TFrame")
        cabecera.grid(row=0, column=0, sticky="ew", padx=28, pady=(22, 10))
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(cabecera, text="Recepcion Maquilas", style="Title.TLabel", anchor="center").grid(row=0, column=0, sticky="ew")
        ttk.Label(cabecera, text="Compara recepcion FAC con SealsReport y genera informes PDF de diferencias y rangos.", style="Subtitle.TLabel", anchor="center").grid(row=1, column=0, sticky="ew", pady=(6, 0))
        ttk.Frame(cabecera, style="RedLine.TFrame", height=2).grid(row=2, column=0, sticky="ew", pady=(10, 0))

        panel_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        panel_canvas.grid(row=1, column=0, sticky="ew", padx=28, pady=(0, 10))
        panel = panel_canvas.body
        for col in range(4):
            panel.columnconfigure(col, weight=1 if col in (1, 3) else 0)
        self.boton_txt = ttk.Button(panel, text="Seleccionar TXT", command=self.seleccionar_txt, style="Next.TButton")
        self.boton_txt.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.lbl_txt = ttk.Label(panel, text="TXT: no seleccionado", style="Card.TLabel")
        self.lbl_txt.grid(row=0, column=1, sticky="ew", padx=(0, 14))
        self.boton_excel = ttk.Button(panel, text="Seleccionar SealsReport", command=self.seleccionar_excel, style="Secondary.TButton")
        self.boton_excel.grid(row=0, column=2, sticky="ew", padx=(0, 8))
        self.lbl_excel = ttk.Label(panel, text="Excel: no seleccionado", style="Card.TLabel")
        self.lbl_excel.grid(row=0, column=3, sticky="ew", padx=(0, 14))
        self.lbl_config = ttk.Label(panel, text="Configuracion interna: pendiente", style="Card.TLabel")
        self.lbl_config.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(10, 0))

        meta_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL_COMPACT)
        meta_canvas.grid(row=2, column=0, sticky="ew", padx=28, pady=(0, 10))
        meta = meta_canvas.body
        for col in range(6):
            meta.columnconfigure(col, weight=1 if col in (1, 3, 5) else 0)
        campos = [
            ("Ganadero", self.ganadero_var, 0, 0),
            ("Origen", self.origen_var, 0, 2),
            ("N DAC", self.dac_var, 0, 4),
            ("Contrato", self.contrato_var, 1, 0),
            ("Especificacion", self.especificacion_var, 1, 2),
        ]
        self.entries_meta = []
        for etiqueta, variable, fila, col in campos:
            ttk.Label(meta, text=etiqueta, style="Card.TLabel").grid(row=fila, column=col, sticky="e", padx=(0, 6), pady=4)
            entry = ttk.Entry(meta, textvariable=variable)
            entry.grid(row=fila, column=col + 1, sticky="ew", padx=(0, 12), pady=4)
            self.entries_meta.append(entry)

        cuerpo = ttk.Frame(self.ventana, style="TFrame")
        cuerpo.grid(row=3, column=0, sticky="nsew", padx=28, pady=(0, 10))
        cuerpo.columnconfigure(0, weight=1)
        cuerpo.rowconfigure(0, weight=1)
        resumen_canvas = suite_crear_panel_canvas(cuerpo, padding=SUITE_PAD_PANEL)
        resumen_canvas.grid(row=0, column=0, sticky="nsew")
        resumen_panel = resumen_canvas.body
        resumen_panel.columnconfigure(0, weight=1)
        resumen_panel.rowconfigure(1, weight=1)
        ttk.Label(resumen_panel, text="Vista previa", style="CardTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.resumen = tk.Text(resumen_panel, wrap="word", state="disabled", height=12)
        suite_aplicar_texto_tk(self.resumen, mono=False)
        self.resumen.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        scroll = ttk.Scrollbar(resumen_panel, orient="vertical", command=self.resumen.yview)
        scroll.grid(row=1, column=1, sticky="ns", pady=(10, 0))
        self.resumen.configure(yscrollcommand=scroll.set)

        acciones_canvas = suite_crear_panel_canvas(self.ventana, padding=SUITE_PAD_PANEL)
        acciones_canvas.grid(row=4, column=0, sticky="ew", padx=28, pady=(0, 10))
        acciones = acciones_canvas.body
        acciones.columnconfigure(0, weight=1)
        self.lbl_estado = ttk.Label(acciones, textvariable=self.estado_var, style="Card.TLabel")
        self.lbl_estado.grid(row=0, column=0, sticky="w")
        self.boton_diferencias = ttk.Button(acciones, text="PDF diferencias", command=self.generar_diferencias, style="Primary.TButton")
        self.boton_diferencias.grid(row=0, column=1, padx=5)
        self.boton_rangos = ttk.Button(acciones, text="PDF rangos", command=self.generar_rangos, style="Primary.TButton")
        self.boton_rangos.grid(row=0, column=2, padx=5)
        self.boton_ambos = ttk.Button(acciones, text="Generar ambos", command=self.generar_ambos, style="Next.TButton")
        self.boton_ambos.grid(row=0, column=3, padx=5)
        self.boton_limpiar = ttk.Button(acciones, text="Limpiar", command=self.limpiar, style="Secondary.TButton")
        self.boton_limpiar.grid(row=0, column=4, padx=5)
        self.boton_salir = ttk.Button(acciones, text="Salir", command=self.salir, style="Danger.TButton")
        self.boton_salir.grid(row=0, column=5, padx=(5, 0))

        suite_configurar_orden_tabulacion(
            self.boton_txt,
            self.boton_excel,
            *self.entries_meta,
            self.boton_diferencias,
            self.boton_rangos,
            self.boton_ambos,
            self.boton_limpiar,
            self.boton_salir,
        )

        footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer.grid(row=5, column=0, sticky="ew", padx=28, pady=(0, 16))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)
        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")
        ttk.Label(footer, text=SUITE_FOOTER_TEXTO, style="Author.TLabel", anchor="center").grid(row=0, column=1, sticky="ew")
        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._actualizar_resumen()

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            return
        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))
            img_izq.thumbnail((180, 62))
            img_der.thumbnail((180, 62))
            self._logo_finura = ImageTk.PhotoImage(img_izq)
            self._logo_rodriguez = ImageTk.PhotoImage(img_der)
            lbl_izq = tk.Label(self.logo_slot_izq, image=self._logo_finura)
            lbl_der = tk.Label(self.logo_slot_der, image=self._logo_rodriguez)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
        except Exception:
            pass

    def configurar_atajos(self):
        suite_configurar_atajos_comunes(self.ventana, abrir=self.seleccionar_txt, limpiar=self.limpiar, salir=self.salir)
        self.ventana.bind("<Control-g>", lambda _event: self.generar_ambos())
        self.ventana.bind("<Control-G>", lambda _event: self.generar_ambos())

    def _set_estado(self, texto: str, importante: bool = False):
        self.estado_var.set(texto)
        if importante:
            suite_anunciar_estado(self.lbl_estado, texto)

    def _actualizar_botones(self):
        hay_txt = bool(self.registros_txt)
        hay_excel = bool(self.registros_oficiales)
        hay_config = bool(self.rangos_por_codigo)
        suite_configurar_boton_estado(self.boton_diferencias, hay_txt and hay_excel)
        suite_configurar_boton_estado(self.boton_rangos, hay_txt and hay_excel and hay_config)
        suite_configurar_boton_estado(self.boton_ambos, hay_txt and hay_excel and hay_config)
        suite_configurar_boton_estado(self.boton_limpiar, bool(self.ruta_txt or self.ruta_excel))

    def _actualizar_resumen(self):
        lineas = []
        if self.registros_txt:
            peso_total = sum((r.peso for r in self.registros_txt), Decimal("0"))
            lineas.append(f"TXT: {len(self.registros_txt)} registros, {len(set(r.precinto for r in self.registros_txt))} precintos unicos.")
            lineas.append(f"Partida: {valor_mayoritario(r.partida for r in self.registros_txt)}")
            lineas.append(f"Codigo FAC: {valor_mayoritario(r.codigo_fac for r in self.registros_txt)}")
            lineas.append(f"Peso total: {decimal_a_es(peso_total, 2)} kg")
        else:
            lineas.append("TXT pendiente.")
        if self.registros_oficiales:
            lineas.append(f"SealsReport: {len(self.registros_oficiales)} precintos oficiales.")
            txt_set = set(r.precinto for r in self.registros_txt)
            oficial_set = set(r.precinto for r in self.registros_oficiales)
            if txt_set:
                lineas.append(f"Diferencias: {len(txt_set - oficial_set)} recibidos no oficiales, {len(oficial_set - txt_set)} oficiales no recibidos.")
        else:
            lineas.append("SealsReport pendiente.")
        if self.rangos_por_codigo:
            total_rangos = sum(len(v) for v in self.rangos_por_codigo.values())
            lineas.append(f"Configuracion interna: {total_rangos} rangos para {len(self.rangos_por_codigo)} codigos FAC.")
        else:
            lineas.append("Configuracion interna de rangos no cargada.")
        if self.incidencias:
            lineas.append("")
            lineas.append("Avisos:")
            lineas.extend(f"- {incidencia}" for incidencia in self.incidencias[:8])
            if len(self.incidencias) > 8:
                lineas.append(f"- ... y {len(self.incidencias) - 8} avisos mas.")
        self.resumen.configure(state="normal")
        self.resumen.delete("1.0", "end")
        self.resumen.insert("1.0", "\n".join(lineas))
        self.resumen.configure(state="disabled")

    def seleccionar_txt(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona TXT de recepcion FAC",
            filetypes=[("TXT", "*.txt"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("recepcion_maquilas_txt"),
            parent=self.ventana,
        )
        if not ruta:
            return
        try:
            registros, incidencias = leer_txt_maquila(Path(ruta))
        except Exception as exc:
            messagebox.showerror("TXT no valido", f"No se pudo leer el TXT:\n{exc}", parent=self.ventana)
            return
        if not registros:
            messagebox.showwarning("TXT sin registros", "No se encontraron registros validos en el TXT.", parent=self.ventana)
            return
        self.ruta_txt = Path(ruta)
        self.registros_txt = registros
        self.incidencias = [i for i in self.incidencias if not i.startswith(self.ruta_txt.name)] + incidencias
        self.lbl_txt.config(text=f"TXT: {self.ruta_txt.name} ({len(registros)} registros)")
        suite_recordar_directorio("recepcion_maquilas_txt", ruta)
        self._set_estado("TXT cargado correctamente.")
        self._actualizar_resumen()
        self._actualizar_botones()

    def seleccionar_excel(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona SealsReport oficial",
            filetypes=[("Excel", "*.xlsx"), ("Todos los archivos", "*.*")],
            initialdir=suite_obtener_ultimo_directorio("recepcion_maquilas_excel"),
            parent=self.ventana,
        )
        if not ruta:
            return
        try:
            oficiales = leer_seals_report(Path(ruta))
        except Exception as exc:
            messagebox.showerror("Excel no valido", f"No se pudo leer SealsReport:\n{exc}", parent=self.ventana)
            return
        if not oficiales:
            messagebox.showwarning("Excel sin precintos", "No se encontraron precintos oficiales en SealsReport.", parent=self.ventana)
            return
        self.ruta_excel = Path(ruta)
        self.registros_oficiales = oficiales
        self.lbl_excel.config(text=f"Excel: {self.ruta_excel.name} ({len(oficiales)} precintos)")
        suite_recordar_directorio("recepcion_maquilas_excel", ruta)
        self._set_estado("SealsReport cargado correctamente.")
        self._actualizar_resumen()
        self._actualizar_botones()

    def cargar_configuracion_interna(self):
        ruta = ruta_recurso(CONFIG_ARTICULOS_INTERNO)
        self.ruta_config = ruta
        if not ruta.exists():
            self.rangos_por_codigo = {}
            self.incidencias.append(f"No se encontro la configuracion interna {CONFIG_ARTICULOS_INTERNO}.")
            self.lbl_config.config(text=f"Configuracion interna: falta {CONFIG_ARTICULOS_INTERNO}")
            self._actualizar_resumen()
            return
        try:
            rangos, incidencias = leer_config_articulos(ruta)
        except Exception as exc:
            self.rangos_por_codigo = {}
            self.incidencias.append(f"No se pudo leer la configuracion interna: {exc}")
            self.lbl_config.config(text=f"Configuracion interna: error al leer {CONFIG_ARTICULOS_INTERNO}")
            self._actualizar_resumen()
            return
        if not rangos:
            self.rangos_por_codigo = {}
            self.incidencias.append("No se detectaron rangos en la configuracion interna.")
            self.lbl_config.config(text=f"Configuracion interna: sin rangos en {CONFIG_ARTICULOS_INTERNO}")
            self._actualizar_resumen()
            return
        self.rangos_por_codigo = rangos
        self.incidencias.extend(incidencias)
        total_rangos = sum(len(v) for v in rangos.values())
        self.lbl_config.config(text=f"Configuracion interna: {CONFIG_ARTICULOS_INTERNO} ({total_rangos} rangos)")
        self._actualizar_resumen()
        self._actualizar_botones()

    def _ruta_salida(self, nombre_defecto: str) -> Path | None:
        initialdir = str(self.ruta_txt.parent) if self.ruta_txt is not None else os.getcwd()
        ruta = filedialog.asksaveasfilename(
            title="Guardar PDF",
            defaultextension=".pdf",
            initialfile=nombre_defecto,
            initialdir=initialdir,
            filetypes=[("PDF", "*.pdf")],
            parent=self.ventana,
        )
        return Path(ruta) if ruta else None

    def generar_diferencias(self):
        if not self.registros_txt or not self.registros_oficiales:
            return
        partida = valor_mayoritario(r.partida for r in self.registros_txt) or "recepcion"
        ruta = self._ruta_salida(f"Informe diferencias {partida}.pdf")
        if not ruta:
            return
        try:
            generar_pdf_diferencias(ruta, self.registros_txt, self.registros_oficiales, self.incidencias)
        except Exception as exc:
            messagebox.showerror("Error al generar PDF", f"No se pudo generar el informe de diferencias:\n{exc}", parent=self.ventana)
            return
        self._set_estado(f"PDF de diferencias generado: {ruta.name}", importante=True)
        messagebox.showinfo("PDF generado", f"Informe generado correctamente:\n{ruta}", parent=self.ventana)

    def _metadatos(self) -> dict[str, str]:
        return {
            "ganadero": self.ganadero_var.get().strip(),
            "origen": self.origen_var.get().strip(),
            "dac": self.dac_var.get().strip(),
            "contrato": self.contrato_var.get().strip(),
            "especificacion": self.especificacion_var.get().strip(),
        }

    def generar_rangos(self):
        if not (self.registros_txt and self.registros_oficiales and self.rangos_por_codigo):
            return
        partida = valor_mayoritario(r.partida for r in self.registros_txt) or "recepcion"
        ruta = self._ruta_salida(f"Informe rangos {partida}.pdf")
        if not ruta:
            return
        try:
            oficiales_por_precinto = {r.precinto: r for r in self.registros_oficiales}
            filas, avisos = agrupar_por_rangos(self.registros_txt, self.rangos_por_codigo, oficiales_por_precinto)
            generar_pdf_rangos(ruta, filas, self.registros_txt, self.registros_oficiales, self._metadatos(), self.incidencias + avisos)
        except Exception as exc:
            messagebox.showerror("Error al generar PDF", f"No se pudo generar el informe de rangos:\n{exc}", parent=self.ventana)
            return
        self._set_estado(f"PDF de rangos generado: {ruta.name}", importante=True)
        messagebox.showinfo("PDF generado", f"Informe generado correctamente:\n{ruta}", parent=self.ventana)

    def generar_ambos(self):
        if not (self.registros_txt and self.registros_oficiales and self.rangos_por_codigo):
            return
        carpeta = filedialog.askdirectory(
            title="Selecciona carpeta de salida",
            initialdir=str(self.ruta_txt.parent) if self.ruta_txt else os.getcwd(),
            parent=self.ventana,
        )
        if not carpeta:
            return
        partida = valor_mayoritario(r.partida for r in self.registros_txt) or "recepcion"
        ruta_dif = Path(carpeta) / f"Informe diferencias {partida}.pdf"
        ruta_rangos = Path(carpeta) / f"Informe rangos {partida}.pdf"
        try:
            generar_pdf_diferencias(ruta_dif, self.registros_txt, self.registros_oficiales, self.incidencias)
            oficiales_por_precinto = {r.precinto: r for r in self.registros_oficiales}
            filas, avisos = agrupar_por_rangos(self.registros_txt, self.rangos_por_codigo, oficiales_por_precinto)
            generar_pdf_rangos(ruta_rangos, filas, self.registros_txt, self.registros_oficiales, self._metadatos(), self.incidencias + avisos)
        except Exception as exc:
            messagebox.showerror("Error al generar PDFs", f"No se pudieron generar los informes:\n{exc}", parent=self.ventana)
            return
        self._set_estado(f"Informes generados en {carpeta}", importante=True)
        messagebox.showinfo("PDFs generados", f"Informes generados correctamente:\n{ruta_dif}\n{ruta_rangos}", parent=self.ventana)

    def limpiar(self):
        self.ruta_txt = None
        self.ruta_excel = None
        self.registros_txt = []
        self.registros_oficiales = []
        self.incidencias = []
        self.lbl_txt.config(text="TXT: no seleccionado")
        self.lbl_excel.config(text="Excel: no seleccionado")
        self._set_estado("Seleccion limpia.")
        self._actualizar_resumen()
        self._actualizar_botones()

    def salir(self):
        self.ventana.destroy()


def lanzar_app_recepcion_maquilas(ventana_padre=None):
    ventana = tk.Toplevel(ventana_padre) if ventana_padre is not None else tk.Tk()
    RecepcionMaquilasApp(ventana)
    return ventana


if __name__ == "__main__":
    root = tk.Tk()
    app = RecepcionMaquilasApp(root)
    suite_mostrar_ventana_sin_parpadeo(root, maximizar=True, enfocar=True, icono=True)
    root.mainloop()
