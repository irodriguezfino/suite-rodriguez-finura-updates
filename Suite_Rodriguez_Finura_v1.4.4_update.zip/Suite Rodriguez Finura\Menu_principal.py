import os
import sys
import json
import ctypes
import importlib
import importlib.util
import platform
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from estilo_suite import (
    FOOTER_TEXTO as SUITE_FOOTER_TEXTO,
    PAD_FOOTER as SUITE_PAD_FOOTER,
    PAD_MENU_APPS as SUITE_PAD_MENU_APPS,
    PAD_MENU_INFO as SUITE_PAD_MENU_INFO,
    PAD_TARJETA_MENU as SUITE_PAD_TARJETA_MENU,
    alternar_modo_oscuro as suite_alternar_modo_oscuro,
    aplicar_logo_label as suite_aplicar_logo_label,
    aplicar_modo_compacto_ventana as suite_aplicar_modo_compacto_ventana,
    configurar_ttk as suite_configurar_ttk,
    configurar_ventana_base as suite_configurar_ventana_base,
    obtener_paleta as suite_obtener_paleta,
    obtener_preferencia as suite_obtener_preferencia,
    obtener_tema_actual as suite_obtener_tema_actual,
    establecer_preferencia as suite_establecer_preferencia,
    refrescar_tema_ventana as suite_refrescar_tema_ventana,
)


try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

def modulo_disponible(nombre_modulo):
    """Comprueba disponibilidad sin importar dependencias pesadas al arrancar."""
    try:
        return importlib.util.find_spec(nombre_modulo) is not None
    except Exception:
        return False


def cargar_atributo(nombre_modulo, nombre_atributo):
    """Importa una aplicacion bajo demanda y devuelve el atributo solicitado."""
    modulo = importlib.import_module(nombre_modulo)
    return getattr(modulo, nombre_atributo)


def ruta_recurso(nombre):
    """Devuelve la ruta correcta de los recursos en modo .py y en empaquetados PyInstaller."""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, nombre)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), nombre)


def obtener_version_local():
    """Lee la version instalada sin romper el arranque si falta el JSON."""
    try:
        import json

        with open(ruta_recurso("version_local.json"), "r", encoding="utf-8-sig") as f:
            datos = json.load(f)
        return str(datos.get("version", "")).strip() or "desconocida"
    except Exception:
        return "desconocida"


def carpeta_logs():
    base = os.environ.get("LOCALAPPDATA") or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, "Suite Rodriguez Finura", "logs")


def leer_json_seguro(ruta):
    try:
        with open(ruta, "r", encoding="utf-8-sig") as f:
            datos = json.load(f)
        return datos if isinstance(datos, dict) else {}
    except Exception:
        return {}


def leer_estado_actualizador():
    return leer_json_seguro(os.path.join(carpeta_logs(), "update_status.json"))


def cola_archivo(ruta, lineas=40):
    try:
        with open(ruta, "r", encoding="utf-8-sig", errors="replace") as f:
            contenido = f.readlines()
        return "".join(contenido[-lineas:]).strip()
    except Exception:
        return ""


def aplicar_icono_ventana(ventana):
    """Aplica ICONO_SUITE como icono de ventana y barra de tareas cuando sea posible."""
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("EmbutidosRodriguez.SuiteFinura")
    except Exception:
        pass
    try:
        ruta_ico = ruta_recurso("ICONO_SUITE.ico")
        if os.path.exists(ruta_ico):
            ventana.iconbitmap(ruta_ico)
    except Exception:
        pass
    try:
        if Image is not None and ImageTk is not None:
            icono = ImageTk.PhotoImage(Image.open(ruta_recurso("ICONO_SUITE.png")))
            ventana._icono_suite = icono
            ventana.iconphoto(True, icono)
    except Exception:
        pass


def minimizar_ventana(ventana):
    """Minimiza la ventana asociada a un logo clicado."""
    try:
        ventana.iconify()
    except Exception:
        pass


def preparar_logo_minimizar(widget, ventana):
    """Mantiene los logos como marca decorativa, sin accion oculta."""
    try:
        widget.configure(cursor="", takefocus=False)
    except Exception:
        pass


class MenuPrincipal:
    def __init__(self, ventana):
        self.ventana = ventana
        suite_configurar_ventana_base(self.ventana, "Suite de Aplicaciones Rodriguez / Finura")
        aplicar_icono_ventana(self.ventana)
        self.ventana.protocol("WM_DELETE_WINDOW", self.salir)
        self.ventanas_abiertas = {}
        self.widgets_apps = {}
        self.botones_categoria = {}
        self._after_estado_id = None

        self.logo_izq = None
        self.logo_der = None

        self.modo_compacto = False
        self._scroll_global_compacto_activo = False
        self._vista_previa_compacto = None
        self._categoria_previa_compacto = None
        self.configurar_estilos()
        self.busqueda_var = tk.StringVar(value="")
        self.categoria_actual = "Todas"
        self.vista_actual = "tarjetas"
        self.apps_catalogo = self.crear_catalogo_apps()
        self.aplicar_favoritos_usuario()
        self.crear_interfaz()
        self.cargar_logos()
        self.configurar_accesibilidad()
        if bool(suite_obtener_preferencia("modo_compacto", False)):
            self.alternar_modo_compacto()
        self.actualizar_estado_aplicaciones_periodico()

    def configurar_estilos(self):
        """Aplica exclusivamente el estilo comun de la suite.

        No toca la logica de procesado: solo centraliza colores, fuentes,
        botones, etiquetas, tarjetas y estados visuales.
        """
        self.style = suite_configurar_ttk(self.ventana)
        paleta = suite_obtener_paleta()
        self.style.configure("TFrame", background=paleta["fondo"])
        self.style.configure("Card.TFrame", background=paleta["tarjeta"], relief="solid", borderwidth=1)
        self.style.configure("Shell.TFrame", background=paleta["fondo"])
        self.style.configure("Header.TFrame", background=paleta["tarjeta"], relief="solid", borderwidth=1)
        self.style.configure("Sidebar.TFrame", background=paleta["estado"], relief="solid", borderwidth=1)
        self.style.configure("SidebarInner.TFrame", background=paleta["estado"])
        self.style.configure("Content.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure("SoftCard.TFrame", background=paleta["tarjeta"], relief="solid", borderwidth=1)
        self.style.configure("SoftRow.TFrame", background=paleta["tarjeta"], relief="solid", borderwidth=1)
        self.style.configure("Footer.TFrame", background=paleta["tarjeta"], relief="flat", borderwidth=0)
        self.style.configure(
            "HeroTitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["principal"],
            font=("Arial", 17, "bold"),
        )
        self.style.configure(
            "HeroSubtitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["muted"],
            font=("Arial", 10, "normal"),
        )
        self.style.configure(
            "BrandBadge.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Arial", 13, "bold"),
            padding=(10, 9),
        )
        self.style.configure(
            "SectionTitle.TLabel",
            background=paleta["tarjeta"],
            foreground=paleta["texto"],
            font=("Arial", 12, "bold"),
        )
        self.style.configure(
            "SidebarTitle.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Arial", 10, "bold"),
        )
        self.style.configure(
            "Chip.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Arial", 9, "bold"),
            padding=(10, 4),
        )
        self.style.configure(
            "SuccessChip.TLabel",
            background=paleta["estado"],
            foreground=paleta["principal"],
            font=("Arial", 9, "bold"),
            padding=(10, 4),
        )
        self.style.configure(
            "Category.TFrame",
            background=paleta["estado"],
            relief="flat",
            borderwidth=0,
        )
        self.style.configure(
            "Category.Active.TFrame",
            background=paleta["principal"],
            relief="flat",
            borderwidth=0,
        )
        self.style.configure(
            "Category.TLabel",
            background=paleta["estado"],
            foreground=paleta["texto"],
            font=("Arial", 10, "normal"),
        )
        self.style.configure(
            "Category.Active.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Arial", 10, "bold"),
        )
        self.style.configure(
            "Category.Count.TLabel",
            background=paleta["estado"],
            foreground=paleta["muted"],
            font=("Arial", 9, "normal"),
        )
        self.style.configure(
            "Category.Count.Active.TLabel",
            background=paleta["principal"],
            foreground=paleta["principal_fg"],
            font=("Arial", 9, "bold"),
        )
        self.style.configure(
            "Favorite.TButton",
            font=("Arial", 10, "bold"),
            padding=(3, 2),
            foreground=paleta["rodriguez"],
            background=paleta["boton_sec"],
            bordercolor=paleta["boton_sec_border"],
        )
        self.style.map(
            "Favorite.TButton",
            foreground=[("active", paleta["rodriguez"]), ("!disabled", paleta["rodriguez"])],
            background=[("active", paleta["boton_sec_active"]), ("pressed", paleta["boton_sec_active"])],
        )
        self.style.configure(
            "Compact.Primary.TButton",
            font=("Arial", 9, "bold"),
            padding=(3, 2),
            foreground=paleta["principal_fg"],
            background=paleta["principal"],
            bordercolor=paleta["principal"],
        )
        self.style.map(
            "Compact.Primary.TButton",
            background=[("active", paleta["principal_hover"]), ("pressed", paleta["principal_hover"])],
            foreground=[("!disabled", paleta["principal_fg"]), ("disabled", paleta["disabled_fg"])],
        )
        self.style.configure(
            "Compact.Secondary.TButton",
            font=("Arial", 9, "bold"),
            padding=(2, 2),
            foreground=paleta["rodriguez"],
            background=paleta["boton_sec"],
            bordercolor=paleta["boton_sec_border"],
        )

    def crear_catalogo_apps(self):
        return [
            {
                "clave": "merma",
                "titulo": "Merma Jamones FAC",
                "descripcion": "Cruza CSV finales con fichero origen y genera el Excel de resultado.",
                "descripcion_compacta": "CSV origen a Excel.",
                "categoria": "Jamones",
                "etiquetas": "merma jamones fac csv origen excel",
                "iniciales": "MJ",
                "atajo": "Alt+1",
                "favorita": True,
                "comando": self.abrir_merma,
                "disponible": lambda: modulo_disponible("programa_mermas"),
            },
            {
                "clave": "txt_csv",
                "titulo": "Procesador TXT a CSV",
                "descripcion": "Carga TXT, normaliza decimales y guarda el CSV final.",
                "descripcion_compacta": "TXT normalizado a CSV.",
                "categoria": "Excel / CSV",
                "etiquetas": "txt csv texto normalizar decimales conversion",
                "iniciales": "TC",
                "atajo": "Alt+2",
                "favorita": False,
                "comando": self.abrir_txt_csv,
                "disponible": lambda: modulo_disponible("FusionarCSV_mejorado"),
            },
            {
                "clave": "palets",
                "titulo": "Palets PDA a CSV",
                "descripcion": "Valida codigos de pallet de PDA, permite correcciones y genera Stock01.csv.",
                "descripcion_compacta": "Valida palets y Stock01.csv.",
                "categoria": "Palets y PDA",
                "etiquetas": "palets pallet pda stock01 csv validacion correcciones",
                "iniciales": "PA",
                "atajo": "Alt+3",
                "favorita": True,
                "comando": self.abrir_palets,
                "disponible": lambda: modulo_disponible("ProcesadorPaletsGUI"),
            },
            {
                "clave": "precintos",
                "titulo": "Precintos Jamones",
                "descripcion": "Valida precintos, GTIN-12 para iberico, duplicados, oficial y correo.",
                "descripcion_compacta": "Valida precintos y TXT/CSV.",
                "categoria": "Jamones",
                "etiquetas": "precintos jamones iberico gtin oficial duplicados correo txt csv",
                "iniciales": "PJ",
                "atajo": "Alt+4",
                "favorita": True,
                "comando": self.abrir_precintos,
                "disponible": lambda: modulo_disponible("ControlPrecintosJamonesGUI"),
            },
            {
                "clave": "exportar_precintos",
                "titulo": "Precintos Excel a CSV",
                "descripcion": "Extrae la columna Identificacion de Excel y genera .csv.",
                "descripcion_compacta": "Identificaciones Excel a CSV.",
                "categoria": "Excel / CSV",
                "etiquetas": "precintos excel identificacion trazabilidad csv anexos",
                "iniciales": "EC",
                "atajo": "Alt+5",
                "favorita": True,
                "comando": self.abrir_exportar_precintos,
                "disponible": lambda: modulo_disponible("ExportarPrecintosExcelGUI"),
            },
        ]

    def favoritos_por_defecto(self):
        return [app["clave"] for app in self.apps_catalogo if app.get("favorita")]

    def aplicar_favoritos_usuario(self):
        favoritos = suite_obtener_preferencia("favoritos_menu", None)
        if not isinstance(favoritos, list):
            favoritos = self.favoritos_por_defecto()
        favoritos = set(str(clave) for clave in favoritos)
        for app in self.apps_catalogo:
            app["favorita"] = app["clave"] in favoritos

    def guardar_favoritos_usuario(self):
        favoritos = [app["clave"] for app in self.apps_catalogo if app.get("favorita")]
        suite_establecer_preferencia("favoritos_menu", favoritos)

    def recientes_usuario(self):
        recientes = suite_obtener_preferencia("recientes_menu", [])
        return recientes if isinstance(recientes, list) else []

    def registrar_uso_app(self, clave):
        recientes = [item for item in self.recientes_usuario() if item != clave]
        recientes.insert(0, clave)
        suite_establecer_preferencia("recientes_menu", recientes[:6])

    def apps_destacadas(self):
        destacadas = []
        claves = set()
        for app in self.apps_catalogo:
            if app.get("favorita"):
                destacadas.append(app)
                claves.add(app["clave"])
        por_clave = {app["clave"]: app for app in self.apps_catalogo}
        for clave in self.recientes_usuario():
            app = por_clave.get(str(clave))
            if app is not None and app["clave"] not in claves:
                destacadas.append(app)
                claves.add(app["clave"])
        return destacadas

    def alternar_favorito(self, app):
        app["favorita"] = not bool(app.get("favorita"))
        self.guardar_favoritos_usuario()
        if self.categoria_actual == "Favoritas" and not app["favorita"]:
            restantes = self.apps_por_categoria("Favoritas")
            if not restantes:
                self.categoria_actual = "Todas"
        self.renderizar_categorias()
        self.renderizar_menu()

    def crear_interfaz(self):
        self.ventana.columnconfigure(0, weight=1)
        self.ventana.rowconfigure(1, weight=1)

        self.cabecera = ttk.Frame(self.ventana, style="Header.TFrame", padding=(18, 14))
        cabecera = self.cabecera
        cabecera.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 0))
        cabecera.columnconfigure(1, weight=1)

        self.badge_sr = ttk.Label(
            cabecera,
            text="SR",
            style="BrandBadge.TLabel",
            anchor="center",
        )
        self.badge_sr.grid(row=0, column=0, rowspan=2, sticky="nsw", padx=(0, 12))

        self.lbl_titulo = ttk.Label(
            cabecera,
            text="Suite de Aplicaciones",
            style="HeroTitle.TLabel",
            anchor="w",
        )
        self.lbl_titulo.grid(row=0, column=1, sticky="ew")

        self.lbl_subtitulo = ttk.Label(
            cabecera,
            text="Menu principal unificado para Rodriguez / Finura",
            style="HeroSubtitle.TLabel",
            anchor="w",
        )
        self.lbl_subtitulo.grid(row=1, column=1, sticky="ew", pady=(3, 0))
        self.linea_cabecera = ttk.Frame(cabecera, style="RedLine.TFrame", height=2)
        self.linea_cabecera.grid(row=2, column=0, columnspan=7, sticky="ew", pady=(14, 0))

        self.boton_compacto = ttk.Button(
            cabecera,
            text="Compacto",
            command=self.alternar_modo_compacto,
            style="Secondary.TButton",
        )
        self.boton_compacto.grid(row=0, column=2, rowspan=2, sticky="e", padx=(16, 0))
        self.boton_tema = ttk.Button(
            cabecera,
            text="Modo claro" if suite_obtener_tema_actual() == "oscuro" else "Modo oscuro",
            command=self.alternar_tema_visual,
            style="Secondary.TButton",
        )
        self.boton_tema.grid(row=0, column=3, rowspan=2, sticky="e", padx=(8, 0))
        self.boton_actualizar_header = ttk.Button(
            cabecera,
            text="Buscar actualizacion",
            command=lambda: self.buscar_actualizacion_manual(self.boton_actualizar_header),
            style="Secondary.TButton",
        )
        self.boton_actualizar_header.grid(row=0, column=4, rowspan=2, sticky="e", padx=(8, 0))
        self.boton_acerca = ttk.Button(
            cabecera,
            text="Acerca de",
            command=self.abrir_acerca_version,
            style="Secondary.TButton",
        )
        self.boton_acerca.grid(row=0, column=5, rowspan=2, sticky="e", padx=(8, 0))
        self.boton_salir_header = ttk.Button(
            cabecera,
            text="Salir",
            command=self.salir,
            style="Primary.TButton",
        )
        self.boton_salir_header.grid(row=0, column=6, rowspan=2, sticky="e", padx=(8, 0))

        self.contenedor = ttk.Frame(self.ventana, style="Shell.TFrame")
        contenedor = self.contenedor
        contenedor.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 8))
        contenedor.columnconfigure(0, weight=0, minsize=250)
        contenedor.columnconfigure(1, weight=1)
        contenedor.rowconfigure(0, weight=1)

        self.sidebar = ttk.Frame(contenedor, style="Sidebar.TFrame", padding=(14, 14))
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
        self.sidebar.columnconfigure(0, weight=1)

        ttk.Label(self.sidebar, text="Categorias", style="SidebarTitle.TLabel").grid(row=0, column=0, sticky="w")
        self.panel_categorias = ttk.Frame(self.sidebar, style="SidebarInner.TFrame")
        self.panel_categorias.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        self.panel_categorias.columnconfigure(0, weight=1)

        self.sidebar.rowconfigure(2, weight=1)
        self.lbl_version_sidebar = ttk.Label(
            self.sidebar,
            text=f"v{obtener_version_local()} instalada",
            style="Chip.TLabel",
            anchor="center",
        )
        self.lbl_version_sidebar.grid(row=3, column=0, sticky="ew", pady=(12, 8))

        self.panel_apps_area = ttk.Frame(contenedor, style="Content.TFrame")
        self.panel_apps_area.grid(row=0, column=1, sticky="nsew")
        self.panel_apps_area.columnconfigure(0, weight=1)
        self.panel_apps_area.rowconfigure(1, weight=1)

        toolbar = ttk.Frame(self.panel_apps_area, style="Content.TFrame", padding=(0, 18, 0, 10))
        toolbar.grid(row=0, column=0, sticky="ew")
        toolbar.columnconfigure(0, weight=1)
        self.entry_busqueda = ttk.Entry(toolbar, textvariable=self.busqueda_var)
        self.entry_busqueda.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.entry_busqueda.insert(0, "")
        self.entry_busqueda.configure(font=("Arial", 12))
        self.boton_limpiar_busqueda = ttk.Button(
            toolbar,
            text="Limpiar",
            command=self.limpiar_busqueda,
            style="Secondary.TButton",
        )
        self.boton_limpiar_busqueda.grid(row=0, column=1, sticky="e", padx=(0, 10))
        self.lbl_resultados = ttk.Label(toolbar, text="", style="Chip.TLabel", anchor="center")
        self.lbl_resultados.grid(row=0, column=2, sticky="e")

        self.canvas_apps = tk.Canvas(self.panel_apps_area, highlightthickness=0, bd=0, bg="#FFFFFF")
        self.canvas_apps.grid(row=1, column=0, sticky="nsew")
        self.scroll_apps = ttk.Scrollbar(self.panel_apps_area, orient="vertical", command=self.canvas_apps.yview)
        self.scroll_apps.grid(row=1, column=1, sticky="ns")
        self.canvas_apps.configure(yscrollcommand=self.scroll_apps.set)

        self.panel_apps = ttk.Frame(self.canvas_apps, style="Card.TFrame", padding=(16, 14))
        panel_apps = self.panel_apps
        self.panel_apps_window = self.canvas_apps.create_window((0, 0), window=panel_apps, anchor="nw")
        self.panel_apps.bind("<Configure>", self._actualizar_scroll_apps)
        self.canvas_apps.bind("<Configure>", self._ajustar_ancho_panel_apps)
        self.canvas_apps.bind("<MouseWheel>", self._scroll_apps_mousewheel)
        self.canvas_apps.bind("<Button-4>", self._scroll_apps_mousewheel)
        self.canvas_apps.bind("<Button-5>", self._scroll_apps_mousewheel)
        self.busqueda_var.trace_add("write", lambda *_args: self.renderizar_menu())

        self.barra_estado = ttk.Frame(self.ventana, style="TFrame")
        self.etiqueta_estado = ttk.Label(
            self.barra_estado,
            text="Listo para abrir una aplicacion",
            style="Status.TLabel",
            anchor="center",
        )

        self.footer = ttk.Frame(self.ventana, style="Footer.TFrame", padding=SUITE_PAD_FOOTER)
        footer = self.footer
        footer.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
        footer.columnconfigure(0, weight=1)
        footer.columnconfigure(1, weight=1)
        footer.columnconfigure(2, weight=1)

        self.logo_slot_izq = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_izq.grid(row=0, column=0, sticky="w")

        self.logo_slot_der = ttk.Frame(footer, style="Footer.TFrame")
        self.logo_slot_der.grid(row=0, column=2, sticky="e")
        self._sincronizar_canvas_tema()
        self.renderizar_categorias()
        self.renderizar_menu()


    def alternar_tema_visual(self):
        """Alterna claro/oscuro desde el modulo comun de estilo."""
        nuevo = suite_alternar_modo_oscuro(self.ventana)
        suite_refrescar_tema_ventana(self.ventana)
        self.configurar_estilos()
        for _clave, (_titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    suite_refrescar_tema_ventana(ventana_app)
            except Exception:
                pass
        self.boton_tema.configure(text="Modo claro" if nuevo == "oscuro" else "Modo oscuro")
        self.etiqueta_estado.configure(text=f"Tema visual aplicado: {nuevo}")
        self._sincronizar_canvas_tema()
        self.renderizar_categorias()
        self.renderizar_menu()

    def categorias_disponibles(self):
        categorias = ["Todas", "Favoritas"]
        for app in self.apps_catalogo:
            if app["categoria"] not in categorias:
                categorias.append(app["categoria"])
        return categorias

    def apps_por_categoria(self, categoria):
        if categoria == "Todas":
            return list(self.apps_catalogo)
        if categoria == "Favoritas":
            return [app for app in self.apps_catalogo if app.get("favorita")]
        return [app for app in self.apps_catalogo if app["categoria"] == categoria]

    def app_disponible(self, app):
        try:
            return bool(app["disponible"]())
        except Exception:
            return False

    def app_abierta(self, app):
        return app["clave"] in self.ventanas_abiertas

    def texto_estado_app(self, app):
        if self.app_abierta(app):
            return "Abierta"
        return "Disponible" if self.app_disponible(app) else "No disponible"

    def estilo_estado_app(self, app):
        if self.app_abierta(app) or self.app_disponible(app):
            return "Success.TLabel"
        return "Error.TLabel"

    def ejecutar_app(self, app):
        self.registrar_uso_app(app["clave"])
        app["comando"]()
        self.renderizar_menu()

    def filtrar_apps(self):
        texto = self.busqueda_var.get().strip().lower()
        apps = self.apps_por_categoria(self.categoria_actual)
        if not texto:
            return apps
        filtradas = []
        for app in apps:
            bloque = " ".join(
                [
                    app["titulo"],
                    app["descripcion"],
                    app["categoria"],
                    app.get("etiquetas", ""),
                ]
            ).lower()
            if texto in bloque:
                filtradas.append(app)
        return filtradas

    def ordenar_apps_compacto(self, apps):
        return sorted(apps, key=lambda app: (not bool(app.get("favorita")), app["titulo"].lower()))

    def renderizar_categorias(self):
        for widget in self.panel_categorias.winfo_children():
            widget.destroy()
        self.botones_categoria = {}
        for fila, categoria in enumerate(self.categorias_disponibles()):
            total = len(self.apps_por_categoria(categoria))
            activa = categoria == self.categoria_actual
            fila_cat = ttk.Frame(
                self.panel_categorias,
                style="Category.Active.TFrame" if activa else "Category.TFrame",
                padding=(10, 9),
            )
            fila_cat.grid(row=fila, column=0, sticky="ew", pady=(0, 7))
            fila_cat.columnconfigure(1, weight=1)
            estilo_texto = "Category.Active.TLabel" if activa else "Category.TLabel"
            estilo_contador = "Category.Count.Active.TLabel" if activa else "Category.Count.TLabel"
            lbl_indice = ttk.Label(
                fila_cat,
                text=f"{fila + 1:02d}",
                style=estilo_texto,
                anchor="w",
            )
            lbl_indice.grid(row=0, column=0, sticky="w", padx=(0, 12))
            lbl_nombre = ttk.Label(
                fila_cat,
                text=categoria,
                style=estilo_texto,
                anchor="w",
            )
            lbl_nombre.grid(row=0, column=1, sticky="ew")
            lbl_total = ttk.Label(
                fila_cat,
                text=str(total),
                style=estilo_contador,
                anchor="e",
            )
            lbl_total.grid(row=0, column=2, sticky="e", padx=(10, 0))
            for widget in (fila_cat, lbl_indice, lbl_nombre, lbl_total):
                widget.bind("<Button-1>", lambda _event, c=categoria: self.seleccionar_categoria(c))
            self.botones_categoria[categoria] = fila_cat

    def seleccionar_categoria(self, categoria):
        self.categoria_actual = categoria
        self.renderizar_categorias()
        self.renderizar_menu()

    def cambiar_vista(self, vista):
        self.vista_actual = vista
        self.renderizar_menu()

    def aplicar_vista_temporal(self, vista):
        self.vista_actual = vista
        self.renderizar_menu()

    def limpiar_busqueda(self):
        self.busqueda_var.set("")
        self.entry_busqueda.focus_set()

    def limpiar_panel_apps(self):
        for widget in self.panel_apps.winfo_children():
            widget.destroy()
        self.widgets_apps = {}
        for columna in range(4):
            self.panel_apps.columnconfigure(columna, weight=0, uniform="")

    def renderizar_menu(self):
        if not hasattr(self, "panel_apps"):
            return
        self.limpiar_panel_apps()
        apps = self.filtrar_apps()
        self.lbl_resultados.configure(text=f"{len(apps)} accesos")
        if self.modo_compacto:
            apps = self.ordenar_apps_compacto(apps)
            titulo = "Accesos compactos"
            if self.busqueda_var.get().strip():
                titulo = "Resultados"
            self.crear_bloque_apps(0, titulo, apps, vista="compacta", limitar_columnas=False)
            self._actualizar_scroll_apps()
            self.vincular_scroll_widgets(self.panel_apps)
            return
        fila = 0
        if self.categoria_actual == "Todas" and not self.busqueda_var.get().strip():
            destacadas = self.apps_destacadas()
            claves_destacadas = {app["clave"] for app in destacadas}
            if destacadas:
                fila = self.crear_bloque_apps(
                    fila,
                    "Favoritas y recientes",
                    destacadas,
                    vista="tarjetas",
                    limitar_columnas=True,
                )
            restantes = [app for app in apps if app["clave"] not in claves_destacadas]
            self.crear_bloque_apps(fila, "Todas las aplicaciones", restantes, vista="lista", limitar_columnas=False)
            self._actualizar_scroll_apps()
            self.vincular_scroll_widgets(self.panel_apps)
            return
        titulo = "Todas las aplicaciones" if self.categoria_actual == "Todas" else self.categoria_actual
        if self.busqueda_var.get().strip():
            titulo = "Resultados de busqueda"
        vista = "lista" if self.busqueda_var.get().strip() else "tarjetas"
        self.crear_bloque_apps(fila, titulo, apps, vista=vista, limitar_columnas=False)
        self._actualizar_scroll_apps()
        self.vincular_scroll_widgets(self.panel_apps)

    def crear_bloque_apps(self, fila_inicio, titulo, apps, vista, limitar_columnas=False):
        cabecera = ttk.Frame(self.panel_apps, style="Content.TFrame")
        cabecera.grid(row=fila_inicio, column=0, columnspan=3, sticky="ew", pady=(0, 10))
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(
            cabecera,
            text=titulo,
            style="SectionTitle.TLabel",
            anchor="w",
        ).grid(row=0, column=0, sticky="ew")
        ttk.Label(
            cabecera,
            text=f"{len(apps)} resultados" if apps else "0 resultados",
            style="Chip.TLabel",
            anchor="center",
        ).grid(row=0, column=1, sticky="e")
        fila = fila_inicio + 1
        if not apps:
            ttk.Label(
                self.panel_apps,
                text="No hay aplicaciones que coincidan con el filtro actual.",
                style="Muted.Card.TLabel",
                anchor="w",
            ).grid(row=fila, column=0, sticky="ew", pady=(0, 14))
            return fila + 1
        if vista == "lista":
            for app in apps:
                self.crear_fila_app(self.panel_apps, fila, app)
                fila += 1
            return fila + 1
        if vista == "compacta":
            for app in apps:
                self.crear_fila_compacta(self.panel_apps, fila, app)
                fila += 1
            return fila + 1
        columnas = 3 if limitar_columnas else 3
        for col in range(columnas):
            self.panel_apps.columnconfigure(col, weight=1, uniform="apps")
        for indice, app in enumerate(apps):
            self.crear_tarjeta_app(self.panel_apps, fila + indice // columnas, indice % columnas, app)
        return fila + ((len(apps) + columnas - 1) // columnas) + 1

    def crear_icono_app(self, padre, app):
        icono = ttk.Frame(padre, style="Card.TFrame")
        icono.columnconfigure(0, weight=1)
        caja = tk.Label(
            icono,
            text=app["iniciales"],
            font=("Arial", 11, "bold"),
            width=3,
            height=1,
            bd=1,
            relief="flat",
        )
        paleta = suite_obtener_paleta()
        caja.configure(
            bg=paleta["estado"],
            fg=paleta["principal"],
            highlightthickness=1,
            highlightbackground="#BFDBFE",
        )
        caja.grid(row=0, column=0, sticky="nsew")
        return icono

    def crear_tarjeta_app(self, padre, fila, columna, app):
        tarjeta = ttk.Frame(padre, style="SoftCard.TFrame", padding=(13, 12))
        tarjeta.grid(row=fila, column=columna, sticky="nsew", padx=7, pady=7)
        tarjeta.columnconfigure(0, weight=1)

        cabecera = ttk.Frame(tarjeta, style="Card.TFrame")
        cabecera.grid(row=0, column=0, sticky="ew")
        cabecera.columnconfigure(0, weight=1)
        ttk.Label(cabecera, text=app["titulo"], style="CardTitle.TLabel", anchor="w").grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Button(
            cabecera,
            text="\u2605" if app.get("favorita") else "\u2606",
            command=lambda a=app: self.alternar_favorito(a),
            style="Favorite.TButton",
            width=3,
        ).grid(row=0, column=1, sticky="ne", padx=(0, 8))
        self.crear_icono_app(cabecera, app).grid(row=0, column=2, sticky="ne")

        ttk.Label(
            tarjeta,
            text=app["descripcion"],
            style="Card.TLabel",
            anchor="w",
            justify="left",
            wraplength=300,
        ).grid(row=1, column=0, sticky="ew", pady=(8, 10))

        chips = ttk.Frame(tarjeta, style="Card.TFrame")
        chips.grid(row=2, column=0, sticky="ew", pady=(0, 12))
        ttk.Label(chips, text=self.texto_estado_app(app), style="SuccessChip.TLabel", anchor="w").grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Label(chips, text=app["categoria"], style="Chip.TLabel", anchor="w").grid(row=0, column=1, sticky="w")

        acciones = ttk.Frame(tarjeta, style="Card.TFrame")
        acciones.grid(row=3, column=0, sticky="ew")
        acciones.columnconfigure(1, weight=1)
        texto_boton = "Traer" if self.app_abierta(app) else "Abrir"
        boton = ttk.Button(
            acciones,
            text=texto_boton,
            command=lambda a=app: self.ejecutar_app(a),
            style="Primary.TButton",
            width=8,
        )
        boton.grid(row=0, column=0, sticky="w", padx=(0, 8))
        ttk.Label(acciones, text=app["atajo"], style="Muted.Card.TLabel", anchor="e").grid(row=0, column=2, sticky="e")
        if not self.app_disponible(app) and not self.app_abierta(app):
            boton.configure(state="disabled")
        self.widgets_apps[app["clave"]] = {"boton": boton}

    def crear_fila_compacta(self, padre, fila, app):
        fila_app = ttk.Frame(padre, style="Card.TFrame", padding=(5, 3))
        fila_app.grid(row=fila, column=0, columnspan=3, sticky="ew", padx=0, pady=(0, 3))
        fila_app.columnconfigure(0, weight=0, minsize=128)
        fila_app.columnconfigure(1, weight=1, minsize=168)
        fila_app.columnconfigure(2, weight=0, minsize=28)
        fila_app.columnconfigure(3, weight=0, minsize=54)
        ttk.Label(
            fila_app,
            text=app["titulo"],
            style="CardTitle.TLabel",
            anchor="w",
        ).grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Label(
            fila_app,
            text=app["descripcion_compacta"],
            style="Muted.Card.TLabel",
            anchor="w",
            wraplength=168,
        ).grid(row=0, column=1, sticky="ew", padx=(0, 5))
        ttk.Button(
            fila_app,
            text="\u2605" if app.get("favorita") else "\u2606",
            command=lambda a=app: self.alternar_favorito(a),
            style="Compact.Secondary.TButton",
            width=2,
        ).grid(row=0, column=2, sticky="ew", padx=(0, 4))
        texto_boton = "Traer" if self.app_abierta(app) else "Abrir"
        boton = ttk.Button(
            fila_app,
            text="Traer" if texto_boton == "Traer" else "Abrir",
            command=lambda a=app: self.ejecutar_app(a),
            style="Compact.Primary.TButton",
            width=5,
        )
        boton.grid(row=0, column=3, sticky="ew")
        if not self.app_disponible(app) and not self.app_abierta(app):
            boton.configure(state="disabled")
        self.widgets_apps[app["clave"]] = {"boton": boton}

    def crear_fila_app(self, padre, fila, app):
        fila_app = ttk.Frame(padre, style="SoftRow.TFrame", padding=(11, 9))
        fila_app.grid(row=fila, column=0, columnspan=3, sticky="ew", padx=7, pady=(0, 8))
        fila_app.columnconfigure(2, weight=1)
        fila_app.columnconfigure(3, weight=4)
        fila_app.columnconfigure(4, weight=0)
        fila_app.columnconfigure(5, weight=0)
        fila_app.columnconfigure(6, weight=0)
        self.crear_icono_app(fila_app, app).grid(row=0, column=1, sticky="w", padx=(0, 12))
        ttk.Label(fila_app, text=app["titulo"], style="CardTitle.TLabel", anchor="w").grid(row=0, column=2, sticky="ew", padx=(0, 10))
        ttk.Label(
            fila_app,
            text=app["descripcion_compacta"],
            style="Muted.Card.TLabel",
            anchor="w",
            wraplength=760,
        ).grid(row=0, column=3, sticky="ew", padx=(0, 10))
        ttk.Label(fila_app, text=app["categoria"], style="Chip.TLabel", anchor="center").grid(row=0, column=4, sticky="ew", padx=(0, 8))
        ttk.Button(
            fila_app,
            text="\u2605" if app.get("favorita") else "\u2606",
            command=lambda a=app: self.alternar_favorito(a),
            style="Favorite.TButton",
            width=3,
        ).grid(row=0, column=5, sticky="ew", padx=(0, 8))
        texto_boton = "Traer" if self.app_abierta(app) else "Abrir"
        boton = ttk.Button(
            fila_app,
            text=texto_boton,
            command=lambda a=app: self.ejecutar_app(a),
            style="Primary.TButton",
            width=10,
        )
        boton.grid(row=0, column=6, sticky="ew")
        if not self.app_disponible(app) and not self.app_abierta(app):
            boton.configure(state="disabled")
        self.widgets_apps[app["clave"]] = {"boton": boton}

    def _actualizar_scroll_apps(self, _event=None):
        try:
            self.canvas_apps.configure(scrollregion=self.canvas_apps.bbox("all"))
        except Exception:
            pass

    def _sincronizar_canvas_tema(self):
        try:
            paleta = suite_obtener_paleta()
            self.canvas_apps.configure(
                bg=paleta["tarjeta"],
                highlightbackground=paleta["borde"],
                highlightcolor=paleta["focus"],
            )
        except Exception:
            pass

    def _ajustar_ancho_panel_apps(self, event):
        try:
            self.canvas_apps.itemconfigure(self.panel_apps_window, width=event.width)
        except Exception:
            pass

    def _scroll_apps_mousewheel(self, event):
        try:
            if getattr(event, "num", None) == 4:
                pasos = -1
            elif getattr(event, "num", None) == 5:
                pasos = 1
            else:
                delta = getattr(event, "delta", 0)
                pasos = int(-1 * (delta / 120)) if delta else 0
            if pasos:
                self.canvas_apps.yview_scroll(pasos, "units")
        except Exception:
            pass
        return "break"

    def vincular_scroll_widgets(self, widget):
        try:
            widget.bind("<MouseWheel>", self._scroll_apps_mousewheel, add="+")
            widget.bind("<Button-4>", self._scroll_apps_mousewheel, add="+")
            widget.bind("<Button-5>", self._scroll_apps_mousewheel, add="+")
            for hijo in widget.winfo_children():
                self.vincular_scroll_widgets(hijo)
        except Exception:
            pass

    def _activar_scroll_global_compacto(self):
        if self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.bind_all("<MouseWheel>", self._scroll_apps_mousewheel, add="+")
            self.ventana.bind_all("<Button-4>", lambda _event: self.canvas_apps.yview_scroll(-1, "units"), add="+")
            self.ventana.bind_all("<Button-5>", lambda _event: self.canvas_apps.yview_scroll(1, "units"), add="+")
            self._scroll_global_compacto_activo = True
        except Exception:
            pass

    def _desactivar_scroll_global_compacto(self):
        if not self._scroll_global_compacto_activo:
            return
        try:
            self.ventana.unbind_all("<MouseWheel>")
            self.ventana.unbind_all("<Button-4>")
            self.ventana.unbind_all("<Button-5>")
        except Exception:
            pass
        self._scroll_global_compacto_activo = False

    def cargar_logos(self):
        if Image is None or ImageTk is None:
            messagebox.showwarning(
                "Pillow no instalado",
                "No se pudieron cargar los logos porque falta la libreria Pillow.\nInstalala con: pip install pillow",
                parent=self.ventana)
            return

        try:
            img_izq = Image.open(ruta_recurso("FINURA.png"))
            img_der = Image.open(ruta_recurso("RODRIGUEZ.png"))

            img_izq.thumbnail((210, 80))
            img_der.thumbnail((200, 80))

            self.logo_izq = ImageTk.PhotoImage(img_izq)
            self.logo_der = ImageTk.PhotoImage(img_der)

            lbl_izq = tk.Label(self.logo_slot_izq, image=self.logo_izq)
            lbl_der = tk.Label(self.logo_slot_der, image=self.logo_der)
            suite_aplicar_logo_label(lbl_izq)
            suite_aplicar_logo_label(lbl_der)
            lbl_izq.pack(anchor="w")
            lbl_der.pack(anchor="e")
            preparar_logo_minimizar(lbl_izq, self.ventana)
            preparar_logo_minimizar(lbl_der, self.ventana)

        except FileNotFoundError:
            messagebox.showwarning(
                "Logos no encontrados",
                "No se encontraron FINURA.png y/o RODRIGUEZ.png en la misma carpeta del script.",
                parent=self.ventana)
        except Exception as e:
            messagebox.showwarning("Error al cargar logos", f"No se pudieron cargar los logos:\n{e}", parent=self.ventana)

    def configurar_accesibilidad(self):
        """Atajos de teclado y refresco manual sin tocar la logica de las aplicaciones."""
        self.ventana.bind("<Alt-Key-1>", lambda _event: self.abrir_merma())
        self.ventana.bind("<Alt-Key-2>", lambda _event: self.abrir_txt_csv())
        self.ventana.bind("<Alt-Key-3>", lambda _event: self.abrir_palets())
        self.ventana.bind("<Alt-Key-4>", lambda _event: self.abrir_precintos())
        self.ventana.bind("<Alt-Key-5>", lambda _event: self.abrir_exportar_precintos())
        self.ventana.bind("<F5>", lambda _event: self.actualizar_estado_aplicaciones())
        self.ventana.bind("<F1>", lambda _event: self.abrir_acerca_version())
        self.ventana.bind("<Escape>", lambda _event: self.salir())
        self.ventana.bind("<Control-k>", lambda _event: self.enfocar_busqueda())
        self.ventana.bind("<Control-K>", lambda _event: self.enfocar_busqueda())

    def enfocar_busqueda(self):
        self.entry_busqueda.focus_set()
        self.entry_busqueda.selection_range(0, tk.END)

    def texto_estado_actualizador(self):
        estado = leer_estado_actualizador()
        if not estado:
            return {
                "status": "sin datos",
                "updated_at": "sin comprobar",
                "version_url": "canal por defecto",
                "message": "Todavia no hay registro de comprobacion.",
            }
        return estado

    def copiar_diagnostico(self):
        estado = leer_estado_actualizador()
        logs = carpeta_logs()
        partes = [
            "Suite Rodriguez Finura - diagnostico",
            f"Version instalada: {obtener_version_local()}",
            f"Ruta app: {os.path.dirname(os.path.abspath(__file__))}",
            f"Ejecutable Python: {sys.executable}",
            f"Python: {sys.version}",
            f"Sistema: {platform.platform()}",
            f"Carpeta logs: {logs}",
            "",
            "Estado actualizador:",
            json.dumps(estado, indent=2, ensure_ascii=False) if estado else "Sin estado registrado.",
            "",
            "launcher_update_check.log:",
            cola_archivo(os.path.join(logs, "launcher_update_check.log")),
            "",
            "updater.log:",
            cola_archivo(os.path.join(logs, "updater.log")),
        ]
        texto = "\n".join(partes)
        try:
            self.ventana.clipboard_clear()
            self.ventana.clipboard_append(texto)
            self.etiqueta_estado.configure(text="Diagnostico copiado al portapapeles")
            messagebox.showinfo("Diagnostico", "Diagnostico copiado al portapapeles.", parent=self.ventana)
        except Exception as exc:
            messagebox.showerror("Diagnostico", f"No se pudo copiar el diagnostico:\n{exc}", parent=self.ventana)

    def buscar_actualizacion_manual(self, boton=None, ventana_acerca=None):
        if boton is not None:
            try:
                boton.configure(state="disabled")
            except Exception:
                pass
        self.etiqueta_estado.configure(text="Comprobando actualizaciones...")

        def trabajador():
            iniciado = False
            error = None
            try:
                import SuiteLauncher

                iniciado = bool(SuiteLauncher.check_and_update(manual=True))
            except Exception as exc:
                error = exc

            def finalizar():
                if boton is not None:
                    try:
                        boton.configure(state="normal")
                    except Exception:
                        pass
                if error is not None:
                    self.etiqueta_estado.configure(text="No se pudo comprobar la actualizacion")
                    messagebox.showerror("Actualizaciones", f"No se pudo comprobar la actualizacion:\n{error}", parent=self.ventana)
                    return
                if iniciado:
                    self.etiqueta_estado.configure(text="Actualizacion iniciada")
                    try:
                        if ventana_acerca is not None and ventana_acerca.winfo_exists():
                            ventana_acerca.destroy()
                    except Exception:
                        pass
                    self.ventana.after(1200, self.ventana.destroy)
                else:
                    self.etiqueta_estado.configure(text="Comprobacion de actualizaciones finalizada")

            self.ventana.after(0, finalizar)

        threading.Thread(target=trabajador, daemon=True).start()

    def abrir_acerca_version(self):
        if hasattr(self, "_ventana_acerca") and self._ventana_acerca is not None:
            try:
                if self._ventana_acerca.winfo_exists():
                    self._ventana_acerca.lift()
                    self._ventana_acerca.focus_force()
                    return
            except Exception:
                pass

        estado = self.texto_estado_actualizador()
        ventana = tk.Toplevel(self.ventana)
        self._ventana_acerca = ventana
        suite_configurar_ventana_base(ventana, "Acerca de / Version")
        aplicar_icono_ventana(ventana)
        ventana.transient(self.ventana)
        ventana.columnconfigure(0, weight=1)

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=(18, 16))
        contenedor.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)
        contenedor.columnconfigure(1, weight=1)

        filas = [
            ("Version instalada", obtener_version_local()),
            ("Propiedad intelectual", SUITE_FOOTER_TEXTO),
            ("Ultima comprobacion", str(estado.get("updated_at", "sin comprobar"))),
            ("URL del canal", str(estado.get("version_url", "canal por defecto"))),
            ("Estado", str(estado.get("status", "sin datos"))),
            ("Detalle", str(estado.get("message", ""))),
            ("Logs", carpeta_logs()),
        ]
        ttk.Label(contenedor, text="Suite Rodriguez Finura", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        for indice, (etiqueta, valor) in enumerate(filas, start=1):
            ttk.Label(contenedor, text=etiqueta, style="Muted.Card.TLabel").grid(row=indice, column=0, sticky="nw", padx=(0, 14), pady=4)
            ttk.Label(contenedor, text=valor or "-", style="Card.TLabel", wraplength=480, justify="left").grid(row=indice, column=1, sticky="ew", pady=4)

        acciones = ttk.Frame(contenedor, style="Card.TFrame")
        acciones.grid(row=len(filas) + 1, column=0, columnspan=2, sticky="ew", pady=(16, 0))
        acciones.columnconfigure(0, weight=1)
        boton_actualizar = ttk.Button(
            acciones,
            text="Buscar actualizacion",
            style="Primary.TButton",
            command=lambda: self.buscar_actualizacion_manual(boton_actualizar, ventana),
        )
        boton_actualizar.grid(row=0, column=0, sticky="w")
        ttk.Button(
            acciones,
            text="Copiar diagnostico",
            style="Secondary.TButton",
            command=self.copiar_diagnostico,
        ).grid(row=0, column=1, padx=(10, 0))
        ttk.Button(
            acciones,
            text="Cerrar",
            style="Secondary.TButton",
            command=ventana.destroy,
        ).grid(row=0, column=2, padx=(10, 0))

    def alternar_modo_compacto(self):
        """Alterna entre menu completo y una vista lista compacta."""
        self.modo_compacto = not self.modo_compacto
        if self.modo_compacto:
            self._vista_previa_compacto = self.vista_actual
            self._categoria_previa_compacto = self.categoria_actual
            suite_aplicar_modo_compacto_ventana(self.ventana, True)
            self.cabecera.grid_configure(padx=10, pady=(8, 6))
            self.lbl_subtitulo.grid_remove()
            self.linea_cabecera.grid_configure(pady=(6, 0))
            self.contenedor.grid_configure(padx=10, pady=4)
            self.contenedor.columnconfigure(0, weight=1, minsize=0)
            self.contenedor.columnconfigure(1, weight=0, minsize=0)
            self.sidebar.grid_remove()
            self.boton_tema.grid_remove()
            self.boton_acerca.grid_remove()
            self.boton_actualizar_header.grid_remove()
            self.boton_salir_header.grid_remove()
            self.panel_apps_area.grid_configure(row=0, column=0, columnspan=2, sticky="nsew")
            self.panel_apps.configure(padding=(8, 8))
            self.footer.grid_remove()
            self.categoria_actual = "Todas"
            self.boton_compacto.config(text="Completo")
            self.aplicar_vista_temporal("compacta")
            self._activar_scroll_global_compacto()
        else:
            self._desactivar_scroll_global_compacto()
            suite_aplicar_modo_compacto_ventana(self.ventana, False)
            self.cabecera.grid_configure(padx=10, pady=(8, 0))
            self.lbl_subtitulo.grid()
            self.linea_cabecera.grid_configure(pady=(14, 0))
            self.contenedor.grid_configure(padx=10, pady=(0, 8))
            self.contenedor.columnconfigure(0, weight=0, minsize=250)
            self.contenedor.columnconfigure(1, weight=1, minsize=0)
            self.sidebar.grid(row=0, column=0, sticky="nsew", padx=(0, 12))
            self.boton_tema.grid()
            self.boton_acerca.grid()
            self.boton_actualizar_header.grid()
            self.boton_salir_header.grid()
            self.panel_apps_area.grid_configure(row=0, column=1, columnspan=1, sticky="nsew")
            self.panel_apps.configure(padding=(16, 14))
            self.footer.grid(row=2, column=0, sticky="ew", padx=10, pady=(0, 10))
            self.boton_compacto.config(text="Compacto")
            self._vista_previa_compacto = None
            self.categoria_actual = self._categoria_previa_compacto or "Todas"
            self._categoria_previa_compacto = None
            self.renderizar_categorias()
            self.aplicar_vista_temporal("tarjetas")
        suite_establecer_preferencia("modo_compacto", bool(self.modo_compacto))

    def salir(self):
        if self.ventanas_abiertas:
            if not messagebox.askyesno(
                "Salir de la suite",
                "Hay aplicaciones abiertas. Si sales del menu se cerrara la suite principal, pero las ventanas abiertas pueden perder el foco.\n\nQuieres salir?",
                parent=self.ventana,
            ):
                return
        if self._after_estado_id:
            try:
                self.ventana.after_cancel(self._after_estado_id)
            except Exception:
                pass
            self._after_estado_id = None
        self.ventana.destroy()

    def minimizar_menu_por_app(self):
        """Mantiene el menu maximizado y lo deja detras de la aplicacion abierta."""
        try:
            self.ventana.state("zoomed")
        except Exception:
            pass
        try:
            self.ventana.lower()
        except Exception:
            pass

    def restaurar_menu_si_no_hay_apps(self):
        """Trae el menu al frente sin animacion de restauracion desde minimizado."""
        if self.ventanas_abiertas:
            return
        try:
            self.ventana.deiconify()
            self.ventana.state("zoomed")
            self.ventana.lift()
            self.ventana.focus_force()
        except Exception:
            pass

    def traer_ventana_existente(self, clave):
        existente = self.ventanas_abiertas.get(clave)
        if not existente:
            return False
        _titulo, ventana_app = existente
        try:
            if ventana_app.winfo_exists():
                ventana_app.deiconify()
                ventana_app.lift()
                ventana_app.focus_force()
                self.ventana.lower(ventana_app)
                self.minimizar_menu_por_app()
                self.actualizar_estado_aplicaciones()
                self.renderizar_menu()
                return True
        except Exception:
            pass
        self.ventanas_abiertas.pop(clave, None)
        return False

    def registrar_ventana(self, clave, titulo, ventana_app):
        self.ventanas_abiertas[clave] = (titulo, ventana_app)
        ventana_app.protocol("WM_DELETE_WINDOW", lambda c=clave, v=ventana_app: self.cerrar_ventana_app(c, v))
        ventana_app.bind("<Destroy>", lambda event, c=clave: self._al_destruir_ventana(event, c), add="+")
        try:
            ventana_app.lift()
            ventana_app.focus_force()
            self.ventana.lower(ventana_app)
            self.minimizar_menu_por_app()
        except Exception:
            pass
        self.actualizar_estado_aplicaciones()
        self.renderizar_menu()

    def _al_destruir_ventana(self, event, clave):
        if event.widget is self.ventanas_abiertas.get(clave, (None, None))[1]:
            self.ventanas_abiertas.pop(clave, None)
            self.ventana.after(50, self.actualizar_estado_aplicaciones)
            self.ventana.after(60, self.renderizar_menu)
            self.ventana.after(80, self.restaurar_menu_si_no_hay_apps)

    def cerrar_ventana_app(self, clave, ventana_app):
        try:
            ventana_app.destroy()
        finally:
            self.ventanas_abiertas.pop(clave, None)
            self.actualizar_estado_aplicaciones()
            self.renderizar_menu()
            self.restaurar_menu_si_no_hay_apps()

    def actualizar_estado_aplicaciones_periodico(self):
        self.actualizar_estado_aplicaciones()
        try:
            self._after_estado_id = self.ventana.after(1500, self.actualizar_estado_aplicaciones_periodico)
        except Exception:
            self._after_estado_id = None
            pass

    def actualizar_estado_aplicaciones(self):
        abiertas = []
        for clave, (titulo, ventana_app) in list(self.ventanas_abiertas.items()):
            try:
                if ventana_app.winfo_exists():
                    abiertas.append(titulo)
                else:
                    self.ventanas_abiertas.pop(clave, None)
            except Exception:
                self.ventanas_abiertas.pop(clave, None)
        if abiertas:
            self.etiqueta_estado.config(text="Aplicaciones abiertas: " + " | ".join(abiertas))
        else:
            self.etiqueta_estado.config(text="Sin aplicaciones abiertas")

    def abrir_merma(self):
        if self.traer_ventana_existente("merma"):
            return
        try:
            lanzar_app_merma = cargar_atributo("programa_mermas", "lanzar_app_merma")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de merma:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_merma(self.ventana)
        self.registrar_ventana("merma", "Merma", ventana_app)

    def abrir_txt_csv(self):
        if self.traer_ventana_existente("txt_csv"):
            return
        try:
            lanzar_app_txt_csv = cargar_atributo("FusionarCSV_mejorado", "lanzar_app_txt_csv")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion TXT a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_app = lanzar_app_txt_csv(self.ventana)
        self.registrar_ventana("txt_csv", "TXT a CSV", ventana_app)

    def abrir_palets(self):
        if self.traer_ventana_existente("palets"):
            return
        try:
            ProcesadorPaletsApp = cargar_atributo("ProcesadorPaletsGUI", "ProcesadorPaletsApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Palets PDA:\n{exc}", parent=self.ventana)
            return
        ventana_palets = tk.Toplevel(self.ventana)
        ProcesadorPaletsApp(ventana_palets)
        self.registrar_ventana("palets", "Palets PDA", ventana_palets)

    def abrir_precintos(self):
        if self.traer_ventana_existente("precintos"):
            return
        try:
            ControlPrecintosJamonesApp = cargar_atributo("ControlPrecintosJamonesGUI", "ControlPrecintosJamonesApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Jamones:\n{exc}", parent=self.ventana)
            return
        ventana_precintos = tk.Toplevel(self.ventana)
        ControlPrecintosJamonesApp(ventana_precintos)
        self.registrar_ventana("precintos", "Precintos Jamones", ventana_precintos)

    def abrir_exportar_precintos(self):
        if self.traer_ventana_existente("exportar_precintos"):
            return
        try:
            ExportarPrecintosExcelApp = cargar_atributo("ExportarPrecintosExcelGUI", "ExportarPrecintosExcelApp")
        except Exception as exc:
            messagebox.showerror("Error", f"No se pudo cargar la aplicacion de Precintos Excel a CSV:\n{exc}", parent=self.ventana)
            return
        ventana_exportar = tk.Toplevel(self.ventana)
        ExportarPrecintosExcelApp(ventana_exportar)
        self.registrar_ventana("exportar_precintos", "Precintos Excel", ventana_exportar)


if __name__ == "__main__":
    root = tk.Tk()
    app = MenuPrincipal(root)
    root.mainloop()
