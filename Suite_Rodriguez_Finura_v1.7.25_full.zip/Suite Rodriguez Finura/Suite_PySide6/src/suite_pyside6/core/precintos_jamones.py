from __future__ import annotations

from .jobs import checkpoint, checked, report_progress, begin_commit

import csv
import io
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal, InvalidOperation
from email.message import EmailMessage
import os
from pathlib import Path

from .atomic_io import write_text_atomically
import re
import smtplib
from difflib import SequenceMatcher
import unicodedata



TIPOS_JAMON = ("Blanco", "Iberico", "Mixto")
CAMPOS_ESPERADOS = 7
SMTP_HOST = "smtp.vallcompanys.es"
SMTP_PORT = 25
SMTP_USER = "envio@smtp.erod.es"
SMTP_USUARIO = SMTP_USER
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD") or os.environ.get("SUITE_PRECINTOS_SMTP_PASSWORD", "")
SMTP_SECURE = False
SMTP_STARTTLS = SMTP_SECURE
ASUNTO_CORREO_DEFECTO = "Control precintos jamones"
MENSAJE_CORREO_DEFECTO = (
    "Adjunto se envian los ficheros generados por Control Precintos Jamones.\n\n"
    "Tipo: {tipo_jamon}\n"
    "Registros validos: {registros_validos}\n"
    "Incidencias pendientes: {incidencias}\n"
    "Duplicados suprimidos: {duplicados}\n"
)


@dataclass(frozen=True)
class RegistroJamones:
    archivo: str
    linea: int
    campos: list[str]
    orden: int

    @property
    def partida(self) -> str:
        return self.campos[0].strip() if len(self.campos) > 0 else ""

    @property
    def fecha(self) -> str:
        return self.campos[1].strip() if len(self.campos) > 1 else ""

    @property
    def hora(self) -> str:
        return self.campos[2].strip() if len(self.campos) > 2 else ""

    @property
    def codigo_articulo(self) -> str:
        return self.campos[3].strip() if len(self.campos) > 3 else ""

    @property
    def precinto(self) -> str:
        return self.campos[4].strip() if len(self.campos) > 4 else ""

    @property
    def lote(self) -> str:
        return self.campos[5].strip() if len(self.campos) > 5 else ""

    @property
    def peso(self) -> str:
        return self.campos[6].strip() if len(self.campos) > 6 else ""

    def fecha_hora(self) -> datetime | None:
        for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%y %H:%M:%S"):
            checkpoint()
            try:
                return datetime.strptime(f"{self.fecha} {self.hora}", fmt)
            except ValueError:
                continue
        return None

    def a_linea(self) -> str:
        campos = list(self.campos[:CAMPOS_ESPERADOS])
        while len(campos) < CAMPOS_ESPERADOS:
            campos.append("")
        return ";".join(campos) + ";"


@dataclass(frozen=True)
class RangoPesoResumen:
    minimo: Decimal
    maximo: Decimal
    piezas_originales: int
    peso_original: Decimal


@dataclass(frozen=True)
class ResumenPartida:
    partida: str
    proveedor: str
    lote: str
    fecha: str
    hora: str
    total_piezas: int
    total_peso: Decimal
    rangos: tuple[RangoPesoResumen, ...]

    @property
    def piezas_en_rangos(self) -> int:
        return sum(rango.piezas_originales for rango in self.rangos)


@dataclass(frozen=True)
class ResultadoRangoPeso:
    rango: RangoPesoResumen
    piezas_validas: int
    peso_valido: Decimal


@dataclass(frozen=True)
class ControlResumenPartida:
    resumen: ResumenPartida
    rangos: tuple[ResultadoRangoPeso, ...]
    total_validos: int
    peso_total_valido: Decimal
    fuera_de_rango: tuple[RegistroJamones, ...]
    pesos_no_validos: tuple[RegistroJamones, ...]

    @property
    def piezas_en_rangos(self) -> int:
        return sum(rango.piezas_validas for rango in self.rangos)

    @property
    def cuadra_con_validos(self) -> bool:
        return (
            self.piezas_en_rangos == self.total_validos
            and not self.fuera_de_rango
            and not self.pesos_no_validos
        )


@dataclass(frozen=True)
class SeleccionPeso:
    minimo: float
    maximo: float
    registros: tuple[RegistroJamones, ...]


@dataclass
class PrecintosJamonesResult:
    selected_files: list[Path] = field(default_factory=list)
    tipo_jamon: str = "Blanco"
    validos: list[RegistroJamones] = field(default_factory=list)
    invalidos: list[tuple[RegistroJamones, str]] = field(default_factory=list)
    duplicados: list[RegistroJamones] = field(default_factory=list)
    oficiales: set[str] = field(default_factory=set)
    grupos_internos: set[tuple[str, str]] = field(default_factory=set)
    correction_preview: str | None = None

    def tipo_registro(self, registro: RegistroJamones) -> str:
        return tipo_registro_detectado(registro, self.grupos_internos)

    def es_lote_mixto(self) -> bool:
        return self.tipo_jamon == "Mixto"

    def detection_messages(self) -> list[str]:
        registros = [*self.validos, *(registro for registro, _motivo in self.invalidos)]
        if not registros:
            return []
        counts = Counter(self.tipo_registro(registro) for registro in registros)
        messages: list[str] = []
        if self.grupos_internos:
            messages.append("Serie interna consecutiva detectada: las coincidencias de control GTIN no cambian el tipo blanco.")
        if counts.get("Iberico"):
            messages.append("Precintos compatibles con GTIN-12, clasificados como ibéricos al no detectarse una serie interna. El control GTIN por sí solo no acredita el tipo de jamón.")
        if counts.get("Blanco"):
            messages.append("Se han detectado precintos internos correspondientes a jamón blanco.")
        invalid_check = sum(
            1
            for registro in registros
            if re.fullmatch(r"\d{12}", registro.precinto.strip()) and not gtin12_valido(registro.precinto)
        )
        if invalid_check:
            messages.append(
                f"{invalid_check} valor(es) tienen 12 dígitos pero un dígito de control GTIN no válido; se tratan según las reglas de precinto interno."
            )
        if len(counts) > 1:
            messages.append("El fichero contiene una mezcla de precintos internos y GTIN-12. Revisa los registros indicados antes de continuar.")
        return messages

    def differences(self) -> tuple[set[str], set[str]]:
        registros = list(self.validos) + [registro for registro, _motivo in self.invalidos]
        leidos = {registro.precinto for registro in registros if self.tipo_registro(registro) == "Iberico" and gtin12_valido(registro.precinto)}
        return leidos - self.oficiales, self.oficiales - leidos

    def summary_lines(self) -> list[str]:
        lines = [
            f"Tipo detectado: {tipo_jamon_visible(self.tipo_jamon)}",
            f"Archivos: {len(self.selected_files)}",
            f"Registros validos: {len(self.validos)}",
            f"Incidencias: {len(self.invalidos)}",
            f"Duplicados suprimidos: {len(self.duplicados)}",
        ]
        if self.oficiales:
            extra, missing = self.differences()
            lines.extend(
                [
                    f"Precintos oficiales: {len(self.oficiales)}",
                    f"Leidos fuera del oficial: {len(extra)}",
                    f"Oficiales no leidos: {len(missing)}",
                ]
            )
        messages = self.detection_messages()
        if messages:
            lines.extend(["", *messages])
        return lines

    def preview_text(self) -> str:
        lines = self.summary_lines()
        if self.invalidos:
            lines.append("")
            lines.append("Incidencias:")
            for registro, motivo in self.invalidos[:80]:
                lines.append(f"- {registro.archivo}:{registro.linea} {registro.precinto or '(sin precinto)'} | {motivo}")
        if self.duplicados:
            lines.append("")
            lines.append("Duplicados suprimidos:")
            for registro in self.duplicados[:40]:
                lines.append(f"- {registro.precinto} | {registro.fecha} {registro.hora} | {registro.archivo}:{registro.linea}")
        if self.oficiales:
            extra, missing = self.differences()
            if extra:
                lines.append("")
                lines.append("Leidos fuera del Excel oficial:")
                lines.extend(f"- {item}" for item in sorted(extra)[:80])
            if missing:
                lines.append("")
                lines.append("Oficiales no leidos:")
                lines.extend(f"- {item}" for item in sorted(missing)[:80])
        return "\n".join(lines)


def normalizar_precinto(value: str) -> str:
    return re.sub(r"\D+", "", value or "")


def gtin12_valido(codigo: str) -> bool:
    codigo = str(codigo or "").strip()
    if not re.fullmatch(r"\d{12}", codigo):
        return False
    digits = [int(char) for char in codigo]
    total = sum(digits[index] * (3 if index % 2 == 0 else 1) for index in range(11))
    check = (10 - (total % 10)) % 10
    return check == digits[11]


def clasificar_precinto(codigo: str) -> str:
    """Clasifica sin mutar el texto: sólo los GTIN-12 reales son ibéricos."""
    return "Iberico" if gtin12_valido(codigo) else "Blanco"


def tipo_jamon_visible(tipo: str) -> str:
    return {"Iberico": "Jamón ibérico", "Blanco": "Jamón blanco", "Mixto": "Tipos mezclados"}.get(tipo, "Sin detectar")


def tipo_lote(registros: list[RegistroJamones]) -> str:
    groups = detectar_series_internas(registros)
    detected = {tipo_registro_detectado(registro, groups) for registro in registros}
    if len(detected) > 1:
        return "Mixto"
    return next(iter(detected), "Blanco")


def detectar_series_internas(registros: list[RegistroJamones]) -> set[tuple[str, str]]:
    """A checksum match alone cannot classify an internal serial as Iberico.

    Four consecutive complete numbers are evidence of a serial, not a GTIN
    sequence. Scope evidence to article and serial prefix, never the whole lot.
    """
    groups: dict[tuple[str, str], set[str]] = {}
    for registro in checked(registros):
        checkpoint()
        code = registro.precinto
        if re.fullmatch(r"[0-9]{12}", code):
            groups.setdefault((registro.codigo_articulo, code[:8]), set()).add(code)
    internal = set()
    for key, codes in groups.items():
        checkpoint()
        if len(codes) < 4 or sum(gtin12_valido(code) for code in codes) * 2 >= len(codes):
            continue
        numbers = sorted(int(code) for code in codes)
        run = 1
        for previous, number in zip(numbers, numbers[1:]):
            checkpoint()
            run = run + 1 if number == previous + 1 else 1
            if run >= 4:
                internal.add(key)
                break
    return internal


def tipo_registro_detectado(registro: RegistroJamones, groups) -> str:
    if (registro.codigo_articulo, registro.precinto[:8]) in groups:
        return "Blanco"
    return clasificar_precinto(registro.precinto)


def distancia_digitos(a: str, b: str) -> int:
    if len(a) != len(b):
        return max(len(a), len(b))
    return sum(1 for x, y in zip(a, b) if x != y)


def es_transposicion_simple(a: str, b: str) -> bool:
    if len(a) != len(b):
        return False
    diferentes = [index for index, (x, y) in enumerate(zip(a, b)) if x != y]
    return (
        len(diferentes) == 2
        and a[diferentes[0]] == b[diferentes[1]]
        and a[diferentes[1]] == b[diferentes[0]]
    )


def sugerir_precintos(codigo: str, oficiales: set[str], max_sugerencias: int = 3) -> list[str]:
    limpio = normalizar_precinto(codigo)
    if not limpio or not oficiales:
        return []
    candidatos: list[tuple[int, float, str]] = []
    for oficial in checked(oficiales, phase="Buscando coincidencias"):
        checkpoint()
        distancia = distancia_digitos(limpio, oficial)
        transposicion = es_transposicion_simple(limpio, oficial)
        matcher = SequenceMatcher(None, limpio, oficial)
        if distancia > 2 and not transposicion and matcher.quick_ratio() < 0.84:
            continue
        ratio = matcher.ratio()
        if distancia <= 2 or transposicion or ratio >= 0.84:
            penalizacion = 0 if transposicion else distancia
            candidatos.append((penalizacion, -ratio, oficial))
    candidatos.sort()
    return [oficial for _penalizacion, _ratio, oficial in candidatos[:max_sugerencias]]


def validar_precinto(codigo: str, tipo_jamon: str) -> tuple[bool, str]:
    original = str(codigo or "")
    clean = original.strip()
    limpio = normalizar_precinto(clean)
    if clean != limpio:
        return False, "contiene caracteres no numericos"
    if not re.fullmatch(r"\d{12}", clean):
        return False, "debe tener exactamente 12 digitos numericos"
    if tipo_jamon.lower() == "iberico" and not gtin12_valido(clean):
        return False, "GTIN-12 incorrecto"
    return True, ""


def valor_mayoritario(values) -> str:
    counter = Counter(value.strip() for value in values if value and value.strip())
    if not counter:
        return ""
    common = counter.most_common(2)
    value, count = common[0]
    if len(common) > 1 and count == common[1][1]:
        return ""
    return value


def sugerir_partida_lote(registros) -> tuple[str, str]:
    records = list(registros)
    partida = valor_mayoritario(record.partida for record in records if re.fullmatch(r"\d{6}", record.partida))
    lote = valor_mayoritario(record.lote for record in records)
    return partida, lote


def validar_registro_completo(
    registro: RegistroJamones,
    tipo_jamon: str,
    partida_sugerida: str = "",
    lote_sugerido: str = "",
) -> list[str]:
    motivos: list[str] = []
    if len(registro.campos) < CAMPOS_ESPERADOS:
        motivos.append(f"faltan campos: {len(registro.campos)} de {CAMPOS_ESPERADOS}")
    if not re.fullmatch(r"\d{6}", registro.partida):
        if partida_sugerida:
            motivos.append(f"partida no valida; sugerida {partida_sugerida}")
        else:
            motivos.append("partida no valida")
    if not registro.lote:
        motivos.append(f"lote vacio; sugerido {lote_sugerido}" if lote_sugerido else "lote vacio")
    ok, motivo = validar_precinto(registro.precinto, tipo_jamon)
    if not ok:
        motivos.append(motivo)
    return motivos


def parsear_peso(valor: str) -> float | None:
    texto = (valor or "").strip().replace(" ", "")
    if not texto:
        return None
    if "," in texto and "." in texto:
        if texto.rfind(",") > texto.rfind("."):
            texto = texto.replace(".", "").replace(",", ".")
        else:
            texto = texto.replace(",", "")
    elif "," in texto:
        texto = texto.replace(",", ".")
    try:
        return float(texto)
    except ValueError:
        return None


def formatear_peso(valor: float) -> str:
    texto = f"{valor:.3f}".rstrip("0").rstrip(".")
    return texto.replace(".", ",")


def _decimal_resumen(valor: str, campo: str) -> Decimal:
    texto = str(valor or "").strip().replace(" ", "")
    if not texto:
        raise ValueError(f"{campo} está vacío.")
    if "," in texto and "." in texto:
        if texto.rfind(",") > texto.rfind("."):
            texto = texto.replace(".", "").replace(",", ".")
        else:
            texto = texto.replace(",", "")
    elif "," in texto:
        texto = texto.replace(",", ".")
    try:
        return Decimal(texto)
    except InvalidOperation as exc:
        raise ValueError(f"{campo} no es un número válido: {valor}") from exc


def _normalizar_rotulo_resumen(valor: str) -> str:
    texto = unicodedata.normalize("NFKD", str(valor or ""))
    texto = "".join(char for char in texto if not unicodedata.combining(char))
    texto = texto.upper().replace("º", "").replace("°", "")
    return re.sub(r"[^A-Z0-9]+", " ", texto).strip()


def _lineas_resumen(texto: str) -> list[str]:
    return [re.sub(r"\s+", " ", linea).strip() for linea in str(texto or "").splitlines() if linea.strip()]


def _valor_despues_de_rotulo(lineas: list[str], *terminos: str) -> list[str]:
    for index, linea in enumerate(lineas):
        normalizada = _normalizar_rotulo_resumen(linea)
        if all(termino in normalizada for termino in terminos):
            if index + 1 >= len(lineas):
                break
            return lineas[index + 1].split()
    raise ValueError(f"No se ha encontrado el dato posterior a {' / '.join(terminos)}.")


def parsear_resumen_partida(texto: str) -> ResumenPartida:
    lineas = _lineas_resumen(texto)
    if not lineas:
        raise ValueError("Pega el resumen de la partida antes de añadirlo.")

    partida_values = _valor_despues_de_rotulo(lineas, "PARTIDA")
    proveedor_lote = _valor_despues_de_rotulo(lineas, "PROVEEDOR", "LOTE")
    fecha_hora = _valor_despues_de_rotulo(lineas, "FECHA", "HORA")
    totales = _valor_despues_de_rotulo(lineas, "TOTAL PIEZAS", "TOTAL PESO")
    if len(proveedor_lote) < 2 or len(fecha_hora) < 2 or len(totales) < 2:
        raise ValueError("El resumen no contiene proveedor/lote, fecha/hora o totales completos.")

    rango_index = next(
        (index for index, linea in enumerate(lineas) if "RANGO DE PESOS" in _normalizar_rotulo_resumen(linea)),
        -1,
    )
    if rango_index < 0:
        raise ValueError("No se ha encontrado la sección RANGO DE PESOS.")

    rangos: list[RangoPesoResumen] = []
    for linea in lineas[rango_index + 1 :]:
        valores = linea.split()
        if len(valores) < 4:
            continue
        try:
            minimo = _decimal_resumen(valores[0], "Mínimo")
            maximo = _decimal_resumen(valores[1], "Máximo")
            piezas_decimal = _decimal_resumen(valores[2], "Piezas")
            peso = _decimal_resumen(valores[3], "Peso")
        except ValueError:
            continue
        if minimo == 0 and maximo == 0 and piezas_decimal == 0 and peso == 0:
            continue
        if maximo <= minimo:
            if piezas_decimal == 0 and peso == 0:
                continue
            raise ValueError(f"Rango no válido: {valores[0]} - {valores[1]}.")
        if piezas_decimal != piezas_decimal.to_integral_value() or piezas_decimal < 0:
            raise ValueError(f"Número de piezas no válido en el rango {valores[0]} - {valores[1]}.")
        rangos.append(RangoPesoResumen(minimo, maximo, int(piezas_decimal), peso))

    if not rangos:
        raise ValueError("El resumen no contiene rangos de peso válidos.")
    rangos.sort(key=lambda rango: (rango.minimo, rango.maximo))
    for anterior, actual in zip(rangos, rangos[1:]):
        if actual.minimo < anterior.maximo:
            raise ValueError("Los rangos de peso se solapan; revisa los mínimos y máximos.")

    total_piezas_decimal = _decimal_resumen(totales[0], "Total de piezas")
    if total_piezas_decimal != total_piezas_decimal.to_integral_value() or total_piezas_decimal < 0:
        raise ValueError("El total de piezas del resumen no es válido.")
    return ResumenPartida(
        partida=partida_values[0],
        proveedor=proveedor_lote[0],
        lote=proveedor_lote[1],
        fecha=fecha_hora[0],
        hora=fecha_hora[1],
        total_piezas=int(total_piezas_decimal),
        total_peso=_decimal_resumen(totales[1], "Total de peso"),
        rangos=tuple(rangos),
    )


def leer_resumen_partida(path: Path) -> ResumenPartida:
    from .text_stream import iter_text_lines

    ruta = Path(path)
    if ruta.suffix.lower() not in {".txt", ".csv"}:
        raise ValueError("El resumen debe ser un archivo TXT o CSV.")
    texto = "\n".join(iter_text_lines(ruta))
    return parsear_resumen_partida(texto)


def calcular_control_resumen(
    result: PrecintosJamonesResult,
    resumen: ResumenPartida,
) -> ControlResumenPartida:
    agrupados: list[list[RegistroJamones]] = [[] for _rango in resumen.rangos]
    fuera: list[RegistroJamones] = []
    pesos_no_validos: list[RegistroJamones] = []
    peso_total = Decimal("0")
    for registro in result.validos:
        checkpoint()
        try:
            peso = _decimal_resumen(registro.peso, "Peso")
        except ValueError:
            pesos_no_validos.append(registro)
            continue
        peso_total += peso
        encontrado = False
        for index, rango in enumerate(resumen.rangos):
            es_ultimo = index == len(resumen.rangos) - 1
            if rango.minimo <= peso < rango.maximo or (es_ultimo and peso == rango.maximo):
                agrupados[index].append(registro)
                encontrado = True
                break
        if not encontrado:
            fuera.append(registro)

    controles = tuple(
        ResultadoRangoPeso(
            rango=rango,
            piezas_validas=len(registros),
            peso_valido=sum((_decimal_resumen(registro.peso, "Peso") for registro in registros), Decimal("0")),
        )
        for rango, registros in zip(resumen.rangos, agrupados)
    )
    return ControlResumenPartida(
        resumen=resumen,
        rangos=controles,
        total_validos=len(result.validos),
        peso_total_valido=peso_total,
        fuera_de_rango=tuple(fuera),
        pesos_no_validos=tuple(pesos_no_validos),
    )


def seleccionar_registros_por_peso(
    result: PrecintosJamonesResult,
    minimo_texto: str,
    maximo_texto: str,
) -> SeleccionPeso:
    if result.invalidos:
        raise ValueError("Primero corrige y revalida las incidencias de precintos.")
    minimo = parsear_peso(minimo_texto)
    maximo = parsear_peso(maximo_texto)
    if minimo is None or maximo is None:
        raise ValueError("Introduce un peso mínimo y un peso máximo válidos.")
    if minimo > maximo:
        raise ValueError("El peso mínimo no puede ser superior al peso máximo.")
    registros = tuple(
        registro
        for registro in result.validos
        if (peso := parsear_peso(registro.peso)) is not None and minimo <= peso <= maximo
    )
    return SeleccionPeso(minimo, maximo, registros)


def formatear_decimal_resumen(valor: Decimal) -> str:
    texto = format(valor, "f")
    if "." in texto:
        texto = texto.rstrip("0").rstrip(".")
    return texto.replace(".", ",") or "0"


def texto_control_resumen(control: ControlResumenPartida) -> str:
    resumen = control.resumen
    lineas = [
        f"Partida: {resumen.partida}",
        f"Proveedor: {resumen.proveedor} | Lote: {resumen.lote}",
        f"Fecha: {resumen.fecha} {resumen.hora}",
        f"Resumen original: {resumen.total_piezas} piezas | {formatear_decimal_resumen(resumen.total_peso)} kg",
        "",
        "Rangos recalculados sobre válidos:",
    ]
    for index, resultado in enumerate(control.rangos):
        rango = resultado.rango
        cierre = "≤" if index == len(control.rangos) - 1 else "<"
        lineas.append(
            f"{formatear_decimal_resumen(rango.minimo)} ≤ kg {cierre} {formatear_decimal_resumen(rango.maximo)}: "
            f"{resultado.piezas_validas} uds / {formatear_decimal_resumen(resultado.peso_valido)} kg | "
            f"Original: {rango.piezas_originales} uds / {formatear_decimal_resumen(rango.peso_original)} kg"
        )
    lineas.extend(
        [
            "",
            f"Total en rangos: {control.piezas_en_rangos} de {control.total_validos} válidos",
            f"Peso válido total: {formatear_decimal_resumen(control.peso_total_valido)} kg",
        ]
    )
    if control.fuera_de_rango:
        lineas.append(f"Fuera de los tramos: {len(control.fuera_de_rango)}")
    if control.pesos_no_validos:
        lineas.append(f"Pesos no válidos: {len(control.pesos_no_validos)}")
    lineas.append("Control correcto: la suma coincide con los válidos." if control.cuadra_con_validos else "Revisar: la suma de los tramos no coincide con los válidos.")
    return "\n".join(lineas)


def parsear_linea(line: str, archivo: str, numero_linea: int, orden: int) -> RegistroJamones | None:
    if not line.strip():
        return None
    try:
        campos = next(csv.reader([line.strip("\r\n")], delimiter=";", quotechar='"'))
    except csv.Error:
        campos = line.strip("\r\n").split(";")
    if campos and campos[-1] == "":
        campos = campos[:-1]
    return RegistroJamones(archivo=archivo, linea=numero_linea, campos=campos, orden=orden)


def leer_ficheros(paths) -> list[RegistroJamones]:
    registros: list[RegistroJamones] = []
    orden = 0
    for path in checked(paths, phase="Leyendo archivos", total=len(paths), unit="archivos"):
        checkpoint()
        from .text_stream import iter_text_lines
        lines = iter_text_lines(path)
        for numero, line in enumerate(lines, start=1):
            checkpoint()
            orden += 1
            registro = parsear_linea(line, Path(path).name, numero, orden)
            if registro is not None:
                registros.append(registro)
    return registros


def es_mas_reciente(nuevo: RegistroJamones, actual: RegistroJamones) -> bool:
    nueva = nuevo.fecha_hora()
    actual_dt = actual.fecha_hora()
    if nueva and actual_dt and nueva != actual_dt:
        return nueva > actual_dt
    if nueva and not actual_dt:
        return True
    if not nueva and actual_dt:
        return False
    return nuevo.orden > actual.orden


def deduplicar(registros: list[RegistroJamones]) -> tuple[list[RegistroJamones], list[RegistroJamones]]:
    por_precinto: dict[str, RegistroJamones] = {}
    eliminados: list[RegistroJamones] = []
    for registro in checked(registros):
        checkpoint()
        anterior = por_precinto.get(registro.precinto)
        if anterior is None:
            por_precinto[registro.precinto] = registro
            continue
        if es_mas_reciente(registro, anterior):
            eliminados.append(anterior)
            por_precinto[registro.precinto] = registro
        else:
            eliminados.append(registro)
    return sorted(por_precinto.values(), key=lambda item: item.orden), eliminados


def leer_precintos_excel_oficial(path: Path) -> list[str]:
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    try:
        for ws in wb.worksheets:
            checkpoint()
            rows = checked(ws.iter_rows(values_only=True), phase='Leyendo Excel')
            header_row = -1
            column = -1
            for row_index, row in enumerate(rows):
                for col_index, value in enumerate(row):
                    text = re.sub(r"\s+", " ", str(value or "").strip().lower())
                    if text == "numero del precinto":
                        header_row = row_index
                        column = col_index
                        break
                if column >= 0:
                    break
            if column < 0:
                continue
            precintos: list[str] = []
            seen: set[str] = set()
            for row in rows:
                value = normalizar_precinto(str(row[column] if column < len(row) else ""))
                if re.fullmatch(r"\d{12}", value) and value not in seen:
                    seen.add(value)
                    precintos.append(value)
            return precintos
    finally:
        wb.close()
    raise ValueError("No se encontro la columna 'Numero del precinto' en el Excel oficial.")


def process_precintos_jamones(
    paths: list[Path],
    tipo_jamon: str | None = None,
    official_excel: Path | None = None,
) -> PrecintosJamonesResult:
    registros = leer_ficheros(paths)
    partida, lote = sugerir_partida_lote(registros)
    internal_groups = detectar_series_internas(registros)
    validos_pre: list[RegistroJamones] = []
    invalidos: list[tuple[RegistroJamones, str]] = []
    for registro in checked(registros):
        checkpoint()
        motivos = validar_registro_completo(registro, tipo_registro_detectado(registro, internal_groups), partida, lote)
        if motivos:
            invalidos.append((registro, "; ".join(motivos)))
        else:
            validos_pre.append(registro)
    validos, duplicados = deduplicar(validos_pre)
    oficiales = set(leer_precintos_excel_oficial(official_excel)) if official_excel is not None else set()
    lote_tipo = tipo_lote(registros)
    result = PrecintosJamonesResult(list(paths), lote_tipo, validos, invalidos, duplicados, oficiales, internal_groups)
    result.correction_preview = correction_text(result)
    return result


def correction_text(result: PrecintosJamonesResult) -> str:
    if result.correction_preview is not None:
        return result.correction_preview
    if not result.invalidos:
        return "# Sin incidencias pendientes.\n"
    blocks = ["# Corrige las lineas de datos. Las lineas que empiezan por # se ignoran al revalidar."]
    suggestions = {}
    for registro, motivo in result.invalidos:
        checkpoint()
        blocks.append(f"# Archivo: {registro.archivo} | linea: {registro.linea} | motivo: {motivo}")
        if registro.precinto not in suggestions:
            suggestions[registro.precinto] = sugerir_precintos(registro.precinto, result.oficiales)
        sugerencias = suggestions[registro.precinto]
        if sugerencias:
            blocks.append("# Sugerencias oficiales cercanas: " + ", ".join(sugerencias))
        blocks.append(registro.a_linea())
    return "\n".join(blocks) + "\n"


def revalidate_corrections(result: PrecintosJamonesResult, text: str) -> PrecintosJamonesResult:
    corrected: list[RegistroJamones] = []
    errors: list[tuple[RegistroJamones, str]] = []
    base_order = max((registro.orden for registro in result.validos), default=0) + 100000
    partida, lote = sugerir_partida_lote(result.validos)
    internal_groups = result.grupos_internos
    for index, line in enumerate(text.splitlines(), start=1):
        checkpoint()
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        registro = parsear_linea(stripped, "CORRECCION_MANUAL", index, base_order + index)
        if registro is None:
            continue
        motivos = validar_registro_completo(registro, tipo_registro_detectado(registro, internal_groups), partida, lote)
        if motivos:
            errors.append((registro, "; ".join(motivos)))
        else:
            corrected.append(registro)
    validos, duplicados = deduplicar(result.validos + corrected)
    updated = PrecintosJamonesResult(
        selected_files=list(result.selected_files),
        tipo_jamon=tipo_lote([*result.validos, *corrected, *(registro for registro, _motivo in errors)]),
        validos=validos,
        invalidos=errors,
        duplicados=list(result.duplicados) + duplicados,
        oficiales=set(result.oficiales),
        grupos_internos=set(internal_groups),
    )
    updated.correction_preview = correction_text(updated)
    return updated


def weight_filter_text(
    result: PrecintosJamonesResult,
    minimo_texto: str = "",
    maximo_texto: str = "",
) -> tuple[str, str, bool]:
    if result.invalidos:
        raise ValueError("Primero corrige y revalida las incidencias de precintos.")
    minimo = parsear_peso(minimo_texto) if minimo_texto.strip() else None
    maximo = parsear_peso(maximo_texto) if maximo_texto.strip() else None
    if minimo is None and maximo is None:
        raise ValueError("Introduce un peso minimo, un peso maximo o ambos.")
    if minimo_texto.strip() and minimo is None:
        raise ValueError("Peso minimo no valido. Ejemplos: 10, 10,5 o 10.5.")
    if maximo_texto.strip() and maximo is None:
        raise ValueError("Peso maximo no valido. Ejemplos: 16, 16,5 o 16.5.")
    if minimo is not None and maximo is not None and minimo > maximo:
        raise ValueError("El peso minimo no puede ser superior al peso maximo.")

    fuera: list[tuple[RegistroJamones, str]] = []
    pesos_no_validos: list[RegistroJamones] = []
    for registro in result.validos:
        checkpoint()
        peso = parsear_peso(registro.peso)
        if peso is None:
            pesos_no_validos.append(registro)
            continue
        if minimo is not None and peso < minimo:
            fuera.append((registro, f"peso {registro.peso} inferior al minimo {formatear_peso(minimo)}"))
        elif maximo is not None and peso > maximo:
            fuera.append((registro, f"peso {registro.peso} superior al maximo {formatear_peso(maximo)}"))

    if not fuera and not pesos_no_validos:
        editor = "# No hay registros fuera del rango de peso indicado.\n"
    else:
        bloques = [
            "# Registros filtrados por peso.",
            "# Puedes modificar estas lineas y pulsar Revalidar para sustituir el registro original por el corregido.",
            "# Las lineas que empiezan por # se ignoran al revalidar.",
        ]
        for registro, motivo in fuera:
            checkpoint()
            blocks = [f"# Archivo: {registro.archivo} | linea: {registro.linea} | motivo: {motivo}", registro.a_linea()]
            bloques.extend(blocks)
        for registro in pesos_no_validos:
            checkpoint()
            bloques.extend(
                [
                    f"# Archivo: {registro.archivo} | linea: {registro.linea} | motivo: peso no numerico o vacio",
                    registro.a_linea(),
                ]
            )
        editor = "\n".join(bloques) + "\n"

    resumen = "\n".join(
        [
            "Filtro de pesos aplicado:",
            f"- Peso minimo: {formatear_peso(minimo) if minimo is not None else '(sin minimo)'}",
            f"- Peso maximo: {formatear_peso(maximo) if maximo is not None else '(sin maximo)'}",
            f"- Registros por debajo del minimo o por encima del maximo: {len(fuera)}",
            f"- Registros con peso no numerico o vacio: {len(pesos_no_validos)}",
        ]
    )
    return editor, resumen, bool(fuera or pesos_no_validos)


def ruta_resumen_para_csv(path: Path) -> Path:
    return path.with_name(f"{path.stem}_resumen.txt")


def formato_importable_ax(codigos) -> str:
    return ",".join(str(codigo).strip() for codigo in codigos if str(codigo).strip())


def save_precintos_txt(path: Path, result: PrecintosJamonesResult) -> Path:
    if result.invalidos:
        raise ValueError("Corrige las incidencias antes de guardar.")
    text = "\r\n".join(registro.a_linea().lstrip("\ufeff") for registro in result.validos)
    write_text_atomically(path, text + ("\r\n" if text else ""), encoding="utf-8")
    return path


def resumen_text(result: PrecintosJamonesResult) -> str:
    return result.preview_text() + "\r\n"


def save_precintos_csv(path: Path, result: PrecintosJamonesResult) -> Path | None:
    if result.invalidos:
        raise ValueError("Corrige las incidencias antes de guardar.")
    if result.es_lote_mixto():
        raise ValueError("El CSV requiere un único tipo de jamón. Separa o corrige los registros mixtos antes de continuar.")
    if result.tipo_jamon.lower() == "iberico":
        output = io.StringIO(newline="")
        writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
        for registro in result.validos:
            checkpoint()
            writer.writerow([registro.precinto])
        write_text_atomically(path, output.getvalue(), encoding="utf-8-sig")
        summary = ruta_resumen_para_csv(path)
        write_text_atomically(summary, resumen_text(result), encoding="utf-8")
        return summary
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\r\n")
    for registro in result.validos:
        checkpoint()
        campos = list(registro.campos[:CAMPOS_ESPERADOS])
        while len(campos) < CAMPOS_ESPERADOS:
            campos.append("")
        writer.writerow(campos + [""])
    write_text_atomically(path, output.getvalue(), encoding="utf-8-sig")
    return None


def send_precintos_email(
    destinatario: str,
    result: PrecintosJamonesResult,
    attachments: list[Path],
    *,
    subject: str = ASUNTO_CORREO_DEFECTO,
    body: str = MENSAJE_CORREO_DEFECTO,
    smtp_host: str = SMTP_HOST,
    smtp_port: int = SMTP_PORT,
    smtp_user: str = SMTP_USER,
    smtp_password: str = SMTP_PASSWORD,
    smtp_starttls: bool = SMTP_SECURE,
) -> EmailMessage:
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", destinatario or ""):
        raise ValueError("Introduce una direccion de correo valida.")
    message = EmailMessage()
    message["From"] = smtp_user
    message["To"] = destinatario
    message["Subject"] = subject.format(tipo_jamon=result.tipo_jamon, registros_validos=len(result.validos))
    message.set_content(
        body.format(
            tipo_jamon=result.tipo_jamon,
            registros_validos=len(result.validos),
            incidencias=len(result.invalidos),
            duplicados=len(result.duplicados),
        )
    )
    for path in attachments:
        checkpoint()
        subtype = "csv" if path.suffix.lower() == ".csv" else "plain"
        message.add_attachment(path.read_bytes(), maintype="text", subtype=subtype, filename=path.name)
    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as smtp:
            smtp.ehlo()
            if smtp_starttls:
                smtp.starttls()
                smtp.ehlo()
            if smtp_user and smtp_password:
                smtp.login(smtp_user, smtp_password)
            begin_commit()
            smtp.send_message(message)
    except smtplib.SMTPException as exc:
        raise RuntimeError("No se pudo enviar el correo con el servidor corporativo. Revisa la conexion o las credenciales SMTP.") from exc
    except OSError as exc:
        raise RuntimeError("No se pudo conectar con el servidor de correo corporativo. Revisa la red o la configuracion SMTP.") from exc
    return message
